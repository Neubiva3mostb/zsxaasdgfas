#version 150

// Фрагментный шейдер Particles: сэмплирует ячейку атласа и тонирует её.
//
// Атлас (textures/particles/atlas.png) белый/серый — весь цвет и альфа
// приходят вершиной (FragColor), поэтому частицы всегда в цвет темы и
// плавно гаснут через альфу.
//
// Без discard: у текстур мягкие альфа-края, и обрезание сделало бы их
// рваными. Прозрачность доводится обычным альфа-блендингом слоя.

uniform sampler2D Sampler0;

in vec2 TexCoord;
in vec4 FragColor;

out vec4 OutColor;

void main() {
    vec4 texel = texture(Sampler0, TexCoord);
    OutColor = vec4(texel.rgb * FragColor.rgb, texel.a * FragColor.a);
}
