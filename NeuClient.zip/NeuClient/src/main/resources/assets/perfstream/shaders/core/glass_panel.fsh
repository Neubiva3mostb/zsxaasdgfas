#version 150

// «Стекло» для колонок ClickGUI: редкие светящиеся линии, которые постоянно
// плывут и поворачиваются, плюс ободок акцентом.
//
// Как устроено движение. Вместо одной синусоиды с фиксированным углом здесь
// три волны, у каждой:
//   • своя базовая частота (3.2 / 2.1 / 1.4 цикла на панель — вместе это
//     примерно 10 видимых линий, как и просили: редкие, а не «рябь»);
//   • свой угол, который НЕ постоянен, а медленно покачивается синусоидой
//     (waveAngle) — поэтому линии всё время доворачиваются и складываются
//     то в одну сторону, то в другую, а не просто едут по прямой;
//   • своя скорость хода линии вдоль её направления (SPEED_*), причём знаки
//     разные, так что часть линий идёт в одну сторону, часть — в другую.
//
// Скорости (0.073 / 0.119 / 0.047 Гц) и частоты покачивания (0.053 / 0.031 /
// 0.089 Гц) подобраны несоизмеримыми, поэтому рисунок не повторяется на
// глаз и выглядит случайным. Суммарный период получается порядка нескольких
// минут, тогда как время зациклено на TIME_WRAP = 128 с из ClickGuiScreen;
// в точке зацикливания линии стоят почти на месте, поэтому щелчка не видно.
//
// Координаты волны считаются в единицах панели (TexCoord * size), но панели
// всех колонок одинакового размера и выровнены по одной верхушке, поэтому
// линии продолжаются из колонки в колонку и зрительно ходят между ними.
//
// ВАЖНО: слой не преломляет картинку под собой. В 1.21.11 у DrawContext нет
// публичного draw()/flush(), поэтому снять кадр экрана между фоном и панелями
// нечем, а сэмплировать основной фреймбуфер во время записи в него —
// неопределённое поведение. Фон и так размыт штатным ctx.applyBlur(), поэтому
// панель делает его полупрозрачной, а стекло изображают линии и блики.

in vec2 TexCoord;
in vec3 AccentColor;
in float FragAlpha;
in float Time;

out vec4 OutColor;

const float TAU = 6.2831853;

// Частота покачивания направления каждой волны (Гц).
const float SPIN_A = 0.053;
const float SPIN_B = 0.031;
const float SPIN_C = 0.089;

// Скорость хода линии вдоль её направления (циклов в секунду). Знак задаёт
// сторону: A и C идут в одну, B — в противоположную.
const float SPEED_A =  0.073;
const float SPEED_B = -0.119;
const float SPEED_C =  0.047;

float waveAngle(float t, float spin, float seed) {
    return 0.70 * sin(TAU * spin * t + seed);
}

// Одна бегущая линия: 0 — впадина, 1 — гребень.
float waveLine(vec2 p, float t, float freq, float spin, float seed, float speed) {
    float a = waveAngle(t, spin, seed);
    float along = p.x * cos(a) + p.y * sin(a);
    float v = sin(TAU * (along * freq - speed * t + seed * 0.11));
    return 0.5 + 0.5 * v;
}

void main() {
    if (FragAlpha <= 0.004) {
        discard;
    }

    // ===== Размер панели и скруглённые углы (SDF), как в rounded_rect.fsh =====
    vec2 size = vec2(1.0 / max(abs(dFdx(TexCoord.x)), 0.000001),
                     1.0 / max(abs(dFdy(TexCoord.y)), 0.000001));
    vec2 halfSize = size * 0.5;
    float radius = min(min(halfSize.x, halfSize.y), 8.0);

    vec2 q = abs(TexCoord * size - halfSize) - (halfSize - radius);
    float sdf = length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - radius;
    float aa = max(fwidth(sdf), 0.75);
    float coverage = 1.0 - smoothstep(-aa, aa, sdf);
    if (coverage <= 0.001) {
        discard;
    }

    // Точка в единицах панели: у колонок одинаковый размер и одна верхушка,
    // поэтому у всех них линии ложатся в один непрерывный рисунок.
    vec2 p = TexCoord * size;
    float t = Time;

    float w1 = waveLine(p, t, 3.2, SPIN_A, 0.0, SPEED_A);
    float w2 = waveLine(p, t, 2.1, SPIN_B, 2.1, SPEED_B);
    float w3 = waveLine(p, t, 1.4, SPIN_C, 4.4, SPEED_C);

    // Возводим в высокую степень: остаются только узкие гребни, то есть
    // отдельные линии, а не размазанная рябь.
    float lines = pow(w1, 8.0) * 0.50
                + pow(w2, 8.0) * 0.32
                + pow(w3, 8.0) * 0.22;

    // Тонкий светлый блик у верхнего края панели.
    float edge = (1.0 - smoothstep(0.0, 10.0, p.y)) * 0.14;

    // Ободок акцентом в ~1 единицу GUI-масштаба от края. Рисуется здесь, а не
    // вторым quad'ом: залитый прямоугольник накрыл бы стекло целиком.
    float rim = (1.0 - smoothstep(0.0, 1.25, -sdf)) * 0.26;

    float shimmer = clamp(lines * 0.46, 0.0, 0.46);
    float white = clamp(edge + lines * 0.045, 0.0, 0.22);
    float amount = clamp(white + shimmer + rim, 0.0, 0.85);

    // База белая (стекло светлее фона), линии и ободок — акцентом.
    vec3 col = mix(vec3(1.0), AccentColor, clamp(shimmer + rim, 0.0, 1.0));
    OutColor = vec4(col * amount, amount * FragAlpha * coverage);
}
