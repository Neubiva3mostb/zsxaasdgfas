#version 150

// Вершинный шейдер Particles: текстурированные билборды.
//
// Вершина несёт позицию, UV и цвет-тинт. UV указывает на ячейку атласа
// (см. textures/particles/atlas.png), цвет — акцент темы и альфу затухания.

layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};
layout(std140) uniform Projection {
    mat4 ProjMat;
};

in vec3 Position;
in vec2 UV0;
in vec4 Color;

out vec2 TexCoord;
out vec4 FragColor;

void main() {
    TexCoord = UV0;
    FragColor = Color;
    gl_Position = ProjMat * ModelViewMat * vec4(Position + ModelOffset, 1.0);
}
