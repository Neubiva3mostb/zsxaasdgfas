#version 150

// Размытая «стеклянная» рука: кадр руки из отдельного фреймбуфера
// сэмплится диском из двух колец (13 точек) с весом по альфе —
// так края не темнеют и не появляется ореол.
// Param = радиус размытия в пикселях; Param < 0.05 — резкая копия.

uniform sampler2D Sampler0;

in vec2 TexCoord;
in vec4 FragColor;
in float Param;

out vec4 OutColor;

void main() {
    vec4 src = texture(Sampler0, TexCoord);

    if (Param < 0.05) {
        // Резкая копия руки (используется в режиме «Обводка»)
        OutColor = src * FragColor;
        return;
    }

    vec2 ts = 1.0 / vec2(textureSize(Sampler0, 0));

    // Накопление с весом альфы (анти-ореол)
    vec3 rgbSum = src.rgb * src.a;
    float wSum = src.a;

    for (int ring = 1; ring <= 2; ring++) {
        float rr = Param * float(ring) * 0.5;
        float w = ring == 1 ? 0.8 : 0.45;
        for (int i = 0; i < 6; i++) {
            float ang = 6.2831853 * float(i) / 6.0 + float(ring) * 0.45;
            vec2 off = vec2(cos(ang), sin(ang)) * ts * rr;
            vec4 s = texture(Sampler0, TexCoord + off);
            rgbSum += s.rgb * s.a * w;
            wSum += s.a * w;
        }
    }

    vec3 rgb = wSum > 0.0001 ? rgbSum / wSum : vec3(0.0);
    // Центральный сэмпл гарантирует силуэт руки даже на тонких краях
    float alpha = max(clamp(wSum / 6.9, 0.0, 1.0), src.a);

    OutColor = vec4(rgb * FragColor.rgb, alpha * FragColor.a);
}
