#version 150

in vec2 TexCoord;
in vec4 FragColor;

uniform sampler2D Sampler0;

out vec4 fragColor;

float median(vec3 c) {
    return max(min(c.r, c.g), min(max(c.r, c.g), c.b));
}

void main() {
    vec4 sampleVal = texture(Sampler0, TexCoord);
    float sd = median(sampleVal.rgb);

    // Screen pixel range: Viktor Chlumsky's standard MSDF AA formula
    vec2 unitRange = vec2(12.0) / vec2(textureSize(Sampler0, 0));
    vec2 screenTexSize = vec2(1.0) / max(fwidth(TexCoord), vec2(0.00001));
    float screenPxRange = max(0.5 * dot(unitRange, screenTexSize), 1.0);

    float screenPxDistance = screenPxRange * (sd - 0.5);
    float alpha = clamp(screenPxDistance + 0.5, 0.0, 1.0);

    if (alpha < 0.001) discard;

    fragColor = vec4(FragColor.rgb, FragColor.a * alpha);
}
