#version 150

// Вершины фуллскрин-квада в нормализованных координатах устройства.
// Матрицы не нужны: Position.xy уже NDC (-1..1), поэтому эффект рисуется
// поверх кадра независимо от текущей проекции (руки/мир/GUI).
// Position.z — параметр эффекта: радиус в пикселях; в режиме «Стекло»
// к нему добавлена дробная фаза волн 0..1 (целая часть = радиус).

in vec3 Position;
in vec2 UV0;
in vec4 Color;

out vec2 TexCoord;
out vec4 FragColor;
out float Param;

void main() {
    TexCoord = UV0;
    FragColor = Color;
    Param = Position.z;
    gl_Position = vec4(Position.xy, 0.0, 1.0);
}
