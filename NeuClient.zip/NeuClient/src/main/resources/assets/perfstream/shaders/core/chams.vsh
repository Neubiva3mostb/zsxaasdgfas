#version 150

// Вершинный шейдер Chams (стеклянные силуэты сквозь стены).
//
// Шейдер намеренно «глухой»: он не читает ни текстуру, ни свет, ни оверлей.
// Из вершины берётся только цвет — в него ванильная отрисовка модели кладёт
// tint сущности, и именно его мы используем как цвет подсветки.
//
// Кроме цвета наружу отдаётся позиция в пространстве камеры: по ней
// фрагментный шейдер восстанавливает нормаль грани и считает френелеву
// кромку. Нормалей в формате POSITION_TEXTURE_COLOR нет, поэтому иначе
// стекло не получить.
//
// Альфа вершины игнорируется: прозрачность зашита во фрагментный шейдер.
// Передать её uniform'ом нельзя — OrderedRenderCommandQueue сортирует команды
// по слоям и выполняет их позже, так что static-поле к моменту отрисовки
// уже устарело бы (см. ChamsRenderLayer: по слою на шаг прозрачности).

layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};
layout(std140) uniform Projection {
    mat4 ProjMat;
};

in vec3 Position;
in vec2 UV0;
in vec4 Color;

out vec4 FragColor;
out vec3 ViewPos;

void main() {
    FragColor = Color;
    vec4 view = ModelViewMat * vec4(Position + ModelOffset, 1.0);
    ViewPos = view.xyz;
    gl_Position = ProjMat * view;
}
