#version 150

uniform sampler2D Sampler0;

in vec2 TexCoord;
in vec4 FragColor;

out vec4 OutColor;

void main() {
    vec4 texel = texture(Sampler0, TexCoord);
    if (texel.a <= 0.01) discard;
    OutColor = texel * FragColor;
}
