#version 150

// Вершинный шейдер «стеклянной» панели ClickGUI.
//
// Раскладка данных (формат POSITION_TEXTURE_COLOR = Position + UV0 + Color):
//   Position.z — ВРЕМЯ в секундах (непрерывное, зацикленное на большом
//                периоде). В GUI этот канал свободен: ванильный
//                vertex(Matrix3x2f, x, y) пишет туда 0, а орто-проекция GUI
//                сдвинута на translate(0, 0, 512), так что z в пределах 0..128
//                не влияет ни на клиппинг, ни на глубину.
//   UV0        — нормированные координаты внутри quad (0..1); по ним
//                фрагментный шейдер через fwidth восстанавливает размер.
//   Color.rgb  — цвет акцента (им красятся линии волн и ободок).
//   Color.a    — непрозрачность слоя, обычная, без упаковки: BufferBuilder
//                урезает каждый канал цвета до байта (i2b).
//
// Время лежит в вершине, а не в static-поле, потому что GUI-элементы
// складываются в GuiRenderState и рисуются позже: static-значение могло бы
// оказаться устаревшим на момент отрисовки.

layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};
layout(std140) uniform Projection {
    mat4 ProjMat;
};

in vec3 Position;
in vec2 UV0;
in vec4 Color;

out vec2 TexCoord;
out vec3 AccentColor;
out float FragAlpha;
out float Time;

void main() {
    TexCoord = UV0;
    AccentColor = Color.rgb;
    FragAlpha = Color.a;
    Time = Position.z;
    gl_Position = ProjMat * ModelViewMat * vec4(Position + ModelOffset, 1.0);
}
