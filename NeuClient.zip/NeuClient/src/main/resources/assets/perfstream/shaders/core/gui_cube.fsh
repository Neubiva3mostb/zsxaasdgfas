#version 150

in vec4 FragColor;
out vec4 OutColor;

void main() {
    OutColor = FragColor;
}
