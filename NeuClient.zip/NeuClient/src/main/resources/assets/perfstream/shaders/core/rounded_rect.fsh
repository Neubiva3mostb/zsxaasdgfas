#version 150

in vec2 TexCoord;
in vec4 FragColor;

out vec4 OutColor;

void main() {
    // При ортографическом GUI-проецировании производная UV даёт размер
    // quad в экранных пикселях.
    float pxW = 1.0 / max(abs(dFdx(TexCoord.x)), 0.000001);
    float pxH = 1.0 / max(abs(dFdy(TexCoord.y)), 0.000001);
    vec2 size = vec2(pxW, pxH);
    vec2 point = TexCoord * size;
    vec2 halfSize = size * 0.5;
    // Радиус автоматически масштабируется под элемент: панели получают
    // мягкие углы, а маленькие ручки и тумблеры становятся круглыми.
    float radius = min(min(halfSize.x, halfSize.y), 8.0);

    vec2 q = abs(point - halfSize) - (halfSize - radius);
    float sdfDistance = length(max(q, vec2(0.0)))
                      + min(max(q.x, q.y), 0.0)
                      - radius;

    // SDF edge smoothing в масштабе одного экранного пикселя.
    float aa = max(fwidth(sdfDistance), 0.75);
    float coverage = 1.0 - smoothstep(-aa, aa, sdfDistance);
    if (coverage <= 0.001) {
        discard;
    }

    OutColor = vec4(FragColor.rgb, FragColor.a * coverage);
}
