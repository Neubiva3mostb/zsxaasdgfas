#version 150

// Обводка руки: 16 сэмплов по кольцу радиусом Param пикселей;
// контур рисуется только там, где кольцо задело руку, а центр — нет.
// Цвет и интенсивность приходят в FragColor из вершинного цвета.

uniform sampler2D Sampler0;

in vec2 TexCoord;
in vec4 FragColor;
in float Param;

out vec4 OutColor;

void main() {
    float center = texture(Sampler0, TexCoord).a;
    vec2 ts = 1.0 / vec2(textureSize(Sampler0, 0));

    float ring = 0.0;
    for (int i = 0; i < 16; i++) {
        float ang = 6.2831853 * float(i) / 16.0;
        vec2 off = vec2(cos(ang), sin(ang)) * ts * Param;
        ring = max(ring, texture(Sampler0, TexCoord + off).a);
    }

    float outline = clamp(ring - center, 0.0, 1.0);
    if (outline < 0.004) {
        discard;
    }

    OutColor = vec4(FragColor.rgb, outline * FragColor.a);
}
