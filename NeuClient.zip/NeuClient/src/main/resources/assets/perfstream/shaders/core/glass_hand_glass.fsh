#version 150

// «Стекло»: размытая рука, по которой плывут волны.
// Две бегущие синусоиды искажают сэмплы (рука «плывёт» как сквозь толщу
// стекла), а гребни волн подсвечиваются цветом акцента.
//
// Param упакован: целая часть — радиус размытия, дробная — фаза волн 0..1.
// Фаза зациклена через sin(2π·phase), поэтому на переходе 1→0 шов невидим.

uniform sampler2D Sampler0;

in vec2 TexCoord;
in vec4 FragColor; // rgb = цвет акцента, a = интенсивность
in float Param;

out vec4 OutColor;

void main() {
    float radius = floor(Param);
    float phase = fract(Param);
    float t = phase * 6.2831853;

    vec2 ts = 1.0 / vec2(textureSize(Sampler0, 0));

    // Бегущие волны: крупная вертикальная + диагональная встречная
    float w1 = sin(TexCoord.y * 34.0 + t);
    float w2 = sin((TexCoord.x + TexCoord.y) * 22.0 - t);
    vec2 waveOff = vec2(w2 * 0.6, w1) * ts * radius * 0.30;

    vec4 src = texture(Sampler0, TexCoord + waveOff);

    // Мягкое размытие диском из двух колец,
    // но сэмплы берутся с волновым сдвигом — волны «плещутся» по руке
    vec3 rgbSum = src.rgb * src.a;
    float wSum = src.a;

    for (int ring = 1; ring <= 2; ring++) {
        float rr = radius * float(ring) * 0.5;
        float w = ring == 1 ? 0.8 : 0.45;
        for (int i = 0; i < 6; i++) {
            float ang = 6.2831853 * float(i) / 6.0 + float(ring) * 0.45;
            vec2 off = vec2(cos(ang), sin(ang)) * ts * rr + waveOff;
            vec4 s = texture(Sampler0, TexCoord + off);
            rgbSum += s.rgb * s.a * w;
            wSum += s.a * w;
        }
    }

    vec3 rgb = wSum > 0.0001 ? rgbSum / wSum : vec3(0.0);
    // Центральный сэмпл гарантирует силуэт руки даже на тонких краях
    float alpha = max(clamp(wSum / 6.9, 0.0, 1.0), src.a);

    // Гребни волн: острые пики синусоид подсвечиваем акцентом
    float crest1 = pow(max(0.0, sin(TexCoord.y * 34.0 + t)), 3.0);
    float crest2 = pow(max(0.0, sin((TexCoord.x + TexCoord.y) * 22.0 - t)), 3.0);
    float shimmer = clamp((crest1 * 0.35 + crest2 * 0.25) * alpha, 0.0, 0.6);

    vec3 col = mix(rgb, FragColor.rgb, shimmer);

    OutColor = vec4(col, alpha * FragColor.a);
}
