package ru.neuclient.client.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.LogoDrawer;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.SplashTextRenderer;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.font.MsdfFontRenderer;
import ru.neuclient.client.font.MsdfFonts;
import ru.neuclient.client.ui.AltManagerScreen;
import ru.neuclient.client.ui.NeonButton;
import ru.neuclient.client.util.RenderUtil;
import ru.neuclient.client.util.SkinUtil;

import java.util.Random;

/**
 * Кастомное главное меню NeuClient:
 *  - плавный интерактивный параллакс-фон;
 *  - живые всплывающие частицы (акцент + белый), реагируют на параллакс;
 *  - мягкое «дышащее» свечение за заголовком;
 *  - кнопка «Продолжить» — мгновенный вход на последний сервер;
 *  - нижняя инфо-панель: аватар + ник слева, версия клиента/игры справа;
 *  - плавное проявление меню при открытии;
 *  - скрытие ванильного логотипа и жёлтого сплэша;
 *  - стильные кнопки NeonButton: Одиночная игра, Сетевая игра, Alt Manager,
 *    Настройки (⚙), Выход (×).
 * При панике (.panic) меню остаётся абсолютно чистым и ванильным.
 */
@Mixin(TitleScreen.class)
public abstract class TitleScreenMixin extends Screen {

	@Shadow
	@Nullable
	private SplashTextRenderer splashText;

	@Unique
	private static final Identifier PC$BG_TEXTURE = Identifier.of("perfstream", "textures/gui/title_bg.png");

	@Unique
	private static final float PC$PARALLAX_MAX = 18.0f;

	@Unique
	private static float pc$currentOffsetX = 0f;
	@Unique
	private static float pc$currentOffsetY = 0f;
	@Unique
	private static long pc$lastFrameTime = 0L;

	// ===== Частицы фона =====
	@Unique
	private static final int PC$PARTICLES = 64;
	@Unique
	private static final float[] pc$pX = new float[PC$PARTICLES];
	@Unique
	private static final float[] pc$pY = new float[PC$PARTICLES];
	@Unique
	private static final float[] pc$pSpeed = new float[PC$PARTICLES];
	@Unique
	private static final float[] pc$pSize = new float[PC$PARTICLES];
	@Unique
	private static final float[] pc$pAlpha = new float[PC$PARTICLES];
	@Unique
	private static final float[] pc$pPhase = new float[PC$PARTICLES];
	@Unique
	private static final float[] pc$pLayer = new float[PC$PARTICLES];
	@Unique
	private static boolean pc$particlesReady = false;
	@Unique
	private static long pc$lastParticleMs = 0L;

	// ===== Настоящий скин игрока (для плашек в меню) =====
	/** Текстура скина из сессии; null, пока не загрузилась — тогда Стив. */
	@Unique
	private static Identifier pc$sessionSkin = null;
	@Unique
	private static boolean pc$skinRequested = false;

	protected TitleScreenMixin() {
		super(Text.empty());
	}

	/** Плавное появление кнопок: прогресс 0..1 и отметка времени. */
	@Unique
	private float pc$intro = 0f;
	@Unique
	private long pc$introStart = 0L;

	@Unique
	private NeonButton pc$addIntroButton(int x, int y, int w, int h, Text label,
			NeonButton.PressAction action, int index) {
		NeonButton button = new NeonButton(x, y, w, h, label, action);
		button.pc$setIntro(this.pc$introStart + index * 55L);
		this.addDrawableChild(button);
		return button;
	}

	/** Отступ верхнего ряда кнопок. */
	@Unique
	private int pc$startY() {
		return this.height / 2 - 20;
	}

	@Inject(method = "init", at = @At("TAIL"))
	private void pc$initTitleScreen(CallbackInfo ci) {
		if (NeuClient.getInstance() != null && NeuClient.getInstance().isPanicked()) {
			return; // Ванильная инициализация меню без изменений
		}

		this.splashText = null;
		this.clearChildren();
		this.pc$intro = 0f;
		this.pc$introStart = System.currentTimeMillis();

		// Подтягиваем настоящий скин игрока (один раз за запуск игры)
		pc$requestSessionSkin(MinecraftClient.getInstance());

		int cx = this.width / 2;
		int btnW = 180;
		int btnH = 22;
		int gap = 6;
		int startY = pc$startY();
		int row = 0;

		// 1. Одиночная игра
		pc$addIntroButton(cx - btnW / 2, startY + (btnH + gap) * row, btnW, btnH,
				Text.literal("Одиночная игра"),
				button -> MinecraftClient.getInstance()
						.setScreen(new net.minecraft.client.gui.screen.world.SelectWorldScreen(this)), row++);

		// 2. Сетевая игра
		pc$addIntroButton(cx - btnW / 2, startY + (btnH + gap) * row, btnW, btnH,
				Text.literal("Сетевая игра"),
				button -> MinecraftClient.getInstance()
						.setScreen(new net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen(this)), row++);

		// 3. Alt Manager
		pc$addIntroButton(cx - btnW / 2, startY + (btnH + gap) * row, btnW, btnH,
				Text.literal("Alt Manager"),
				button -> MinecraftClient.getInstance()
						.setScreen(new AltManagerScreen((Screen) (Object) this)), row++);

		// 4. Последний ряд: слева Настройки, справа Выход
		int smallW = (btnW - gap) / 2;
		int row4Y = startY + (btnH + gap) * row;

		pc$addIntroButton(cx - btnW / 2, row4Y, smallW, btnH,
				Text.literal("⚙  Настройки"),
				button -> MinecraftClient.getInstance()
						.setScreen(new net.minecraft.client.gui.screen.option.OptionsScreen(this, this.client.options)), row++);

		pc$addIntroButton(cx - btnW / 2 + smallW + gap, row4Y, smallW, btnH,
				Text.literal("×  Выход"),
				button -> MinecraftClient.getInstance().scheduleStop(), row++);
	}

	/** Текстура скина для плашек: настоящий, если успел загрузиться, иначе Стив. */
	@Unique
	private static Identifier pc$skinTexture() {
		return pc$sessionSkin != null ? pc$sessionSkin : SkinUtil.defaultSkin();
	}

	/** Один раз за запуск просим у SkinProvider настоящий скин из сессии. */
	@Unique
	private static void pc$requestSessionSkin(MinecraftClient mc) {
		if (pc$skinRequested || mc == null) {
			return;
		}
		try {
			if (mc.getSession() == null || mc.getGameProfile() == null || mc.getSkinProvider() == null) {
				return;
			}
			pc$skinRequested = true;
			mc.getSkinProvider().fetchSkinTextures(mc.getGameProfile()).thenAccept(optional -> {
				try {
					if (optional != null) {
						optional.ifPresent(textures -> {
							try {
								if (textures.body() != null) {
									Identifier id = textures.body().texturePath();
									if (id != null) {
										mc.execute(() -> pc$sessionSkin = id);
									}
								}
							} catch (Throwable ignored) {
							}
						});
					}
				} catch (Throwable ignored) {
				}
			});
		} catch (Throwable ignored) {
		}
	}

	@Redirect(
			method = "render",
			at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/LogoDrawer;draw(Lnet/minecraft/client/gui/DrawContext;IF)V")
	)
	private void pc$hideMinecraftLogo(LogoDrawer instance, DrawContext context, int screenWidth, float alpha) {
		if (NeuClient.getInstance() != null && NeuClient.getInstance().isPanicked()) {
			instance.draw(context, screenWidth, alpha);
			return;
		}

		int startY = pc$startY();
		int cx = this.width / 2;
		int ty = startY - 46;

		// Вместо текстового тайтла — плашка с головой скина игрока и ником
		// (стиль нижних плашек, но крупнее) + мягкое «дышащее» свечение.
		MinecraftClient mc = MinecraftClient.getInstance();
		String nick = "Player";
		if (mc != null && mc.getSession() != null && mc.getSession().getUsername() != null) {
			// В интерфейсе клиента — ник аккаунта сайта (fallback — ник сессии).
			nick = ru.neuclient.client.util.SiteUser.displayName(mc.getSession().getUsername());
		}

		float nameSize = 11.0f;
		float nameH = MsdfFontRenderer.getHeight(MsdfFonts.sfMedium(), nameSize);
		float nameW = MsdfFontRenderer.getWidth(MsdfFonts.sfMedium(), nick, nameSize);
		int head = 32;
		int padX = 12;
		int panelH = 46;
		int panelW = (int) (padX * 2 + head + 12 + nameW);

		int px = cx - panelW / 2;
		int py = ty - 8;

		double pulse = 0.5 + 0.5 * Math.sin(System.currentTimeMillis() / 1500.0);
		int rgb = RenderUtil.accent() & 0x00FFFFFF;
		int a1 = (int) (0x07 + 0x07 * pulse);
		int a2 = (int) (0x0E + 0x0F * pulse);
		RenderUtil.roundRect(context, px - 18, py - 10, panelW + 36, panelH + 20, 24, rgb | (a1 << 24));
		RenderUtil.roundRect(context, px - 8, py - 4, panelW + 16, panelH + 8, 16, rgb | (a2 << 24));

		RenderUtil.roundRect(context, px, py, panelW, panelH, 10, 0x8A07070D);
		SkinUtil.drawSkinHead(context, pc$skinTexture(), px + padX, py + (panelH - head) / 2.0f, head);
		MsdfFontRenderer.drawWithShadow(context, MsdfFonts.sfMedium(), nick,
				px + padX + head + 12, py + (panelH - nameH) / 2.0f, 0xF2FFFFFF, nameSize);
	}

	@Redirect(
			method = "render",
			at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screen/SplashTextRenderer;render(Lnet/minecraft/client/gui/DrawContext;ILnet/minecraft/client/font/TextRenderer;F)V")
	)
	private void pc$hideSplashText(SplashTextRenderer instance, DrawContext context, int screenWidth, TextRenderer textRenderer, float alpha) {
		if (NeuClient.getInstance() != null && NeuClient.getInstance().isPanicked()) {
			if (instance != null) {
				instance.render(context, screenWidth, textRenderer, alpha);
			}
			return;
		}
		// Скрываем жёлтую надпись сплэша
	}

	@Redirect(
			method = "render",
			at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;drawTextWithShadow(Lnet/minecraft/client/font/TextRenderer;Ljava/lang/String;III)V")
	)
	private void pc$hideVersionText(DrawContext context, TextRenderer textRenderer, String text, int x, int y, int color) {
		if (NeuClient.getInstance() != null && NeuClient.getInstance().isPanicked()) {
			context.drawTextWithShadow(textRenderer, text, x, y, color);
		}
		// Скрываем «Minecraft 1.21.11/Fabric (модифицированно)» слева снизу
	}

	@Override
	public void renderPanoramaBackground(DrawContext context, float delta) {
		if (NeuClient.getInstance() != null && NeuClient.getInstance().isPanicked()) {
			super.renderPanoramaBackground(context, delta);
			return;
		}

		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc == null) return;

		double windowW = mc.getWindow().getWidth();
		double windowH = mc.getWindow().getHeight();
		double mouseX = windowW > 0 ? (mc.mouse.getX() * (double) this.width / windowW) : this.width / 2.0;
		double mouseY = windowH > 0 ? (mc.mouse.getY() * (double) this.height / windowH) : this.height / 2.0;

		float normX = (float) ((mouseX - this.width / 2.0) / (this.width / 2.0));
		float normY = (float) ((mouseY - this.height / 2.0) / (this.height / 2.0));
		normX = Math.max(-1.0f, Math.min(1.0f, normX));
		normY = Math.max(-1.0f, Math.min(1.0f, normY));

		float targetX = -normX * PC$PARALLAX_MAX;
		float targetY = -normY * PC$PARALLAX_MAX;

		long now = System.currentTimeMillis();
		float dt = (pc$lastFrameTime == 0L) ? 0.016f : Math.min((now - pc$lastFrameTime) / 1000.0f, 0.05f);
		pc$lastFrameTime = now;

		float factor = 1.0f - (float) Math.exp(-dt * 4.5f);
		pc$currentOffsetX += (targetX - pc$currentOffsetX) * factor;
		pc$currentOffsetY += (targetY - pc$currentOffsetY) * factor;

		int pad = (int) Math.ceil(PC$PARALLAX_MAX + 10.0f);
		int bgW = this.width + pad * 2;
		int bgH = this.height + pad * 2;

		var m = context.getMatrices();
		m.pushMatrix();
		m.translate(pc$currentOffsetX, pc$currentOffsetY);

		context.drawTexture(
				RenderPipelines.GUI_TEXTURED,
				PC$BG_TEXTURE,
				-pad, -pad,
				0.0f, 0.0f,
				bgW, bgH,
				1376, 768,
				1376, 768
		);

		m.popMatrix();

		// === Лаунчерный оверлей: глубокий фиолетовый тон + затемнение слева ===
		context.fill(0, 0, this.width, this.height, 0x30060912);

		// Мягкое затемнение от левого края (квадратичный спад, без ступенек):
		// задаёт «рабочую зону» меню как в лаунчерах.
		int strips = 24;
		int gw = this.width * 55 / 100;
		for (int i = 0; i < strips; i++) {
			float p = (i + 0.5f) / strips;
			float fall = (1.0f - p);
			int a = (int) (0x56 * fall * fall);
			if (a <= 0) continue;
			context.fill(gw * i / strips, 0, gw * (i + 1) / strips, this.height, 0x08040F | (a << 24));
		}

		// === Виньетка: затемнение сверху и снизу для глубины ===
		context.fillGradient(0, 0, this.width, this.height / 3, 0x44000000, 0x00000000);
		context.fillGradient(0, this.height * 2 / 3, this.width, this.height, 0x00000000, 0x66000000);

		// === «Дышащий» акцентный свет снизу (в цвет темы) ===
		double pulse = 0.5 + 0.5 * Math.sin(System.currentTimeMillis() / 1600.0);
		int acc = RenderUtil.accent() & 0x00FFFFFF;
		int a = (int) (0x0A + 0x12 * pulse);
		context.fillGradient(0, this.height / 2, this.width, this.height, 0x00000000, acc | (a << 24));

		// === Живые частицы: медленно всплывают, мерцают, живут в параллаксе ===
		pc$renderParticles(context, now);
	}

	/** Инициализация частиц случайными параметрами. */
	@Unique
	private static void pc$ensureParticles() {
		if (pc$particlesReady) {
			return;
		}
		Random rnd = new Random();
		for (int i = 0; i < PC$PARTICLES; i++) {
			pc$pX[i] = rnd.nextFloat();
			pc$pY[i] = rnd.nextFloat();
			pc$pSpeed[i] = 0.010f + rnd.nextFloat() * 0.022f;   // доля высоты в секунду
			pc$pSize[i] = rnd.nextFloat() < 0.8f ? 1.0f : 2.0f; // 1–2 px
			pc$pAlpha[i] = 0.14f + rnd.nextFloat() * 0.34f;
			pc$pPhase[i] = rnd.nextFloat() * (float) (Math.PI * 2.0);
			pc$pLayer[i] = 0.35f + rnd.nextFloat() * 0.65f;     // глубина для параллакса
		}
		pc$particlesReady = true;
	}

	/** Обновление и отрисовка частиц поверх фона. */
	@Unique
	private void pc$renderParticles(DrawContext context, long now) {
		pc$ensureParticles();
		float dt = (pc$lastParticleMs == 0L)
				? 0.016f
				: Math.min((now - pc$lastParticleMs) / 1000.0f, 0.05f);
		pc$lastParticleMs = now;

		int acc = RenderUtil.accent() & 0x00FFFFFF;
		for (int i = 0; i < PC$PARTICLES; i++) {
			// Всплывание + лёгкое покачивание по горизонтали
			pc$pY[i] -= pc$pSpeed[i] * dt;
			if (pc$pY[i] < -0.04f) {
				pc$pY[i] = 1.04f;
				pc$pX[i] = new Random().nextFloat();
			}
			float wob = (float) Math.sin(now * 0.0004 + pc$pPhase[i]) * 0.012f;
			float fx = pc$pX[i] + wob;
			float px = fx * this.width - pc$currentOffsetX * pc$pLayer[i] * 0.6f;
			float py = pc$pY[i] * this.height - pc$currentOffsetY * pc$pLayer[i] * 0.6f;

			// Мерцание
			float twinkle = 0.62f + 0.38f * (float) Math.sin(now * 0.002 + pc$pPhase[i] * 1.7f);
			int alpha = (int) (pc$pAlpha[i] * twinkle * 255.0f);
			if (alpha <= 2) {
				continue;
			}
			int color = (i % 5 == 0) ? (acc | (alpha << 24)) : (0xFFFFFF | (alpha << 24));
			int s = (int) pc$pSize[i];
			context.fill((int) px, (int) py, (int) px + s, (int) py + s, color);
		}
	}

	/**
	 * Хвост рендера: нижняя инфо-панель (аватар + ник / версия) и
	 * плавное проявление меню при открытии.
	 */
	@Inject(method = "render", at = @At("TAIL"))
	private void pc$renderExtras(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
		if (NeuClient.getInstance() != null && NeuClient.getInstance().isPanicked()) {
			return;
		}

		// === Плавное проявление меню при открытии (~0.8 c) ===
		if (pc$introStart > 0L) {
			long elapsed = System.currentTimeMillis() - pc$introStart;
			if (elapsed < 800L) {
				float p = Math.max(0f, Math.min(1f, elapsed / 800.0f));
				float fade = 1f - p;
				int alpha = (int) (fade * fade * 255.0f);
				if (alpha > 2) {
					context.fill(0, 0, this.width, this.height, alpha << 24);
				}
			}
		}
	}
}
