package ru.neuclient.client.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.entity.PlayerLikeEntity;
import net.minecraft.entity.player.SkinTextures;
import net.minecraft.util.AssetInfo;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.impl.combat.AttackAuraModule;
import ru.neuclient.client.module.impl.misc.AutoWardenModule;
import ru.neuclient.client.module.impl.misc.TreeFarmModule;
import ru.neuclient.client.module.impl.render.CapeModule;
import ru.neuclient.client.module.impl.render.SpinnerModule;
import ru.neuclient.client.module.impl.movement.AutoSprintModule;
import ru.neuclient.client.module.impl.movement.WallClimbModule;

/**
 * F5 Body Fix — отображает серверный угол для AttackAura и WallClimb.
 *
 * Локальная камера от первого лица не меняется: подмена применяется только
 * к render state тела игрока. Для WallClimb приоритетом является угол на
 * нужную грань блока, чтобы в F5 было видно ту же ориентацию, которую
 * сервер получает перед установкой.
 */
@Mixin(PlayerEntityRenderer.class)
public abstract class PlayerBodyRendererMixin {

	@Inject(method = "updateRenderState(Lnet/minecraft/entity/PlayerLikeEntity;Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;F)V",
			at = @At("RETURN"))
	private void pc$applySpoofedBodyYaw(PlayerLikeEntity entity, PlayerEntityRenderState state, float tickDelta, CallbackInfo ci) {
		try {
			MinecraftClient mc = MinecraftClient.getInstance();
			if (mc == null || mc.player == null || entity != mc.player) {
				return;
			}

			// Подменяем capeTexture только для локального игрока. Ванильный
			// CapeFeatureRenderer после этого сам рисует плащ и его физику.
			// ВАЖНО: при надетых элитрах НЕ трогаем — в 1.21.11 CapeFeatureRenderer
			// рисует модель элитр той же cape-текстурой; подмена делала элитры
			// невидимыми. Не подменяем — ванилла показывает настоящие элитры.
			CapeModule cape = CapeModule.active();
			if (cape != null && state.skinTextures != null
					&& !state.equippedChestStack.isOf(net.minecraft.item.Items.ELYTRA)) {
				SkinTextures skin = state.skinTextures;
				state.skinTextures = new SkinTextures(
						skin.body(),
						new AssetInfo.TextureAssetInfo(CapeModule.CAPE_TEXTURE),
						skin.elytra(),
						skin.model(),
						skin.secure());
				state.capeVisible = true;
			}

			// Если Spinner активен — он сам крутит bodyYaw, другие модули не мешают.
			SpinnerModule spinner = SpinnerModule.active();
			if (spinner != null && spinner.shouldSpinSelf(entity)) {
				return;
			}

			WallClimbModule wall = WallClimbModule.active();
			if (wall != null && wall.isSpoofingForRender()) {
				state.bodyYaw = wall.getSpoofYaw();
				state.pitch = wall.getSpoofPitch();
				state.relativeHeadYaw = 0.0f;
				return;
			}

			AutoWardenModule warden = AutoWardenModule.active();
			if (warden != null && warden.isSpoofing()) {
				state.bodyYaw = warden.getSpoofYaw();
				state.pitch = warden.getSpoofPitch();
				state.relativeHeadYaw = 0.0f;
				return;
			}

			// TreeFarm бот: в F5 видно тот же угол, что уходит серверу.
			TreeFarmModule treeFarm = TreeFarmModule.active();
			if (treeFarm != null && treeFarm.isSpoofing()) {
				state.bodyYaw = treeFarm.getSpoofYaw();
				state.pitch = treeFarm.getSpoofPitch();
				state.relativeHeadYaw = 0.0f;
				return;
			}

			AttackAuraModule aura = AttackAuraModule.active();
			if (aura != null && aura.isSpoofing()) {
				state.bodyYaw = aura.getSpoofYaw();
				state.pitch = aura.getSpoofPitch();
				state.relativeHeadYaw = 0.0f;
				return;
			}

			// AutoSprint «Во все стороны» — самый низкий приоритет:
			// в F5 видно ту же ориентацию, что уходит серверу.
			AutoSprintModule autoSprint = AutoSprintModule.active();
			if (autoSprint != null && autoSprint.isSpoofingForRender()) {
				state.bodyYaw = autoSprint.getSpoofYaw();
				state.pitch = autoSprint.getSpoofPitch();
				state.relativeHeadYaw = 0.0f;
			}
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка F5 Body Fix", t);
		}
	}
}
