package ru.neuclient.client.mixin;

import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.neuclient.client.module.impl.render.KillEffectModule;

/** Оставляет убитого игрока локально на время визуального KillEffect. */
@Mixin(ClientWorld.class)
public abstract class ClientWorldMixin {

	@Inject(method = "addEntity", at = @At("HEAD"))
	private void pc$releaseKillEffectReplacement(Entity entity, CallbackInfo ci) {
		KillEffectModule effect = KillEffectModule.active();
		if (effect != null) {
			effect.onEntityAdded(entity);
		}
	}

	@Inject(method = "removeEntity", at = @At("HEAD"), cancellable = true)
	private void pc$keepKillEffectEntity(int entityId, Entity.RemovalReason reason,
			CallbackInfo ci) {
		KillEffectModule effect = KillEffectModule.active();
		if (effect != null && effect.onEntityRemoved(entityId)) {
			ci.cancel();
		}
	}
}
