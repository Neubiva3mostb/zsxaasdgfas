package ru.neuclient.client.hud.impl;

import net.minecraft.client.gui.DrawContext;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.font.MsdfFontRenderer;
import ru.neuclient.client.font.MsdfFonts;
import ru.neuclient.client.hud.HudElement;
import ru.neuclient.client.module.impl.render.MusicModule;
import ru.neuclient.client.util.MediaBridge;
import ru.neuclient.client.util.RenderUtil;

/**
 * «Музыка» — HUD-элемент с треком из Spotify / Яндекс Музыки / любого
 * плеера Windows (через MediaBridge, системные медиа-контролы).
 *
 * Визуал: 4 «прыгающие» линии-эквалайзер + название + исполнитель +
 * полоса прогресса с временем. На паузе линии ЗАМИРАЮТ и панель
 * приглушается. Обложки нет сознательно.
 * Видимость определяет модуль Music (не Interface).
 */
public class MediaElement extends HudElement {

	/** Накопленное время анимации: растёт только пока играет. */
	private long animMs = 0L;
	private long lastFrameMs = 0L;

	public MediaElement() {
		super("music", 4, 84);
	}

	@Override
	public boolean isVisible() {
		var modules = NeuClient.getInstance().getModuleManager();
		if (modules == null) {
			return false;
		}
		MusicModule music = modules.get(MusicModule.class);
		return music != null && music.isEnabled();
	}

	@Override
	protected void drawElement(DrawContext ctx, boolean editing) {
		MediaBridge bridge = MediaBridge.get();
		bridge.ensureStarted();
		bridge.tickKeepAlive();
		MediaBridge.State st = bridge.state();

		if (st == null) {
			if (editing) {
				// Плейсхолдер для редактора HUD.
				width = 150;
				height = 30;
				RenderUtil.roundRect(ctx, getX(), getY(), width, height, 6, 0x8A07070D);
				drawBold(ctx, "Музыка", getX() + 8, getY() + (30 - 9) / 2, 0x66FFFFFF);
			} else {
				width = 0;
				height = 0;
			}
			return;
		}

		int panelW = 210;
		int panelH = 40;
		int x = getX();
		int y = getY();
		width = panelW;
		height = panelH;

		float dim = st.playing ? 1.0f : 0.45f;
		RenderUtil.roundRect(ctx, x, y, panelW, panelH, 6, fade(0x8A07070D, dim));

		// === Анимация: время накапливается только пока играет ===
		long now = System.currentTimeMillis();
		if (lastFrameMs != 0L) {
			long dt = now - lastFrameMs;
			if (dt > 0L && dt < 250L) {
				if (st.playing) {
					animMs += dt;
				}
			}
		}
		lastFrameMs = now;

		// === Эквалайзер: 4 линии (замирают на паузе) ===
		int eqSize = panelH - 12;
		int eqX = x + 7;
		int eqY = y + (panelH - eqSize) / 2;
		drawEqualizer(ctx, eqX, eqY, eqSize, st.playing, dim);

		// === Текст ===
		int tx = eqX + eqSize + 9;
		int tw = panelW - (tx - x) - 6;

		String title = cut(st.title == null ? "" : st.title, tw, 9.0f);
		String artistRaw = st.artist == null || st.artist.isBlank() ? "Неизвестный исполнитель" : st.artist;
		String artist = cut(st.playing ? artistRaw : "Пауза · " + artistRaw, tw, 8.0f);

		MsdfFontRenderer.drawWithShadow(ctx, MsdfFonts.sfMedium(), title,
				tx, y + 6, fade(0xF2FFFFFF, dim), 9.0f);
		MsdfFontRenderer.drawWithShadow(ctx, MsdfFonts.sfMedium(), artist,
				tx, y + 18, fade(0x9CFFFFFF, dim), 8.0f);

		// === Прогресс/время ===
		// Позиция уже сглажена в MediaBridge (монотонная, без миганий 0:00).
		long dur = Math.max(0L, st.durMs);
		long pos = Math.max(0L, st.posMs);
		if (dur > 0) {
			pos = Math.min(pos, dur);
		}
		int barY = y + panelH - 7;
		int barW = tw;
		RenderUtil.roundRect(ctx, tx, barY, barW, 3, 1, fade(0x28FFFFFF, dim));
		String time;
		if (dur > 0) {
			int fill = (int) Math.round(barW * (pos / (double) dur));
			if (fill > 0) {
				RenderUtil.roundRect(ctx, tx, barY, fill, 3, 1, fade(0xFF000000 | (RenderUtil.accent() & 0x00FFFFFF), dim));
			}
			time = formatTime(pos) + " / " + formatTime(dur);
		} else {
			// Плеер не отдаёт таймлайн — показываем только прожитое время.
			time = pos > 500L ? formatTime(pos) : "";
		}
		if (!time.isEmpty()) {
			float timeW = MsdfFontRenderer.getWidth(MsdfFonts.sfMedium(), time, 7.0f);
			MsdfFontRenderer.draw(ctx, MsdfFonts.sfMedium(), time,
					tx + barW - timeW, barY - 10, fade(0x80FFFFFF, dim), 7.0f);
		}
	}

	/** 4 «прыгающие» линии; playing=false — застывший узор. */
	private void drawEqualizer(DrawContext ctx, int x, int y, int size, boolean playing, float dim) {
		int accent = 0xFF000000 | (RenderUtil.accent() & 0x00FFFFFF);
		int n = 4;
		int gap = 2;
		int barW = (size - gap * (n - 1)) / n;
		for (int i = 0; i < n; i++) {
			// На паузе фаза зафиксирована: линии замирают в текущем положении.
			double phase = animMs / 220.0 + i * 0.9;
			float k = 0.35f + 0.65f * (0.5f + 0.5f * (float) Math.sin(phase));
			int h = Math.max(3, (int) (size * 0.3f + size * 0.55f * k));
			int bx = x + i * (barW + gap);
			int by = y + (size - h) / 2;
			ctx.fill(bx, by, bx + barW, by + h, eqAlpha(accent, (int) (170 * dim)));
		}
	}

	private static int eqAlpha(int argb, int a) {
		return (Math.max(0, Math.min(255, a)) << 24) | (argb & 0x00FFFFFF);
	}

	private static int fade(int argb, float k) {
		int a = (int) (((argb >>> 24) & 0xFF) * Math.max(0f, Math.min(1f, k)));
		return (a << 24) | (argb & 0x00FFFFFF);
	}

	/** Обрезать строку под ширину px с «…». */
	private static String cut(String s, int maxWidthPx, float size) {
		if (s == null) return "";
		if (MsdfFontRenderer.getWidth(MsdfFonts.sfMedium(), s, size) <= maxWidthPx) {
			return s;
		}
		while (s.length() > 1
				&& MsdfFontRenderer.getWidth(MsdfFonts.sfMedium(), s + "…", size) > maxWidthPx) {
			s = s.substring(0, s.length() - 1);
		}
		return s + "…";
	}

	/** мс → m:ss. */
	private static String formatTime(long ms) {
		long total = Math.max(0L, ms) / 1000L;
		return (total / 60) + ":" + String.format("%02d", total % 60);
	}
}
