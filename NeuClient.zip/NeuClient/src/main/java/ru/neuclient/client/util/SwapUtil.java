package ru.neuclient.client.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.screen.slot.SlotActionType;

/**
 * Единый механизм свапа предметов для всех модулей клиента.
 *
 * РАСКЛАДКА СЛОТОВ ЭКРАНА (PlayerScreenHandler, syncId = 0, активен всегда —
 * открывать экран не нужно):
 *   0      результат крафта
 *   1–4    сетка крафта
 *   5–8    броня (шлем, нагрудник, поножи, ботинки)
 *   9–35   основной инвентарь (совпадает с индексами PlayerInventory)
 *   36–44  хотбар (индекс инвентаря + 36)
 *   45     оффхенд
 *
 * ТРИ ПРАВИЛА, ОБЩИЕ ДЛЯ ВСЕХ СВАППЕРОВ.
 *
 * 1. АТОМАРНОСТЬ. Где протокол позволяет — один пакет SlotActionType.SWAP
 *    вместо цепочки PICKUP. Кнопка 0–8 означает ячейку хотбара, кнопка 40 —
 *    оффхенд. Цепочка PICKUP оставляет предмет висеть на курсоре между
 *    кликами: если сервер отклонит любой из них, предмет теряется в
 *    «руке» до следующего клика.
 *
 * 2. ОСТАНОВКА НА ОДИН ТИК. Клик НЕ отправляется на месте: он уходит в
 *    {@link SwapPause}, который сперва даёт серверу пакет стоящего
 *    игрока (обнулённый ввод + снятый спринт) и лишь потом, в конце
 *    того же тика, выполняет клик. Задержка — ровно один тик (50 мс).
 *
 *    Раньше пакет улетал немедленно, а ввод гасился только на СЛЕДУЮЩЕМ
 *    тике: свапперы тикают в конце тика, уже после sendMovementPackets.
 *    Сервер видел клик вместе с пакетом бегущего игрока — то есть
 *    защита не работала вообще. Отсюда «AutoSwap не останавливает».
 *
 *    Следствие для вызывающих: методы возвращают true как «принято»,
 *    а не «уже выполнено». Модуль со ступенчатым автоматом обязан
 *    пропускать тики, пока {@link SwapPause#isBusy()}.
 *
 * 3. ВОЗВРАТ СЛОТОВ. {@link #restoreSwap} отменяет ранее сделанный свап,
 *    возвращая оба предмета на их исходные места. Модули зовут его, как
 *    только предмет отработал (съеден, брошен, блок доломан).
 */
public final class SwapUtil {

	/** Слот оффхенда в раскладке PlayerScreenHandler. */
	public static final int OFFHAND_SLOT = 45;
	/** Кнопка оффхенда для SlotActionType.SWAP (ванильная клавиша F). */
	public static final int OFFHAND_SWAP_BUTTON = 40;
	/** Первый слот брони (шлем). */
	public static final int EQUIPMENT_START = 5;

	private SwapUtil() {
	}

	/**
	 * Переводит индекс инвентаря игрока (0–35) в слот экрана.
	 * Хотбар 0–8 → 36–44, остальное совпадает.
	 */
	public static int toScreenSlot(int inventoryIndex) {
		return inventoryIndex < 9 ? inventoryIndex + 36 : inventoryIndex;
	}

	/** Слот экрана для части брони. */
	public static int armorScreenSlot(EquipmentSlot slot) {
		return switch (slot) {
			case HEAD -> 5;
			case CHEST -> 6;
			case LEGS -> 7;
			case FEET -> 8;
			default -> -1;
		};
	}

	/** Можно ли сейчас работать с инвентарём (свой хендлер, курсор пуст). */
	public static boolean canInteract(MinecraftClient client, PlayerEntity player) {
		if (client == null || client.interactionManager == null || player == null) {
			return false;
		}
		// Клик уходит по playerScreenHandler (syncId 0). Открытый чужой
		// контейнер этот syncId не примет.
		if (player.currentScreenHandler != player.playerScreenHandler) {
			return false;
		}
		// Предмет на курсоре — игрок перекладывает вручную, не мешаем.
		return player.playerScreenHandler.getCursorStack().isEmpty();
	}

	/**
	 * Обменять ячейку инвентаря с ячейкой ХОТБАРА одним пакетом.
	 *
	 * Это ванильное нажатие цифры над слотом: атомарно, без курсора.
	 *
	 * @param inventoryIndex источник, 0–35
	 * @param hotbarIndex    ячейка-приёмник, 0–8
	 */
	public static boolean swapToHotbar(MinecraftClient client, PlayerEntity player,
			int inventoryIndex, int hotbarIndex) {
		return swapToHotbar(client, player, inventoryIndex, hotbarIndex, false);
	}

	/** Вариант для макросов, работающих только с закрытым GUI (проверка и при выполнении очереди). */
	public static boolean swapToHotbar(MinecraftClient client, PlayerEntity player,
			int inventoryIndex, int hotbarIndex, boolean onlyInWorld) {
		if ((onlyInWorld && client.currentScreen != null) || !canInteract(client, player)) {
			return false;
		}
		if (inventoryIndex < 0 || inventoryIndex > 35 || hotbarIndex < 0 || hotbarIndex > 8) {
			return false;
		}
		if (inventoryIndex == hotbarIndex) {
			return false;
		}
		SwapPause.submit(() -> {
			// Условия перепроверяем в момент клика: за тик паузы игрок
			// мог открыть сундук или взять предмет на курсор.
			if ((onlyInWorld && client.currentScreen != null) || !canInteract(client, player)) {
				return;
			}
			client.interactionManager.clickSlot(player.playerScreenHandler.syncId,
					toScreenSlot(inventoryIndex), hotbarIndex, SlotActionType.SWAP, player);
		});
		return true;
	}

	/**
	 * Положить предмет во вторую руку одним пакетом (кнопка 40).
	 *
	 * @param inventoryIndex источник, 0–35
	 */
	public static boolean swapToOffhand(MinecraftClient client, PlayerEntity player,
			int inventoryIndex) {
		if (!canInteract(client, player)) {
			return false;
		}
		if (inventoryIndex < 0 || inventoryIndex > 35) {
			return false;
		}
		SwapPause.submit(() -> {
			if (!canInteract(client, player)) {
				return;
			}
			client.interactionManager.clickSlot(player.playerScreenHandler.syncId,
					toScreenSlot(inventoryIndex), OFFHAND_SWAP_BUTTON, SlotActionType.SWAP, player);
		});
		return true;
	}

	/**
	 * Надеть деталь брони (старая вернётся на место источника).
	 *
	 * Из хотбара — атомарный SWAP: кликаем по слоту брони, кнопкой
	 * указываем ячейку хотбара. Для глубокого инвентаря такого пакета в
	 * протоколе нет, поэтому там честная цепочка PICKUP.
	 */
	public static boolean swapToArmor(MinecraftClient client, PlayerEntity player,
			int inventoryIndex, EquipmentSlot equipmentSlot) {
		return swapToArmor(client, player, inventoryIndex, equipmentSlot, false);
	}

	public static boolean swapToArmor(MinecraftClient client, PlayerEntity player,
			int inventoryIndex, EquipmentSlot equipmentSlot, boolean onlyInWorld) {
		int armorSlot = armorScreenSlot(equipmentSlot);
		if (armorSlot < 0 || (onlyInWorld && client.currentScreen != null) || !canInteract(client, player)) {
			return false;
		}
		if (inventoryIndex < 0 || inventoryIndex > 35) {
			return false;
		}
		SwapPause.submit(() -> {
			if ((onlyInWorld && client.currentScreen != null) || !canInteract(client, player)) {
				return;
			}
			int syncId = player.playerScreenHandler.syncId;
			if (inventoryIndex < 9) {
				client.interactionManager.clickSlot(syncId, armorSlot, inventoryIndex,
						SlotActionType.SWAP, player);
			} else {
				// Цепочку PICKUP не разрываем по тикам: предмет висел бы
				// на курсоре между тиками и потерялся бы при любом сбое.
				int screenSlot = toScreenSlot(inventoryIndex);
				client.interactionManager.clickSlot(syncId, screenSlot, 0, SlotActionType.PICKUP, player);
				client.interactionManager.clickSlot(syncId, armorSlot, 0, SlotActionType.PICKUP, player);
				client.interactionManager.clickSlot(syncId, screenSlot, 0, SlotActionType.PICKUP, player);
			}
		});
		return true;
	}

	/**
	 * ВЕРНУТЬ СЛОТЫ НА МЕСТО.
	 *
	 * Повторяет тот же обмен в обратную сторону: SWAP симметричен, так
	 * что второй такой же пакет возвращает оба предмета туда, где они
	 * лежали до свапа.
	 *
	 * @param inventoryIndex исходная ячейка, откуда брали (0–35)
	 * @param hotbarIndex    ячейка хотбара, куда клали (0–8)
	 */
	public static boolean restoreSwap(MinecraftClient client, PlayerEntity player,
			int inventoryIndex, int hotbarIndex) {
		return swapToHotbar(client, player, inventoryIndex, hotbarIndex);
	}

	/** Вернуть предмет из оффхенда в ту ячейку, откуда он пришёл. */
	public static boolean restoreOffhand(MinecraftClient client, PlayerEntity player,
			int inventoryIndex) {
		return swapToOffhand(client, player, inventoryIndex);
	}

}
