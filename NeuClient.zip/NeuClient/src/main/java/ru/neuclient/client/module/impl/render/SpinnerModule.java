package ru.neuclient.client.module.impl.render;

import net.minecraft.client.MinecraftClient;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.NumberSetting;

/**
 * Spinner — быстрое вращение СОБСТВЕННОЙ модели вокруг вертикальной оси.
 *
 * ЧИСТО ВИЗУАЛЬНЫЙ ЭФФЕКТ.
 * Крутится только то, что рисуется на экране в виде от третьего лица
 * (F5). Ни угол игрока, ни пакеты движения не трогаются вообще:
 * серверу уходит настоящий взгляд, другие игроки видят обычную модель,
 * попадания и наведение работают как всегда.
 *
 * Реализовано подменой bodyYaw в состоянии рендера (см.
 * PlayerSpinRenderMixin): это последняя стадия перед отрисовкой, дальше
 * значение никуда не утекает.
 *
 * ПОЧЕМУ ВРАЩЕНИЕ СЧИТАЕТСЯ ПО ВРЕМЕНИ, А НЕ ПО КАДРАМ.
 * Если прибавлять фиксированный угол каждый кадр, скорость вращения
 * будет зависеть от FPS: на 30 кадрах вдвое медленнее, чем на 60.
 * Поэтому угол берётся от системных часов — заданные обороты в секунду
 * соблюдаются при любом FPS.
 */
public final class SpinnerModule extends Module {

	private static SpinnerModule instance;

	/**
	 * Скорость вращения в оборотах за секунду.
	 *
	 * Верхняя граница честно бесполезна визуально: клиент рисует
	 * максимум ~60–240 кадров в секунду, поэтому уже с нескольких
	 * десятков оборотов модель превращается в мельтешение, а дальше
	 * начинается алиасинг (кажется, что вращение замедлилось или пошло
	 * назад). Диапазон оставлен как просили — 1..100.
	 */
	private final NumberSetting speed =
			new NumberSetting("Оборотов в секунду", 10.0, 1.0, 100.0, 1.0);

	public SpinnerModule() {
		super("Spinner", "Крутилка как в кс",
				Category.RENDER);
		addSettings(speed);
		instance = this;
	}

	/** Активный экземпляр, если модуль включён (для миксина рендера). */
	public static SpinnerModule active() {
		return instance != null && instance.isEnabled() ? instance : null;
	}

	/**
	 * Текущий угол вращения в градусах.
	 *
	 * Считается от монотонных часов, поэтому не зависит ни от FPS, ни от
	 * тикрейта сервера. Результат уже приведён к 0..360.
	 */
	public float currentAngle() {
		double rps = speed.get();
		// nanoTime монотонен — в отличие от currentTimeMillis его не
		// дёргает перевод системных часов
		double seconds = System.nanoTime() / 1_000_000_000.0;
		double deg = seconds * rps * 360.0;
		return (float) (deg % 360.0);
	}

	/**
	 * Крутить ли модель этого игрока.
	 *
	 * Только своя модель и только когда её видно: в виде от первого лица
	 * тело не рисуется, и вращать нечего.
	 */
	public boolean shouldSpinSelf(net.minecraft.entity.Entity entity) {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc == null || mc.player == null || entity != mc.player) {
			return false;
		}
		return mc.options != null && !mc.options.getPerspective().isFirstPerson();
	}
}
