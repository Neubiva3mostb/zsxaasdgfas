package ru.neuclient.client.mixin;

import net.minecraft.scoreboard.Team;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.neuclient.client.util.NameProtectUtil;

/**
 * NameProtect в СКОРБОРДЕ (сайдбар справа): имя записи с командным
 * оформлением (цвет/префикс/суффикс) проходит через Team.decorateName(Text).
 * Сюда и попадает ник игрока в статах FunTime.
 * require=0: метода вдруг нет в текущей версии — тихо пропускаем.
 */
@Mixin(Team.class)
public abstract class TeamNameMixin {

	@Inject(method = "decorateName(Lnet/minecraft/text/Text;)Lnet/minecraft/text/MutableText;",
			at = @At("RETURN"), cancellable = true, require = 0)
	private void pc$nameProtectTeam(Text name, CallbackInfoReturnable<MutableText> cir) {
		MutableText value = cir.getReturnValue();
		if (value != null && NameProtectUtil.active()) {
			cir.setReturnValue((MutableText) NameProtectUtil.transformIfActive(value));
		}
	}
}
