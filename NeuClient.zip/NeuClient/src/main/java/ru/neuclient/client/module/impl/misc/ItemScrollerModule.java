package ru.neuclient.client.module.impl.misc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.util.InputUtil;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import org.lwjgl.glfw.GLFW;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.NumberSetting;

/**
 * ItemScroller — быстрое перекладывание предметов в контейнерах.
 *
 * Зажми ЛЕВЫЙ Shift + ЛКМ и веди мышью по слотам сундука/шалкера/бочки/
 * воронки (и своего инвентаря) — каждый слот, над которым проходит курсор,
 * мгновенно уходит в другую сторону (ванильный shift+клик, SlotActionType
 * .QUICK_MOVE). Та же механика зажатого перетаскивания, что у известных
 * твиков инвентаря, — но с настраиваемой скоростью.
 *
 * Скорость — пауза в миллисекундах между перекладываниями (0 = как только
 * курсор попал на новый слот; серверу при высоком пинге комфортнее 50).
 * Один и тот же слот при стоянии на нём не кликается повторно — как рука
 * игрока; ушёл со слота и вернулся — клик разрешён снова.
 */
public class ItemScrollerModule extends Module {

	private final NumberSetting speed = new NumberSetting("Скорость", 50.0, 0.0, 100.0, 5.0);

	/** Момент последнего перекладывания. */
	private long lastMoveTime;
	/** Слот, по которому уже кликнули (анти-повтор, пока курсор на нём). */
	private int lastClickedSlot = -1;

	public ItemScrollerModule() {
		super("ItemScroller", "Быстро двигает предметы",
				Category.MISC);
		addSettings(speed);
	}

	/** Из HandledScreenMixin#render: открыт контейнер, курсор сейчас над slot (может быть null). */
	public void onSlotHover(HandledScreen<?> screen, Slot slot) {
		MinecraftClient client = MinecraftClient.getInstance();
		ClientPlayerEntity player = client.player;
		if (player == null || client.interactionManager == null || screen.getScreenHandler() == null) {
			resetTracking();
			return;
		}

		boolean lmbDown = GLFW.glfwGetMouseButton(client.getWindow().getHandle(),
				GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
		boolean shiftDown = InputUtil.isKeyPressed(client.getWindow(), GLFW.GLFW_KEY_LEFT_SHIFT);

		if (!lmbDown || !shiftDown) {
			resetTracking(); // клавиши отпущены — следующий заход начнётся с чистого листа
			return;
		}
		if (slot == null || !slot.hasStack()) {
			lastClickedSlot = -1; // ушли со слота — при возврате клик снова разрешён
			return;
		}
		if (slot.id == lastClickedSlot) {
			return; // стоим на уже переложенном слоте — не дёргаем его повторно
		}

		long now = System.currentTimeMillis();
		long delayMs = speed.get().longValue();
		if (now - lastMoveTime < delayMs) {
			return; // ждём свою паузу «Скорость»
		}

		// Легитный шифт-клик по слоту (QUICK_MOVE): сундуки, шалкеры, бочки — обе стороны
		client.interactionManager.clickSlot(screen.getScreenHandler().syncId, slot.id, 0,
				SlotActionType.QUICK_MOVE, player);
		lastMoveTime = now;
		lastClickedSlot = slot.id;
	}

	private void resetTracking() {
		lastClickedSlot = -1;
	}

	@Override
	protected void onDisable() {
		resetTracking();
	}
}
