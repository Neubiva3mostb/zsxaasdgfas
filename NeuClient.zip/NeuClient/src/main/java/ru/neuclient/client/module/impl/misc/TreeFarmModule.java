package ru.neuclient.client.module.impl.misc;

import ru.neuclient.client.module.impl.player.BlinkModule;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.LeavesBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.module.impl.misc.autowarden.PathFinder;
import ru.neuclient.client.module.impl.misc.autowarden.Walker;
import ru.neuclient.client.setting.TextSetting;
import ru.neuclient.client.util.ChatUtil;
import ru.neuclient.client.util.InventoryUtil;
import ru.neuclient.client.util.SwapPause;
import ru.neuclient.client.util.SwapUtil;

import java.util.List;

/**
 * Цикл дубовой фермы: ресурсы → саженец → костная мука → дерево →
 * сам ломает oak_log (движение по пути как у AutoWarden: Walker + PathFinder,
 * без Baritone) → возврат в исходную точку → продажа.
 */
public final class TreeFarmModule extends Module {

	private static final int REQUIRED_SAPLINGS = 1;
	private static final int REQUIRED_BONE_MEAL = 32;
	private static final int CHEST_RADIUS = 3;
	private static final long BONE_MEAL_COOLDOWN_MS = 120L;
	private static final long SELL_COOLDOWN_MS = 2_000L;
	/** Дальность руки для ломания брёвен (с запасом от серверных 4.5). */
	private static final double BREAK_REACH_SQ = 4.3 * 4.3;
	/** Сколько блоков над ногами ещё считаем достижимыми для ходьбы. */
	private static final int MAX_LOG_STEP_UP = 5;
	/** Лимит неудачных перестроек пути подряд, после которого ферма останавливается. */
	private static final int MAX_PATH_FAILS = 12;

	private final TextSetting price = new TextSetting("Цена", "100000", 16);

	private enum State {
		PREPARE,
		TAKE_RESOURCES,
		PLANTING,
		GROWING,
		MINING,
		RETURNING,
		CLEARING_HEAD,
		SELLING
	}

	private enum PendingAction {
		NONE,
		PLANT,
		BONE_MEAL,
		HEAD_START,
		HEAD_PROGRESS
	}

	private State state = State.PREPARE;
	private PendingAction pendingAction = PendingAction.NONE;
	private BlockPos startPos;
	private BlockPos plantingPos;
	private Direction plantingDirection;
	private BlockPos chestPos;
	private long lastBoneMealAt;
	private long sellCooldownUntil;
	private boolean sellArmed = true;
	private boolean returningToStart;
	private State resumeAfterHeadClear = State.PREPARE;
	private BlockPos headClearPos;
	private int headClearTicks;
	private BlockPos pendingActionPos;
	private BlockHitResult pendingActionHit;
	private float spoofYaw;
	private float spoofPitch;
	private float smoothYaw;
	private float smoothPitch;
	private float desiredYaw;
	private float desiredPitch;
	private boolean hasSmoothRotation;
	private boolean rotationReady;
	private boolean continuousAim;
	private long aimStartedAtNanos;
	private double aimPhase;
	private int visualSpoofTicks;

	/** Движение по пути как у AutoWarden: нажатие клавиш + серверный угол. */
	private Walker walker;
	private PathFinder pathFinder;
	private ClientWorld pathWorld;
	private int repathCooldown;
	private int pathFails;
	/** Ломание брёвен своими руками: текущий блок и спуф-угол на него. */
	private BlockPos breakTargetPos;
	private int breakTicks;
	private int breakRestarts;
	private boolean hasBotAim;
	private float botYaw;
	private float botPitch;

	public TreeFarmModule() {
		super("TreeFarm", "Автоматическая ферма дуба", Category.MISC);
		addSettings(price);
	}

	@Override
	protected void onEnable() {
		resetCycle();
	}

	@Override
	protected void onDisable() {
		stopBotMovement();
		if (mc.interactionManager != null) {
			mc.interactionManager.cancelBlockBreaking();
		}
		state = State.PREPARE;
		pendingAction = PendingAction.NONE;
		pendingActionPos = null;
		pendingActionHit = null;
		visualSpoofTicks = 0;
		returningToStart = false;
		headClearPos = null;
		headClearTicks = 0;
		continuousAim = false;
		breakTargetPos = null;
		breakTicks = 0;
		hasBotAim = false;
	}

	private void resetCycle() {
		state = State.PREPARE;
		startPos = null;
		plantingPos = null;
		plantingDirection = null;
		chestPos = null;
		lastBoneMealAt = 0L;
		sellCooldownUntil = 0L;
		sellArmed = true;
		returningToStart = false;
		resumeAfterHeadClear = State.PREPARE;
		headClearPos = null;
		headClearTicks = 0;
		pendingAction = PendingAction.NONE;
		pendingActionPos = null;
		pendingActionHit = null;
		hasSmoothRotation = false;
		rotationReady = false;
		continuousAim = false;
		aimStartedAtNanos = 0L;
		aimPhase = 0.0;
		visualSpoofTicks = 0;
		stopBotMovement();
		walker = new Walker(mc);
		pathFinder = null;
		pathWorld = null;
		repathCooldown = 0;
		pathFails = 0;
		breakTargetPos = null;
		breakTicks = 0;
		breakRestarts = 0;
		hasBotAim = false;
	}

	@Override
	public void onTick(MinecraftClient client) {
		ClientPlayerEntity player = client.player;
		ClientWorld world = client.world;
		if (player == null || world == null || client.interactionManager == null) {
			return;
		}
		BlinkModule blink = NeuClient.getInstance() == null || NeuClient.getInstance().getModuleManager() == null
				? null : NeuClient.getInstance().getModuleManager().get(BlinkModule.class);
		if (blink != null && blink.isEnabled()) {
			stopWithMessage("TreeFarm: выключи Blink — задержка движения вызывает возврат сервером");
			return;
		}
		if (visualSpoofTicks > 0) {
			visualSpoofTicks--;
		}
		continuousAim = false;
		if (pendingAction != PendingAction.NONE) {
			advanceSmoothRotation(player);
		}

		if (startPos == null) {
			startPos = player.getBlockPos();
			plantingDirection = player.getHorizontalFacing();
			plantingPos = startPos.offset(plantingDirection);
		}
		// После открытия сундука ждём закрытия окна. Не отправляем
		// игровые действия поверх чужого контейнера.
		if (state != State.TAKE_RESOURCES && client.currentScreen != null) {
			return;
		}
		// Плавно доворачиваем настоящий взгляд и выполняем действие
		// только после того, как следующий серверный пакет уже будет
		// содержать этот угол.
		if (pendingAction != PendingAction.NONE) {
			advanceSmoothRotation(player);
			if (rotationReady) {
				performPendingAction(client, player);
			}
			return;
		}

		// Если дерево прижало игрока листвой или игрок оказался в
		// crawl-позе под блоком, сначала освобождаем ровно один блок
		// над головой. Ходьба на это время останавливается.
		if (state != State.TAKE_RESOURCES && state != State.CLEARING_HEAD
				&& state != State.SELLING) {
			BlockPos obstruction = findHeadObstruction(player, world);
			if (obstruction != null) {
				resumeAfterHeadClear = state;
				headClearPos = obstruction;
				headClearTicks = 0;
				stopBotMovement();
				if (mc.interactionManager != null) {
					mc.interactionManager.cancelBlockBreaking();
				}
				breakTargetPos = null;
				hasBotAim = false;
				state = State.CLEARING_HEAD;
			}
		}

		// Продажа проверяется между циклами. Пока сервер не убрал проданный
		// стак из инвентаря, sellArmed не даст отправить команду повторно.
		boolean fullOakStack = hasFullStack(player, Items.OAK_LOG);
		if (!fullOakStack) {
			sellArmed = true;
		}
		if (sellArmed && fullOakStack && System.currentTimeMillis() >= sellCooldownUntil
				&& state != State.MINING && state != State.RETURNING) {
			state = State.SELLING;
		}

		switch (state) {
			case PREPARE -> prepare(client, player, world);
			case TAKE_RESOURCES -> takeResources(client, player);
			case PLANTING -> plant(client, player, world);
			case GROWING -> grow(client, player, world);
			case MINING -> mine(client, player, world);
			case RETURNING -> returnToStart(client, player);
			case CLEARING_HEAD -> clearHeadBlock(client, player, world);
			case SELLING -> sell(client, player);
		}
	}

	private void prepare(MinecraftClient client, ClientPlayerEntity player, ClientWorld world) {
		if (!hasRequiredResources(player)) {
			chestPos = findChest(world, startPos, CHEST_RADIUS);
			if (chestPos == null) {
				stopWithMessage("TreeFarm: рядом нет сундука с дубовым саженцем и костной мукой");
				return;
			}
			BlockHitResult hit = new BlockHitResult(
					Vec3d.ofCenter(chestPos), Direction.UP, chestPos, false);
			client.interactionManager.interactBlock(player, Hand.MAIN_HAND, hit);
			state = State.TAKE_RESOURCES;
			return;
		}

		BlockState planted = world.getBlockState(plantingPos);
		if (isOakLog(planted)) {
			startMining();
			return;
		}
		if (planted.isOf(Blocks.OAK_SAPLING)) {
			state = State.GROWING;
			return;
		}
		if (!planted.isAir()) {
			stopWithMessage("TreeFarm: место посадки занято, ферма остановлена");
			return;
		}
		state = State.PLANTING;
	}

	private void takeResources(MinecraftClient client, ClientPlayerEntity player) {
		if (!(client.currentScreen instanceof HandledScreen<?>)) {
			// Окно сундука появляется после обработки пакета в следующем тике.
			return;
		}
		ScreenHandler handler = player.currentScreenHandler;
		if (handler == player.playerScreenHandler) {
			state = State.PREPARE;
			return;
		}

		int chestSlots = Math.max(0, handler.slots.size() - 36);
		if (countItem(player, Items.OAK_SAPLING) < REQUIRED_SAPLINGS) {
			int slot = findContainerItem(handler, chestSlots, Items.OAK_SAPLING);
			if (slot >= 0) {
				clickContainer(client, player, handler, slot);
				return;
			}
			closeChest(player);
			stopWithMessage("TreeFarm: в сундуке нет дубового саженца");
			return;
		}

		if (countItem(player, Items.BONE_MEAL) < REQUIRED_BONE_MEAL) {
			int slot = findContainerItem(handler, chestSlots, Items.BONE_MEAL);
			if (slot >= 0) {
				clickContainer(client, player, handler, slot);
				return;
			}
			closeChest(player);
			stopWithMessage("TreeFarm: в сундуке меньше 32 костной муки");
			return;
		}

		closeChest(player);
		state = State.PREPARE;
	}

	private int findContainerItem(ScreenHandler handler, int chestSlots, net.minecraft.item.Item item) {
		for (int i = 0; i < chestSlots; i++) {
			if (handler.getSlot(i).getStack().isOf(item)) {
				return i;
			}
		}
		return -1;
	}

	private void clickContainer(MinecraftClient client, ClientPlayerEntity player,
			ScreenHandler handler, int slot) {
		if (client.interactionManager != null) {
			client.interactionManager.clickSlot(handler.syncId, slot, 0,
					SlotActionType.QUICK_MOVE, player);
		}
	}

	private void closeChest(ClientPlayerEntity player) {
		if (player.currentScreenHandler != player.playerScreenHandler) {
			player.closeHandledScreen();
		}
	}

	private void plant(MinecraftClient client, ClientPlayerEntity player, ClientWorld world) {
		if (pendingAction != PendingAction.NONE) {
			return;
		}
		if (!world.getBlockState(plantingPos).isAir()) {
			state = State.PREPARE;
			return;
		}
		if (!selectItemInHand(client, player, Items.OAK_SAPLING)) {
			return;
		}

		BlockPos soilPos = plantingPos.down();
		BlockHitResult hit = new BlockHitResult(
				Vec3d.ofCenter(soilPos).add(0.0, 0.5, 0.0), Direction.UP, soilPos, false);
		queueServerAction(PendingAction.PLANT, soilPos, hit, player);
	}

	private void grow(MinecraftClient client, ClientPlayerEntity player, ClientWorld world) {
		if (pendingAction != PendingAction.NONE) {
			return;
		}
		if (isOakLog(world.getBlockState(plantingPos))) {
			startMining();
			return;
		}
		if (!world.getBlockState(plantingPos).isOf(Blocks.OAK_SAPLING)) {
			state = State.PREPARE;
			return;
		}
		// Пока саженец жив, серверный взгляд плавно держится на нём
		// между всеми применениями костной муки — без рывков туда-сюда.
		updateContinuousAim(player, Vec3d.ofCenter(plantingPos));
		if (!selectItemInHand(client, player, Items.BONE_MEAL)) {
			return;
		}
		long now = System.currentTimeMillis();
		if (now - lastBoneMealAt < BONE_MEAL_COOLDOWN_MS) {
			return;
		}
		BlockHitResult hit = new BlockHitResult(
				Vec3d.ofCenter(plantingPos), Direction.UP, plantingPos, false);
		queueServerAction(PendingAction.BONE_MEAL, plantingPos, hit, player);
	}

	private void startMining() {
		breakTargetPos = null;
		breakTicks = 0;
		hasBotAim = false;
		hasSmoothRotation = false;
		continuousAim = false;
		state = State.MINING;
	}

	private void mine(MinecraftClient client, ClientPlayerEntity player, ClientWorld world) {
		// 1) Если есть бревно в пределах руки — стоим и ломаем его сами,
		// серверная голова плавно смотрит на блок (спуф как у AutoWarden).
		BlockPos reachable = findLogWithinReach(world, player);
		if (reachable != null) {
			stopWalking();
			Vec3d center = Vec3d.ofCenter(reachable);
			updateBotAim(player, center);
			tickBreakBlock(client, player, world, reachable);
			return;
		}

		// 2) Достижимых брёвен больше нет — дерево считается срубленным
		// (остатки выше руки трогать нечем и не нужно).
		if (!hasTreeLogs(world, plantingPos)
				|| findNearestWalkableLog(world, player) == null) {
			stopBotMovement();
			hasSmoothRotation = false;
			returningToStart = true;
			state = State.RETURNING;
			return;
		}

		// 3) Иначе идём к ближайшему достижимому бревну пешком.
		BlockPos target = findNearestWalkableLog(world, player);
		walkTo(client, player, world, target, 1.6);
	}

	private void returnToStart(MinecraftClient client, ClientPlayerEntity player) {
		if (startPos == null) {
			state = State.PREPARE;
			return;
		}
		double dx = player.getX() - (startPos.getX() + 0.5);
		double dy = player.getY() - startPos.getY();
		double dz = player.getZ() - (startPos.getZ() + 0.5);
		if (dx * dx + dy * dy + dz * dz <= 3.24) {
			stopBotMovement();
			hasSmoothRotation = false;
			continuousAim = false;
			returningToStart = false;
			state = State.PREPARE;
			return;
		}

		walkTo(client, player, client.world, startPos, 1.2);
	}

	// ===== Ходьба и ломание без Baritone =====

	/** Путь к цели пешком (A* как в AutoWarden) + нажатие клавиш движения. */
	private void walkTo(MinecraftClient client, ClientPlayerEntity player,
			ClientWorld world, BlockPos goal, double reach) {
		if (goal == null) {
			stopBotMovement();
			return;
		}
		if (walker == null) {
			walker = new Walker(mc);
		}
		boolean needPath = walker.getGoal() == null
				|| !goal.equals(walker.getGoal())
				|| !walker.hasPath()
				|| walker.isStuck();
		if (repathCooldown > 0) {
			repathCooldown--;
		}
		if (needPath && repathCooldown <= 0) {
			walker.stop();
			List<BlockPos> path = pf(world).find(player.getBlockPos(), goal, reach);
			if (path == null || path.isEmpty()) {
				pathFails++;
				repathCooldown = 10;
				if (pathFails > MAX_PATH_FAILS) {
					stopWithMessage("TreeFarm: не удалось построить путь до бревна");
				}
				return;
			}
			pathFails = 0;
			repathCooldown = 0;
			walker.setPath(path, goal, reach);
		}
		if (walker.hasPath()) {
			walker.tick();
		}
	}

	/** Остановить ходьбу и слом ломания: клавиши отпускаем, путь сбрасываем. */
	private void stopBotMovement() {
		if (walker != null) {
			walker.stop();
		}
		breakTargetPos = null;
		hasBotAim = false;
	}

	private void stopWalking() {
		if (walker != null) {
			walker.stop();
		}
	}

	/** Плавный «серверный» взгляд на блок, который ломаем (как chest-look у AutoWarden). */
	private void updateBotAim(ClientPlayerEntity player, Vec3d target) {
		float[] rotation = rotationTo(player.getEyePos(), target);
		if (!hasBotAim) {
			botYaw = rotation[0];
			botPitch = rotation[1];
			hasBotAim = true;
		}
		float yawError = MathHelper.wrapDegrees(rotation[0] - botYaw);
		float pitchError = rotation[1] - botPitch;
		botYaw = MathHelper.wrapDegrees(
				botYaw + MathHelper.clamp(yawError * 0.35f, -18.0f, 18.0f));
		botPitch = MathHelper.clamp(
				botPitch + MathHelper.clamp(pitchError * 0.35f, -12.0f, 12.0f),
				-90.0f, 90.0f);
	}

	/** Ломание блока: attackBlock на старте, затем updateBlockBreakingProgress. */
	private void tickBreakBlock(MinecraftClient client, ClientPlayerEntity player,
			ClientWorld world, BlockPos pos) {
		if (client.interactionManager == null) {
			return;
		}
		BlockState block = world.getBlockState(pos);
		if (block.isAir() || !block.getFluidState().isEmpty()) {
			client.interactionManager.cancelBlockBreaking();
			breakTargetPos = null;
			breakTicks = 0;
			breakRestarts = 0;
			hasBotAim = false;
			return;
		}
		if (!pos.equals(breakTargetPos)) {
			// Новый блок — начинаем ломать с нуля.
			breakRestarts++;
			if (breakRestarts > 24) {
				stopWithMessage("TreeFarm: сервер не принимает ломание блока");
				return;
			}
			breakTargetPos = pos.toImmutable();
			breakTicks = 0;
			hasBotAim = false;
			updateBotAim(player, Vec3d.ofCenter(pos));
			client.interactionManager.attackBlock(pos, breakFace(player, pos));
			player.swingHand(Hand.MAIN_HAND);
			return;
		}
		breakTicks++;
		if (breakTicks > 600) {
			// Что-то зависло — сбрасываем и пробуем заново.
			client.interactionManager.cancelBlockBreaking();
			breakTargetPos = null;
			breakTicks = 0;
			hasBotAim = false;
			return;
		}
		updateBotAim(player, Vec3d.ofCenter(pos));
		client.interactionManager.updateBlockBreakingProgress(pos, breakFace(player, pos));
		player.swingHand(Hand.MAIN_HAND);
	}

	/** Грань блока, на которую «смотрим» при ломании: доминирующая ось от глаз. */
	private static Direction breakFace(ClientPlayerEntity player, BlockPos pos) {
		Vec3d delta = Vec3d.ofCenter(pos).subtract(player.getEyePos());
		double ax = Math.abs(delta.x);
		double ay = Math.abs(delta.y);
		double az = Math.abs(delta.z);
		if (ay >= ax && ay >= az) {
			return delta.y > 0.0 ? Direction.UP : Direction.DOWN;
		}
		if (ax >= az) {
			return delta.x > 0.0 ? Direction.EAST : Direction.WEST;
		}
		return delta.z > 0.0 ? Direction.SOUTH : Direction.NORTH;
	}

	/** Ближайшее бревно дерева в пределах руки. */
	private BlockPos findLogWithinReach(ClientWorld world, ClientPlayerEntity player) {
		BlockPos best = null;
		double bestDist = Double.MAX_VALUE;
		Vec3d eye = player.getEyePos();
		for (int dx = -3; dx <= 3; dx++) {
			for (int dy = 0; dy <= 10; dy++) {
				for (int dz = -3; dz <= 3; dz++) {
					BlockPos pos = plantingPos.add(dx, dy, dz);
					if (!isOakLog(world.getBlockState(pos))) {
						continue;
					}
					double dist = Vec3d.ofCenter(pos).squaredDistanceTo(eye);
					if (dist <= BREAK_REACH_SQ && dist < bestDist) {
						best = pos;
						bestDist = dist;
					}
				}
			}
		}
		return best;
	}

	/** Ближайшее бревно, до которого ещё есть смысл идти (не слишком высоко). */
	private BlockPos findNearestWalkableLog(ClientWorld world, ClientPlayerEntity player) {
		BlockPos best = null;
		double bestDist = Double.MAX_VALUE;
		Vec3d eye = player.getEyePos();
		int feetY = player.getBlockPos().getY();
		for (int dx = -3; dx <= 3; dx++) {
			for (int dy = 0; dy <= 10; dy++) {
				if (dy > MAX_LOG_STEP_UP + 1) {
					break;
				}
				for (int dz = -3; dz <= 3; dz++) {
					BlockPos pos = plantingPos.add(dx, dy, dz);
					if (!isOakLog(world.getBlockState(pos))) {
						continue;
					}
					if (pos.getY() - feetY > MAX_LOG_STEP_UP) {
						continue;
					}
					double dist = Vec3d.ofCenter(pos).squaredDistanceTo(eye);
					if (dist < bestDist) {
						best = pos;
						bestDist = dist;
					}
				}
			}
		}
		return best;
	}

	/** A*-поиск пути как у AutoWarden, кэшируется на мир. */
	private PathFinder pf(ClientWorld world) {
		if (pathFinder == null || pathWorld != world) {
			BlockPos a = startPos != null ? startPos : plantingPos;
			BlockPos b = plantingPos != null ? plantingPos : a;
			int minX = Math.min(a.getX(), b.getX()) - 8;
			int maxX = Math.max(a.getX(), b.getX()) + 8;
			int minZ = Math.min(a.getZ(), b.getZ()) - 8;
			int maxZ = Math.max(a.getZ(), b.getZ()) + 8;
			int minY = Math.min(a.getY(), b.getY()) - 8;
			int maxY = Math.max(a.getY(), b.getY()) + 16;
			pathFinder = new PathFinder(world,
					new BlockPos(minX, minY, minZ), new BlockPos(maxX, maxY, maxZ));
			pathWorld = world;
		}
		return pathFinder;
	}

	/** Найти один блок прямо над головой, который мешает стоять/ползти. */
	private BlockPos findHeadObstruction(ClientPlayerEntity player, ClientWorld world) {
		BlockPos head = BlockPos.ofFloored(
				player.getX(), player.getBoundingBox().maxY, player.getZ()).up();
		BlockState state = world.getBlockState(head);
		if (state.isAir() || !state.getFluidState().isEmpty()) {
			return null;
		}
		boolean leaves = state.getBlock() instanceof LeavesBlock;
		boolean crawling = player.getPose() == EntityPose.SWIMMING;
		return leaves || crawling ? head : null;
	}

	private void ensureSmoothRotation(ClientPlayerEntity player) {
		if (hasSmoothRotation) return;
		smoothYaw = player.getYaw();
		smoothPitch = player.getPitch();
		hasSmoothRotation = true;
		aimStartedAtNanos = System.nanoTime();
		aimPhase = (System.nanoTime() % 100000L) / 100000.0;
	}

	/** Плавно обновлять настоящий угол камеры к точке саженца. */
	private void updateContinuousAim(ClientPlayerEntity player, Vec3d target) {
		float[] rotation = rotationTo(player.getEyePos(), target);
		desiredYaw = rotation[0];
		desiredPitch = rotation[1];
		ensureSmoothRotation(player);
		advanceSmoothRotation(player);
		continuousAim = true;
	}

	/** Шаг как у Legit-поворота AttackAura с мягкими колебаниями. */
	private void advanceSmoothRotation(ClientPlayerEntity player) {
		if (!hasSmoothRotation) return;

		double seconds = (System.nanoTime() - aimStartedAtNanos) / 1_000_000_000.0;
		// Небольшое «дыхание» прицела: движение синусоидальное,
		// поэтому нет белого шума и резких скачков. Оно применяется
		// только к реальному TreeFarm-повороту, не к Baritone.
		float wobbleYaw = (float) (Math.sin(seconds * Math.PI * 1.35 + aimPhase) * 0.65
				+ Math.sin(seconds * Math.PI * 0.67 + aimPhase * 1.7) * 0.18);
		float wobblePitch = (float) (Math.cos(seconds * Math.PI * 1.10 + aimPhase * 0.8) * 0.32);
		float aimYaw = desiredYaw + wobbleYaw;
		float aimPitch = desiredPitch + wobblePitch;

		float yawError = MathHelper.wrapDegrees(aimYaw - smoothYaw);
		float pitchError = aimPitch - smoothPitch;
		float yawStep = MathHelper.clamp(yawError * 0.24f, -7.0f, 7.0f);
		float pitchStep = MathHelper.clamp(pitchError * 0.24f, -4.0f, 4.0f);
		smoothYaw = Math.abs(yawError) < 0.25f ? aimYaw : smoothYaw + yawStep;
		smoothPitch = Math.abs(pitchError) < 0.25f
				? aimPitch
				: MathHelper.clamp(smoothPitch + pitchStep, -90.0f, 90.0f);

		spoofYaw = smoothYaw;
		spoofPitch = smoothPitch;
		// Это настоящий локальный взгляд: камера и сервер получают
		// один и тот же yaw/pitch.
		player.setYaw(smoothYaw);
		player.setPitch(smoothPitch);
		// Для действия допускаем только небольшую ошибку до исходной
		// точки, а колебание остаётся внутри этого допуска.
		rotationReady = Math.abs(MathHelper.wrapDegrees(desiredYaw - smoothYaw)) < 1.8f
				&& Math.abs(desiredPitch - smoothPitch) < 1.8f;
	}

	/** Запланировать действие после плавного реального поворота камеры. */
	private void queueServerAction(PendingAction action, BlockPos pos,
			BlockHitResult hit, ClientPlayerEntity player) {
		if (pendingAction != PendingAction.NONE) {
			return;
		}
		float[] rotation = rotationTo(player.getEyePos(), hit.getPos());
		desiredYaw = rotation[0];
		desiredPitch = rotation[1];
		ensureSmoothRotation(player);
		advanceSmoothRotation(player);
		pendingAction = action;
		pendingActionPos = pos;
		pendingActionHit = hit;
		if (action == PendingAction.BONE_MEAL) {
			continuousAim = true;
		}
		visualSpoofTicks = 2;
	}

	/**
	 * Выполняется после того, как реальный поворот камеры уже плавно
	 * достиг нужной точки. Сначала отправляем серверу обычный пакет
	 * текущего yaw/pitch, затем выполняем interact/attack.
	 */
	public void performPendingAction(MinecraftClient client, ClientPlayerEntity player) {
		if (pendingAction == PendingAction.NONE || !rotationReady) {
			return;
		}
		PendingAction action = pendingAction;
		BlockPos actionPos = pendingActionPos;
		BlockHitResult actionHit = pendingActionHit;
		pendingAction = PendingAction.NONE;
		pendingActionPos = null;
		pendingActionHit = null;

		try {
			if (client.world != null && client.interactionManager != null
					&& actionPos != null && actionHit != null) {
				switch (action) {
					case PLANT -> {
						if (client.world.getBlockState(plantingPos).isAir()) {
							client.interactionManager.interactBlock(player, Hand.MAIN_HAND, actionHit);
							state = State.GROWING;
						}
					}
					case BONE_MEAL -> {
						if (client.world.getBlockState(plantingPos).isOf(Blocks.OAK_SAPLING)) {
							client.interactionManager.interactBlock(player, Hand.MAIN_HAND, actionHit);
							lastBoneMealAt = System.currentTimeMillis();
						}
					}
					case HEAD_START -> {
						if (headClearPos != null && !client.world.getBlockState(headClearPos).isAir()) {
							client.interactionManager.attackBlock(headClearPos, Direction.DOWN);
							headClearTicks++;
						}
					}
					case HEAD_PROGRESS -> {
						if (headClearPos != null && !client.world.getBlockState(headClearPos).isAir()) {
							client.interactionManager.updateBlockBreakingProgress(headClearPos, Direction.DOWN);
							headClearTicks++;
						}
					}
					default -> { }
				}
			}
		} finally {
			if (action == PendingAction.BONE_MEAL) {
				// Камера уже настоящая и остаётся направленной на саженец
				// между применениями костной муки.
				continuousAim = true;
			} else {
				// Для посадки и ломания возвращаем настоящий обзор отдельным
				// обычным пакетом. В F5 рабочий угол останется на пару кадров.
				continuousAim = false;
				if (player.networkHandler != null) {
					float realYaw = player.getYaw();
					float realPitch = player.getPitch();
					player.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(
							realYaw, realPitch, player.isOnGround(), player.horizontalCollision));
				}
			}
			visualSpoofTicks = 2;
		}
	}

	/** Ломает блок над головой напрямую, не трогая остальные блоки. */
	private void clearHeadBlock(MinecraftClient client, ClientPlayerEntity player, ClientWorld world) {
		if (headClearPos == null) {
			state = resumeAfterHeadClear;
			return;
		}
		BlockState block = world.getBlockState(headClearPos);
		if (block.isAir() || !block.getFluidState().isEmpty()) {
			if (mc.interactionManager != null) {
				mc.interactionManager.cancelBlockBreaking();
			}
			headClearPos = null;
			headClearTicks = 0;
			state = resumeAfterHeadClear;
			return;
		}

		// Блок прямо над головой всегда в пределах руки: листва и всё
		// остальное ломается одной и той же серверной процедурой для
		// одного конкретного блока. Камень, землю и прочее ферма ломает
		// только здесь — при освобождении головы.
		if (pendingAction != PendingAction.NONE) {
			return;
		}
		Vec3d hitPos = Vec3d.ofCenter(headClearPos).add(0.0, -0.5, 0.0);
		BlockHitResult hit = new BlockHitResult(hitPos, Direction.DOWN, headClearPos, false);
		queueServerAction(headClearTicks == 0 ? PendingAction.HEAD_START : PendingAction.HEAD_PROGRESS,
				headClearPos, hit, player);
		if (headClearTicks > 40) {
			client.interactionManager.cancelBlockBreaking();
			headClearPos = null;
			headClearTicks = 0;
			state = resumeAfterHeadClear;
		}
	}

	private void sell(MinecraftClient client, ClientPlayerEntity player) {
		if (!sellArmed || !hasFullStack(player, Items.OAK_LOG)) {
			state = State.PREPARE;
			return;
		}
		if (!selectFullStackInHand(client, player, Items.OAK_LOG)) {
			return;
		}

		String rawPrice = price.get() == null ? "" : price.get().trim().replace("_", "");
		if (!rawPrice.matches("[0-9]{1,16}")) {
			stopWithMessage("TreeFarm: цена должна содержать только цифры");
			return;
		}
		ClientPlayNetworkHandler handler = client.getNetworkHandler();
		if (handler == null) return;
		try {
			handler.sendChatCommand("ah sell " + Long.parseLong(rawPrice));
			sellArmed = false;
			sellCooldownUntil = System.currentTimeMillis() + SELL_COOLDOWN_MS;
			state = State.PREPARE;
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] TreeFarm: ошибка команды продажи", t);
			stopWithMessage("TreeFarm: не удалось отправить /ah sell");
		}
	}

	/** Доставить предмет в руку с обычным серверным свапом. */
	private boolean selectItemInHand(MinecraftClient client, ClientPlayerEntity player,
			net.minecraft.item.Item item) {
		if (player.getMainHandStack().isOf(item)) {
			return true;
		}
		if (SwapPause.isBusy()) {
			return false;
		}

		int hotbarSlot = -1;
		for (int i = 0; i < 9; i++) {
			if (player.getInventory().getStack(i).isOf(item)) {
				hotbarSlot = i;
				break;
			}
		}
		if (hotbarSlot >= 0) {
			InventoryUtil.selectSlot(player, hotbarSlot, client.interactionManager);
			return false;
		}

		int inventorySlot = -1;
		for (int i = 9; i <= 35; i++) {
			if (player.getInventory().getStack(i).isOf(item)) {
				inventorySlot = i;
				break;
			}
		}
		if (inventorySlot < 0) return false;

		int selected = player.getInventory().getSelectedSlot();
		int emptyHotbar = -1;
		for (int i = 0; i < 9; i++) {
			if (player.getInventory().getStack(i).isEmpty()) {
				emptyHotbar = i;
				break;
			}
		}
		int targetHotbar = emptyHotbar >= 0 ? emptyHotbar : selected;
		if (SwapUtil.swapToHotbar(client, player, inventorySlot, targetHotbar)) {
			InventoryUtil.selectSlot(player, targetHotbar, client.interactionManager);
		}
		return false;
	}

	private boolean selectFullStackInHand(MinecraftClient client, ClientPlayerEntity player,
			net.minecraft.item.Item item) {
		if (player.getMainHandStack().isOf(item) && player.getMainHandStack().getCount() >= 64) {
			return true;
		}
		if (SwapPause.isBusy()) return false;

		for (int i = 0; i < 9; i++) {
			if (player.getInventory().getStack(i).isOf(item)
					&& player.getInventory().getStack(i).getCount() >= 64) {
				InventoryUtil.selectSlot(player, i, client.interactionManager);
				return false;
			}
		}
		for (int i = 9; i <= 35; i++) {
			if (player.getInventory().getStack(i).isOf(item)
					&& player.getInventory().getStack(i).getCount() >= 64) {
				int selected = player.getInventory().getSelectedSlot();
				int targetHotbar = -1;
				for (int hotbar = 0; hotbar < 9; hotbar++) {
					if (player.getInventory().getStack(hotbar).isEmpty()) {
						targetHotbar = hotbar;
						break;
					}
				}
				if (targetHotbar < 0) targetHotbar = selected;
				if (SwapUtil.swapToHotbar(client, player, i, targetHotbar)) {
					InventoryUtil.selectSlot(player, targetHotbar, client.interactionManager);
				}
				return false;
			}
		}
		return false;
	}

	/**
	 * Бот сейчас крутит «серверную» голову: идёт по пути (Walker) или
	 * целится в бревно, которое ломает. Работает так же, как AutoWarden:
	 * камера от первого лица не крутится.
	 */
	public boolean isSpoofing() {
		if (!isEnabled() || mc.player == null) {
			return false;
		}
		if (breakTargetPos != null) {
			return true;
		}
		return walker != null && walker.isSpoofing();
	}

	/** Угол для серверного пакета и отображения тела в F5. */
	public float getSpoofYaw() {
		if (breakTargetPos != null) {
			return botYaw;
		}
		return walker != null ? walker.getSpoofYaw() : mc.player != null ? mc.player.getYaw() : 0.0f;
	}

	public float getSpoofPitch() {
		if (breakTargetPos != null) {
			return botPitch;
		}
		return walker != null ? walker.getSpoofPitch() : mc.player != null ? mc.player.getPitch() : 0.0f;
	}

	private int countItem(ClientPlayerEntity player, net.minecraft.item.Item item) {
		int count = 0;
		PlayerInventory inventory = player.getInventory();
		for (int i = 0; i <= 35; i++) {
			ItemStack stack = inventory.getStack(i);
			if (stack.isOf(item)) count += stack.getCount();
		}
		return count;
	}

	private boolean hasFullStack(ClientPlayerEntity player, net.minecraft.item.Item item) {
		for (int i = 0; i <= 35; i++) {
			ItemStack stack = player.getInventory().getStack(i);
			if (stack.isOf(item) && stack.getCount() >= 64) return true;
		}
		return false;
	}

	private boolean hasRequiredResources(ClientPlayerEntity player) {
		return countItem(player, Items.OAK_SAPLING) >= REQUIRED_SAPLINGS
				&& countItem(player, Items.BONE_MEAL) >= REQUIRED_BONE_MEAL;
	}

	private BlockPos findChest(ClientWorld world, BlockPos center, int radius) {
		BlockPos best = null;
		double bestDistance = Double.MAX_VALUE;
		for (int dx = -radius; dx <= radius; dx++) {
			for (int dy = -radius; dy <= radius; dy++) {
				for (int dz = -radius; dz <= radius; dz++) {
					BlockPos pos = center.add(dx, dy, dz);
					if (!(world.getBlockState(pos).getBlock() instanceof net.minecraft.block.ChestBlock)) {
						continue;
					}
					double distance = pos.getSquaredDistance(center);
					if (distance <= radius * radius && distance < bestDistance) {
						best = pos;
						bestDistance = distance;
					}
				}
			}
		}
		return best;
	}

	/** Проверяем область одного дерева: ствол и ветки до 3 блоков в стороны. */
	private boolean hasTreeLogs(ClientWorld world, BlockPos base) {
		for (int dx = -3; dx <= 3; dx++) {
			for (int dy = 0; dy <= 10; dy++) {
				for (int dz = -3; dz <= 3; dz++) {
					if (isOakLog(world.getBlockState(base.add(dx, dy, dz)))) {
						return true;
					}
				}
			}
		}
		return false;
	}

	private boolean isOakLog(BlockState state) {
		return state.isOf(Blocks.OAK_LOG);
	}

	/** Рассчитать yaw/pitch от глаз игрока к точке действия. */
	private static float[] rotationTo(Vec3d eye, Vec3d target) {
		double dx = target.x - eye.x;
		double dy = target.y - eye.y;
		double dz = target.z - eye.z;
		float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0f;
		float pitch = (float) -Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz)));
		pitch = Math.max(-90.0f, Math.min(90.0f, pitch));
		return new float[]{yaw, pitch};
	}

	/** Доступ к модулю из AuraTickSpoofMixin и PlayerBodyRendererMixin. */
	public static TreeFarmModule active() {
		NeuClient client = NeuClient.getInstance();
		if (client == null || client.getModuleManager() == null) {
			return null;
		}
		TreeFarmModule module = client.getModuleManager().get(TreeFarmModule.class);
		return module != null && module.isEnabled() ? module : null;
	}

	private void stopWithMessage(String message) {
		ChatUtil.error(message);
		setEnabled(false);
	}
}
