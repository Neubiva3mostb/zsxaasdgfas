package ru.neuclient.client.ui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import ru.neuclient.client.bot.BotManager;
import ru.neuclient.client.bot.BotManager.BotStatus;
import ru.neuclient.client.font.MsdfFont;
import ru.neuclient.client.font.MsdfFontRenderer;
import ru.neuclient.client.font.MsdfFonts;
import ru.neuclient.client.util.NeuSounds;
import ru.neuclient.client.util.RenderUtil;
import ru.neuclient.client.util.ScaleUtil;

import java.util.List;

/**
 * Менеджер ботов: слева список ников (добавить / удалить / запустить),
 * справа карточка выбранного бота — HP, координаты, сервер, инвентарь.
 * Открывается кнопкой «Боты» из ClickGUI.
 */
public class BotManagerScreen extends Screen {

    private static final int W = 420;
    private static final int H = 336;
    private static final int DETAILS_H = 280;
    private static final int LEFT_W = 150;
    private static final int PAD = 8;
    private static final int ROW_H = 18;
    private static final int BTN_H = 14;
    private static final float F = 8.0f;
    private static final float FS = 6.5f;

    private final Screen parent;
    private String selected;
    private String input = "";
    private boolean inputFocused;
    private String proxyInput = "";
    private boolean proxyFocused;
    private String proxyFor;
    private String groupInput = "";
    private boolean groupFocused;
    private float alpha = 0f;
    private boolean closing;
    private long lastMs = System.currentTimeMillis();
    private int scroll;

    public BotManagerScreen(Screen parent) {
        super(Text.literal("AutoWarden Bots"));
        this.parent = parent;
        List<String> nicks = BotManager.getInstance().getSavedNicks();
        if (!nicks.isEmpty()) selected = nicks.get(0);
    }

    // ---------- геометрия ----------
    private int x0() { return (ScaleUtil.getVirtualWidth() - W) / 2; }
    private int y0() { return (ScaleUtil.getVirtualHeight() - H) / 2; }
    private int rightX() { return x0() + LEFT_W + PAD; }
    private int rightW() { return W - LEFT_W - PAD * 2; }
    private int listTop() { return y0() + 30; }
    private int listBottom() { return y0() + DETAILS_H - PAD - 2 * BTN_H - 10; }
    private int visibleRows() { return Math.max(1, (listBottom() - listTop()) / ROW_H); }

    private static boolean in(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private int a(int color) {
        int base = color >>> 24;
        if (base == 0) base = 255;
        return (Math.max(0, Math.min(255, (int) (base * alpha))) << 24) | (color & 0xFFFFFF);
    }

    private void txt(DrawContext ctx, String s, float x, float y, int color, float size) {
        MsdfFontRenderer.drawWithShadow(ctx, MsdfFonts.sfRegular(), s, x, y, a(color), size);
    }

    private void txtC(DrawContext ctx, String s, float cx, float y, int color, float size) {
        float w = MsdfFontRenderer.getWidth(MsdfFonts.sfRegular(), s, size);
        txt(ctx, s, cx - w / 2f, y, color, size);
    }

    private float tw(String s, float size) {
        return MsdfFontRenderer.getWidth(MsdfFonts.sfRegular(), s, size);
    }

    private void button(DrawContext ctx, int x, int y, int w, int h, String label, int mx, int my, int fill, boolean enabled) {
        boolean hover = enabled && in(mx, my, x, y, w, h);
        int c = enabled ? (hover ? RenderUtil.shade(fill, 1.2f) : fill) : 0xFF2A2A34;
        RenderUtil.roundRect(ctx, x, y, w, h, 3, a(c));
        txtC(ctx, label, x + w / 2f, y + (h - FS) / 2f - 0.5f, enabled ? RenderUtil.TEXT : 0xFF6A6A78, FS);
    }

    // ---------- рендер ----------
    @Override
    public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
        if (client.world != null) ctx.applyBlur();
        ctx.fill(0, 0, width, height, a(0x90000000));
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        long now = System.currentTimeMillis();
        float dt = Math.min((now - lastMs) / 1000f, 0.1f);
        lastMs = now;
        if (closing) {
            alpha = Math.max(0f, alpha - dt * 6f);
            if (alpha <= 0f) { client.setScreen(parent); return; }
        } else {
            alpha = Math.min(1f, alpha + dt * 6f);
        }

        ScaleUtil.begin(ctx);
        try {
        int vmx = (int) ScaleUtil.toVirtualX(mx);
        int vmy = (int) ScaleUtil.toVirtualY(my);

        BotManager bm = BotManager.getInstance();
        int accent = RenderUtil.accent();
        int x = x0(), y = y0();

        // Подложки
        RenderUtil.roundRect(ctx, x - 4, y - 4, W + 8, H + 8, 8, a(0xF0121218));
        RenderUtil.roundRect(ctx, x, y, LEFT_W, DETAILS_H, 6, a(0xFF1A1A22));
        RenderUtil.roundRect(ctx, rightX(), y, rightW() + PAD, DETAILS_H, 6, a(0xFF1A1A22));

        // ===== Левая колонка =====
        txt(ctx, "Боты", x + PAD, y + PAD, RenderUtil.TEXT, F + 1);
        txt(ctx, bm.getSavedNicks().size() + " ников", x + LEFT_W - PAD - tw(bm.getSavedNicks().size() + " ников", FS), y + PAD + 2, RenderUtil.textDim(), FS);

        List<String> nicks = bm.getSavedNicks();
        int rows = visibleRows();
        scroll = Math.max(0, Math.min(scroll, Math.max(0, nicks.size() - rows)));
        int ry = listTop();
        for (int i = scroll; i < nicks.size() && i < scroll + rows; i++) {
            String nick = nicks.get(i);
            boolean sel = nick.equalsIgnoreCase(selected);
            boolean running = bm.isRunning(nick);
            boolean joined = bm.isJoined(nick);
            int rowX = x + 4, rowW = LEFT_W - 8;
            if (sel) RenderUtil.roundRect(ctx, rowX, ry, rowW, ROW_H - 2, 3, a(0xFF26262F));
            else if (in(vmx, vmy, rowX, ry, rowW, ROW_H - 2)) RenderUtil.roundRect(ctx, rowX, ry, rowW, ROW_H - 2, 3, a(0xFF202028));
            // индикатор
            int dot = running ? (joined ? accent : 0xFF4CD964) : 0xFF555560;
            RenderUtil.circle(ctx, rowX + 7, ry + (ROW_H - 2) / 2, 2f, a(dot));
            txt(ctx, nick, rowX + 14, ry + (ROW_H - 2 - F) / 2f - 0.5f, sel ? RenderUtil.TEXT : RenderUtil.textDim(), F);
            // кнопка запустить / стоп
            int bw = 44, bx = rowX + rowW - bw - 3, by = ry + (ROW_H - 2 - 11) / 2;
            String lbl = running ? "Стоп" : "Запустить";
            int fill = running ? 0xFF7A2E2E : RenderUtil.shade(accent, 0.55f);
            button(ctx, bx, by, bw, 11, lbl, vmx, vmy, fill, true);
            ry += ROW_H;
        }
        if (nicks.isEmpty()) {
            txtC(ctx, "Список пуст", x + LEFT_W / 2f, listTop() + 20, RenderUtil.textDim(), FS);
            txtC(ctx, "Введи ник и нажми +", x + LEFT_W / 2f, listTop() + 32, RenderUtil.textDim(), FS);
        }

        // Поле ввода + кнопки
        int by = y + DETAILS_H - PAD - BTN_H;
        int inW = LEFT_W - PAD * 2 - 20 - 3;
        int inX = x + PAD;
        RenderUtil.roundRect(ctx, inX, by, inW, BTN_H, 3, a(0xFF0F0F14));
        if (inputFocused) RenderUtil.roundBorderRect(ctx, inX, by, inW, BTN_H, 3, a(accent), a(0xFF0F0F14));
        String shown = input.isEmpty() && !inputFocused ? "ник бота…" : input;
        boolean caret = inputFocused && (System.currentTimeMillis() / 450) % 2 == 0;
        txt(ctx, shown + (caret ? "_" : ""), inX + 4, by + (BTN_H - FS) / 2f - 0.5f,
                input.isEmpty() && !inputFocused ? RenderUtil.textDim() : RenderUtil.TEXT, FS);
        button(ctx, inX + inW + 3, by, 20, BTN_H, "+", vmx, vmy, RenderUtil.shade(accent, 0.7f), !input.isBlank());
        // Удалить — над полем ввода
        button(ctx, x + PAD, by - BTN_H - 4, LEFT_W - PAD * 2, BTN_H, "Удалить выбранного", vmx, vmy, 0xFF3A2A2A, selected != null);

        renderGroup(ctx, vmx, vmy);

        // ===== Правая панель =====
        int rx = rightX() + PAD, rw = rightW() - PAD;
        if (selected == null) {
            txtC(ctx, "Выбери бота слева", rx + rw / 2f, y + DETAILS_H / 2f - 4, RenderUtil.textDim(), F);
            return;
        }
        boolean running = bm.isRunning(selected);
        boolean joined = bm.isJoined(selected);
        BotStatus st = bm.getStatus(selected);
        boolean ready = bm.isReady(selected);

        txt(ctx, selected, rx, y + PAD, RenderUtil.TEXT, F + 2);
        String state = !running ? "Не запущен" : joined ? "На экране" : !ready ? "Подключается…" : "В фоне";
        int stateCol = !running ? RenderUtil.textDim() : joined ? accent : 0xFF4CD964;
        txt(ctx, state, rx + rw - tw(state, FS), y + PAD + 3, stateCol, FS);

        // HP-бар
        int hy = y + PAD + 16;
        float hp = st == null ? 0 : st.health, mhp = st == null ? 20 : Math.max(1, st.maxHealth);
        String hpText = st == null ? "-- / --" : String.format("%.0f / %.0f", hp, mhp);
        txt(ctx, hpText, rx, hy, RenderUtil.textDim(), FS);
        int barX = rx + 44, barW = rw - 44;
        RenderUtil.roundRect(ctx, barX, hy + 2, barW, 4, 2, a(0xFF2A2A34));
        if (st != null) {
            int hpCol = hp / mhp > 0.5f ? 0xFF4CD964 : hp / mhp > 0.25f ? 0xFFFFC107 : 0xFFFF5252;
            RenderUtil.roundRect(ctx, barX, hy + 2, Math.max(2, (int) (barW * Math.min(1f, hp / mhp))), 4, 2, a(hpCol));
        }

        // Инфо-карточки
        int cy = hy + 14;
        int cw = (rw - 4) / 2, ch = 24;
        String coords = st == null ? "—" : String.format("%.0f  %.0f  %.0f", st.x, st.y, st.z);
        String server = st == null || st.server.isEmpty() ? "—" : st.server;
        String dim = st == null || st.dimension.isEmpty() ? "—" : st.dimension;
        String hpCard = st == null ? "—" : String.format("%.1f / %.0f  (еда %d)", hp, mhp, st.food);
        card(ctx, rx, cy, cw, ch, "Координаты", coords);
        card(ctx, rx + cw + 4, cy, cw, ch, "Сервер", server);
        card(ctx, rx, cy + ch + 4, cw, ch, "Мир", dim);
        card(ctx, rx + cw + 4, cy + ch + 4, cw, ch, "Хп", hpCard);

        // Прокси (socks5 ip:port[:login:pass]) — применяется при следующем запуске
        int py = cy + (ch + 4) * 2;
        if (!selected.equalsIgnoreCase(proxyFor)) { proxyFor = selected; proxyInput = bm.getProxy(selected); proxyFocused = false; }
        txt(ctx, "Прокси", rx, py + (BTN_H - FS) / 2f - 0.5f, RenderUtil.textDim(), FS);
        int pfX = rx + 34, pfW = rw - 34;
        RenderUtil.roundRect(ctx, pfX, py, pfW, BTN_H, 3, a(0xFF0F0F14));
        if (proxyFocused) RenderUtil.roundBorderRect(ctx, pfX, py, pfW, BTN_H, 3, a(accent), a(0xFF0F0F14));
        boolean pEmpty = proxyInput.isEmpty() && !proxyFocused;
        String pShown = pEmpty ? "ip:port  или  ip:port:login:pass  (Enter — сохранить)" : proxyInput;
        boolean pCaret = proxyFocused && (System.currentTimeMillis() / 450) % 2 == 0;
        ctx.enableScissor(pfX + 2, py, pfX + pfW - 2, py + BTN_H);
        txt(ctx, pShown + (pCaret ? "_" : ""), pfX + 4, py + (BTN_H - FS) / 2f - 0.5f,
                pEmpty ? RenderUtil.textDim() : RenderUtil.TEXT, FS);
        ctx.disableScissor();

        // Инвентарь
        int iy = py + BTN_H + 4;
        txt(ctx, "Инвентарь", rx, iy, RenderUtil.textDim(), FS);
        iy += 10;
        int cell = 17, gap = 1;
        int gridW = 9 * (cell + gap);
        int gx = rx + (rw - gridW) / 2;
        // броня + левая рука ряд
        for (int i = 0; i < 4; i++) slot(ctx, gx + i * (cell + gap), iy, cell, st, 39 - i);
        slot(ctx, gx + 8 * (cell + gap), iy, cell, st, 40);
        iy += cell + 3;
        for (int r = 0; r < 3; r++)
            for (int c = 0; c < 9; c++)
                slot(ctx, gx + c * (cell + gap), iy + r * (cell + gap), cell, st, 9 + r * 9 + c);
        iy += 3 * (cell + gap) + 2;
        for (int c = 0; c < 9; c++) slot(ctx, gx + c * (cell + gap), iy, cell, st, c);

        String orderResult = bm.groupResult(selected);
        clipped(ctx, orderResult, rx, y + DETAILS_H - PAD - BTN_H - 16, rw, FS, RenderUtil.textDim());

        // Кнопки действий
        int aby = y + DETAILS_H - PAD - BTN_H;
        int abw = (rw - 8) / 3;
        button(ctx, rx, aby, abw, BTN_H, running ? "Остановить" : "Запустить", vmx, vmy,
                running ? 0xFF7A2E2E : RenderUtil.shade(accent, 0.6f), true);
        button(ctx, rx + abw + 4, aby, abw, BTN_H, "На экран", vmx, vmy, RenderUtil.shade(accent, 0.6f), running && ready && !joined);
        button(ctx, rx + (abw + 4) * 2, aby, abw, BTN_H, "Вернуться", vmx, vmy, 0xFF34343E, joined);

        } finally { ScaleUtil.end(ctx); }
    }

    private int groupY() { return y0() + DETAILS_H + 6; }
    private void clipped(DrawContext ctx, String text, int x, int y, int width, float size, int color) {
        ctx.enableScissor(x, y - 1, x + width, y + 11);
        try { txt(ctx, text, x, y, color, size); } finally { ctx.disableScissor(); }
    }
    private void renderGroup(DrawContext ctx, int mx, int my) {
        BotManager bm = BotManager.getInstance();
        int x = x0(), y = groupY(), accent = RenderUtil.accent();
        boolean parent = !bm.isChildBot(), ready = parent && bm.readyGroupCount() > 0;
        RenderUtil.roundRect(ctx, x, y, W, H - DETAILS_H - 6, 6, a(0xFF1A1A22));
        button(ctx, x + PAD, y + 7, 138, BTN_H, bm.hasFollowers() ? "Следуют за главным" : "Всем к главному", mx, my, RenderUtil.shade(accent, 0.65f), ready);
        button(ctx, x + 152, y + 7, 114, BTN_H, "Стоп движения", mx, my, 0xFF7A2E2E, parent && (ready || bm.hasFollowers()));
        txt(ctx, "Готовы: " + bm.readyGroupCount(), x + 278, y + 10, RenderUtil.textDim(), FS);
        int fy = y + 27, fw = W - PAD * 2 - 100;
        RenderUtil.roundRect(ctx, x + PAD, fy, fw, BTN_H, 3, a(0xFF0F0F14));
        if (groupFocused) RenderUtil.roundBorderRect(ctx, x + PAD, fy, fw, BTN_H, 3, a(accent), a(0xFF0F0F14));
        String shown = groupInput.isEmpty() && !groupFocused ? "/spawn или сообщение…" : groupInput;
        boolean caret = groupFocused && (System.currentTimeMillis() / 450) % 2 == 0;
        // Tail follows the caret; the full command is kept in memory, never stored in config/logs.
        while (tw(shown + "_", FS) > fw - 10 && shown.length() > 1) shown = shown.substring(shown.offsetByCodePoints(0, 1));
        clipped(ctx, shown + (caret ? "_" : ""), x + PAD + 4, fy + 3, fw - 8, FS, RenderUtil.TEXT);
        button(ctx, x + W - PAD - 96, fy, 96, BTN_H, "Отправить всем", mx, my, RenderUtil.shade(accent, 0.65f), ready && !groupInput.isBlank());
    }
    private void notifyGroup(String message) {
        if (!message.startsWith("Отправлено ботам:")) ru.neuclient.client.util.ChatUtil.error(message);
    }
    private void submitGroup() {
        notifyGroup(BotManager.getInstance().sendAll(groupInput));
        NeuSounds.play(NeuSounds.SETTINGS);
    }
    private void appendGroup(String add) {
        if (add == null) return;
        if (add.codePoints().anyMatch(c -> Character.isISOControl(c) || c == 0xA7 || c == 0x2028 || c == 0x2029)) {
            notifyGroup("Вставка отклонена: нужна одна строка без управляющих символов"); return;
        }
        if (groupInput.length() + add.length() > 256) { notifyGroup("Максимум 256 символов; вставка не применена"); return; }
        groupInput += add;
    }

    private void card(DrawContext ctx, int x, int y, int w, int h, String title, String value) {
        RenderUtil.roundRect(ctx, x, y, w, h, 3, a(0xFF22222B));
        txtC(ctx, title, x + w / 2f, y + 3, RenderUtil.textDim(), FS - 0.5f);
        String v = value;
        while (tw(v, FS) > w - 6 && v.length() > 3) v = v.substring(0, v.length() - 2) + "…";
        txtC(ctx, v, x + w / 2f, y + h - FS - 3, RenderUtil.TEXT, FS);
    }

    private void slot(DrawContext ctx, int x, int y, int size, BotStatus st, int index) {
        RenderUtil.roundRect(ctx, x, y, size, size, 2, a(0xFF22222B));
        if (st == null || index < 0 || index >= st.inv.length) return;
        ItemStack stack = st.inv[index];
        if (stack == null || stack.isEmpty()) return;
        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().translate(x + (size - 16) / 2f, y + (size - 16) / 2f);
        ctx.drawItem(stack, 0, 0);
        ctx.drawStackOverlay(client.textRenderer, stack, 0, 0);
        ctx.getMatrices().popMatrix();
    }

    // ---------- ввод ----------
    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (alpha < 0.9f) return true;
        double mx = ScaleUtil.toVirtualX(click.x());
        double my = ScaleUtil.toVirtualY(click.y());
        if (click.button() != 0) return super.mouseClicked(click, doubled);
        BotManager bm = BotManager.getInstance();
        int x = x0(), y = y0();

        int gy = groupY();
        groupFocused = !bm.isChildBot() && in(mx, my, x + PAD, gy + 27, W - PAD * 2 - 100, BTN_H);
        if (in(mx, my, x, gy, W, H - DETAILS_H - 6)) {
            inputFocused = false;
            if (proxyFocused) { proxyFocused = false; commitProxy(); }
            if (!bm.isChildBot()) {
                if (in(mx, my, x + PAD, gy + 7, 138, BTN_H) && bm.readyGroupCount() > 0) notifyGroup(bm.rallyAll());
                else if (in(mx, my, x + 152, gy + 7, 114, BTN_H)) notifyGroup(bm.stopAllRallies());
                else if (in(mx, my, x + W - PAD - 96, gy + 27, 96, BTN_H) && !groupInput.isBlank()) submitGroup();
            }
            return true;
        }

        // поле ввода
        int by = y + DETAILS_H - PAD - BTN_H;
        int inW = LEFT_W - PAD * 2 - 20 - 3;
        int inX = x + PAD;
        if (in(mx, my, inX, by, inW, BTN_H)) { inputFocused = true; if (proxyFocused) { proxyFocused = false; commitProxy(); } return true; }
        inputFocused = false;
        if (in(mx, my, inX + inW + 3, by, 20, BTN_H)) { submitAdd(); return true; }
        if (in(mx, my, x + PAD, by - BTN_H - 4, LEFT_W - PAD * 2, BTN_H) && selected != null) {
            bm.removeNick(selected);
            List<String> n = bm.getSavedNicks();
            selected = n.isEmpty() ? null : n.get(0);
            NeuSounds.play(NeuSounds.SETTINGS);
            return true;
        }

        // список
        List<String> nicks = bm.getSavedNicks();
        int rows = visibleRows();
        int ry = listTop();
        for (int i = scroll; i < nicks.size() && i < scroll + rows; i++) {
            String nick = nicks.get(i);
            int rowX = x + 4, rowW = LEFT_W - 8;
            int bw = 44, bx = rowX + rowW - bw - 3, bby = ry + (ROW_H - 2 - 11) / 2;
            if (in(mx, my, bx, bby, bw, 11)) {
                toggleRun(nick);
                return true;
            }
            if (in(mx, my, rowX, ry, rowW, ROW_H - 2)) {
                if (proxyFocused) { proxyFocused = false; commitProxy(); }
                selected = nick;
                NeuSounds.play(NeuSounds.TAB);
                return true;
            }
            ry += ROW_H;
        }

        // правые кнопки
        if (selected != null) {
            int rx = rightX() + PAD, rw = rightW() - PAD;
            int pfY = y + PAD + 16 + 14 + (24 + 4) * 2;
            if (in(mx, my, rx + 34, pfY, rw - 34, BTN_H)) { proxyFocused = true; return true; }
            if (proxyFocused) { proxyFocused = false; commitProxy(); }
            int aby = y + DETAILS_H - PAD - BTN_H;
            int abw = (rw - 8) / 3;
            boolean running = bm.isRunning(selected);
            boolean joined = bm.isJoined(selected);
            if (in(mx, my, rx, aby, abw, BTN_H)) { toggleRun(selected); return true; }
            if (in(mx, my, rx + abw + 4, aby, abw, BTN_H) && running && !joined && bm.isReady(selected)) {
                NeuSounds.play(NeuSounds.BIND);
                bm.joinBot(selected);
                return true;
            }
            if (in(mx, my, rx + (abw + 4) * 2, aby, abw, BTN_H) && joined) {
                bm.joinBot("main");
                return true;
            }
        }

        if (!in(mx, my, x - 4, y - 4, W + 8, H + 8)) closing = true;
        return true;
    }

    private void toggleRun(String nick) {
        BotManager bm = BotManager.getInstance();
        if (bm.isRunning(nick)) {
            bm.stopBot(nick);
            NeuSounds.toggle(false);
        } else {
            bm.startBot(nick);
            NeuSounds.toggle(true);
        }
    }

    private void commitProxy() {
        if (proxyFor == null) return;
        BotManager.getInstance().setProxy(proxyFor, proxyInput);
        proxyInput = BotManager.getInstance().getProxy(proxyFor);
        NeuSounds.play(NeuSounds.SETTINGS);
    }

    private void submitAdd() {
        if (BotManager.getInstance().addNick(input)) {
            selected = input.trim();
            input = "";
            NeuSounds.play(NeuSounds.BIND);
        } else {
            NeuSounds.play(NeuSounds.SETTINGS);
        }
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double h, double v) {
        double vmx = ScaleUtil.toVirtualX(mx);
        double vmy = ScaleUtil.toVirtualY(my);
        if (in(vmx, vmy, x0(), listTop(), LEFT_W, listBottom() - listTop())) {
            scroll -= (int) Math.signum(v);
            return true;
        }
        return super.mouseScrolled(mx, my, h, v);
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        int code = input.key();
        if (groupFocused) {
            if (code == GLFW.GLFW_KEY_BACKSPACE && !groupInput.isEmpty()) groupInput = groupInput.substring(0, groupInput.offsetByCodePoints(groupInput.length(), -1));
            else if (code == GLFW.GLFW_KEY_ENTER || code == GLFW.GLFW_KEY_KP_ENTER) submitGroup();
            else if (code == GLFW.GLFW_KEY_ESCAPE) groupFocused = false;
            else if ((input.modifiers() & GLFW.GLFW_MOD_CONTROL) != 0 && code == GLFW.GLFW_KEY_V) appendGroup(client.keyboard.getClipboard());
            else if ((input.modifiers() & GLFW.GLFW_MOD_CONTROL) != 0 && code == GLFW.GLFW_KEY_A) groupInput = "";
            return true;
        }
        if (inputFocused) {
            if (code == GLFW.GLFW_KEY_BACKSPACE && !this.input.isEmpty()) {
                this.input = this.input.substring(0, this.input.length() - 1);
                return true;
            }
            if (code == GLFW.GLFW_KEY_ENTER || code == GLFW.GLFW_KEY_KP_ENTER) { submitAdd(); return true; }
            if (code == GLFW.GLFW_KEY_ESCAPE) { inputFocused = false; return true; }
            if (code == GLFW.GLFW_KEY_V && (input.modifiers() & GLFW.GLFW_MOD_CONTROL) != 0) {
                String clip = client.keyboard.getClipboard();
                if (clip != null) this.input = (this.input + clip.trim()).replaceAll("[^A-Za-z0-9_]", "");
                if (this.input.length() > 16) this.input = this.input.substring(0, 16);
                return true;
            }
            return true;
        }
        if (proxyFocused) {
            if (code == GLFW.GLFW_KEY_BACKSPACE && !proxyInput.isEmpty()) {
                proxyInput = proxyInput.substring(0, proxyInput.length() - 1);
                return true;
            }
            if (code == GLFW.GLFW_KEY_ENTER || code == GLFW.GLFW_KEY_KP_ENTER) { proxyFocused = false; commitProxy(); return true; }
            if (code == GLFW.GLFW_KEY_ESCAPE) { proxyFocused = false; proxyInput = BotManager.getInstance().getProxy(proxyFor); return true; }
            if (code == GLFW.GLFW_KEY_V && (input.modifiers() & GLFW.GLFW_MOD_CONTROL) != 0) {
                String clip = client.keyboard.getClipboard();
                if (clip != null) proxyInput = (proxyInput + clip.trim()).replaceAll("\\s", "");
                return true;
            }
            return true;
        }
        if (code == GLFW.GLFW_KEY_ESCAPE) { closing = true; return true; }
        return super.keyPressed(input);
    }

    @Override
    public boolean charTyped(CharInput input) {
        if (groupFocused) { if (input.isValidChar()) appendGroup(input.asString()); return true; }
        if (proxyFocused) {
            if (!input.isValidChar()) return false;
            String add = input.asString().replaceAll("\\s", "");
            if (proxyInput.length() < 96) proxyInput += add;
            return true;
        }
        if (!inputFocused) return false;
        if (!input.isValidChar()) return false;
        String add = input.asString().replaceAll("[^A-Za-z0-9_]", "");
        if (add.isEmpty() || this.input.length() >= 16) return true;
        this.input += add;
        return true;
    }

    @Override
    public boolean shouldPause() { return false; }

    @Override
    public void close() { closing = true; }
}
