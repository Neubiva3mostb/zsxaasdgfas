package ru.neuclient.client.render;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderSetup;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;
import ru.neuclient.client.mixin.RenderLayerAccessor;

/**
 * Текстурный слой для частиц (атлас textures/particles/atlas.png).
 *
 * Текстуры — Kenney «Particle Pack» (CC0): сердце, снежинка, шарик, искра
 * и мягкое гало. Всё белое, цвет и альфа приходят вершиной.
 *
 * Без теста глубины — частицы должны светиться и не прятаться за блоками,
 * как и раньше (геометрия тоже рисовалась поверх). Блендинг обычный
 * альфа-прозрачный: у текстур мягкие края, и этого хватает для свечения.
 */
public final class ParticleRenderLayer {

	/** Атлас частиц. */
	public static final Identifier ATLAS = Identifier.of("perfstream", "textures/particles/atlas.png");

	private static final RenderPipeline PIPELINE = RenderPipelines.register(
			RenderPipeline.builder()
					.withLocation(Identifier.of("perfstream", "pipeline/particles"))
					.withVertexShader(Identifier.of("perfstream", "core/particles"))
					.withFragmentShader(Identifier.of("perfstream", "core/particles"))
					.withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR, VertexFormat.DrawMode.QUADS)
					.withSampler("Sampler0")
					.withUniform("DynamicTransforms", UniformType.UNIFORM_BUFFER)
					.withUniform("Projection", UniformType.UNIFORM_BUFFER)
					.withBlend(BlendFunction.TRANSLUCENT)
					.withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
					.withCull(false)
					.withColorWrite(true, true)
					.build()
	);

	public static final RenderLayer LAYER = RenderLayerAccessor.pc$of(
			"neuclient_particles",
			RenderSetup.builder(PIPELINE)
					.texture("Sampler0", ATLAS)
					.build());

	/** Заставляет класс инициализироваться (регистрация пайплайна). */
	public static void touch() {
	}

	private ParticleRenderLayer() {
	}
}
