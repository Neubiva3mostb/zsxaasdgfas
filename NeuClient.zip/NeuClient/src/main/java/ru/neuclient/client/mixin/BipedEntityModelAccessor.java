package ru.neuclient.client.mixin;

import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/** Доступ к родительской body-части vanilla biped-модели. */
@Mixin(BipedEntityModel.class)
public interface BipedEntityModelAccessor {

	@Accessor("body")
	ModelPart pc$getBody();
}
