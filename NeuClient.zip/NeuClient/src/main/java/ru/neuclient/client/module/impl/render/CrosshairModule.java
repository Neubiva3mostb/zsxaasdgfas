package ru.neuclient.client.module.impl.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.BooleanSetting;
import ru.neuclient.client.setting.ColorSetting;
import ru.neuclient.client.setting.NumberSetting;

/**
 * Crosshair — кастомный прицел вместо ванильного крестика.
 * Четыре луча + опциональная точка, цвет на выбор (включая радугу и акцент
 * темы), а в режиме «Динамика» разрыв лучей «дышит»: расширяется от
 * скорости бега, прыжков и падения и собирается обратно в покое — как в
 * классических клиентах.
 */
public class CrosshairModule extends Module {

	private final ColorSetting color = new ColorSetting("Цвет", 0xFFFFFFFF);
	/** Длина каждого луча (px). */
	private final NumberSetting size = new NumberSetting("Размер", 3, 1, 12, 1);
	/** Толщина лучей (px). */
	private final NumberSetting thickness = new NumberSetting("Толщина", 1, 1, 4, 1);
	/** Базовый зазор между центром и лучами (px). */
	private final NumberSetting gap = new NumberSetting("Разрыв", 2, 0, 8, 1);
	/** Точка по центру. */
	private final BooleanSetting dot = new BooleanSetting("Точка", true);
	/** Дыхание разрыва от движения (скорость/прыжок/падение). */
	private final BooleanSetting dynamic = new BooleanSetting("Динамика", true);

	/** Плавно плавающий текущий зазор (деградация в покое). */
	private float smoothGap;

	public CrosshairModule() {
		super("Crosshair", "Кастомный прицел",
				Category.RENDER);
		addSettings(color, size, thickness, gap, dot, dynamic);
	}

	/** Отрисовка прицела (вызывает InGameHudCrosshairMixin вместо ванильного). */
	public void render(DrawContext ctx) {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc == null || mc.player == null) {
			return;
		}
		int cx = ctx.getScaledWindowWidth() / 2;
		int cy = ctx.getScaledWindowHeight() / 2;
		int s = size.get().intValue();
		int t = thickness.get().intValue();
		int halfT = t / 2;

		// Целевой зазор (динамика — от скорости и воздуха)
		float target = gap.get().floatValue();
		if (dynamic.get()) {
			double vx = mc.player.getVelocity().x;
			double vz = mc.player.getVelocity().z;
			float speedBonus = (float) Math.min(4.0, Math.hypot(vx, vz) * 20.0 * 0.35);
			float airBonus = mc.player.isOnGround() ? 0.0f : 2.0f;
			target += speedBonus + airBonus;
		}
		// Плавное сжатие/расширение (разная скорость вверх/вниз — отзывчиво)
		float k = target > smoothGap ? 0.35f : 0.18f;
		smoothGap += (target - smoothGap) * k;
		int g = Math.round(smoothGap);

		int color = resolveColor();

		// Прямоугольник центра (точка) — лучи откладываем СИММЕТРИЧНО от его
		// краёв. Раньше отсчёт шёл от cx: при нечётной толщине (1/3) зазор
		// слева/сверху получался на 1px больше, и лучи выглядели разной длины
		int x0 = cx - halfT;      // левый край точки
		int x1 = x0 + t;          // правый край (не включительно)
		int y0 = cy - halfT;      // верхний край точки
		int y1 = y0 + t;          // нижний край (не включительно)

		// Четыре луча: внутренний край ВСЕГДА в g пикселях от края точки,
		// длина каждого — ровно s
		ctx.fill(x0 - g - s, y0, x0 - g, y1, color); // левый
		ctx.fill(x1 + g, y0, x1 + g + s, y1, color); // правый
		ctx.fill(x0, y0 - g - s, x1, y0 - g, color); // верхний
		ctx.fill(x0, y1 + g, x1, y1 + g + s, color); // нижний
		// Точка
		if (dot.get()) {
			ctx.fill(x0, y0, x1, y1, color);
		}
	}

	/** Цвет берётся из настроек модуля. */
	private int resolveColor() {
		return color.get();
	}

	/** true — модуль включён и прицел рендерим (для миксина-отмены ванили). */
	public static CrosshairModule activeModule() {
		NeuClient c = NeuClient.getInstance();
		if (c == null || c.getModuleManager() == null) {
			return null;
		}
		CrosshairModule m = c.getModuleManager().get(CrosshairModule.class);
		return m != null && m.isEnabled() ? m : null;
	}
}
