package ru.neuclient.client.tooltip;

import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipData;

import java.util.List;

/**
 * Данные для визуального превью шалкера в тултипе (как у ShulkerBoxTooltip):
 * список стаков + режим. Подхватывается TooltipComponentCallback,
 * зарегистрированным в NeuClient (#onInitializeClient).
 *
 * full = false → одна строка до 5 иконок (склейка одинаковых предметов),
 * full = true (зажат Ctrl) → вся сетка 9×3, как окно шалкера.
 */
public record ShulkerPreviewData(List<ItemStack> stacks, boolean full) implements TooltipData {
}
