package ru.neuclient.client.remote;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.jar.JarEntry;
import java.util.jar.JarInputStream;

/**
 * ClassLoader для скачанного пака модулей.
 *
 * Родитель - обычный ClassLoader клиента: все классы каркаса (Module,
 * настройки, Minecraft) резолвятся через родителя ПЕРВЫМИ, из пака
 * берутся только новые классы. Так пак не может подменить каркас.
 */
public final class RemoteModuleClassLoader extends ClassLoader {

    public RemoteModuleClassLoader(ClassLoader parent) {
        super(parent);
    }

    /**
     * Определяет все классы из jar-байткода.
     * Классы, уже загруженные родителем (модуль переехал в пак, а в jar
     * ещё остался), пропускаются - побеждает jar клиента.
     *
     * @return список определённых классов (только ru.neuclient.** и прочие
     *         не-java/-META-INF записи)
     */
    public List<Class<?>> defineAll(byte[] jar) throws Exception {
        List<Class<?>> defined = new ArrayList<>();
        ClassLoader parent = getParent();

        try (JarInputStream jin = new JarInputStream(new ByteArrayInputStream(jar))) {
            JarEntry entry;
            byte[] buffer = new byte[8192];
            while ((entry = jin.getNextJarEntry()) != null) {
                String name = entry.getName();
                if (entry.isDirectory()
                        || name.startsWith("META-INF/")
                        || "module-info.class".equals(name)
                        || !name.endsWith(".class")) {
                    continue;
                }
                String className = name.substring(0, name.length() - ".class".length())
                        .replace('/', '.');

                // Дубликат с jar клиента - родитель выигрывает
                try {
                    parent.loadClass(className);
                    continue;
                } catch (ClassNotFoundException ignored) {
                    // ок - класс новый, определяем
                }

                ByteArrayOutputStream buf = new ByteArrayOutputStream();
                int n;
                while ((n = jin.read(buffer)) > 0) {
                    buf.write(buffer, 0, n);
                }
                byte[] bytes = buf.toByteArray();

                try {
                    defined.add(defineClass(className, bytes, 0, bytes.length));
                } catch (LinkageError duplicate) {
                    // уже определён кем-то - пропускаем
                }
            }
        }
        return defined;
    }
}
