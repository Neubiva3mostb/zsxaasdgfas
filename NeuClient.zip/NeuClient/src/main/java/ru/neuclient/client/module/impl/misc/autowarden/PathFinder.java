package ru.neuclient.client.module.impl.misc.autowarden;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.fluid.FluidState;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Direction.Axis;
import net.minecraft.util.shape.VoxelShape;

public final class PathFinder {
   private static final int MAX_NODES = 6000;
   private static final int MAX_DROP = 3;
   private final ClientWorld world;
   private final BlockPos min;
   private final BlockPos max;
   private final List<Vec3d> dangers = new ArrayList<>();
   private double dangerRadius = 12.0;

   public PathFinder(ClientWorld world, BlockPos areaMin, BlockPos areaMax) {
      this.world = world;
      this.min = areaMin;
      this.max = areaMax;
   }

   public void setDangers(List<Vec3d> points, double radius) {
      this.dangers.clear();
      this.dangers.addAll(points);
      this.dangerRadius = radius;
   }

   private boolean inArea(BlockPos p) {
      return p.getX() >= this.min.getX() - 2
         && p.getX() <= this.max.getX() + 2
         && p.getZ() >= this.min.getZ() - 2
         && p.getZ() <= this.max.getZ() + 2
         && p.getY() >= this.world.getBottomY()
         && p.getY() < this.world.getBottomY() + this.world.getHeight();
   }

   public boolean isDangerous(BlockPos p) {
      BlockState st = this.world.getBlockState(p);
      FluidState fl = st.getFluidState();
      return !fl.isEmpty() && fl.isIn(FluidTags.LAVA)
         ? true
         : st.isOf(Blocks.LAVA)
            || st.isOf(Blocks.FIRE)
            || st.isOf(Blocks.SOUL_FIRE)
            || st.isOf(Blocks.MAGMA_BLOCK)
            || st.isOf(Blocks.CACTUS)
            || st.isOf(Blocks.SWEET_BERRY_BUSH)
            || st.isOf(Blocks.POWDER_SNOW)
            || st.isOf(Blocks.CAMPFIRE)
            || st.isOf(Blocks.SOUL_CAMPFIRE)
            || st.isOf(Blocks.WITHER_ROSE);
   }

   public boolean isPassable(BlockPos p) {
      BlockState st = this.world.getBlockState(p);
      if (this.isDangerous(p)) {
         return false;
      } else if (st.isAir()) {
         return true;
      } else if (!st.getFluidState().isEmpty()) {
         return true;
      } else {
         VoxelShape shape = st.getCollisionShape(this.world, p);
         // Ковры/моховые ковры/тонкий снег: коллизия ниже ванильного шага
         // (0.6), игрок проходит их БЕЗ прыжка. Раньше тонкий блок считался
         // стеной, путь шёл «на верх ковра» ступенькой — и бот скакал.
         return shape.getMax(Axis.Y) <= 0.2;
      }
   }

   /** Свечи и тортики со свечками: тонкий декор, на который залезать не нужно. */
   private static boolean isCandle(BlockState st) {
      return st.isIn(BlockTags.CANDLES) || st.isIn(BlockTags.CANDLE_CAKES);
   }

   public boolean isStandable(BlockPos below) {
      BlockState st = this.world.getBlockState(below);
      if (this.isDangerous(below)) {
         return false;
      } else if (st.isOf(Blocks.SCULK_SENSOR)
         || st.isOf(Blocks.CALIBRATED_SCULK_SENSOR)
         || st.isOf(Blocks.SCULK_CATALYST)) {
         // На скалковых сенсорах и катализаторах не стоим в принципе:
         // любой шаг/прыжок на них — вибрация вардену. Ходить МИМО
         // (рядом) можно, запрет только на саму опору.
         return false;
      } else if (isCandle(st)) {
         // На свечи не залезаем — иначе бот стоит на них и выглядит/работает криво.
         return false;
      } else if (!st.getFluidState().isEmpty() && st.getCollisionShape(this.world, below).isEmpty()) {
         return st.getFluidState().isIn(FluidTags.WATER);
      } else {
         VoxelShape shape = st.getCollisionShape(this.world, below);
         return shape.isEmpty() ? false : shape.getMax(Axis.Y) <= 1.0001;
      }
   }

   public boolean canStandAt(BlockPos feet) {
      return this.isStandable(feet.down()) && this.isPassable(feet) && this.isPassable(feet.up());
   }

   private boolean isFence(BlockPos p) {
      VoxelShape shape = this.world.getBlockState(p).getCollisionShape(this.world, p);
      return !shape.isEmpty() && shape.getMax(Axis.Y) > 1.0001;
   }

   private boolean inWater(BlockPos p) {
      return !this.world.getBlockState(p).getFluidState().isEmpty();
   }

   private double dangerCost(BlockPos p) {
      if (this.dangers.isEmpty()) {
         return 0.0;
      } else {
         double c = 0.0;
         double px = (double)p.getX() + 0.5;
         double pz = (double)p.getZ() + 0.5;

         for (Vec3d d : this.dangers) {
            double dist = Math.hypot(px - d.x, pz - d.z);
            if (dist < this.dangerRadius) {
               c += (this.dangerRadius - dist) * 4.0;
            }
         }

         return c;
      }
   }

   /** Мелкий штраф за клетку, соседнюю с забором (1.5-высокая коллизия). */
   private double fenceHugCost(BlockPos p) {
      double c = 0.0;

      for (int dx = -1; dx <= 1; dx++) {
         for (int dz = -1; dz <= 1; dz++) {
            if (dx != 0 || dz != 0) {
               if (this.isFence(p.add(dx, 0, dz))) {
                  c += 0.3;
               }
            }
         }
      }

      return c;
   }

   private static double heuristic(BlockPos a, BlockPos b) {
      double dx = (double)Math.abs(a.getX() - b.getX());
      double dz = (double)Math.abs(a.getZ() - b.getZ());
      double dy = (double)Math.abs(a.getY() - b.getY());
      return Math.max(dx, dz) + 0.41 * Math.min(dx, dz) + dy * 0.5;
   }

   public List<BlockPos> find(BlockPos start, BlockPos goal, double reach) {
      if (!this.canStandAt(start)) {
         BlockPos fixed = null;

         for (BlockPos c : new BlockPos[]{start.up(), start.down(), start}) {
            if (this.canStandAt(c)) {
               fixed = c;
               break;
            }
         }

         if (fixed == null) {
            return null;
         }

         start = fixed;
      }

      PriorityQueue<PathFinder.Node> open = new PriorityQueue<>();
      Map<BlockPos, Double> best = new HashMap<>();
      open.add(new PathFinder.Node(start, null, 0.0, heuristic(start, goal)));
      best.put(start, 0.0);
      PathFinder.Node closest = open.peek();
      double closestH = heuristic(start, goal);
      int expanded = 0;

      while (!open.isEmpty() && expanded < 6000) {
         PathFinder.Node cur = open.poll();
         expanded++;
         double h = heuristic(cur.pos, goal);
         if (h < closestH) {
            closestH = h;
            closest = cur;
         }

         if (horizontalDist(cur.pos, goal) <= reach && Math.abs(cur.pos.getY() - goal.getY()) <= 2) {
            return rebuild(cur);
         }

         for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
               if (dx != 0 || dz != 0) {
                  boolean diagonal = dx != 0 && dz != 0;
                  BlockPos base = cur.pos.add(dx, 0, dz);
                  if (this.inArea(base)) {
                     if (diagonal) {
                        BlockPos c1 = cur.pos.add(dx, 0, 0);
                        BlockPos c2 = cur.pos.add(0, 0, dz);
                        if (!this.isPassable(c1) || !this.isPassable(c1.up()) || !this.isPassable(c2) || !this.isPassable(c2.up())) {
                           continue;
                        }
                     }

                     BlockPos next = null;
                     double stepCost = diagonal ? 1.41 : 1.0;
                     if (this.canStandAt(base)) {
                        next = base;
                     } else if (this.isPassable(base) && this.isPassable(base.up())) {
                        for (int drop = 1; drop <= 3; drop++) {
                           BlockPos d = base.down(drop);
                           if (!this.isPassable(d) || !this.isPassable(d.up())) {
                              break;
                           }

                           if (this.canStandAt(d)) {
                              next = d;
                              stepCost += (double)drop * 0.6;
                              break;
                           }
                        }
                     } else {
                        BlockPos up = base.up();
                        if (!diagonal && this.canStandAt(up) && this.isPassable(cur.pos.up(2)) && !this.isFence(base)) {
                           next = up;
                           stepCost++;
                        }
                     }

                     if (next != null) {
                        if (this.inWater(next)) {
                           stepCost += 3.0;
                        }

                        stepCost += this.dangerCost(next);
                        // Держимся подальше от заборов: тело (0.6) цепляет
                        // выступы забора на поворотах и бот в них втыкается.
                        stepCost += this.fenceHugCost(next);
                        double ng = cur.g + stepCost;
                        Double old = best.get(next);
                        if (old == null || !(old <= ng)) {
                           best.put(next, ng);
                           open.add(new PathFinder.Node(next, cur, ng, heuristic(next, goal)));
                        }
                     }
                  }
               }
            }
         }
      }

      return closest != null && closest.parent != null && closestH < heuristic(start, goal) - 2.0 ? rebuild(closest) : null;
   }

   private static double horizontalDist(BlockPos a, BlockPos b) {
      return Math.hypot((double)(a.getX() - b.getX()), (double)(a.getZ() - b.getZ()));
   }

   private static List<BlockPos> rebuild(PathFinder.Node n) {
      LinkedList<BlockPos> path = new LinkedList<>();

      while (n.parent != null) {
         path.addFirst(n.pos);
         n = n.parent;
      }

      return path;
   }

   private static final class Node implements Comparable<PathFinder.Node> {
      final BlockPos pos;
      final PathFinder.Node parent;
      final double g;
      final double f;

      Node(BlockPos pos, PathFinder.Node parent, double g, double h) {
         this.pos = pos;
         this.parent = parent;
         this.g = g;
         this.f = g + h;
      }

      public int compareTo(PathFinder.Node o) {
         return Double.compare(this.f, o.f);
      }
   }
}
