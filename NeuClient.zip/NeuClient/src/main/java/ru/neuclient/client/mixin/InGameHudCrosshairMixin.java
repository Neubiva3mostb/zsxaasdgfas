package ru.neuclient.client.mixin;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.neuclient.client.module.impl.render.CrosshairModule;

/**
 * Crosshair: вместо ванильного крестика рисуем свой (CrosshairModule),
 * когда модуль включён — иначе отдаём рендер ванилле без изменений.
 */
@Mixin(InGameHud.class)
public abstract class InGameHudCrosshairMixin {

	@Inject(method = "renderCrosshair(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/client/render/RenderTickCounter;)V",
			at = @At("HEAD"), cancellable = true)
	private void pc$customCrosshair(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
		try {
			CrosshairModule module = CrosshairModule.activeModule();
			if (module != null) {
				module.render(context);
				ci.cancel();
			}
		} catch (Throwable t) {
			// Кастомный прицел не должен ронять кадр/HUD
		}
	}
}
