package ru.neuclient.client.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.impl.render.BigHeadModule;

/**
 * BigHead: масштабирует часть модели «head».
 *
 * Ставим масштаб в конце setAngles — после всех ванильных сбросов
 * трансформации, поэтому значение гарантированно доживает до отрисовки.
 * Увеличиваем голову только у рендер-стейта с id локального игрока;
 * у остальных всегда масштаб 1.
 */
@Mixin(PlayerEntityModel.class)
public abstract class PlayerEntityModelMixin {

	@Inject(
			method = "setAngles(Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;)V",
			at = @At("RETURN"))
	private void pc$bigHead(PlayerEntityRenderState state, CallbackInfo ci) {
		try {
			float scale = 1.0f;
			MinecraftClient mc = MinecraftClient.getInstance();
			if (mc != null && mc.player != null && state != null
					&& state.id == mc.player.getId()) {
				NeuClient owner = NeuClient.getInstance();
				if (owner != null && owner.getModuleManager() != null) {
					BigHeadModule module = owner.getModuleManager().get(BigHeadModule.class);
					if (module != null && module.isEnabled()) {
						scale = module.getScale();
					}
				}
			}
			BipedEntityModel<?> model = (BipedEntityModel<?>) (Object) this;
			model.head.xScale = scale;
			model.head.yScale = scale;
			model.head.zScale = scale;
		} catch (Throwable t) {
			// Косметический эффект — рендер не ломаем
		}
	}
}
