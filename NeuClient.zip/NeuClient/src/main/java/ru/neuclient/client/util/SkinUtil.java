package ru.neuclient.client.util;

import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;

/**
 * Отрисовка головы скина игрока (лицо + слой шлема из атласа 64×64).
 * Общий хелпер: используется NameTags'ом и TargetHUD'ом.
 * Фолбэк при отсутствии скина (боты/оффлайн) — Стив.
 */
public final class SkinUtil {

	private static final Identifier STEVE = Identifier.of("minecraft", "textures/entity/player/wide/steve.png");

	private SkinUtil() {
	}

	/** Скин по умолчанию (для экранов, где сущности игрока ещё нет — гл. меню). */
	public static Identifier defaultSkin() {
		return STEVE;
	}

	/** Текстура скина игрока (тело), либо Стив. */
	public static Identifier skinOf(PlayerEntity player) {
		try {
			if (player instanceof AbstractClientPlayerEntity acp && acp.getSkin() != null) {
				return acp.getSkin().body().texturePath();
			}
		} catch (Throwable ignored) {
			// упадём в дефолт
		}
		return STEVE;
	}

	/** Головка size×size в точке (x, y): лицо 8×8 + оверлей шлема. */
	public static void drawHead(DrawContext ctx, PlayerEntity player, float x, float y, float size) {
		drawSkinHead(ctx, skinOf(player), x, y, size);
	}

	/** Головка по готовой текстуре скина (когда entity игрока недоступна). */
	public static void drawSkinHead(DrawContext ctx, Identifier skin, float x, float y, float size) {
		var m = ctx.getMatrices();
		m.pushMatrix();
		m.translate(x, y);
		m.scale(size / 8.0f, size / 8.0f); // ванильный атлас 8×8 → size
		ctx.drawTexture(RenderPipelines.GUI_TEXTURED, skin, 0, 0, 8.0f, 8.0f, 8, 8, 64, 64);   // лицо
		ctx.drawTexture(RenderPipelines.GUI_TEXTURED, skin, 0, 0, 40.0f, 8.0f, 8, 8, 64, 64);  // шлем
		m.popMatrix();
	}
}
