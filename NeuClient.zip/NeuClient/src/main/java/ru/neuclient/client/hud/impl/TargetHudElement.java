package ru.neuclient.client.hud.impl;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.font.MsdfFontRenderer;
import ru.neuclient.client.font.MsdfFonts;
import ru.neuclient.client.hud.HudElement;
import ru.neuclient.client.util.RenderUtil;
import ru.neuclient.client.util.SkinUtil;

import java.util.Locale;

/**
 * Таргет-худ в фирменном стиле Delta:
 *  - Размеры 110x26
 *  - Скругленная карточка (радиус 5)
 *  - Голова игрока 18x18
 *  - Никнейм шрифтом SF Medium 7.5f
 *  - Текущее HP в правом углу акцентным цветом
 *  - Сглаженная полоса HP с треком
 *  - Иконки брони и предмета в руках
 */
public class TargetHudElement extends HudElement {

	private static final long SHOW_MS = 2500;
	private static final long FADE_MS = 400;

	private static final int CARD_W = 110;
	private static final int CARD_H = 26;
	private static final int HEAD_SIZE = 18;

	private static Entity lastTarget;
	private static long lastHitMs;

	public TargetHudElement() {
		super("targethud", 0, 0);
	}

	public static void onHit(Entity target) {
		lastTarget = target;
		lastHitMs = System.currentTimeMillis();
	}

	@Override
	protected int getDefaultX() {
		return mc.getWindow().getScaledWidth() / 2 + 50;
	}

	@Override
	protected int getDefaultY() {
		return mc.getWindow().getScaledHeight() / 2 + 15;
	}

	@Override
	protected void drawElement(DrawContext ctx, boolean editing) {
		long age = System.currentTimeMillis() - lastHitMs;
		boolean fresh = lastTarget != null && age <= SHOW_MS;

		if (!fresh) {
			if (editing) {
				drawCard(ctx, getX(), getY(), null, "Target", 20.0f, 20.0f, 1.0f);
			} else {
				this.width = 0;
				this.height = 0;
			}
			return;
		}

		LivingEntity living = lastTarget instanceof LivingEntity l ? l : null;
		String name = lastTarget.getName().getString();

		float hp = 20.0f;
		float maxHp = 20.0f;
		if (living != null) {
			hp = Math.max(0.0f, living.getHealth() + living.getAbsorptionAmount());
			maxHp = Math.max(1.0f, living.getMaxHealth());
		}

		float alpha = age > SHOW_MS - FADE_MS ? (SHOW_MS - age) / (float) FADE_MS : 1.0f;
		int lift = Math.round((1.0f - alpha) * 2.0f);

		drawCard(ctx, getX(), getY() - lift, living, name, hp, maxHp, alpha);
	}

	private void drawCard(DrawContext ctx, int x, int y, LivingEntity living,
						  String name, float hp, float maxHp, float alpha) {
		this.width = CARD_W;
		this.height = CARD_H;

		var im = NeuClient.getInstance().getInterfaceModule();
		int accent = im != null ? im.getTargetHudColor() : RenderUtil.accent();
		int bg = 0xEE0B0B16;

		// Карточка
		RenderUtil.roundRect(ctx, x, y, CARD_W, CARD_H, 5, fade(bg, alpha));
		RenderUtil.roundBorderEdge(ctx, x, y, CARD_W, CARD_H, 5, fade(withAlpha(accent, 0x33), alpha));

		// Голова цели
		int headX = x + 4;
		int headY = y + 4;
		if (living instanceof PlayerEntity player) {
			SkinUtil.drawHead(ctx, player, headX, headY, HEAD_SIZE);
		} else {
			RenderUtil.roundRect(ctx, headX, headY, HEAD_SIZE, HEAD_SIZE, 3, fade(0x33FFFFFF, alpha));
			var textFont = MsdfFonts.sfMedium();
			MsdfFontRenderer.drawCenteredWithShadow(ctx, textFont, "?", headX + HEAD_SIZE / 2.0f, headY + 4.0f,
					fade(0xFFFFFFFF, alpha), 10.0f);
		}

		// Никнейм
		var textFont = MsdfFonts.sfMedium();
		int textX = headX + HEAD_SIZE + 5;
		String displayName = name.length() > 11 ? name.substring(0, 10) + ".." : name;
		MsdfFontRenderer.drawWithShadow(ctx, textFont, displayName, textX, y + 4.5f,
				fade(0xFFFFFFFF, alpha), 7.5f);

		// Значение HP
		String hpText = ((int) hp) + " HP";
		float hpW = MsdfFontRenderer.getWidth(textFont, hpText, 7.0f);
		MsdfFontRenderer.drawWithShadow(ctx, textFont, hpText, x + CARD_W - 5 - hpW, y + 5.0f,
				fade(accent, alpha), 7.0f);

		// Полоса HP
		float frac = Math.min(1.0f, Math.max(0.0f, hp / maxHp));
		int barX = textX;
		int barY = y + 16;
		int barW = 50;
		int barH = 3;

		RenderUtil.roundRect(ctx, barX, barY, barW, barH, 1, fade(withAlpha(accent, 0x35), alpha));
		int fillW = Math.round(barW * frac);
		if (fillW > 0) {
			RenderUtil.roundRect(ctx, barX, barY, fillW, barH, 1, fade(accent, alpha));
		}

		// Предметы брони / оружия
		if (living != null) {
			ItemStack[] items = new ItemStack[]{
					living.getEquippedStack(EquipmentSlot.MAINHAND),
					living.getEquippedStack(EquipmentSlot.OFFHAND),
					living.getEquippedStack(EquipmentSlot.CHEST)
			};
			int itemX = x + CARD_W - 12;
			for (ItemStack is : items) {
				if (is != null && !is.isEmpty()) {
					ctx.getMatrices().pushMatrix();
					ctx.getMatrices().translate(itemX, y + 13);
					ctx.getMatrices().scale(0.55f, 0.55f);
					ctx.drawItem(is, 0, 0);
					ctx.getMatrices().popMatrix();
					itemX -= 10;
				}
			}
		}
	}

	private static int fade(int color, float k) {
		int a = (int) (((color >>> 24) & 0xFF) * k) & 0xFF;
		return (a << 24) | (color & 0x00FFFFFF);
	}
}
