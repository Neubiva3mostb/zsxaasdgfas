package ru.neuclient.client.module.impl.misc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.DisconnectedScreen;
import net.minecraft.client.gui.screen.multiplayer.ConnectScreen;
import net.minecraft.client.network.CookieStorage;
import net.minecraft.client.network.ServerAddress;
import net.minecraft.client.network.ServerInfo;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.NumberSetting;

import java.util.Map;

/**
 * AutoReconnect — сам перезаходит на сервер после кика/потери связи.
 *
 * Механика: пока игрок на сервере — сохраняем ServerInfo каждый тик.
 * При дисконнекте используем сохранённый сервер для перезахода.
 */
public final class AutoReconnectModule extends Module {

	/** Задержка перед перезаходом, секунды. */
	private final NumberSetting delay = new NumberSetting("Задержка", 3.0, 1.0, 10.0, 1.0);

	/** Момент (currentTimeMillis), когда выполнять перезаход; -1 = таймера нет. */
	private long reconnectAt = -1L;
	/** Сервер, с которого выкинуло (сохраняем заранее, пока на сервере). */
	private ServerInfo lastServer;
	/** Флаг: мы уже видели экран дисконнекта и запустили таймер. */
	private boolean detectedDisconnect = false;

	public AutoReconnectModule() {
		super("AutoReconnect", "Перезаходит на сервер после кика", Category.MISC);
		addSettings(delay);
	}

	@Override
	public void onTick(MinecraftClient client) {
		// Пока игрок в мире (экрана нет) — сохраняем сервер каждый тик
		if (client.currentScreen == null) {
			ServerInfo info = client.getCurrentServerEntry();
			if (info != null) {
				lastServer = info;
			}
			detectedDisconnect = false;
			reconnectAt = -1L;
			return;
		}

		// Экран дисконнекта — запускаем перезаход
		if (client.currentScreen instanceof DisconnectedScreen) {
			if (!detectedDisconnect) {
				detectedDisconnect = true;
				// Пробуем ещё раз получить сервер
				ServerInfo info = client.getCurrentServerEntry();
				if (info != null) {
					lastServer = info;
				}
				if (lastServer == null) {
					return; // не знаем, куда возвращаться
				}
				reconnectAt = System.currentTimeMillis() + delay.get().longValue() * 1000L;
				return;
			}

			if (reconnectAt < 0L || lastServer == null) {
				return;
			}
			if (System.currentTimeMillis() < reconnectAt) {
				return; // отсчёт ещё идёт
			}

			// Перезаход
			reconnectAt = -1L;
			detectedDisconnect = false;
			try {
				ConnectScreen.connect(client.currentScreen, client,
						ServerAddress.parse(lastServer.address), lastServer, false,
						new CookieStorage(Map.of(), Map.of(), true));
			} catch (Throwable t) {
				ru.neuclient.client.NeuClient.LOGGER.error("[NeuClient] AutoReconnect не смог подключиться", t);
			}
			lastServer = null;
			return;
		}

		// Другой экран — сбрасываем
		detectedDisconnect = false;
		reconnectAt = -1L;
	}

	@Override
	protected void onEnable() {
		MinecraftClient client = MinecraftClient.getInstance();
		ServerInfo info = client.getCurrentServerEntry();
		if (info != null) {
			lastServer = info;
		}
		reconnectAt = -1L;
		detectedDisconnect = false;
	}

	@Override
	protected void onDisable() {
		reconnectAt = -1L;
		lastServer = null;
		detectedDisconnect = false;
	}
}
