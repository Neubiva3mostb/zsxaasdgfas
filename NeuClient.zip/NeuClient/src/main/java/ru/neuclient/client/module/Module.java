package ru.neuclient.client.module;

import net.minecraft.client.MinecraftClient;
import ru.neuclient.client.setting.Setting;
import ru.neuclient.client.util.KeyNames;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Базовый модуль клиента.
 *
 * Жизненный цикл: конструктор (register/добавление настроек) →
 * setEnabled(true/false) с вызовом onEnable/onDisable →
 * onTick каждый клиентский тик, пока модуль включён.
 *
 * Бинд хранится как GLFW-код клавиши (NONE = -1). Переключение по клавише
 * выполняет ModuleManager через опрос InputUtil (детект фронта нажатия).
 */
public abstract class Module {

	protected final MinecraftClient mc = MinecraftClient.getInstance();

	private final String name;
	private final String description;
	private final Category category;
	private final List<Setting<?>> settings = new ArrayList<>();

	private boolean enabled = false;
	private int keyBind = KeyNames.NONE;

	protected Module(String name, String description, Category category) {
		this.name = name;
		this.description = description;
		this.category = category;
	}

	/** Любой открытый экран (включая меню ботов) блокирует бинды игрового мира. */
	protected static boolean blockingScreen(MinecraftClient client) {
		return client != null && client.currentScreen != null;
	}

	// ===== Хуки жизненного цикла (переопределяются наследниками) =====

	/** Вызывается при каждом включении модуля (клик/бинд/конфиг). */
	protected void onEnable() {
	}

	/** Вызывается при каждом выключении модуля. */
	protected void onDisable() {
	}

	/** Вызывается каждый клиентский тик, пока модуль включён. */
	public void onTick(MinecraftClient client) {
	}

	// ===== Состояние =====

	public final void toggle() {
		setEnabled(!enabled);
	}

	public void setEnabled(boolean enabled) {
		if (this.enabled == enabled) {
			return;
		}
		this.enabled = enabled;
		markConfigDirty();
		try {
			if (enabled) {
				onEnable();
			} else {
				onDisable();
			}
		} catch (Throwable t) {
			// Модуль не должен уронить игру ни при каких условиях
			ru.neuclient.client.NeuClient.LOGGER.error("[NeuClient] Ошибка в модуле {}", name, t);
		}
	}

	/** Просит ConfigManager обновить default.json (null-безопасно). */
	public static void markConfigDirty() {
		ru.neuclient.client.NeuClient c = ru.neuclient.client.NeuClient.getInstance();
		if (c != null && c.getConfigManager() != null) {
			c.getConfigManager().markDirty();
		}
	}

	public boolean isEnabled() {
		return enabled;
	}

	// ===== Бинд =====

	public int getKeyBind() {
		return keyBind;
	}

	public void setKeyBind(int keyBind) {
		this.keyBind = keyBind;
		markConfigDirty();
	}

	public String getBindName() {
		return KeyNames.getName(keyBind);
	}

	// ===== Метаданные и настройки =====

	public String getName() {
		return name;
	}

	public String getDescription() {
		return description;
	}

	public Category getCategory() {
		return category;
	}

	/**
	 * Скрытый ли это модуль.
	 *
	 * Скрытые модули полноценно живут и тикают, но не показываются в
	 * ClickGUI, в списке активных модулей на HUD и не участвуют в поиске.
	 * Нужно для служебных модулей, которыми управляют только командой
	 * (NeuAI): держать их в общем списке удобно — они получают тик,
	 * конфиг и корректно гаснут по .panic, — но в меню им делать нечего.
	 */
	public boolean isHidden() {
		return false;
	}

	protected void addSettings(Setting<?>... toAdd) {
		Collections.addAll(settings, toAdd);
	}

	public List<Setting<?>> getSettings() {
		return settings;
	}

	public boolean hasSettings() {
		return !settings.isEmpty();
	}

	public Setting<?> getSettingByName(String settingName) {
		for (Setting<?> s : settings) {
			if (s.getName().equalsIgnoreCase(settingName)) {
				return s;
			}
		}
		return null;
	}
}
