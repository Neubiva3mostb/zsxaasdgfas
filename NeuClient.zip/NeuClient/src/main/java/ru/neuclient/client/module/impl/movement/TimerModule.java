package ru.neuclient.client.module.impl.movement;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.BooleanSetting;
import ru.neuclient.client.setting.NumberSetting;

/**
 * Timer — ускоряет (или замедляет) игровое время клиента.
 *
 * Как работает ваниль: RenderTickCounter.Dynamic каждый кадр считает
 * dynamicDeltaTicks = прошедшие_мс / targetMillisPerTick (обычно 50 мс) и
 * копит их в tickProgress; целая часть — это количество игровых тиков,
 * которые надо отыграть в этом кадре.
 *
 * Миксин RenderTickCounterMixin перехватывает вычисление
 * targetMillisPerTick и делит его на множитель модуля. При множителе 2.0
 * «тик» для клиента длится 25 мс вместо 50 — за реальную секунду проходит
 * 40 игровых тиков вместо 20: игрок бежит, копает, ест и летит вдвое быстрее.
 *
 * Настройки:
 *  • «Множитель» — 0.1..10 (1.0 = ваниль; меньше 1 = замедление);
 *  • «Только в движении» — ускорять только когда реально идёшь
 *    (стоя на месте таймер не крутится, и это заметно тише для античитов).
 *
 * Важно: серверный тикрейт остаётся 20 tps. Любой античит с проверкой
 * скорости пакетов увидит поток движения быстрее нормы — большие значения
 * ловятся почти мгновенно. Умеренные (1.1–1.3) обычно проходят.
 */
public final class TimerModule extends Module {

	private final NumberSetting multiplier = new NumberSetting("Множитель", 1.5, 0.1, 10.0, 0.1);

	public TimerModule() {
		super("Timer", "Ускоряет игру", Category.MOVEMENT);
		addSettings(multiplier);
	}

	/**
	 * Текущий множитель скорости времени — читается миксином каждый кадр.
	 * @return 1.0, если ускорять сейчас не нужно.
	 */
	public float getTimerSpeed() {
		if (!isEnabled()) {
			return 1.0f;
		}
		MinecraftClient client = MinecraftClient.getInstance();
		ClientPlayerEntity player = client.player;
		if (player == null || client.world == null) {
			return 1.0f; // в меню и на загрузке не трогаем время
		}
		// "Только в движении" всегда off — не проверяем
		return multiplier.get().floatValue();
	}
}
