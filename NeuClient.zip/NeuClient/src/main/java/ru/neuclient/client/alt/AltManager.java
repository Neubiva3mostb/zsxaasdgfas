package ru.neuclient.client.alt;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.session.Session;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.mixin.MinecraftClientAccessor;
import ru.neuclient.client.util.ClientPaths;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Менеджер альтов.
 *
 * Список аккаунтов хранится в alts.json в папке конфигов (C:\NeuClient).
 * Реальной авторизации Microsoft нет: "вход" под альтом ставит в клиент
 * оффлайн-сессию через MinecraftClientAccessor, поэтому ник в игре меняется
 * (на оффлайн-серверах и в одиночной игре это работает как полноценная смена).
 */
public class AltManager {

	private final Gson gson = new GsonBuilder().setPrettyPrinting().create();
	private final List<AltEntry> alts = new ArrayList<>();

	private Path file() {
		return ClientPaths.file("alts.json");
	}

	public void load() {
		Path file = file();
		if (!Files.exists(file)) {
			return;
		}
		try (Reader reader = Files.newBufferedReader(file)) {
			Type listType = new TypeToken<List<AltEntry>>() {}.getType();
			List<AltEntry> loaded = gson.fromJson(reader, listType);
			if (loaded != null) {
				alts.clear();
				alts.addAll(loaded);
			}
			NeuClient.LOGGER.info("[NeuClient] Альтов загружено: {}", alts.size());
		} catch (Exception e) {
			NeuClient.LOGGER.error("[NeuClient] Не удалось прочитать alts.json", e);
		}
	}

	public void save() {
		try (Writer writer = Files.newBufferedWriter(file())) {
			gson.toJson(alts, writer);
		} catch (IOException e) {
			NeuClient.LOGGER.error("[NeuClient] Не удалось сохранить alts.json", e);
		}
	}

	public List<AltEntry> getAlts() {
		return alts;
	}

	/** Добавить альт в список. @return null при успехе, иначе текст ошибки. */
	public String add(String username, String password) {
		String name = username == null ? "" : username.trim();
		if (name.isEmpty()) {
			return "Введите логин";
		}
		if (name.length() > 16) {
			return "Ник длиннее 16 символов";
		}
		if (!name.matches("[A-Za-z0-9_]+")) {
			return "Ник: только латиница, цифры и '_'";
		}
		for (AltEntry a : alts) {
			if (a.getUsername().equalsIgnoreCase(name)) {
				return "Такой альт уже есть";
			}
		}
		alts.add(new AltEntry(name, password == null ? "" : password));
		save();
		return null;
	}

	public void remove(AltEntry entry) {
		alts.remove(entry);
		save();
	}

	/**
	 * "Войти" под альтом: ставит клиенту оффлайн-сессию с ником альта.
	 * UUID считается так же, как на оффлайн-серверах ("OfflinePlayer:"),
	 * поэтому инвентарь/данные на них сохранятся за этим ником.
	 *
	 * @return null при успехе, иначе текст ошибки
	 */
	public String login(AltEntry entry) {
		String name = entry.getUsername().trim();
		if (name.isEmpty() || name.length() > 16) {
			return "Некорректный ник альта";
		}
		try {
			// Оффлайн UUID — ровно как у оффлайн-режима Mojang
			UUID uuid = UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(StandardCharsets.UTF_8));
			Session fake = new Session(name, uuid, "", Optional.empty(), Optional.empty());
			((MinecraftClientAccessor) MinecraftClient.getInstance()).pc$setSession(fake);
			NeuClient.LOGGER.info("[NeuClient] Сессия переключена на {}", name);
			return null;
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка смены сессии", t);
			return "Ошибка: " + t.getMessage();
		}
	}

	/** Текущий ник сессии клиента (для строки статуса в GUI). */
	public String currentName() {
		return MinecraftClient.getInstance().getSession().getUsername();
	}
}
