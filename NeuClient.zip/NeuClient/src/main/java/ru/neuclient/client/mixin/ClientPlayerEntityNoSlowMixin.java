package ru.neuclient.client.mixin;

import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.impl.movement.NoSlowModule;

/**
 * NoSlow: ванилла в applyMovementSpeedFactors (вызывается из tickMovementInput)
 * спрашивает isUsingItem() и, если предмет используется (еда/щит/лук...),
 * множит скорость ввода на getActiveItemSpeedMultiplier() (~×0.2).
 * Подменяем ответ на решение модуля: «нет, не используем» → замедления нет.
 * Сам ввод и движение дальше идут по обычному клиентскому пути.
 */
@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerEntityNoSlowMixin {

	@Redirect(method = "applyMovementSpeedFactors",
			at = @At(value = "INVOKE", target = "Lnet/minecraft/client/network/ClientPlayerEntity;isUsingItem()Z"))
	private boolean pc$noSlow(ClientPlayerEntity self) {
		boolean actuallyUsing = self.isUsingItem();
		try {
			NoSlowModule noSlow = NeuClient.getInstance().getModuleManager().get(NoSlowModule.class);
			if (noSlow != null && noSlow.isEnabled()) {
				return noSlow.spoofUsingItem(self, actuallyUsing);
			}
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка NoSlow", t);
		}
		return actuallyUsing;
	}
}
