package ru.neuclient.client.module.impl.movement;

import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.impl.combat.AttackAuraModule;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.MathHelper;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.BooleanSetting;
import ru.neuclient.client.util.RotationSpoof;

/**
 * AutoSprint — игрок бежит всегда, когда движется,
 * даже если клавиша бега (Ctrl) не зажата.
 *
 * Обычный режим: спринт включается только при движении вперёд, как в ванилли.
 *
 * «Во все стороны» (выключено по умолчанию): бежать можно и вбок, и назад.
 * Ваниль не даёт спринтить назад и в сторону, поэтому модуль идёт через спуф
 * угла — тот же механизм, что у WallClimb («Блоки») и AttackAura:
 * сервер видит игрока, который смотрит туда, куда бежит, и бежит вперёд,
 * а на экране и в управлении ничего не меняется. В F5 тело показывается
 * под тем же углом.
 *
 * ПОЧЕМУ УГОЛ СЧИТАЕТСЯ ИЗ СЫРОГО ВВОДА И В КОНЦЕ ТИКА ВВОДА.
 *
 * KeyboardInputMixin перезаписывает playerInput и movementVector своей
 * коррекцией. Если читать ввод из client.player.input после этого, модуль
 * увидит уже исправленный вектор (0, 1) вместо настоящих клавиш, посчитает
 * localAngle = 0 и «схлопнет» спуф на реальный yaw. На следующем тике ввод
 * снова сырой — и угол снова поворачивается. Отсюда дёрганье головы и
 * ощущение, что лево с правом перепутаны.
 *
 * Поэтому:
 *  1. KeyboardInputMixin запоминает СЫРОЙ movementVector в самом начале,
 *     до любой коррекции;
 *  2. коррекция движения читает УЖЕ ПРИМЕНЁННЫЙ угол (тот, что стоит на
 *     сущности в этом тике) — иначе ввод и угол разъезжаются на тик;
 *  3. новый угол считается в самом конце тика ввода и уезжает на следующий.
 *
 * Сдвиг ровно на один тик постоянен, поэтому голова не прыгает.
 *
 * Знак взят из ванили: KeyboardInput.tick кладёт в movementVector.x значение
 * getMovementMultiplier(left, right), то есть +1 — это ВЛЕВО. Отсюда
 * localAngle = atan2(-x, y): клавиша A даёт -90°, что при взгляде на юг
 * (yaw 0) и есть восток, то есть налево.
 */
public class AutoSprintModule extends Module {

	private final BooleanSetting allDirections = new BooleanSetting("Во все стороны", false);

	/**
	 * Угол, который СЕЙЧАС применён к сущности (или будет применён в следующем
	 * тике). Коррекция ввода и рендер F5 читают именно его.
	 */
	private float spoofYaw;
	private float spoofPitch;
	private boolean spoofActive;

	public AutoSprintModule() {
		super("AutoSprint", "Бежит при движении вперёд", Category.MOVEMENT);
		addSettings(allDirections);
	}

	@Override
	protected void onDisable() {
		spoofActive = false;
	}

	@Override
	public void onTick(MinecraftClient client) {
		if (client.player == null || client.player.input == null) {
			return;
		}
		// Аура ждёт крит — спринт включать нельзя: в спринте ваниль крит
		// не засчитывает (PlayerEntity#isCriticalHit).
		// Идёт остановка под работу с инвентарём — спринт снят намеренно,
		// возвращать его в этом же тике нельзя: серверу должен уйти
		// пакет стоящего игрока. Спринт вернётся сам следующим тиком.
		if (ru.neuclient.client.util.SwapPause.isStopping()) {
			return;
		}

		AttackAuraModule aura = AttackAuraModule.active();
		if ((aura != null && aura.needsSprintOffForCrit())
					|| ru.neuclient.client.module.impl.combat.TriggerBotModule.shouldHoldSprintForCrit()) {
			if (client.player.isSprinting()) {
				client.player.setSprinting(false);
			}
			return;
		}

		// Спринт нужен в обоих режимах; в режиме «во все стороны» после
		// коррекции ввода движение всегда «вперёд», так что ванильное
		// ограничение на спринт назад/вбок нас больше не касается.
		boolean moving = allDirections.get()
				? client.player.input.getMovementInput().lengthSquared() > 1.0E-4F
				: client.player.input.hasForwardMovement();
		if (moving && !client.player.isSprinting()) {
			client.player.setSprinting(true);
		}
	}

	// ===== Расчёт угла (вызывается из KeyboardInputMixin) =====

	/**
	 * Посчитать серверный угол на следующий тик по СЫРОМУ вводу.
	 *
	 * @param rawForward movementVector.y до коррекции
	 * @param rawStrafe  movementVector.x до коррекции (+1 = влево)
	 */
	public void refreshFromInput(float rawForward, float rawStrafe) {
		if (!isEnabled() || !allDirections.get()) {
			spoofActive = false;
			return;
		}
		ClientPlayerEntity player = mc.player;
		if (player == null) {
			spoofActive = false;
			return;
		}
		// Стоит на месте — поворачивать некуда, возвращаем обычный вид
		if (rawForward == 0.0f && rawStrafe == 0.0f) {
			spoofActive = false;
			return;
		}
		// WallClimb и AttackAura крутят угол сами — не перебиваем их
		WallClimbModule wall = WallClimbModule.active();
		AttackAuraModule aura = AttackAuraModule.active();
		if ((wall != null && wall.shouldApplySpoof())
				|| (aura != null && (aura.isSpoofing() || aura.needsSprintOffForCrit()))
				|| ru.neuclient.client.module.impl.combat.TriggerBotModule.shouldHoldSprintForCrit()) {
			spoofActive = false;
			return;
		}

		// В этот момент на сущности уже стоит спуфнутый угол, поэтому настоящий
		// yaw берём из RotationSpoof — там он сохранён до подмены.
		float trueYaw = RotationSpoof.realYaw(player.getYaw());
		float localAngle = (float) Math.toDegrees(Math.atan2(-rawStrafe, rawForward));
		spoofYaw = MathHelper.wrapDegrees(trueYaw + localAngle);
		spoofPitch = RotationSpoof.realPitch(player.getPitch());
		spoofActive = true;
	}

	// ===== Доступ для миксинов =====

	/** true, если сейчас нужно наложить угол на сущность на этот тик. */
	public boolean shouldApplySpoof() {
		return isEnabled() && allDirections.get() && spoofActive;
	}

	/** То же условие — для F5 тело показываем под тем же углом. */
	public boolean isSpoofingForRender() {
		return shouldApplySpoof();
	}

	public float getSpoofYaw() {
		return spoofYaw;
	}

	public float getSpoofPitch() {
		return spoofPitch;
	}

	/**
	 * Пересчитать ввод под спуфнутый yaw так, чтобы мировое направление
	 * движения не изменилось.
	 *
	 * spoofYaw и есть направление движения, поэтому на выходе всегда
	 * получается «вперёд» (forward = 1, strafe = 0) — сервер видит обычный бег
	 * вперёд, а игрок едет туда, куда нажал.
	 */
	public float[] correctMovement(float forward, float strafe) {
		if (!shouldApplySpoof() || (forward == 0.0f && strafe == 0.0f)) {
			return new float[]{forward, strafe};
		}
		ClientPlayerEntity player = mc.player;
		if (player == null) {
			return new float[]{forward, strafe};
		}

		float trueYaw = RotationSpoof.realYaw(player.getYaw());
		float delta = MathHelper.wrapDegrees(spoofYaw - trueYaw);
		float localAngle = (float) Math.toDegrees(Math.atan2(-strafe, forward));
		float snapped = Math.round((localAngle - delta) / 45.0f) * 45.0f;
		float fixedForward = Math.round((float) Math.cos(Math.toRadians(snapped)));
		float fixedStrafe = -Math.round((float) Math.sin(Math.toRadians(snapped)));
		return new float[]{fixedForward, fixedStrafe};
	}

	/** Активный экземпляр для миксинов. */
	public static AutoSprintModule active() {
		NeuClient client = NeuClient.getInstance();
		if (client == null || client.getModuleManager() == null) {
			return null;
		}
		AutoSprintModule self = client.getModuleManager().get(AutoSprintModule.class);
		return self != null && self.isEnabled() ? self : null;
	}
}
