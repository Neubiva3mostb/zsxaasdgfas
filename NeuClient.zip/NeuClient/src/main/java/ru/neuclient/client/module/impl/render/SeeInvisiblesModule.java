package ru.neuclient.client.module.impl.render;

import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.BooleanSetting;
import ru.neuclient.client.setting.NumberSetting;

/**
 * SeeInvisibles — делает невидимых игроков видимыми полупрозрачными.
 *
 * Как это работает в ванилле: LivingEntityRenderer#render спрашивает
 * isVisible(state); если сущность невидима, модель либо не рисуется
 * совсем, либо (для «своих» — invisibleToPlayer) рисуется полупрозрачным
 * слоем itemEntityTranslucentCull с зашитой альфой 0x26FFFFFF (≈ 15 %).
 *
 * Миксин LivingEntityRendererMixin подменяет ответ isVisible на true для
 * невидимых игроков и заставляет ваниль пойти по «полупрозрачной» ветке,
 * а альфу берёт из настройки модуля — от 0.3 (еле заметный силуэт) до
 * 1.0 (как обычный игрок).
 *
 * Настройки:
 *  • «Прозрачность» 0.3–1.0 — насколько плотно рисовать невидимок;
 *  • «Только игроки» — не трогать невидимых мобов (по умолчанию включено:
 *    иначе весь мир заполняется полупрозрачными летучими мышами).
 *
 * Чистый рендер: сервер по-прежнему считает игрока невидимым.
 */
public final class SeeInvisiblesModule extends Module {

	private final NumberSetting opacity = new NumberSetting("Прозрачность", 0.5, 0.3, 1.0, 0.05);
	private final BooleanSetting onlyPlayers = new BooleanSetting("Только игроки", true);

	public SeeInvisiblesModule() {
		super("SeeInvisibles", "Показывает невидимых игроков",
				Category.RENDER);
		addSettings(opacity, onlyPlayers);
	}

	/**
	 * Нужно ли показать эту невидимую сущность.
	 * Вызывается из миксина рендерера.
	 */
	public boolean shouldReveal(LivingEntityRenderState state) {
		if (!isEnabled() || !state.invisible) {
			return false;
		}
		if (onlyPlayers.get()) {
			// PlayerEntityRenderState — единственное состояние игроков
			return state instanceof net.minecraft.client.render.entity.state.PlayerEntityRenderState;
		}
		return true;
	}

	/** Альфа-канал (0..255) для полупрозрачной отрисовки. */
	public int getAlphaByte() {
		return Math.max(1, Math.min(255, (int) Math.round(opacity.get() * 255.0)));
	}

	/** Цвет-множитель модели: белый с нашей альфой. */
	public int getTintColor() {
		return (getAlphaByte() << 24) | 0x00FFFFFF;
	}

	/** Активный экземпляр для миксина (null — модуль выключен). */
	public static SeeInvisiblesModule active() {
		ru.neuclient.client.NeuClient c = ru.neuclient.client.NeuClient.getInstance();
		if (c == null || c.getModuleManager() == null) {
			return null;
		}
		SeeInvisiblesModule m = c.getModuleManager().get(SeeInvisiblesModule.class);
		return m != null && m.isEnabled() ? m : null;
	}
}
