package ru.neuclient.client.mixin;

import net.minecraft.scoreboard.AbstractTeam;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.neuclient.client.util.NameProtectUtil;

/**
 * NameProtect в скорборде: decorateName может быть унаследован от
 * AbstractTeam без переопределения в Team — дублируем подмену и здесь.
 * require=0: если метод объявлен только в Team — тихо пропускаем.
 */
@Mixin(AbstractTeam.class)
public abstract class AbstractTeamNameMixin {

	@Inject(method = "decorateName(Lnet/minecraft/text/Text;)Lnet/minecraft/text/MutableText;",
			at = @At("RETURN"), cancellable = true, require = 0)
	private void pc$nameProtectAbstractTeam(Text name, CallbackInfoReturnable<MutableText> cir) {
		MutableText value = cir.getReturnValue();
		if (value != null && NameProtectUtil.active()) {
			cir.setReturnValue((MutableText) NameProtectUtil.transformIfActive(value));
		}
	}
}
