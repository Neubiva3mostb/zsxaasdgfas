package ru.neuclient.client.module.impl.render;

import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.ModeSetting;
import ru.neuclient.client.setting.NumberSetting;

/**
 * Attack Animations — замена ванильной анимации удара.
 *
 * Переписано по рабочему референсу Swing Animation Plus для 1.21.11
 * (github.com/sskyness/Swing-Animation, лицензия CC0). Прошлая версия
 * лишь добавляла довороты поверх ванильного маха, поэтому все режимы
 * выглядели «одинаково, просто под разным углом».
 *
 * Ключевая идея референса: анимация не дополняет ваниль, а ПОЛНОСТЬЮ её
 * заменяет. Для этого миксин глушит и swingArm, и последний
 * applyEquipOffset, а сам режим сначала руками ставит базовое смещение
 * руки (translate 0.56/−0.52/−0.72), а затем крутит её своими поворотами.
 *
 * Режимы (имена — как их принято называть в клиентах):
 *  • «Никакой»   — рука не двигается совсем;
 *  • «Exhibition»— мах с разворотом кисти, самый «клиентский» вид;
 *  • «Slide»     — рука уходит вбок с сильным наклоном;
 *  • «Stab»      — колющий выпад с доворотом по Y;
 *  • «Pushdown»  — рубящий удар сверху вниз;
 *  • «Spin»      — полный оборот предмета вокруг оси X.
 *
 * Настройки:
 *  • «Сила» 20–75 — амплитуда доворота (у режимов, где она применяется);
 *  • «Скорость» 3–10 — как быстро проигрывается взмах (подменяет
 *    LivingEntity#getHandSwingDuration: 3 → 10 тиков, 10 → 3 тика).
 */
public final class AttackAnimationsModule extends Module {

	private static final String NONE = "Никакой";
	private static final String EXHIBITION = "Exhibition";
	private static final String SLIDE = "Slide";
	private static final String STAB = "Stab";
	private static final String PUSHDOWN = "Pushdown";
	private static final String SPIN = "Spin";

	private final ModeSetting mode = new ModeSetting("Анимация", EXHIBITION,
			NONE, EXHIBITION, SLIDE, STAB, PUSHDOWN, SPIN);
	private final NumberSetting strength = new NumberSetting("Сила", 20.0, 20.0, 75.0, 5.0);
	private final NumberSetting speed = new NumberSetting("Скорость", 6.0, 3.0, 10.0, 1.0);

	public AttackAnimationsModule() {
		super("Attack Animations", "Изменяет анимацию удара",
				Category.RENDER);
		addSettings(mode, strength, speed);
	}

	/**
	 * Длительность взмаха в тиках для подмены ванильной.
	 * Скорость 3 → 10 тиков (медленно), 10 → 3 тика (очень быстро).
	 */
	public int getSwingDuration() {
		return Math.max(2, 13 - speed.get().intValue());
	}

	/**
	 * Анимируем ли сейчас эту руку.
	 * Как в референсе — только ОСНОВНУЮ руку игрока: у оффхенда своя
	 * ванильная логика, её ломать не надо.
	 */
	public boolean shouldAnimate(Arm arm) {
		if (!isEnabled()) {
			return false;
		}
		return mc.player != null && mc.player.getMainArm() == arm;
	}

	/** Режим «Никакой»: рука не должна двигаться вообще. */
	public boolean isNoneMode() {
		return NONE.equals(mode.get());
	}

	/**
	 * Применяет анимацию вместо ванильной раскачки.
	 *
	 * @return true — анимация применена, ванильный swingArm звать НЕ надо.
	 */
	public boolean apply(MatrixStack matrices, Arm arm, float swingProgress) {
		if (!shouldAnimate(arm)) {
			return false; // не наша рука — пусть играет ваниль
		}
		if (isNoneMode()) {
			// «Никакой»: базовое смещение ставим, движение — нет
			applyEquipOffset(matrices, arm);
			return true;
		}

		// Две кривые из референса: g — «резкий выброс», anim — плавная дуга
		float g = MathHelper.sin(MathHelper.sqrt(swingProgress) * MathHelper.PI);
		float anim = (float) Math.sin(swingProgress * Math.PI);
		float side = arm == Arm.LEFT ? -1.0f : 1.0f;
		float power = MathHelper.clamp(strength.get().floatValue(), 20.0f, 75.0f);

		// Базовое положение руки: ванильный applyEquipOffset мы глушим,
		// поэтому ставим смещение сами
		applyEquipOffset(matrices, arm);

		switch (mode.get()) {
			case EXHIBITION -> {
				matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * (45.0f + anim * -20.0f)));
				matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(side * g * -20.0f));
				matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(g * -80.0f));
				matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * -45.0f));
			}
			case SLIDE -> {
				matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(50.0f));
				matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * -60.0f));
				matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(side * (110.0f + power * g)));
			}
			case STAB -> {
				matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(50.0f));
				matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(
						side * (-30.0f * (1.0f - g) - 30.0f + (power - 20.0f) * g)));
				matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(side * 110.0f));
			}
			case PUSHDOWN -> {
				matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(side * 90.0f));
				matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(side * -30.0f));
				matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-90.0f - power * anim + 10.0f));
			}
			case SPIN -> matrices.multiply(RotationAxis.POSITIVE_X.rotationDegrees(swingProgress * -360.0f));
			default -> {
				// неизвестный режим — просто базовое положение
			}
		}
		return true;
	}

	/**
	 * Базовое смещение руки в кадре — эквивалент ванильного
	 * applyEquipOffset для полностью выдвинутой руки (equipProgress = 0).
	 */
	private static void applyEquipOffset(MatrixStack matrices, Arm arm) {
		float side = arm == Arm.RIGHT ? 1.0f : -1.0f;
		matrices.translate(side * 0.56f, -0.52f, -0.72f);
	}

	/** Активный экземпляр для миксинов (null — модуль выключен). */
	public static AttackAnimationsModule active() {
		ru.neuclient.client.NeuClient c = ru.neuclient.client.NeuClient.getInstance();
		if (c == null || c.getModuleManager() == null) {
			return null;
		}
		AttackAnimationsModule m = c.getModuleManager().get(AttackAnimationsModule.class);
		return m != null && m.isEnabled() ? m : null;
	}
}
