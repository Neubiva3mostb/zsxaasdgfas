package ru.neuclient.client.bot;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ServerAddress;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.entity.Entity;
import org.lwjgl.glfw.GLFW;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.util.ChatUtil;
import ru.neuclient.client.util.ClientPaths;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.Consumer;
import com.google.gson.*;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

/**
 * Multi-Instance BotManager для NeuClient (Minecraft 1.21.11).
 * 
 * Управляет отдельными экземплярами Minecraft для ботов.
 */
public final class BotManager {

    private static final BotManager INSTANCE = new BotManager();


    private final boolean isChildBot;
    private final String botNickname;
    private boolean initialHiddenApplied = false;

    // Для родительского (основного) процесса
    private ServerSocket ipcServerSocket;
    private int ipcPort = 0;
    private final Map<String, BotProcessHandle> activeBots = new ConcurrentHashMap<>();
    private String currentJoinedBot = null;

    /** Сохранённые ники (bots.json) — показываются в менеджере ботов. */
    private final List<String> savedNicks = new ArrayList<>();
    /** Прокси по нику (нижний регистр) → "ip:port[:login:pass]". */
    private final Map<String, String> proxies = new ConcurrentHashMap<>();
    /** Дочерний процесс: громкость до скрытия окна (для восстановления). */
    private double savedMasterVolume = -1;
    /** Последняя телеметрия от каждого бота (ключ — ник в нижнем регистре). */
    private final Map<String, BotStatus> statuses = new ConcurrentHashMap<>();
    /** Тиков до следующей отправки статуса (дочерний процесс). */
    private int statusCooldown = 0;

    // Для дочернего (бот) процесса
    private Socket ipcClientSocket;
    private volatile PrintWriter ipcWriter;
    private final String ipcToken = System.getProperty("neuclient.bot.ipc_token", UUID.randomUUID().toString());
    private final BotOrderGuard orderGuard = new BotOrderGuard();
    private BotRallyNavigation rally;
    private long lastGroupText = Long.MIN_VALUE / 2;
    private volatile GroupReport groupReport;
    private final Map<String, BotGroupOrder> followers = new ConcurrentHashMap<>();
    private Object followWorld, followPlayer;
    private int followCooldown;
    private BufferedReader ipcReader;

    private BotManager() {
        String propBotName = System.getProperty("neuclient.bot.name");
        this.isChildBot = (propBotName != null && !propBotName.isBlank());
        this.botNickname = isChildBot ? propBotName.trim() : null;

        if (isChildBot) {
            initChildIpc();
        } else {
            initParentIpc();
            loadNicks();
        }
    }

    // =========================================================================
    // СПИСОК НИКОВ (bots.json) + ТЕЛЕМЕТРИЯ
    // =========================================================================

    public static final class BotStatus {
        public float health, maxHealth;
        public double x, y, z;
        public String server = "";
        public String dimension = "";
        public String dimensionKey = "";
        public int groupProtocol;
        public int food;
        public long updatedMs;
        /** 41 слот: 0-8 хотбар, 9-35 инвентарь, 36-39 броня (ноги→шлем), 40 — левая рука. */
        public final ItemStack[] inv = new ItemStack[41];
        public BotStatus() { Arrays.fill(inv, ItemStack.EMPTY); }
    }

    public List<String> getSavedNicks() { return Collections.unmodifiableList(savedNicks); }

    public boolean addNick(String nick) {
        if (nick == null) return false;
        nick = nick.trim();
        if (nick.isEmpty() || nick.length() > 16 || !nick.matches("[A-Za-z0-9_]+")) return false;
        for (String n : savedNicks) if (n.equalsIgnoreCase(nick)) return false;
        savedNicks.add(nick);
        saveNicks();
        return true;
    }

    public String getProxy(String nick) {
        if (nick == null) return "";
        return proxies.getOrDefault(nick.toLowerCase(Locale.ROOT), "");
    }

    /** Назначить прокси боту (пусто/off — убрать). Применится при следующем запуске. */
    public void setProxy(String nick, String proxy) {
        if (nick == null) return;
        String key = nick.toLowerCase(Locale.ROOT);
        ru.neuclient.client.config.ProxyConfig cfg = ru.neuclient.client.config.ProxyConfig.parse(proxy);
        if (cfg.isActive()) proxies.put(key, cfg.toCompact());
        else proxies.remove(key);
        saveNicks();
    }

    public boolean removeNick(String nick) {
        if (nick == null) return false;
        boolean removed = savedNicks.removeIf(n -> n.equalsIgnoreCase(nick));
        if (removed) {
            proxies.remove(nick.toLowerCase(Locale.ROOT));
            if (isRunning(nick)) stopBot(nick);
            saveNicks();
        }
        return removed;
    }

    public boolean isRunning(String nick) {
        if (nick == null) return false;
        BotProcessHandle h = activeBots.get(nick.toLowerCase(Locale.ROOT));
        return h != null && h.process.isAlive();
    }

    public boolean isJoined(String nick) {
        return nick != null && currentJoinedBot != null && currentJoinedBot.equalsIgnoreCase(nick);
    }

    /** Бот готов к переключению: процесс жив, IPC подключён и пришла телеметрия (бот в мире). */
    public boolean isReady(String nick) {
        if (nick == null) return false;
        String key = nick.toLowerCase(Locale.ROOT);
        BotProcessHandle h = activeBots.get(key);
        if (h == null || !h.process.isAlive() || h.writer == null) return false;
        BotStatus st = statuses.get(key);
        return st != null && st.updatedMs > h.launchTimeMs && System.currentTimeMillis() - st.updatedMs < 4000;
    }

    public BotStatus getStatus(String nick) {
        return nick == null ? null : statuses.get(nick.toLowerCase(Locale.ROOT));
    }

    // Group control is not queued for offline bots. Results refer only to the latest dispatch.
    private record GroupResult(String state, String message, long updated) {}
    private static final class GroupReport {
        final String id = UUID.randomUUID().toString();
        final Map<String, GroupResult> results = new ConcurrentHashMap<>();
    }

    public int readyGroupCount() {
        int count = 0;
        for (String nick : activeBots.keySet()) {
            BotStatus st = statuses.get(nick);
            if (isReady(nick) && st != null && st.groupProtocol == BotGroupOrder.VERSION) count++;
        }
        return count;
    }

    public String groupResult(String nick) {
        GroupReport report = groupReport;
        GroupResult r = report == null || nick == null ? null : report.results.get(nick.toLowerCase(Locale.ROOT));
        if (r == null) return "";
        if ((r.state().equals("pending") || r.state().equals("moving") || r.state().equals("waiting")) && System.currentTimeMillis() - r.updated() > 6000)
            return "Нет подтверждения: проверьте подключение бота";
        return r.message();
    }

    public boolean hasFollowers() { return !followers.isEmpty(); }

    /** Вызывается только после отправки ванильного attackEntity-пакета (не для отменённых ударов). */
    public void onAttackPacket(Entity target) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (isChildBot) {
            if (rally != null) rally.onAttackPacket(target);
            return;
        }
        if (followers.isEmpty() || !(target instanceof net.minecraft.entity.LivingEntity living)
                || !living.isAlive() || mc.player == null || mc.world == null
                || mc.player != followPlayer || mc.world != followWorld || NeuClient.getInstance().isPanicked()) return;
        String server = getServerTarget(mc), dimension = mc.world.getRegistryKey().getValue().toString();
        long now = System.currentTimeMillis();
        for (var entry : followers.entrySet()) {
            BotGroupOrder session = entry.getValue();
            if (!BotGroupOrder.normalizeServer(server).equals(BotGroupOrder.normalizeServer(session.server()))
                    || !dimension.equals(session.dimension()) || !isReady(entry.getKey())) continue;
            BotProcessHandle handle = activeBots.get(entry.getKey());
            PrintWriter writer = handle == null ? null : handle.writer;
            if (writer == null) continue;
            writer.println(new BotGroupOrder(session.id(), "HIT", server, dimension,
                    mc.player.getX(), mc.player.getY(), mc.player.getZ(), target.getUuid().toString(), now).encode());
            if (writer.checkError()) followers.remove(entry.getKey(), session);
        }
    }

    private void stopFollowers() {
        for (var entry : followers.entrySet()) {
            BotGroupOrder session = entry.getValue();
            if (!followers.remove(entry.getKey(), session)) continue;
            BotProcessHandle handle = activeBots.get(entry.getKey());
            PrintWriter writer = handle == null ? null : handle.writer;
            if (writer != null) writer.println(new BotGroupOrder(UUID.randomUUID().toString(), "STOP", session.server(),
                    session.dimension(), 0, 0, 0, "", System.currentTimeMillis()).encode());
        }
        followWorld = followPlayer = null;
        followCooldown = 0;
    }

    private void tickFollowers(MinecraftClient mc) {
        if (followers.isEmpty()) { followWorld = followPlayer = null; return; }
        if (mc.player == null || mc.world == null || mc.player != followPlayer || mc.world != followWorld
                || !mc.player.isAlive() || NeuClient.getInstance().isPanicked()) { stopFollowers(); return; }
        if (--followCooldown > 0) return;
        followCooldown = 5;
        String server = getServerTarget(mc), dimension = mc.world.getRegistryKey().getValue().toString();
        for (var entry : followers.entrySet()) {
            BotGroupOrder session = entry.getValue();
            if (!BotGroupOrder.normalizeServer(server).equals(BotGroupOrder.normalizeServer(session.server()))
                    || !dimension.equals(session.dimension())) { stopFollowers(); return; }
            BotProcessHandle handle = activeBots.get(entry.getKey());
            PrintWriter writer = handle == null ? null : handle.writer;
            if (writer == null || !isReady(entry.getKey())) {
                if (followers.remove(entry.getKey(), session) && writer != null)
                    writer.println(new BotGroupOrder(UUID.randomUUID().toString(), "STOP", session.server(), dimension, 0, 0, 0, "", System.currentTimeMillis()).encode());
                continue;
            }
            writer.println(new BotGroupOrder(session.id(), "FOLLOW", server, dimension,
                    mc.player.getX(), mc.player.getY(), mc.player.getZ(), "", System.currentTimeMillis()).encode());
            if (writer.checkError()) followers.remove(entry.getKey(), session);
        }
    }

    public String rallyAll() { return dispatchGroup("GO", ""); }
    public String stopAllRallies() { return dispatchGroup("STOP", ""); }
    public String sendAll(String text) {
        try { return dispatchGroup("TEXT", BotGroupOrder.validateText(text)); }
        catch (IllegalArgumentException e) { return e.getMessage(); }
    }

    private String dispatchGroup(String kind, String text) {
        if (isChildBot) return "Групповые команды доступны из основного окна";
        MinecraftClient mc = MinecraftClient.getInstance();
        String server = getServerTarget(mc);
        if (kind.equals("GO") && (mc.player == null || mc.world == null || server == null || !mc.player.isAlive()))
            return "Главный аккаунт должен быть в игре";
        long now = System.currentTimeMillis();
        if (kind.equals("TEXT") && now - lastGroupText < 2000) return "Подождите 2 секунды перед следующей отправкой";
        String dimension = mc.world == null ? "" : mc.world.getRegistryKey().getValue().toString();
        if (kind.equals("GO") || kind.equals("STOP")) stopFollowers();
        if (kind.equals("GO")) { followWorld = mc.world; followPlayer = mc.player; followCooldown = 0; }
        GroupReport report = new GroupReport();
        groupReport = report;
        int sent = 0;
        for (BotProcessHandle handle : activeBots.values()) {
            String key = handle.nickname.toLowerCase(Locale.ROOT);
            BotStatus st = statuses.get(key);
            String skip = !isReady(key) || st == null ? "Не подключён / нет свежего статуса"
                    : st.groupProtocol != BotGroupOrder.VERSION ? "Перезапустите бота с новым JAR"
                    : kind.equals("GO") && !BotGroupOrder.normalizeServer(server).equals(BotGroupOrder.normalizeServer(st.server)) ? "Бот на другом сервере"
                    : kind.equals("GO") && !dimension.equals(st.dimensionKey) ? "Бот в другом измерении" : null;
            if (skip != null) { report.results.put(key, new GroupResult("rejected", skip, now)); continue; }
            BotGroupOrder order = new BotGroupOrder(report.id, kind, st.server, dimension,
                    mc.player == null ? 0 : mc.player.getX(), mc.player == null ? 0 : mc.player.getY(), mc.player == null ? 0 : mc.player.getZ(), text, now);
            report.results.put(key, new GroupResult("pending", "Приказ отправлен, ждём ответ бота", now));
            PrintWriter writer = handle.writer;
            if (writer == null) { report.results.put(key, new GroupResult("failed", "IPC отключён", now)); continue; }
            if (kind.equals("GO")) followers.put(key, order);
            writer.println(order.encode());
            if (writer.checkError()) {
                followers.remove(key, order);
                report.results.put(key, new GroupResult("failed", "Ошибка отправки IPC", now));
            } else sent++;
        }
        if (kind.equals("TEXT") && sent > 0) lastGroupText = now;
        return sent == 0 ? "Нет готовых получателей. Причина — в карточке бота" : "Отправлено ботам: " + sent + ". Ожидаем подтверждения";
    }

    private void applyGroupResult(String nick, String json) {
        if (json.length() > 2048) return;
        JsonObject o = JsonParser.parseString(json).getAsJsonObject();
        String id = o.get("id").getAsString(), state = o.get("state").getAsString(), message = o.get("message").getAsString();
        if (!Set.of("moving", "waiting", "arrived", "sent", "stopped", "failed", "rejected").contains(state) || message.length() > 180) return;
        BotGroupOrder session = followers.get(nick);
        if (session != null && session.id().equals(id) && Set.of("stopped", "failed", "rejected").contains(state)) followers.remove(nick, session);
        GroupReport report = groupReport;
        if (report == null || !report.id.equals(id) || !report.results.containsKey(nick)) return;
        report.results.put(nick, new GroupResult(state, message, System.currentTimeMillis()));
    }

    private void sendGroupResult(String id, String state, String message) {
        PrintWriter writer = ipcWriter;
        if (writer == null) return;
        JsonObject o = new JsonObject(); o.addProperty("id", id); o.addProperty("state", state); o.addProperty("message", message);
        writer.println("GROUP_RESULT:" + o);
    }

    private void executeGroupOrder(BotGroupOrder order) {
        if (!isChildBot) return;
        try {
            if (order.kind().equals("FOLLOW")) {
                order.validate(System.currentTimeMillis());
                if (rally != null) rally.update(order);
                return;
            }
            if (order.kind().equals("HIT")) {
                order.validate(System.currentTimeMillis());
                if (rally != null && BotGroupOrder.normalizeServer(getServerTarget(MinecraftClient.getInstance()))
                        .equals(BotGroupOrder.normalizeServer(order.server()))) rally.onLeaderHit(order);
                return;
            }
            String accepted = orderGuard.accept(order, System.currentTimeMillis());
            if (accepted.equals("duplicate")) return;
            if (!accepted.equals("ok")) { sendGroupResult(order.id(), "rejected", "Слишком частая отправка текста"); return; }
            if (order.kind().equals("STOP")) {
                cancelRally("Остановлено главным"); sendGroupResult(order.id(), "stopped", "Групповое движение остановлено"); return;
            }
            MinecraftClient mc = MinecraftClient.getInstance();
            if (mc.player == null || mc.world == null || mc.getNetworkHandler() == null || NeuClient.getInstance().isPanicked()) {
                sendGroupResult(order.id(), "rejected", "Бот не в игре / клиент отключён"); return;
            }
            if (!BotGroupOrder.normalizeServer(getServerTarget(mc)).equals(BotGroupOrder.normalizeServer(order.server()))) {
                sendGroupResult(order.id(), "rejected", "Сервер изменился после отправки приказа"); return;
            }
            if (order.kind().equals("TEXT")) {
                String message = BotGroupOrder.validateText(order.text());
                if (message.startsWith("/")) mc.getNetworkHandler().sendChatCommand(message.substring(1));
                else mc.getNetworkHandler().sendChatMessage(message);
                sendGroupResult(order.id(), "sent", "Передано серверу (ответ сервера — в чате бота)");
            } else {
                if (rally == null) rally = new BotRallyNavigation(mc);
                rally.start(order, (state, message) -> sendGroupResult(order.id(), state, message));
            }
        } catch (Exception e) { sendGroupResult(order.id(), "failed", "Приказ отклонён / ошибка выполнения"); }
    }

    public void tickRally() {
        if (!isChildBot) { tickFollowers(MinecraftClient.getInstance()); return; }
        if (isChildBot && rally != null) {
            if (ipcWriter == null) cancelRally("Соединение с главным потеряно");
            rally.tick();
        }
    }
    public boolean isRallying() { return isChildBot && rally != null && rally.active(); }
    public net.minecraft.util.PlayerInput rallyInput(net.minecraft.util.PlayerInput input) { return isRallying() ? rally.input(input) : input; }
    private void cancelRally(String reason) { if (rally != null) rally.cancel(reason); }

    private void loadNicks() {
        Path f = ClientPaths.file("bots.json");
        if (!Files.exists(f)) return;
        try {
            JsonElement el = JsonParser.parseString(Files.readString(f, StandardCharsets.UTF_8));
            if (el.isJsonArray()) {
                for (JsonElement e : el.getAsJsonArray()) {
                    String n;
                    String proxy = "";
                    if (e.isJsonObject()) {
                        JsonObject o = e.getAsJsonObject();
                        n = o.get("nick").getAsString();
                        if (o.has("proxy")) proxy = o.get("proxy").getAsString();
                    } else {
                        n = e.getAsString();
                    }
                    if (savedNicks.stream().noneMatch(x -> x.equalsIgnoreCase(n))) savedNicks.add(n);
                    if (!proxy.isBlank()) proxies.put(n.toLowerCase(Locale.ROOT), proxy);
                }
            }
        } catch (Exception e) {
        }
    }

    private void saveNicks() {
        try {
            JsonArray arr = new JsonArray();
            for (String n : savedNicks) {
                JsonObject o = new JsonObject();
                o.addProperty("nick", n);
                String p = proxies.get(n.toLowerCase(Locale.ROOT));
                if (p != null && !p.isBlank()) o.addProperty("proxy", p);
                arr.add(o);
            }
            Files.writeString(ClientPaths.file("bots.json"),
                    new GsonBuilder().setPrettyPrinting().create().toJson(arr), StandardCharsets.UTF_8);
        } catch (Exception e) {
        }
    }

    /** Дочерний процесс: собрать телеметрию в JSON-строку. */
    private String buildStatusJson(MinecraftClient mc) {
        if (mc.player == null || mc.world == null || mc.getNetworkHandler() == null) return "{\"online\":false}";
        JsonObject o = new JsonObject();
        o.addProperty("hp", mc.player.getHealth());
        o.addProperty("maxhp", mc.player.getMaxHealth());
        o.addProperty("food", mc.player.getHungerManager().getFoodLevel());
        o.addProperty("x", mc.player.getX());
        o.addProperty("y", mc.player.getY());
        o.addProperty("z", mc.player.getZ());
        o.addProperty("dim", mc.world.getRegistryKey().getValue().getPath());
        o.addProperty("dimensionKey", mc.world.getRegistryKey().getValue().toString());
        o.addProperty("groupProtocol", BotGroupOrder.VERSION);
        String srv = getServerTarget(mc);
        o.addProperty("server", srv == null ? "" : srv);
        JsonArray inv = new JsonArray();
        var pinv = mc.player.getInventory();
        for (int i = 0; i < 41; i++) {
            ItemStack st;
            if (i < 36) st = pinv.getStack(i);
            else if (i < 40) st = mc.player.getEquippedStack(switch (i) {
                case 36 -> net.minecraft.entity.EquipmentSlot.FEET;
                case 37 -> net.minecraft.entity.EquipmentSlot.LEGS;
                case 38 -> net.minecraft.entity.EquipmentSlot.CHEST;
                default -> net.minecraft.entity.EquipmentSlot.HEAD;
            });
            else st = mc.player.getOffHandStack();
            if (st == null || st.isEmpty()) {
                inv.add(JsonNull.INSTANCE);
            } else {
                JsonObject it = new JsonObject();
                it.addProperty("id", Registries.ITEM.getId(st.getItem()).toString());
                it.addProperty("n", st.getCount());
                it.addProperty("dmg", st.getDamage());
                inv.add(it);
            }
        }
        o.add("inv", inv);
        return o.toString();
    }

    /** Родитель: разобрать телеметрию бота. */
    private void applyStatus(String nick, String json) {
        try {
            JsonObject o = JsonParser.parseString(json).getAsJsonObject();
            if (o.has("online") && !o.get("online").getAsBoolean()) { statuses.remove(nick.toLowerCase(Locale.ROOT)); return; }
            BotStatus st = new BotStatus();
            st.health = o.get("hp").getAsFloat();
            st.maxHealth = o.get("maxhp").getAsFloat();
            st.food = o.has("food") ? o.get("food").getAsInt() : 0;
            st.x = o.get("x").getAsDouble();
            st.y = o.get("y").getAsDouble();
            st.z = o.get("z").getAsDouble();
            st.dimension = o.has("dim") ? o.get("dim").getAsString() : "";
            st.dimensionKey = o.has("dimensionKey") ? o.get("dimensionKey").getAsString() : "";
            st.groupProtocol = o.has("groupProtocol") ? o.get("groupProtocol").getAsInt() : 0;
            st.server = o.has("server") ? o.get("server").getAsString() : "";
            JsonArray inv = o.getAsJsonArray("inv");
            for (int i = 0; i < 41 && i < inv.size(); i++) {
                JsonElement e = inv.get(i);
                if (e == null || e.isJsonNull()) { st.inv[i] = ItemStack.EMPTY; continue; }
                JsonObject it = e.getAsJsonObject();
                Item item = Registries.ITEM.get(Identifier.of(it.get("id").getAsString()));
                ItemStack stack = new ItemStack(item, it.get("n").getAsInt());
                if (it.has("dmg") && it.get("dmg").getAsInt() > 0) stack.setDamage(it.get("dmg").getAsInt());
                st.inv[i] = stack;
            }
            st.updatedMs = System.currentTimeMillis();
            statuses.put(nick.toLowerCase(Locale.ROOT), st);
        } catch (Exception ignored) {
        }
    }

    public static BotManager getInstance() {
        return INSTANCE;
    }

    public boolean isChildBot() {
        return isChildBot;
    }

    public String getBotNickname() {
        return botNickname;
    }

    public boolean isBot(String nickname) {
        if (nickname == null || activeBots.isEmpty()) return false;
        return activeBots.containsKey(nickname.toLowerCase(Locale.ROOT));
    }

    public boolean isBot(Entity entity) {
        if (entity == null || activeBots.isEmpty()) return false;
        return isBot(entity.getName().getString());
    }

    // =========================================================================
    // РОДИТЕЛЬСКИЙ ПРОЦЕСС: IPC СЕРВЕР
    // =========================================================================

    private void initParentIpc() {
        try {
            ipcServerSocket = new ServerSocket(0, 50, InetAddress.getByName("127.0.0.1"));
            ipcPort = ipcServerSocket.getLocalPort();
            System.setProperty("neuclient.bot.ipc_port", String.valueOf(ipcPort));

            Path portFile = ClientPaths.tempFile("bot_ipc.port");
            try {
                Files.writeString(portFile, String.valueOf(ipcPort), StandardCharsets.UTF_8);
            } catch (Exception ignored) {}

            Thread serverThread = new Thread(this::runIpcServer, "NeuBot-IPC-Server");
            serverThread.setDaemon(true);
            serverThread.start();
        } catch (Exception e) {
        }
    }

    private void runIpcServer() {
        while (!ipcServerSocket.isClosed()) {
            try {
                Socket socket = ipcServerSocket.accept();
                socket.setTcpNoDelay(true);
                Thread clientHandler = new Thread(() -> handleParentSocket(socket), "NeuBot-IPC-Handler");
                clientHandler.setDaemon(true);
                clientHandler.start();
            } catch (Exception e) {
                if (ipcServerSocket.isClosed()) break;
            }
        }
    }

    private void handleParentSocket(Socket socket) {
        String registeredName = null;
        try (socket;
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
             PrintWriter out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8), true)) {
            socket.setSoTimeout(5000);
            String first = in.readLine();
            if (first == null || first.length() > 256 || !first.startsWith("REGISTER:")) return;
            String[] registration = first.substring(9).split(":", 2);
            if (registration.length != 2 || !ipcToken.equals(registration[1])) return;
            String key = registration[0].trim().toLowerCase(Locale.ROOT);
            BotProcessHandle handle = activeBots.get(key);
            if (handle == null || !handle.process.isAlive()) return;
            registeredName = key;
            synchronized (handle) {
                Socket old = handle.socket;
                handle.socket = socket;
                handle.writer = out;
                if (old != null && old != socket) try { old.close(); } catch (IOException ignored) {}
            }
            socket.setSoTimeout(0);
            out.println("ACK_REGISTER");
            String line;
            while ((line = in.readLine()) != null) {
                if (line.length() > 65536 || handle.socket != socket) break;
                try { handleParentLine(line.trim(), registeredName); } catch (Exception ignored) {}
            }
        } catch (Exception ignored) {
        } finally {
            if (registeredName != null) {
                BotProcessHandle handle = activeBots.get(registeredName);
                if (handle != null) synchronized (handle) {
                    if (handle.socket == socket) {
                        handle.writer = null;
                        handle.socket = null;
                        statuses.remove(registeredName);
                        followers.remove(registeredName);
                    }
                }
                onBotExited(registeredName);
            }
        }
    }

    private void handleParentLine(String line, String registeredName) {
        if (line.equals("SHOW_MAIN")) showMainWindow();
        else if (line.startsWith("SWITCH_TO_BOT:")) {
            String target = line.substring("SWITCH_TO_BOT:".length()).trim();
            MinecraftClient.getInstance().execute(() -> joinBot(target));
        } else if (line.startsWith("STATUS:")) applyStatus(registeredName, line.substring(7));
        else if (line.startsWith("GROUP_RESULT:")) applyGroupResult(registeredName, line.substring(13));
        else if (line.startsWith("BOT_CLOSED:")) onBotExited(registeredName);
    }

    // =========================================================================
    // ДОЧЕРНИЙ ПРОЦЕСС: IPC КЛИЕНТ
    // =========================================================================

    private void initChildIpc() {
        int targetPort = 0;
        String propPort = System.getProperty("neuclient.bot.ipc_port");
        if (propPort != null && !propPort.isBlank()) {
            try {
                targetPort = Integer.parseInt(propPort.trim());
            } catch (Exception ignored) {}
        }

        if (targetPort <= 0) {
            Path portFile = ClientPaths.tempFile("bot_ipc.port");
            if (Files.exists(portFile)) {
                try {
                    targetPort = Integer.parseInt(Files.readString(portFile, StandardCharsets.UTF_8).trim());
                } catch (Exception ignored) {}
            }
        }

        final int connectPort = targetPort;
        if (connectPort > 0) {
            Thread clientThread = new Thread(() -> runChildIpcClient(connectPort), "NeuBot-IPC-Client");
            clientThread.setDaemon(true);
            clientThread.start();
        }
    }

    private void runChildIpcClient(int port) {
        while (true) {
            ipcReader = null;
            ipcWriter = null;
            runChildIpcSession(port);
            try { Thread.sleep(1000); } catch (InterruptedException e) { return; }
        }
    }

    private void runChildIpcSession(int port) {
        for (int attempt = 0; attempt < 30; attempt++) {
            try {
                ipcClientSocket = new Socket("127.0.0.1", port);
                ipcClientSocket.setTcpNoDelay(true);
                ipcWriter = new PrintWriter(new OutputStreamWriter(ipcClientSocket.getOutputStream(), StandardCharsets.UTF_8), true);
                ipcReader = new BufferedReader(new InputStreamReader(ipcClientSocket.getInputStream(), StandardCharsets.UTF_8));
                ipcWriter.println("REGISTER:" + botNickname + ":" + ipcToken);
                break;
            } catch (Exception e) {
                try {
                    Thread.sleep(300);
                } catch (Exception ignored) {}
            }
        }

        if (ipcReader == null) return;

        try {
            String line;
            while ((line = ipcReader.readLine()) != null) {
                line = line.trim();
                try {
                    if (line.startsWith(BotGroupOrder.PREFIX)) {
                        BotGroupOrder order = BotGroupOrder.decode(line, System.currentTimeMillis());
                        MinecraftClient.getInstance().execute(() -> executeGroupOrder(order));
                    } else if (line.equals("SHOW")) {
                        showChildWindow();
                    } else if (line.equals("HIDE")) {
                        hideChildWindow();
                    } else if (line.equals("TERMINATE")) {
                        MinecraftClient.getInstance().execute(() -> { cancelRally("Бот остановлен"); MinecraftClient.getInstance().scheduleStop(); });
                    }
                } catch (Throwable t) {
                }
            }
        } catch (Exception ignored) {
        } finally {
            try { if (ipcClientSocket != null) ipcClientSocket.close(); } catch (Exception ignored) {}
            ipcWriter = null;
            MinecraftClient.getInstance().execute(() -> cancelRally("Соединение с главным потеряно"));
        }
    }

    // =========================================================================
    // УПРАВЛЕНИЕ ОКНАМИ
    // =========================================================================

    /** Показать окно текущего процесса (вызывать в render-потоке). */
    private void glfwShowSelf(MinecraftClient mc) {
        try {
            long handle = mc.getWindow().getHandle();
            if (handle == 0) return;
            GLFW.glfwShowWindow(handle);
            GLFW.glfwRestoreWindow(handle);
            GLFW.glfwFocusWindow(handle);
            GLFW.glfwRequestWindowAttention(handle);
        } catch (Throwable ignored) {}
    }

    /** Спрятать окно текущего процесса полностью (не в трей и не в панель задач). */
    private void glfwHideSelf(MinecraftClient mc) {
        try {
            long handle = mc.getWindow().getHandle();
            if (handle != 0) {
                GLFW.glfwHideWindow(handle);
            }
        } catch (Throwable ignored) {}
    }

    /** Глушим звук спрятанного окна (мастер-громкость → 0, значение запоминаем). */
    private void muteSelf(MinecraftClient mc) {
        try {
            var opt = mc.options.getSoundVolumeOption(net.minecraft.sound.SoundCategory.MASTER);
            if (savedMasterVolume < 0) savedMasterVolume = opt.getValue();
            opt.setValue(0.0);
            mc.getSoundManager().setVolume(net.minecraft.sound.SoundCategory.MASTER, 0.0f);
        } catch (Throwable ignored) {}
    }

    private void unmuteSelf(MinecraftClient mc) {
        try {
            if (savedMasterVolume < 0) return;
            var opt = mc.options.getSoundVolumeOption(net.minecraft.sound.SoundCategory.MASTER);
            opt.setValue(savedMasterVolume);
            mc.getSoundManager().setVolume(net.minecraft.sound.SoundCategory.MASTER, (float) savedMasterVolume);
            savedMasterVolume = -1;
        } catch (Throwable ignored) {}
    }

    public void showMainWindow() {
        currentJoinedBot = null;
        MinecraftClient mc = MinecraftClient.getInstance();
        mc.execute(() -> {
            glfwShowSelf(mc);
            unmuteSelf(mc);
            ChatUtil.send("§a[NeuBot] Экран возвращен на §fосновной аккаунт§a.");
        });
    }

    public void hideMainWindow() {
        MinecraftClient mc = MinecraftClient.getInstance();
        mc.execute(() -> {
            glfwHideSelf(mc);
            muteSelf(mc);
        });
    }

    public void showChildWindow() {
        MinecraftClient mc = MinecraftClient.getInstance();
        mc.execute(() -> {
            glfwShowSelf(mc);
            unmuteSelf(mc);
            ChatUtil.send("§a[NeuBot] Вы переключились на бота §f" + botNickname + "§a. Вернуться: кнопка §f«Вернуться обратно»§a в меню (RShift).");
        });
    }

    public void hideChildWindow() {
        MinecraftClient mc = MinecraftClient.getInstance();
        mc.execute(() -> {
            glfwHideSelf(mc);
            muteSelf(mc);
        });
    }

    // =========================================================================
    // КОМАНДЫ ПОЛЬЗОВАТЕЛЯ
    // =========================================================================

    public void startBot(String nickname) {
        if (isChildBot) {
            ChatUtil.error("§c[NeuBot] Запуск ботов выполняется из основного аккаунта.");
            return;
        }

        MinecraftClient mc = MinecraftClient.getInstance();
        if (nickname == null || nickname.trim().isEmpty()) {
            ChatUtil.error("§c[NeuBot] Укажите ник бота.");
            return;
        }

        nickname = nickname.trim();
        String key = nickname.toLowerCase(Locale.ROOT);

        // 1. Проверка на ник основного игрока
        if (mc.getSession() != null && nickname.equalsIgnoreCase(mc.getSession().getUsername())) {
            ChatUtil.error("§c[NeuBot] Нельзя запустить бота с тем же ником, что и у вашего основного аккаунта!");
            return;
        }

        // 2. Проверка: нельзя запустить 2 бота с одинаковым ником
        if (activeBots.containsKey(key)) {
            BotProcessHandle existing = activeBots.get(key);
            if (existing != null && existing.process.isAlive()) {
                ChatUtil.error("§c[NeuBot] Бот с ником §f" + nickname + " §cуже запущен! Нельзя запустить двух ботов с одинаковым ником.");
                return;
            } else {
                activeBots.remove(key);
            }
        }

        String serverTarget = getServerTarget(mc);

        ChatUtil.send("§a[NeuBot] Запуск отдельного окна Minecraft для бота §f" + nickname + "§a...");
        try {
            BotProcessHandle handle = launchBotProcess(nickname, serverTarget, true);
            activeBots.put(key, handle);
            if (savedNicks.stream().noneMatch(n -> n.equalsIgnoreCase(handle.nickname))) {
                savedNicks.add(handle.nickname);
                saveNicks();
            }
            ChatUtil.send("§a[NeuBot] Бот §f" + nickname + " §aзапущен! Переключение станет доступно, как только он зайдёт в игру.");
        } catch (Exception e) {
            ChatUtil.error("§c[NeuBot] Ошибка запуска процесса бота: " + e.getMessage());
        }
    }

    public void joinBot(String nickname) {
        if (nickname == null || nickname.trim().isEmpty()) {
            nickname = "main";
        }
        nickname = nickname.trim();

        if (nickname.equalsIgnoreCase("main") || nickname.equalsIgnoreCase("me") || nickname.equalsIgnoreCase("leave")) {
            if (isChildBot) {
                hideChildWindow();
                if (ipcWriter != null) {
                    ipcWriter.println("SHOW_MAIN");
                }
            } else {
                showMainWindow();
            }
            return;
        }

        if (isChildBot) {
            if (ipcWriter != null) {
                hideChildWindow();
                ipcWriter.println("SWITCH_TO_BOT:" + nickname);
            }
            return;
        }

        String key = nickname.toLowerCase(Locale.ROOT);
        BotProcessHandle handle = activeBots.get(key);

        if (handle == null || !handle.process.isAlive()) {
            ChatUtil.send("§e[NeuBot] Бот §f" + nickname + " §eещё не запущен. Запускаем...");
            startBot(nickname);
            return;
        }

        if (!isReady(handle.nickname)) {
            ChatUtil.error("§e[NeuBot] Бот §f" + handle.nickname + " §eещё подключается к серверу, подождите...");
            return;
        }
        currentJoinedBot = key;
        handle.writer.println("SHOW");
        hideMainWindow();
    }

    public void stopBot(String nickname) {
        if (isChildBot) {
            ChatUtil.error("§c[NeuBot] Остановка ботов выполняется из основного аккаунта.");
            return;
        }

        if (nickname.equalsIgnoreCase("all")) {
            disconnectAll();
            showMainWindow();
            ChatUtil.send("§a[NeuBot] Все окна ботов закрыты и остановлены.");
            return;
        }

        String key = nickname.toLowerCase(Locale.ROOT);
        BotProcessHandle handle = activeBots.remove(key);
        statuses.remove(key);
        if (handle != null) {
            if (key.equals(currentJoinedBot)) {
                showMainWindow();
            }
            if (handle.writer != null) {
                try {
                    handle.writer.println("TERMINATE");
                } catch (Exception ignored) {}
            }
            try {
                handle.process.destroyForcibly();
            } catch (Exception ignored) {}
            ChatUtil.send("§a[NeuBot] Бот §f" + nickname + " §aостановлен и закрыт.");
        } else {
            ChatUtil.error("§c[NeuBot] Бот с ником §f" + nickname + " §cне найден.");
        }
    }

    public void listBots(Consumer<String> out) {
        if (isChildBot) {
            out.accept("§7Вы находитесь в окне бота: §f" + botNickname + "§7.");
            return;
        }

        // Проверяем живые процессы
        List<BotProcessHandle> living = new ArrayList<>();
        for (BotProcessHandle b : activeBots.values()) {
            if (b.process.isAlive()) {
                living.add(b);
            }
        }

        if (living.isEmpty()) {
            out.accept("§7Активных ботов нет.");
            return;
        }

        out.accept("§aАктивные боты (" + living.size() + "):");
        for (BotProcessHandle b : living) {
            boolean isCurrent = b.nickname.equalsIgnoreCase(currentJoinedBot);
            String status;
            if (isCurrent) {
                status = " §a[АКТИВЕН/ЭКРАН]";
            } else if (!isReady(b.nickname)) {
                status = " §6[ПОДКЛЮЧАЕТСЯ...]";
            } else {
                status = " §e[В ИГРЕ/ФОН]";
            }
            out.accept(" §8- §f" + b.nickname + " §7(PID: " + b.process.pid() + ")" + status);
        }
    }

    public void disconnectAll() {
        if (isChildBot) return;
        for (BotProcessHandle handle : activeBots.values()) {
            try {
                if (handle.writer != null) {
                    handle.writer.println("TERMINATE");
                }
                handle.process.destroyForcibly();
            } catch (Exception ignored) {}
        }
        activeBots.clear();
        statuses.clear();
        currentJoinedBot = null;
        if (ipcServerSocket != null && !ipcServerSocket.isClosed()) {
            try {
                ipcServerSocket.close();
            } catch (Exception ignored) {}
        }
        try {
            Path portFile = ClientPaths.tempFile("bot_ipc.port");
            Files.deleteIfExists(portFile);
        } catch (Exception ignored) {}
    }

    private void onBotExited(String name) {
        String key = name.toLowerCase(Locale.ROOT);
        BotProcessHandle handle = activeBots.get(key);
        if (handle != null && !handle.process.isAlive()) {
            activeBots.remove(key);
            statuses.remove(key);
            if (key.equalsIgnoreCase(currentJoinedBot)) {
                showMainWindow();
            }
        }
    }

    public void tick(MinecraftClient mc) {
        if (isChildBot) {
            mc.options.pauseOnLostFocus = false; // Background bots must not open the pause menu.
            String initHidden = System.getProperty("neuclient.bot.initial_hidden");
            if (!initialHiddenApplied && "true".equalsIgnoreCase(initHidden) && mc.getWindow() != null) {
                initialHiddenApplied = true;
                glfwHideSelf(mc);
                muteSelf(mc);
            }
            if (savedMasterVolume >= 0 && mc.getWindow() != null
                    && GLFW.glfwGetWindowAttrib(mc.getWindow().getHandle(), GLFW.GLFW_VISIBLE) == GLFW.GLFW_FALSE) {
                try {
                    var opt = mc.options.getSoundVolumeOption(net.minecraft.sound.SoundCategory.MASTER);
                    if (opt.getValue() > 0) opt.setValue(0.0);
                } catch (Throwable ignored) {}
            }
            if (ipcWriter != null && --statusCooldown <= 0) {
                statusCooldown = 10; // раз в полсекунды
                try {
                    String json = buildStatusJson(mc);
                    if (json != null) ipcWriter.println("STATUS:" + json);
                } catch (Throwable ignored) {}
            }
            return;
        }

        // Родительский процесс: отслеживаем закрытие подпроцессов
        Iterator<Map.Entry<String, BotProcessHandle>> it = activeBots.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, BotProcessHandle> entry = it.next();
            BotProcessHandle handle = entry.getValue();
            if (!handle.process.isAlive()) {
                it.remove();
                statuses.remove(entry.getKey());
                if (entry.getKey().equalsIgnoreCase(currentJoinedBot)) {
                    showMainWindow();
                    ChatUtil.send("§e[NeuBot] Окно бота §f" + handle.nickname + " §eбыло закрыто. Экран возвращен на основной аккаунт.");
                }
            }
        }
    }

    private String getServerTarget(MinecraftClient mc) {
        ServerInfo serverEntry = mc.getCurrentServerEntry();
        if (serverEntry != null && serverEntry.address != null && !serverEntry.address.isBlank()) {
            return serverEntry.address.trim();
        }
        if (mc.getNetworkHandler() != null && mc.getNetworkHandler().getConnection() != null) {
            SocketAddress remote = mc.getNetworkHandler().getConnection().getAddress();
            if (remote instanceof InetSocketAddress inet) {
                if (inet.getPort() == 25565) {
                    return inet.getHostString();
                } else {
                    return inet.getHostString() + ":" + inet.getPort();
                }
            }
        }
        return null;
    }

    // =========================================================================
    // ВНУТРЕННИЙ МЕТОД СПАВНА ПОДПРОЦЕССА JAVA
    // =========================================================================

    private BotProcessHandle launchBotProcess(String nickname, String serverTarget, boolean initialHidden) throws Exception {
        MinecraftClient mc = MinecraftClient.getInstance();

        // Настоящая игровая папка (.minecraft / папка лаунчера) — именно оттуда
        // Fabric грузит mods/, поэтому бот получит этот же мод.
        Path gameDir = mc.runDirectory != null ? mc.runDirectory.toPath().toAbsolutePath() : Path.of(".").toAbsolutePath();
        Path logDir = gameDir;

        // 1. Java — тот же бинарник, что и у нас
        String javaBin = ProcessHandle.current().info().command().orElse(null);
        if (javaBin == null) {
            String javaHome = System.getProperty("java.home");
            Path candW = Path.of(javaHome, "bin", "javaw.exe");
            Path candE = Path.of(javaHome, "bin", "java.exe");
            Path candU = Path.of(javaHome, "bin", "java");
            javaBin = Files.exists(candW) ? candW.toString() : Files.exists(candE) ? candE.toString() : candU.toString();
        }
        // На Windows предпочитаем javaw, чтобы не вылезала консоль
        if (javaBin.endsWith("java.exe")) {
            Path w = Path.of(javaBin.substring(0, javaBin.length() - "java.exe".length()) + "javaw.exe");
            if (Files.exists(w)) javaBin = w.toString();
        }

        List<String> cmd = new ArrayList<>();
        cmd.add(javaBin);

        // 2. JVM-аргументы родителя (java.library.path, fabric.*, natives и т.д.)
        //    минус память, дебаг-агенты и наши собственные флаги
        for (String arg : java.lang.management.ManagementFactory.getRuntimeMXBean().getInputArguments()) {
            if (arg.startsWith("-Xmx") || arg.startsWith("-Xms") || arg.startsWith("-Xss")
                    || arg.startsWith("-agentlib") || arg.startsWith("-javaagent") || arg.startsWith("-agentpath")
                    || arg.startsWith("-Dneuclient.bot.") || arg.startsWith("-Dfabric.log.file")
                    || arg.startsWith("-XX:HeapDumpPath") || arg.startsWith("-Dminecraft.launcher")) {
                continue;
            }
            cmd.add(arg);
        }
        cmd.add("-Xmx2048M");
        cmd.add("-Xms512M");
        cmd.add("-Dminecraft.launcher.brand=autowarden-bot");
        cmd.add("-Dminecraft.launcher.version=1.0.0");
        cmd.add("-Dneuclient.bot.name=" + nickname);
        cmd.add("-Dneuclient.bot.ipc_port=" + ipcPort);
        cmd.add("-Dneuclient.bot.ipc_token=" + ipcToken);
        if (initialHidden) {
            cmd.add("-Dneuclient.bot.initial_hidden=true");
        }
        String proxy = proxies.get(nickname.toLowerCase(Locale.ROOT));
        if (proxy != null && !proxy.isBlank()) {
            cmd.add("-Dneuclient.bot.proxy=" + proxy);
        }

        Path botLogFile = logDir.resolve("logs").resolve("bot-" + nickname + ".log");
        Files.createDirectories(botLogFile.getParent());
        cmd.add("-Dfabric.log.file=" + botLogFile.toAbsolutePath());

        cmd.add("-cp");
        cmd.add(System.getProperty("java.class.path"));

        // 3. Главный класс — тот же, что и у нас (Knot в проде, dev-launch в IDE)
        String mainClass = System.getProperty("sun.java.command", "");
        int sp = mainClass.indexOf(' ');
        if (sp > 0) mainClass = mainClass.substring(0, sp);
        if (mainClass.isBlank() || mainClass.endsWith(".jar")) {
            mainClass = "net.fabricmc.loader.impl.launch.knot.KnotClient";
        }
        cmd.add(mainClass);

        // 4. Игровые аргументы: берём родительские и подменяем аккаунт/сервер
        List<String> parentArgs = parentGameArgs();
        Set<String> drop = Set.of("--username", "--uuid", "--accessToken", "--clientId", "--xuid",
                "--userType", "--quickPlayMultiplayer", "--quickPlaySingleplayer", "--quickPlayRealms",
                "--quickPlayPath", "--server", "--port", "--width", "--height", "--fullscreen");
        boolean hasGameDir = false, hasAssets = false, hasIndex = false, hasVersion = false;
        for (int i = 0; i < parentArgs.size(); i++) {
            String a = parentArgs.get(i);
            boolean hasValue = i + 1 < parentArgs.size() && !parentArgs.get(i + 1).startsWith("--");
            if (drop.contains(a)) {
                if (hasValue) i++;
                continue;
            }
            if (a.equals("--gameDir")) hasGameDir = true;
            if (a.equals("--assetsDir")) hasAssets = true;
            if (a.equals("--assetIndex")) hasIndex = true;
            if (a.equals("--version")) hasVersion = true;
            cmd.add(a);
            if (hasValue) cmd.add(parentArgs.get(++i));
        }
        if (!hasGameDir) { cmd.add("--gameDir"); cmd.add(gameDir.toString()); }
        if (!hasAssets) { cmd.add("--assetsDir"); cmd.add(mc.getResourcePackDir().getParent().resolve("assets").toString()); }
        if (!hasIndex) { cmd.add("--assetIndex"); cmd.add("29"); }
        if (!hasVersion) { cmd.add("--version"); cmd.add("1.21.11"); }

        cmd.add("--username");
        cmd.add(nickname);
        cmd.add("--uuid");
        cmd.add(UUID.nameUUIDFromBytes(("OfflinePlayer:" + nickname).getBytes(StandardCharsets.UTF_8)).toString().replace("-", ""));
        cmd.add("--accessToken");
        cmd.add("0");
        cmd.add("--userType");
        cmd.add("legacy");

        if (serverTarget != null && !serverTarget.isBlank()) {
            cmd.add("--quickPlayMultiplayer");
            cmd.add(serverTarget.trim());
        }


        ProcessBuilder pb = new ProcessBuilder(cmd);
        pb.directory(gameDir.toFile());
        pb.redirectErrorStream(true);
        pb.redirectOutput(ProcessBuilder.Redirect.appendTo(botLogFile.toFile()));

        Process proc = pb.start();
        return new BotProcessHandle(nickname, proc);
    }

    /** Аргументы командной строки родителя после имени главного класса. */
    private static List<String> parentGameArgs() {
        List<String> out = new ArrayList<>();
        try {
            // Вариант 1: полная командная строка процесса (доступна почти всегда)
            Optional<String[]> args = ProcessHandle.current().info().arguments();
            if (args.isPresent()) {
                String[] a = args.get();
                int idx = -1;
                // Ищем первый ИГРОВОЙ аргумент (JVM-флаги вроде --add-opens идут раньше)
                for (String marker : new String[] { "--username", "--gameDir", "--version", "--assetsDir" }) {
                    for (int i = 0; i < a.length; i++) {
                        if (a[i].equals(marker)) { idx = idx < 0 ? i : Math.min(idx, i); break; }
                    }
                }
                if (idx >= 0) {
                    out.addAll(Arrays.asList(a).subList(idx, a.length));
                    return out;
                }
            }
            // Вариант 2: sun.java.command = "MainClass arg1 arg2 ..."
            String cmdline = System.getProperty("sun.java.command", "");
            int sp = cmdline.indexOf(' ');
            if (sp > 0) {
                for (String tok : cmdline.substring(sp + 1).trim().split("\\s+")) {
                    if (!tok.isBlank()) out.add(tok);
                }
            }
        } catch (Throwable ignored) {
        }
        return out;
    }

    private static class BotProcessHandle {
        final String nickname;
        final Process process;
        final long launchTimeMs;
        volatile Socket socket;
        volatile PrintWriter writer;

        BotProcessHandle(String nickname, Process process) {
            this.nickname = nickname;
            this.process = process;
            this.launchTimeMs = System.currentTimeMillis();
        }
    }
}
