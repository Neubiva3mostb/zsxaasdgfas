package ru.neuclient.client.mixin;

import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.render.state.CameraRenderState;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.impl.render.ChamsModule;
import ru.neuclient.client.module.impl.render.KillEffectModule;
import ru.neuclient.client.module.impl.render.SeeInvisiblesModule;

/** SeeInvisibles, Chams и скрытие тела во время визуальных KillEffect. */
@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererMixin {

	/** Во время KillEffect оставляем только кубы, пирамиды, фонтан или молнию. */
	@Inject(method = "render(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;"
			+ "Lnet/minecraft/client/util/math/MatrixStack;"
			+ "Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;"
			+ "Lnet/minecraft/client/render/state/CameraRenderState;)V",
			at = @At("HEAD"))
	private void pc$prepareKillEffect(LivingEntityRenderState state, MatrixStack matrices,
			OrderedRenderCommandQueue queue, CameraRenderState camera, CallbackInfo ci) {
		KillEffectModule effect = KillEffectModule.active();
		if (effect != null && effect.shouldHideBody(killEffectEntityId(state))) {
			state.invisible = true;
		}
	}

	/** Не рисуем ванильное тело убитого игрока; Chams подменяет слой модели. */
	@Inject(method = "getRenderLayer", at = @At("HEAD"), cancellable = true)
	private void pc$hideKillEffectBody(LivingEntityRenderState state, boolean showBody,
			boolean translucent, boolean showOutline, CallbackInfoReturnable<RenderLayer> cir) {
		try {
			KillEffectModule effect = KillEffectModule.active();
			if (effect != null && effect.shouldHideBody(killEffectEntityId(state))) {
				// KillEffect важнее подсветки: иначе тело вернулось бы
				// сквозь стену ровно там, где его специально спрятали.
				cir.setReturnValue(null);
				return;
			}
			ChamsModule chams = ChamsModule.active();
			if (chams != null && chams.shouldCham(state)) {
				cir.setReturnValue(chams.layer());
			}
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка Chams", t);
		}
	}

	/** Броня, плащ и остальные feature-слои тоже не должны оставаться после смерти. */
	@Inject(method = "shouldRenderFeatures", at = @At("HEAD"), cancellable = true)
	private void pc$hideKillEffectFeatures(LivingEntityRenderState state,
			CallbackInfoReturnable<Boolean> cir) {
		KillEffectModule effect = KillEffectModule.active();
		if (effect != null && effect.shouldHideBody(killEffectEntityId(state))) {
			cir.setReturnValue(false);
		}
	}

	/** Ванильная альфа невидимок SeeInvisibles. */
	@ModifyArg(method = "render(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;"
			+ "Lnet/minecraft/client/util/math/MatrixStack;"
			+ "Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;"
			+ "Lnet/minecraft/client/render/state/CameraRenderState;)V",
			at = @At(value = "INVOKE",
					target = "Lnet/minecraft/util/math/ColorHelper;mix(II)I"),
			index = 0)
	private int pc$invisibleAlpha(int vanillaTint) {
		try {
			if (vanillaTint != 0x26FFFFFF) {
				return vanillaTint;
			}
			SeeInvisiblesModule module = SeeInvisiblesModule.active();
			if (module != null) {
				return module.getTintColor();
			}
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка SeeInvisibles", t);
		}
		return vanillaTint;
	}

	/** Невидимые сущности, которых SeeInvisibles должен показать. */
	@Inject(method = "isVisible", at = @At("RETURN"), cancellable = true)
	private void pc$revealInvisible(LivingEntityRenderState state,
			CallbackInfoReturnable<Boolean> cir) {
		try {
			if (cir.getReturnValue()) return;
			SeeInvisiblesModule module = SeeInvisiblesModule.active();
			if (module != null && module.shouldReveal(state) && state.invisibleToPlayer) {
				state.invisibleToPlayer = false;
			}
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка SeeInvisibles (видимость)", t);
		}
	}

	private static int killEffectEntityId(LivingEntityRenderState state) {
		return state instanceof PlayerEntityRenderState playerState ? playerState.id : -1;
	}
}
