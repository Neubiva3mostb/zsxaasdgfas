package ru.neuclient.client.mixin;

import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.impl.movement.NoPushModule;

/**
 * NoPush («Вода»).
 *
 * Entity#updateMovementInFluid прибавляет скорость течения только когда
 * isPushedByFluids() == true. У PlayerEntity этот метод возвращает
 * !abilities.flying. Подменяем результат на false для НАШЕГО игрока —
 * река, водопад и пузырьковые колонны перестают сносить в сторону.
 *
 * Плавание при этом работает штатно: гребля идёт через travelInFluid,
 * а не через толчок течения.
 */
@Mixin(PlayerEntity.class)
public abstract class PlayerFluidPushMixin {

	@Inject(method = "isPushedByFluids", at = @At("HEAD"), cancellable = true)
	private void pc$noWaterPush(CallbackInfoReturnable<Boolean> cir) {
		try {
			NoPushModule noPush = NeuClient.getInstance().getModuleManager().get(NoPushModule.class);
			if (noPush != null && noPush.isEnabled()
					&& noPush.shouldIgnoreFluidPush((PlayerEntity) (Object) this)) {
				cir.setReturnValue(false);
			}
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка NoPush (вода)", t);
		}
	}
}
