package ru.neuclient.client.render;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.minecraft.client.gui.ScreenRect;
import net.minecraft.client.gui.render.state.SimpleGuiElementRenderState;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.texture.TextureSetup;
import org.joml.Matrix3x2f;

/** Состояние одного GPU-quad-набора из трёх граней изометрического кубика. */
public record GuiCubeElementRenderState(
		Matrix3x2f pose,
		float[] vertices,
		int[] colors,
		ScreenRect scissorArea,
		ScreenRect bounds
) implements SimpleGuiElementRenderState {

	@Override
	public void setupVertices(VertexConsumer buffer) {
		for (int i = 0; i < colors.length; i++) {
			buffer.vertex(pose, vertices[i * 2], vertices[i * 2 + 1]).color(colors[i]);
		}
	}

	@Override
	public RenderPipeline pipeline() {
		return GuiCubePipeline.PIPELINE;
	}

	@Override
	public TextureSetup textureSetup() {
		return TextureSetup.empty();
	}
}
