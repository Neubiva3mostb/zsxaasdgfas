package ru.neuclient.client.mixin;

import net.minecraft.client.render.Camera;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

/**
 * Доступ к полям камеры (для FreeCam и NeuBot — камера ставится в позицию модуля/бота;
 * blockPos тоже двигаем, чтобы туман/погружение считались по новой точке).
 */
@Mixin(Camera.class)
public interface CameraAccessor {

	@Accessor("pos")
	void pc$setPos(Vec3d pos);

	@Accessor("blockPos")
	BlockPos.Mutable pc$getBlockPos();

	@Invoker("setRotation")
	void pc$setRotation(float yaw, float pitch);
}
