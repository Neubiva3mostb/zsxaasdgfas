package ru.neuclient.client.module.impl.render;

import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.render.WorldRenderUtil;
import ru.neuclient.client.setting.NumberSetting;

/**
 * China Hat — «китайская шляпа» (конус) над своей головой, цветом темы.
 *
 * Рисуется ТОЛЬКО себе и только от ТРЕТЬЕГО лица (F5): от первого лица
 * шляпа висела бы прямо перед камерой и мешала обзору. Единственная
 * настройка — «Размер». Конус собирается вручную из треугольников:
 * вершина сверху по центру, круг основания, и медленно вращается.
 *
 * Чистая косметика: ни одного пакета, сервер о шляпе не знает.
 */
public final class ChinaHatModule extends Module {

	/** Сегментов в основании конуса — чем больше, тем глаже. */
	private static final int SEGMENTS = 24;
	/** Высота конуса относительно радиуса. */
	private static final double HEIGHT_RATIO = 0.45;
	/**
	 * Насколько шляпа висит над макушкой.
	 * 0.35 → 0.75 оказалось слишком высоко, вернули примерно на 0.10 выше
	 * исходного: шляпа сидит прямо над головой, не паря отдельно.
	 */
	private static final double HEAD_OFFSET = 0.10;

	private final ru.neuclient.client.setting.ColorSetting color = new ru.neuclient.client.setting.ColorSetting("Цвет", 0xFF7A5CFF);
	private final NumberSetting size = new NumberSetting("Размер", 3.0, 1.0, 5.0, 1.0);

	public ChinaHatModule() {
		super("ChinaHat", "Китайская шляпа", Category.RENDER);
		addSettings(color, size);
	}

	/** Мировой рендер (AFTER_ENTITIES). */
	public void renderWorld(WorldRenderContext context, MinecraftClient client) {
		ClientPlayerEntity player = client.player;
		if (client.world == null || player == null || context.commandQueue() == null) {
			return;
		}
		if (player.isSpectator()) {
			return;
		}
		// От первого лица шляпа оказалась бы перед самой камерой
		if (client.options == null || client.options.getPerspective().isFirstPerson()) {
			return;
		}

		Vec3d cam = client.gameRenderer.getCamera().getCameraPos();
		MatrixStack matrices = context.matrices();
		float tickDelta = client.getRenderTickCounter().getTickProgress(false);

		// Радиус: 1 → 0.38, 5 → 0.9 блока
		double radius = 0.25 + size.get() * 0.13;
		double height = radius * HEIGHT_RATIO;
		// Медленный оборот: полный круг примерно за 6 секунд
		double spinAngle = (System.currentTimeMillis() % 6000L) / 6000.0 * Math.PI * 2.0;

		int accent = color.get();
		float r = WorldRenderUtil.red(accent);
		float g = WorldRenderUtil.green(accent);
		float b = WorldRenderUtil.blue(accent);

		// Интерполированная позиция — шляпа не дёргается между тиками
		Vec3d pos = player.getLerpedPos(tickDelta);
		double baseY = pos.y + player.getHeight() + HEAD_OFFSET;

		matrices.push();
		matrices.translate(-cam.x, -cam.y, -cam.z);

		context.commandQueue().submitCustom(matrices, WorldRenderUtil.QUADS, (entry, buffer) -> {
			org.joml.Matrix4f m = entry.getPositionMatrix();
			double step = Math.PI * 2.0 / SEGMENTS;
			double apexY = baseY + height;
			for (int i = 0; i < SEGMENTS; i++) {
				double a1 = spinAngle + i * step;
				double a2 = spinAngle + (i + 1) * step;
				double x1 = pos.x + Math.cos(a1) * radius;
				double z1 = pos.z + Math.sin(a1) * radius;
				double x2 = pos.x + Math.cos(a2) * radius;
				double z2 = pos.z + Math.sin(a2) * radius;
				// Альфа по кругу слегка плавает — шляпа «дышит»
				float alpha = 0.45f + 0.15f * (float) Math.sin(a1 * 2.0);
				// Боковая грань конуса: вершина + два соседних края основания
				WorldRenderUtil.triangle(buffer, m,
						pos.x, apexY, pos.z, x1, baseY, z1, x2, baseY, z2,
						r, g, b, alpha);
				// Обратная сторона (чтобы конус был виден и снизу)
				WorldRenderUtil.triangle(buffer, m,
						pos.x, apexY, pos.z, x2, baseY, z2, x1, baseY, z1,
						r, g, b, alpha);
			}
		});

		matrices.pop();
	}

	/** Диспетчер мирового рендера (вызывается из NeuClient). */
	public static void renderAllWorld(WorldRenderContext context) {
		var modules = ru.neuclient.client.NeuClient.getInstance().getModuleManager();
		if (modules == null) {
			return;
		}
		ChinaHatModule self = modules.get(ChinaHatModule.class);
		if (self != null && self.isEnabled()) {
			self.renderWorld(context, MinecraftClient.getInstance());
		}
	}
}
