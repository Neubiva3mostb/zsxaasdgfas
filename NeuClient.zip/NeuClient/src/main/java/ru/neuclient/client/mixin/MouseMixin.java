package ru.neuclient.client.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.Mouse;
import net.minecraft.client.input.MouseInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.ModuleManager;
import ru.neuclient.client.module.impl.misc.MiddleClickPearlModule;
import ru.neuclient.client.module.impl.player.FreeCamModule;

/**
 * Сырой перехват кнопок мыши:
 *  - СКМ (кнопка 2) -> MiddleClickPearl;
 *  - каждый кадр после ванильного updateMouse -> FreeCam забирает поворот мыши.
 */
@Mixin(Mouse.class)
public abstract class MouseMixin {

	@Inject(method = "updateMouse", at = @At("TAIL"))
	private void pc$freeCamLook(double timeDelta, CallbackInfo ci) {
		try {
			ModuleManager modules = NeuClient.getInstance().getModuleManager();
			if (modules == null) {
				return;
			}
			FreeCamModule freeCam = modules.get(FreeCamModule.class);
			if (freeCam != null && freeCam.isEnabled()) {
				freeCam.transferMouseLook();
			}
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка FreeCam поворота", t);
		}
	}

	@Inject(method = "onMouseButton", at = @At("HEAD"), cancellable = true)
	private void pc$onMouseButton(long window, MouseInput input, int action, CallbackInfo ci) {
		try {
			MinecraftClient client = MinecraftClient.getInstance();
			if (client.currentScreen != null) {
				return;
			}

			// GLFW_PRESS = 1
			if (action == 1) {
				// СКМ (2) — MiddleClickPearl
				if (input.button() == 2) {
					ModuleManager modules = NeuClient.getInstance().getModuleManager();
					if (modules != null) {
						MiddleClickPearlModule pearl = modules.get(MiddleClickPearlModule.class);
						if (pearl != null && pearl.isEnabled() && pearl.tryStart(client)) {
							ci.cancel();
							return;
						}
					}
				}
			}
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка в хуке мыши", t);
		}
	}
}
