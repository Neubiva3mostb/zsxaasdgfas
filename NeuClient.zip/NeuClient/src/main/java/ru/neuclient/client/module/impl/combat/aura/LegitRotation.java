package ru.neuclient.client.module.impl.combat.aura;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.Random;
import ru.neuclient.client.util.RotationGcd;
import ru.neuclient.client.util.RotationSpoof;

/**
 * Legit — плавный доворот РЕАЛЬНОЙ камеры игрока.
 *
 * Тот режим, что был в модуле раньше: угол двигается обычным setYaw/
 * setPitch, поэтому поворот видно на экране и он уходит серверу
 * штатным пакетом движения. Никакого спуфа.
 *
 * Пять параметров (по одному на каждую ось плюс шум):
 *  • Скорость yaw     — доля горизонтальной ошибки, устраняемая за тик;
 *  • Ограничение yaw  — максимальный шаг по горизонтали за тик;
 *  • Скорость pitch   — то же по вертикали (обычно сильно меньше:
 *                       живой игрок ведёт цель в основном горизонтально);
 *  • Ограничение pitch — максимальный шаг по вертикали;
 *  • Сила рандома     — дрожание прицела, чтобы угол не был идеально
 *                       ровным.
 */
public final class LegitRotation {

	private final MinecraftClient mc = MinecraftClient.getInstance();
	private final Random rand = new Random();

	/** Цель, под которую выбрана точка прицеливания. */
	private LivingEntity trackedTarget;

	/** Смещение точки прицеливания внутри хитбокса (доли размеров). */
	private double aimOffsetX;
	private double aimOffsetY;
	private double aimOffsetZ;

	/** Накопленное дрожание — плавное блуждание, а не белый шум. */
	private float jitterYaw;
	private float jitterPitch;

	/**
	 * Сколько тиков ещё держим паузу (мышь стоит).
	 * По записям боя таких тиков около 25 % — см. AimProfile.
	 */
	private int pauseTicksLeft;

	/**
	 * Остатки квантования по осям (GCD-фикс).
	 *
	 * Камера обязана двигаться шагами, кратными «шагу мыши», иначе
	 * анти-чит видит углы вне сетки чувствительности. Потерянные при
	 * округлении доли копятся здесь и доезжают в следующих тиках.
	 */
	private final ru.neuclient.client.util.RotationGcd.Accumulator gcdYaw =
			new ru.neuclient.client.util.RotationGcd.Accumulator();
	private final ru.neuclient.client.util.RotationGcd.Accumulator gcdPitch =
			new ru.neuclient.client.util.RotationGcd.Accumulator();

	public void reset() {
		trackedTarget = null;
		jitterYaw = jitterPitch = 0.0f;
		gcdYaw.reset();
		gcdPitch.reset();
	}

	/** Сменить точку прицеливания (после удара). */
	public void rerollAimPoint() {
		aimOffsetX = MathHelper.clamp(rand.nextGaussian() * 0.14, -0.35, 0.35);
		aimOffsetY = MathHelper.clamp(rand.nextGaussian() * 0.10, -0.25, 0.25);
		aimOffsetZ = MathHelper.clamp(rand.nextGaussian() * 0.14, -0.35, 0.35);
	}

	/**
	 * Доворачивает камеру к цели на один тик.
	 *
	 * @param yawSpeed    доля ошибки по yaw за тик (0.1–0.9)
	 * @param yawLimit    потолок шага по yaw в градусах (10–40)
	 * @param pitchSpeed  доля ошибки по pitch за тик (0.01–0.2)
	 * @param pitchLimit  потолок шага по pitch в градусах (1–10)
	 * @param randomPower сила дрожания прицела (0–3)
	 */
	public void update(LivingEntity target, float yawSpeed, float yawLimit,
			float pitchSpeed, float pitchLimit, float randomPower) {
		ClientPlayerEntity player = mc.player;
		if (player == null || target == null) {
			return;
		}
		if (trackedTarget != target) {
			trackedTarget = target;
			rerollAimPoint();
			jitterYaw = jitterPitch = 0.0f;
			gcdYaw.reset();
			gcdPitch.reset();
		}

		// --- Точка прицеливания внутри хитбокса ---
		Box box = target.getBoundingBox();
		Vec3d aim = new Vec3d(
				box.minX + box.getLengthX() * (0.5 + aimOffsetX),
				box.minY + box.getLengthY() * (0.55 + aimOffsetY),
				box.minZ + box.getLengthZ() * (0.5 + aimOffsetZ));

		Vec3d eye = player.getEyePos();
		double dx = aim.x - eye.x;
		double dy = aim.y - eye.y;
		double dz = aim.z - eye.z;

		float wantYaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0f;
		float wantPitch = (float) -Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz)));

		float errYaw = MathHelper.wrapDegrees(wantYaw - player.getYaw());
		float errPitch = wantPitch - player.getPitch();

		// --- Дрожание: блуждание с затуханием, а не рывки ---
		if (randomPower > 0.0f) {
			jitterYaw += (float) (rand.nextGaussian() * randomPower * 0.18);
			jitterPitch += (float) (rand.nextGaussian() * randomPower * 0.12);
			jitterYaw *= 0.82f;
			jitterPitch *= 0.82f;
		} else {
			jitterYaw = jitterPitch = 0.0f;
		}

		// --- Шаг с ограничением (режим Legit: по ползункам) ---
		// Разворот на большой угол идёт быстрее: живой игрок, у которого
		// цель ушла за спину, не доворачивается вяло — он делает резкий
		// мах мышью, а у самой цели уже переходит на обычную скорость.
		float boost = bigTurnBoost(errYaw);
		float stepYaw = MathHelper.clamp(errYaw * yawSpeed * boost + jitterYaw,
				-yawLimit * boost, yawLimit * boost);
		float stepPitch = MathHelper.clamp(errPitch * pitchSpeed + jitterPitch,
				-pitchLimit, pitchLimit);

		applyStep(player, stepYaw, stepPitch);
	}

	/**
	 * Режим Neuro: доворот по ПРОФИЛЮ РЕАЛЬНОГО БОЯ.
	 *
	 * Отличие от {@link #update}: скорость не задаётся ползунками, а
	 * подставляется из записи — для текущей величины ошибки берётся та
	 * скорость, с которой в такой же ситуации крутил мышью живой игрок.
	 * Плюс моделируются ПАУЗЫ: у человека около четверти тиков мышь
	 * фактически стоит, и без них движение выходит неестественно ровным.
	 *
	 * @param fidelity 1.0 — точно как в записи; меньше — быстрее и
	 *                 точнее оригинала, больше — медленнее и небрежнее
	 * @param usePauses моделировать ли паузы
	 */
	public void updateFromProfile(LivingEntity target, float fidelity, boolean usePauses) {
		updateFromProfile(target, fidelity, usePauses, false);
	}

	/**
	 * @param serverOnly true — камеру не трогаем, доворачиваем только тот
	 *                   угол, который уйдёт серверу (см. spoofYaw)
	 */
	public void updateFromProfile(LivingEntity target, float fidelity, boolean usePauses,
			boolean serverOnly) {
		ClientPlayerEntity player = mc.player;
		if (player == null || target == null) {
			// Сбрасываем спуф к реальному углу, чтобы сервер не видел застывшую точку
			if (spoofActive) {
				spoofYaw = RotationSpoof.realYaw(player.getYaw());
				spoofPitch = RotationSpoof.realPitch(player.getPitch());
				spoofActive = false;
			}
			return;
		}
		ru.neuclient.client.ai.AimProfile profile = ru.neuclient.client.ai.AimProfile.get();
		if (!profile.isLoaded()) {
			// Профиля нет — молча работаем как Legit на дефолтах, чтобы
			// режим не превращался в «аура не наводится вообще».
			spoofActive = false;
			update(target, 0.4f, 25.0f, 0.08f, 4.0f, 1.0f);
			return;
		}

		// В режиме «только серверу» доворачиваем ВИРТУАЛЬНЫЙ угол.
		// Стартуем его от текущей камеры, иначе при включении спуфа
		// голова прыгнула бы с последнего значения прошлого боя.
		if (serverOnly && !spoofActive) {
			// Берём НАСТОЯЩИЙ угол: внутри тика игрока на сущность уже
			// может быть наложен спуф прошлого тика (AuraTickSpoofMixin).
			spoofYaw = ru.neuclient.client.util.RotationSpoof.realYaw(player.getYaw());
			spoofPitch = ru.neuclient.client.util.RotationSpoof.realPitch(player.getPitch());
			gcdYaw.reset();
			gcdPitch.reset();
		}
		spoofActive = serverOnly;
		if (trackedTarget != target) {
			trackedTarget = target;
			rerollAimPoint();
			jitterYaw = jitterPitch = 0.0f;
			pauseTicksLeft = 0;
			gcdYaw.reset();
			gcdPitch.reset();
		}

		// Ошибку считаем от того угла, который РЕАЛЬНО доворачиваем:
		// при спуфе это виртуальный угол, иначе — камера. Иначе наведение
		// никогда не сойдётся: мы бы крутили одно, а мерили другое.
		float baseYaw = serverOnly ? spoofYaw : player.getYaw();
		float basePitch = serverOnly ? spoofPitch : player.getPitch();
		float[] err = aimError(player, target, baseYaw, basePitch);
		float errYaw = err[0];
		float errPitch = err[1];

		float stepYaw;
		float stepPitch;
		if (usePauses && pauseTicksLeft > 0) {
			pauseTicksLeft--;
			stepYaw = 0.0f;
			stepPitch = 0.0f;
		} else {
			if (usePauses && profile.shouldPause()) {
				pauseTicksLeft = profile.pauseTicks();
			}
			// fidelity>1 — медленнее оригинала, <1 — быстрее
			float scale = fidelity <= 0.0f ? 1.0f : 1.0f / fidelity;
			// Разворот на большой угол — ускоренный (см. bigTurnBoost)
			scale *= bigTurnBoost(errYaw);
			stepYaw = Math.copySign(profile.yawStep(Math.abs(errYaw)) * scale, errYaw);
			stepPitch = Math.copySign(profile.pitchStep(Math.abs(errPitch)) * scale, errPitch);
			// Не перелетаем цель
			stepYaw = MathHelper.clamp(stepYaw, -Math.abs(errYaw), Math.abs(errYaw));
			stepPitch = MathHelper.clamp(stepPitch, -Math.abs(errPitch), Math.abs(errPitch));
		}
		if (serverOnly) {
			// Камеру не трогаем — двигаем только серверный угол.
			// Квантование под сетку мыши всё равно обязательно: серверу
			// уходит обычный пакет поворота, и он должен выглядеть как
			// движение настоящей мыши.
			float grid = ru.neuclient.client.util.RotationGcd.step();
			spoofYaw += gcdYaw.apply(stepYaw, grid);
			spoofPitch = MathHelper.clamp(spoofPitch + gcdPitch.apply(stepPitch, grid),
					-90.0f, 90.0f);
		} else {
			applyStep(player, stepYaw, stepPitch);
		}
	}

	/** С какого угла начинается «разворот» и включается ускорение. */
	private static final float BIG_TURN_DEGREES = 140.0f;

	/** Во сколько раз быстрее крутить на развороте. */
	private static final float BIG_TURN_MULTIPLIER = 1.8f;

	/**
	 * Множитель скорости для разворота на большой угол.
	 *
	 * Пока цель дальше 140° (фактически за спиной), доворот идёт
	 * ускоренно: иначе аура вяло переползает полкруга и цель успевает
	 * уйти. Как только ошибка опускается ниже порога, множитель
	 * возвращается к 1.0 и наведение доводится обычной скоростью —
	 * то есть у самой цели прицел ведёт себя как всегда.
	 *
	 * Настройки не имеет: это не стилевой параметр, а компенсация
	 * заведомо неигровой ситуации «противник строго сзади».
	 */
	private static float bigTurnBoost(float errYaw) {
		return Math.abs(errYaw) > BIG_TURN_DEGREES ? BIG_TURN_MULTIPLIER : 1.0f;
	}

	/** Ошибка прицела до точки наведения относительно заданного угла. */
	private float[] aimError(ClientPlayerEntity player, LivingEntity target,
			float fromYaw, float fromPitch) {
		Box box = target.getBoundingBox();
		Vec3d aim = new Vec3d(
				box.minX + box.getLengthX() * (0.5 + aimOffsetX),
				box.minY + box.getLengthY() * (0.55 + aimOffsetY),
				box.minZ + box.getLengthZ() * (0.5 + aimOffsetZ));
		Vec3d eye = player.getEyePos();
		double dx = aim.x - eye.x;
		double dy = aim.y - eye.y;
		double dz = aim.z - eye.z;
		float wantYaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0f;
		float wantPitch = (float) -Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz)));
		return new float[]{
				MathHelper.wrapDegrees(wantYaw - fromYaw),
				wantPitch - fromPitch
		};
	}

	// ===== Спуф угла (режим «поворот только серверу») =====

	/** Активен ли спуф прямо сейчас. */
	private boolean spoofActive;
	/** Угол, который уходит серверу вместо настоящего. */
	private float spoofYaw;
	private float spoofPitch;

	public boolean isSpoofActive() {
		return spoofActive;
	}

	public float spoofYaw() {
		return spoofYaw;
	}

	public float spoofPitch() {
		return spoofPitch;
	}

	/** Сбросить спуф (смена режима, выключение модуля). */
	public void clearSpoof() {
		spoofActive = false;
	}

	/**
	 * Коррекция ввода движения под спуфнутый угол.
	 *
	 * Серверу уходит не
	 * настоящий yaw, и ваниль посчитала бы мировое направление движения
	 * от него — игрок побежал бы не туда, куда жмёт. Пересчитываем ввод
	 * так, чтобы мировой вектор совпал с настоящим.
	 *
	 * Результат округляется до 8 ванильных направлений: серверу уходят
	 * БУЛЕВЫ клавиши, и предсказывающий анти-чит пересимулирует движение
	 * именно по ним — дробный вектор в эту модель не укладывается.
	 */
	public float[] correctInput(float forward, float strafe, boolean focused) {
		ClientPlayerEntity player = mc.player;
		if (player == null || !spoofActive || (forward == 0.0f && strafe == 0.0f)) {
			return new float[]{forward, strafe};
		}
		float trueYaw = ru.neuclient.client.util.RotationSpoof.realYaw(player.getYaw());
		float delta = MathHelper.wrapDegrees(spoofYaw - trueYaw);

		float localAngle = (float) Math.toDegrees(Math.atan2(-strafe, forward));
		float wanted = localAngle - delta;
		float snapped = Math.round(wanted / 45.0f) * 45.0f;

		float nf = Math.round((float) Math.cos(Math.toRadians(snapped)));
		float ns = -Math.round((float) Math.sin(Math.toRadians(snapped)));

		if (focused && nf < 0.0f) {
			// Для сервера не должно получаться движение спиной вперёд
			nf = 0.0f;
			if (ns == 0.0f) {
				ns = 1.0f;
			}
		}
		return new float[]{nf, ns};
	}

	/** Нужно ли снимать спринт (только «Сфокусированная» коррекция). */
	public boolean shouldStopSprint(boolean focused) {
		ClientPlayerEntity player = mc.player;
		if (!focused || player == null || player.input == null || !spoofActive) {
			return false;
		}
		var mv = player.input.getMovementInput();
		if (mv.x == 0.0f && mv.y == 0.0f) {
			return false;
		}
		float[] fixed = correctInput(mv.y, mv.x, true);
		// Ваниль не даёт спринтовать без движения вперёд
		return fixed[0] <= 0.0f;
	}

	/**
	 * Применить шаг к камере: квантование под сетку мыши + клэмп питча.
	 * Общая часть обоих режимов — угол обязан лежать на «мышиной» сетке
	 * независимо от того, откуда взялась скорость.
	 */
	private void applyStep(ClientPlayerEntity player, float stepYaw, float stepPitch) {
		// Живой игрок физически не может повернуться на угол, не кратный
		// шагу своей чувствительности. Округляем ДЕЛЬТУ, остаток копим.
		float grid = ru.neuclient.client.util.RotationGcd.step();
		stepYaw = gcdYaw.apply(stepYaw, grid);
		stepPitch = gcdPitch.apply(stepPitch, grid);

		// Питч упирается в ±90: съеденный клэмпом остаток копить нельзя,
		// иначе он будет бесконечно расти при взгляде в зенит/надир.
		float newPitch = MathHelper.clamp(player.getPitch() + stepPitch, -90.0f, 90.0f);
		if (newPitch != player.getPitch() + stepPitch) {
			gcdPitch.reset();
		}
		player.setYaw(player.getYaw() + stepYaw);
		player.setPitch(newPitch);
	}
}
