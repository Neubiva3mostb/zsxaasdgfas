package ru.neuclient.client.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.neuclient.client.module.impl.player.HitSoundsModule;
import ru.neuclient.client.module.impl.combat.ShiftTAPModule;

/**
 * HitSounds: перехват атаки ТОЛЬКО локального игрока через PlayerEntity.attack().
 * ShiftTAP: уведомляем модуль об атаке игрока.
 */
@Mixin(PlayerEntity.class)
public abstract class PlayerEntityAttackMixin {

	@Inject(method = "attack", at = @At("HEAD"))
	private void pc$onAttack(Entity target, CallbackInfo ci) {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc == null || (Object) this != mc.player) {
			return; // Игнорируем атаки других игроков и серверных копий
		}
		if (target instanceof LivingEntity living && living.isAlive()) {
			HitSoundsModule.onPlayerAttack((PlayerEntity) (Object) this);
		}
		// ShiftTAP: при атаке игрока — окно sneak
		ShiftTAPModule shiftTap = ShiftTAPModule.active();
		if (shiftTap != null) {
			shiftTap.onAttack(target);
		}
	}
}
