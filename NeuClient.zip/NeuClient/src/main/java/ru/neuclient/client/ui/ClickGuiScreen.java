package ru.neuclient.client.ui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.ScreenRect;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.joml.Matrix3x2f;
import org.lwjgl.glfw.GLFW;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.render.GlassPanelGuiElementRenderState;
import ru.neuclient.client.render.GuiCubeElementRenderState;
import ru.neuclient.client.render.GuiCubePipeline;
import ru.neuclient.client.config.ConfigManager;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.*;
import ru.neuclient.client.font.MsdfFontRenderer;
import ru.neuclient.client.font.MsdfFonts;
import ru.neuclient.client.util.ChatUtil;
import ru.neuclient.client.util.KeyNames;
import ru.neuclient.client.util.NeuSounds;
import ru.neuclient.client.util.ScaleUtil;
import ru.neuclient.client.util.RenderUtil;

import java.io.IOException;
import java.util.*;

/**
 * ClickGUI — все категории в ряд.
 * Высокопроизводительный рендеринг через нативный MSDF-шрифт.
 */
public class ClickGuiScreen extends Screen {

    private static final int PANEL_W = 125;
    private static final int PANEL_H = 270;
    private static final int GAP = 8;
    private static final int M = 6;
    private static final int ROW_H = 16;
    private static final int ROW_GAP = 4;
    private static final int HEADER_H = 24;
    private static final int SETTING_ROW_H = 16;

    private static int settingH(Setting<?> s) {
        if (s instanceof ColorSetting cs) {
            return cs.isExpanded() ? 106 : SETTING_ROW_H;
        }
        return (s instanceof NumberSetting) ? 18 : SETTING_ROW_H;
    }

    private enum ColorDragMode { NONE, SHADES, HUE, RED, GREEN, BLUE }
    private static ColorSetting activeColorSetting = null;
    private static ColorDragMode colorDragMode = ColorDragMode.NONE;
    private static int colorDragX = 0;
    private static int colorDragY = 0;
    private static int colorDragW = 0;
    private static int colorDragH = 0;

    private static final float FONT_PX = 7.5f;
    /** Шрифт в строках настроек — мельче основного: подписи и числа. */
    private static final float SETTING_FONT_PX = 6.5f;
    private static final int TOGGLE_W = 14;
    private static final int TOGGLE_H = 9;
    /** Сторона чекбокса настроек (Delta-стиль). */
    private static final int BOX_SIZE = 9;

    private float guiAlpha = 0f;
    private final Map<Module, Float> moduleAnim = new HashMap<>();
    private final Map<Module, Float> expandAnim = new HashMap<>();
    private final Map<Module, Float> toggleAnim = new HashMap<>();
    private long lastTick = System.currentTimeMillis();
    private float dt = 0f;

    private static Module selectedModule;
    private static Module bindListening;
    /**
     * Настройка-клавиша, ожидающая нажатия.
     *
     * Отдельно от {@link #bindListening}: раньше клик по KeyBindSetting
     * ставил bindListening = mod, и нажатая клавиша уходила в
     * mod.setKeyBind() — то есть биндился САМ МОДУЛЬ, а не настройка.
     * Теперь это два независимых состояния.
     */
    private static KeyBindSetting settingBindListening;
    private static NumberSetting activeSlider;
    private static boolean sliderDragging = false;
    private static boolean searchFocused = false;
    private static String searchText = "";
    private static TextSetting activeTextSetting = null;
    private static String activeTextBuffer = "";
    private final Map<Category, Double> panelScrolls = new EnumMap<>(Category.class);
    private boolean closing;

    // ===== Плашка с описанием модуля (верх экрана, фиксирована) =====
    //
    // Рисуется ПОСЛЕ панелей и позиционируется от края экрана, а не от
    // панели: прокрутка списка и любое смещение панелей её не двигают.
    private static final int DESC_TOP_Y = 8;
    private Module hoveredModule;

    public ClickGuiScreen() {
        super(Text.literal("NeuClient"));
    }

    @Override
    protected void init() {
        activeSlider = null;
        bindListening = null;
        settingBindListening = null;
        sliderDragging = false;
        activeTextSetting = null;
        activeTextBuffer = "";
        textCaret = 0;
        textViewOff = 0f;
        searchCaret = clampCaret(searchText, searchText.length());
        searchViewOff = 0f;
        hoveredModule = null;
        guiAlpha = 0f;
        moduleAnim.clear();
        expandAnim.clear();
        toggleAnim.clear();
        lastTick = System.currentTimeMillis();
    }

    private static boolean inside(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    private float lerp(float a, float b, float t) {
        return a + (b - a) * Math.min(1f, Math.max(0f, t));
    }

    private static int getAccent() {
        return RenderUtil.accent();
    }

    private static int withAlpha(int color, float alpha) {
        int baseA = (color >>> 24);
        if (baseA == 0) baseA = 255;
        int a = Math.max(0, Math.min(255, (int) (baseA * alpha)));
        return (a << 24) | (color & 0x00FFFFFF);
    }

    private float getTextWidth(String text) {
        return getTextWidth(text, FONT_PX);
    }

    private float getTextWidth(String text, float size) {
        return MsdfFontRenderer.getWidth(MsdfFonts.sfRegular(), text, size);
    }

    private void drawScaledText(DrawContext ctx, String text, float x, float y, int color) {
        drawScaledText(ctx, text, x, y, color, FONT_PX);
    }

    private void drawScaledText(DrawContext ctx, String text, float x, float y, int color, float size) {
        int finalColor = withAlpha(color, guiAlpha);
        MsdfFontRenderer.drawWithShadow(ctx, MsdfFonts.sfRegular(), text, x, y, finalColor, size);
    }

    // ===== Бегущая строка (marquee) =====
    //
    // Применяется ТОЛЬКО в текстовых полях: значение TextSetting (например
    // строка Spammer'а), поле поиска и поле имени конфига. Везде остальном —
    // в именах настроек, числах, режимах, биндах — текст статичен.
    //
    // Раньше любая надпись длиннее 8 символов насильно ужималась в окошко
    // шириной в эти 8 символов и начинала ехать. Это резало даже те подписи,
    // которым места хватало. Теперь окно = всё доступное место в строке, и
    // лента запускается, только если текст в него реально не влез.

    /** Скорость бега, пикселей в секунду. */
    private static final float MARQUEE_SPEED = 16f;
    /** Пауза в начале круга, мс (чтобы успеть прочитать начало). */
    private static final long MARQUEE_PAUSE_MS = 900L;
    /** Разрыв между хвостом строки и её повтором, px. */
    private static final float MARQUEE_GAP = 12f;

    /** Смещение ленты для текущего момента (0 — пауза в начале круга). */
    private static float marqueeOffset(float loop) {
        if (loop <= 0f) return 0f;
        float travelMs = loop / MARQUEE_SPEED * 1000f;
        long cycle = (long) travelMs + MARQUEE_PAUSE_MS;
        if (cycle <= 0L) return 0f;
        long t = System.currentTimeMillis() % cycle;
        if (t < MARQUEE_PAUSE_MS) return 0f;
        return (t - MARQUEE_PAUSE_MS) / 1000f * MARQUEE_SPEED;
    }

    /**
     * Текст с левой привязкой: влезает — рисуем как есть, не влезает —
     * пускаем бегущей строкой внутри окна шириной {@code window}.
     */
    private void drawMarqueeText(DrawContext ctx, String text, float x, float y, float window, int color) {
        drawMarqueeText(ctx, text, x, y, window, color, FONT_PX);
    }

    private void drawMarqueeText(DrawContext ctx, String text, float x, float y, float window, int color, float size) {
        if (text == null || text.isEmpty() || window <= 0.5f) return;

        float full = getTextWidth(text, size);
        if (full <= window + 0.5f) {
            drawScaledText(ctx, text, x, y, color, size);
            return;
        }

        float loop = full + MARQUEE_GAP;
        float off = marqueeOffset(loop);

        // Вложенный scissor автоматически пересекается с ножницами панели
        ctx.enableScissor((int) Math.floor(x), (int) Math.floor(y) - 3,
                (int) Math.ceil(x + window), (int) Math.ceil(y + size) + 4);
        drawScaledText(ctx, text, x - off, y, color, size);
        if (off > 0f) {
            // Второй экземпляр догоняет первый — лента без разрыва в конце круга
            drawScaledText(ctx, text, x - off + loop, y, color, size);
        }
        ctx.disableScissor();
    }

    /**
     * Статичный текст, обрезанный по ширине окна.
     *
     * Нужен там, где бегущая строка запрещена (панели конфигов и цветов):
     * по правилу marquee живёт ТОЛЬКО в настройках модулей.
     */
    private void drawClippedText(DrawContext ctx, String text, float x, float y, float window, int color) {
        drawClippedText(ctx, text, x, y, window, color, FONT_PX);
    }

    private void drawClippedText(DrawContext ctx, String text, float x, float y, float window, int color, float size) {
        if (text == null || text.isEmpty() || window <= 0.5f) return;
        if (getTextWidth(text, size) <= window + 0.5f) {
            drawScaledText(ctx, text, x, y, color, size);
            return;
        }
        ctx.enableScissor((int) Math.floor(x), (int) Math.floor(y) - 3,
                (int) Math.ceil(x + window), (int) Math.ceil(y + size) + 4);
        drawScaledText(ctx, text, x, y, color, size);
        ctx.disableScissor();
    }

    /** Статичный текст, прижатый правым краем к {@code right}. */
    private void drawClippedRight(DrawContext ctx, String text, float right, float y, float window, int color, float size) {
        float full = getTextWidth(text, size);
        float wnd = Math.min(window, full);
        drawClippedText(ctx, text, right - wnd, y, wnd, color, size);
    }

    // ===== Поля ввода: каретка, прокрутка окна и навигация стрелками =====
    //
    // Пока поле НЕ редактируется — работает обычная бегущая строка.
    // Как только поле активно, лента останавливается и то же самое окно
    // начинает следовать за кареткой: стрелками ← → можно проехать по
    // всему тексту, даже если он длиннее окна.

    /** Минимальная ширина «пилюли» TextSetting в режиме ввода, px. */
    private static final float EDIT_MIN_WINDOW = 40f;

    private static int searchCaret = 0;
    private static int textCaret = 0;
    private static float searchViewOff = 0f;
    private static float textViewOff = 0f;
    private static long lastEditMs = 0L;

    // Геометрия активного текстового поля — нужна, чтобы кликом ставить каретку
    private static float activeTextFieldX = 0f;
    private static float activeTextFieldW = 0f;
    private static float activeTextFieldY = 0f;

    private static void markEdit() {
        lastEditMs = System.currentTimeMillis();
    }

    private static int clampCaret(String s, int caret) {
        int len = (s == null) ? 0 : s.length();
        return Math.max(0, Math.min(len, caret));
    }

    /** Каретка не мигает сразу после ввода/движения — иначе её теряешь глазами. */
    private static boolean caretVisible() {
        if (System.currentTimeMillis() - lastEditMs < 500L) return true;
        return (System.currentTimeMillis() / 450) % 2 == 0;
    }

    /** Начало предыдущего слова (Ctrl + ←). */
    private static int prevWord(String s, int caret) {
        int i = clampCaret(s, caret);
        while (i > 0 && s.charAt(i - 1) == ' ') i--;
        while (i > 0 && s.charAt(i - 1) != ' ') i--;
        return i;
    }

    /** Начало следующего слова (Ctrl + →). */
    private static int nextWord(String s, int caret) {
        int i = clampCaret(s, caret);
        int n = s.length();
        while (i < n && s.charAt(i) != ' ') i++;
        while (i < n && s.charAt(i) == ' ') i++;
        return i;
    }

    /** Минимальный сдвиг окна, при котором каретка остаётся видимой. */
    private float caretScroll(String text, int caret, float window, float prevOff) {
        return caretScroll(text, caret, window, prevOff, FONT_PX);
    }

    private float caretScroll(String text, int caret, float window, float prevOff, float size) {
        float full = getTextWidth(text, size);
        float caretPx = getTextWidth(text.substring(0, clampCaret(text, caret)), size);
        float max = Math.max(0f, full - window);
        float off = Math.max(0f, Math.min(max, prevOff));
        if (caretPx - off > window - 1f) off = caretPx - window + 1f;
        if (caretPx - off < 0f) off = caretPx;
        return Math.max(0f, Math.min(max, off));
    }

    /** Позиция каретки по клику мышью (ближайшая граница символа). */
    private int caretFromX(String text, float textStartX, double mouseX) {
        return caretFromX(text, textStartX, mouseX, FONT_PX);
    }

    private int caretFromX(String text, float textStartX, double mouseX, float size) {
        if (text == null || text.isEmpty()) return 0;
        int best = 0;
        float bestD = Float.MAX_VALUE;
        for (int i = 0; i <= text.length(); i++) {
            float px = textStartX + getTextWidth(text.substring(0, i), size);
            float d = Math.abs(px - (float) mouseX);
            if (d < bestD) {
                bestD = d;
                best = i;
            }
        }
        return best;
    }

    /**
     * Активное поле ввода: окно фиксированной ширины, текст едет за кареткой.
     * Возвращает новое смещение окна — его надо сохранить обратно.
     */
    private float drawEditable(DrawContext ctx, String text, int caret, float x, float y,
                               float window, int textColor, int caretColor, float prevOff) {
        return drawEditable(ctx, text, caret, x, y, window, textColor, caretColor, prevOff, FONT_PX);
    }

    private float drawEditable(DrawContext ctx, String text, int caret, float x, float y,
                               float window, int textColor, int caretColor, float prevOff, float size) {
        if (text == null) text = "";
        float off = caretScroll(text, caret, window, prevOff, size);

        ctx.enableScissor((int) Math.floor(x), (int) Math.floor(y) - 3,
                (int) Math.ceil(x + window) + 1, (int) Math.ceil(y + size) + 4);
        if (!text.isEmpty()) {
            drawScaledText(ctx, text, x - off, y, textColor, size);
        }
        if (caretVisible()) {
            float cx = x + getTextWidth(text.substring(0, clampCaret(text, caret)), size) - off;
            float ch = size + 2f;
            ctx.fill((int) cx, (int) y - 1, (int) cx + 1, (int) (y - 1 + ch), withAlpha(caretColor, guiAlpha));
        }
        ctx.disableScissor();
        return off;
    }

    private int vW() {
        return ScaleUtil.getVirtualWidth();
    }

    private int vH() {
        return ScaleUtil.getVirtualHeight();
    }

    /**
     * Декоративные кубики в фоне GUI. Это тот же изометрический принцип,
     * что и у TargetESP, но в экранных координатах и с очень низкой
     * прозрачностью, поэтому панели и текст остаются читаемыми.
     */
    private void renderBackgroundCubes(DrawContext ctx, int accent, int w, int h) {
        Matrix3x2f pose = new Matrix3x2f(ctx.getMatrices());
        float time = (System.currentTimeMillis() % 120_000L) / 1000.0f;
        int cubeCount = 12;

        for (int i = 0; i < cubeCount; i++) {
            float phase = i * 2.3999631f;
            float x = w * 0.5f + (float) Math.sin(time * 0.16f + phase) * w * 0.43f;
            float y = h * 0.5f + (float) Math.cos(time * 0.21f + phase * 1.17f) * h * 0.38f;
            float size = 8.0f + (float) (Math.sin(time * 0.8f + phase) * 2.0f + 2.0f);
            float topDepth = size * 0.52f;
            float sideHeight = size * 0.92f;
            float alpha = guiAlpha * (0.10f + (i % 4) * 0.025f);

            float left = x - size;
            float right = x + size;
            float top = y - topDepth;
            float middle = y;
            float lowerMiddle = y + topDepth;
            float bottom = y + sideHeight;
            float lowerLeft = left;
            float lowerRight = right;
            float bottomMiddle = y + topDepth + sideHeight;

            float[] vertices = {
                    x, top, right, middle, x, lowerMiddle, left, middle,
                    left, middle, x, lowerMiddle, x, bottomMiddle, lowerLeft, bottom,
                    x, lowerMiddle, right, middle, lowerRight, bottom, x, bottomMiddle
            };
            int[] colors = {
                    withAlpha(RenderUtil.shade(accent, 1.28f), alpha),
                    withAlpha(RenderUtil.shade(accent, 1.28f), alpha),
                    withAlpha(RenderUtil.shade(accent, 1.28f), alpha),
                    withAlpha(RenderUtil.shade(accent, 1.28f), alpha),
                    withAlpha(RenderUtil.shade(accent, 0.70f), alpha),
                    withAlpha(RenderUtil.shade(accent, 0.70f), alpha),
                    withAlpha(RenderUtil.shade(accent, 0.70f), alpha),
                    withAlpha(RenderUtil.shade(accent, 0.70f), alpha),
                    withAlpha(RenderUtil.shade(accent, 0.92f), alpha),
                    withAlpha(RenderUtil.shade(accent, 0.92f), alpha),
                    withAlpha(RenderUtil.shade(accent, 0.92f), alpha),
                    withAlpha(RenderUtil.shade(accent, 0.92f), alpha)
            };

            int minX = (int) Math.floor(left - 1.0f);
            int minY = (int) Math.floor(top - 1.0f);
            int maxX = (int) Math.ceil(right + 1.0f);
            int maxY = (int) Math.ceil(bottomMiddle + 1.0f);
            ScreenRect rawBounds = new ScreenRect(minX, minY, maxX - minX, maxY - minY);
            ScreenRect scissor = ctx.scissorStack.peekLast();
            ScreenRect transformed = rawBounds.transformEachVertex(pose);
            ScreenRect bounds = scissor == null ? transformed : transformed.intersection(scissor);
            ctx.state.addSimpleElement(new GuiCubeElementRenderState(
                    pose, vertices, colors, scissor, bounds));
        }
    }

    @Override
    public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
        if (client.world != null) ctx.applyBlur();
        ctx.fill(0, 0, width, height, withAlpha(0x90000000, guiAlpha));
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);

        long now = System.currentTimeMillis();
        dt = Math.min((now - lastTick) / 1000f, 0.1f);
        lastTick = now;

        if (closing) {
            guiAlpha = Math.max(0f, guiAlpha - dt * 5f);
            if (guiAlpha <= 0f) { MinecraftClient.getInstance().setScreen(null); return; }
        } else {
            guiAlpha = Math.min(1f, guiAlpha + dt * 5f);
        }

        int accent = getAccent();

        ScaleUtil.begin(ctx);
        int vw = vW();
        int vh = vH();
        int vmx = (int) ScaleUtil.toVirtualX(mx);
        int vmy = (int) ScaleUtil.toVirtualY(my);

        // Кубики добавляются первыми, поэтому панели GUI лежат поверх них.
        renderBackgroundCubes(ctx, accent, vw, vh);

        Category[] cats = Category.values();
        int totalW = cats.length * PANEL_W + (cats.length - 1) * GAP;
        int startX = (vw - totalW) / 2;
        int startY = (vh - PANEL_H) / 2 - 10;

        // Наведённый модуль ищется заново каждый кадр
        hoveredModule = null;

        for (int i = 0; i < cats.length; i++) {
            Category cat = cats[i];
            int px = startX + i * (PANEL_W + GAP);
            int py = startY;
            renderCategoryPanel(ctx, px, py, cat, vmx, vmy, accent);
        }

        int searchY = startY + PANEL_H + 12;
        renderSearchBar(ctx, vw / 2, searchY, vmx, vmy, accent);

        if (guiAlpha >= 0.2f) {
            String hint = "ЛКМ — вкл/выкл  |  ПКМ — настройки  |  СКМ — бинд  |  Esc — закрыть";
            float tw = getTextWidth(hint);
            drawScaledText(ctx, hint, (vw - tw) / 2f, searchY + 24f, 0x77FFFFFF);
        }

        renderBotsButton(ctx, vmx, vmy, accent);
        renderBackButton(ctx, vmx, vmy, accent);

        // Описание — самым последним
        renderDescription(ctx, accent, vw, startY);

        ScaleUtil.end(ctx);
    }

    // ===== Описание наведённого модуля (верх экрана, не двигается) =====

    /** Плавность появления/исчезновения плашки. */
    private float descAlpha = 0f;
    private String descText = "";

    private void renderDescription(DrawContext ctx, int accent, int vw, int startY) {
        String want = (hoveredModule == null) ? null : hoveredModule.getDescription();
        if (want != null && want.isBlank()) {
            want = null;
        }

        if (want != null) {
            descText = want;
            descAlpha = Math.min(1f, descAlpha + dt * 8f);
        } else {
            descAlpha = Math.max(0f, descAlpha - dt * 8f);
        }
        if (descAlpha <= 0.01f || descText.isEmpty()) {
            return;
        }

        float a = descAlpha * guiAlpha;
        float tw = getTextWidth(descText, 7.5f);
        int boxW = (int) tw + 16;
        int boxH = 16;
        int bx = (vw - boxW) / 2;
        int by = Math.max(4, startY - 18);

        RenderUtil.roundRect(ctx, bx, by, boxW, boxH, 4, withAlpha(RenderUtil.bg(), 0.85f * a));
        RenderUtil.roundBorderEdge(ctx, bx, by, boxW, boxH, 4, withAlpha(accent, 0.4f * a));

        float ty = by + (boxH - 7.5f) / 2f - 0.5f;
        MsdfFontRenderer.drawWithShadow(ctx, MsdfFonts.sfRegular(), descText,
                bx + 8, ty, withAlpha(RenderUtil.TEXT, a), 7.5f);
    }

    private void renderSearchBar(DrawContext ctx, int centerX, int y, int mx, int my, int accent) {
        int searchW = 120;
        int searchH = 20;
        int sx = centerX - searchW / 2;

        int borderColor = searchFocused ? accent : withAlpha(accent, 0.3f);
        int borderWithAlpha = withAlpha(borderColor, guiAlpha);

        RenderUtil.roundRect(ctx, sx, y, searchW, searchH, 4, withAlpha(RenderUtil.GUI_BG, 0.85f * guiAlpha));
        RenderUtil.roundBorderEdge(ctx, sx, y, searchW, searchH, 4, borderWithAlpha);

        float textY = y + (searchH - FONT_PX) / 2f - 0.5f;
        float searchWindow = searchW - 12;
        if (searchText.isEmpty()) {
            if (!searchFocused) {
                drawScaledText(ctx, "Поиск по модулям", sx + 6, textY, RenderUtil.shade(RenderUtil.textDim(), 0.7f), FONT_PX);
            } else if (caretVisible()) {
                ctx.fill(sx + 6, (int) textY - 1, sx + 7, (int) textY + 9, withAlpha(accent, guiAlpha));
            }
        } else {
            ctx.enableScissor(sx + 2, y + 2, sx + searchW - 2, y + searchH - 2);
            if (searchFocused) {
                // Редактирование: лента стоит, окно едет за кареткой
                searchCaret = clampCaret(searchText, searchCaret);
                searchViewOff = drawEditable(ctx, searchText, searchCaret, sx + 6, textY,
                        searchWindow, RenderUtil.TEXT, accent, searchViewOff, FONT_PX);
            } else {
                // Не в фокусе — статичный текст, обрезанный по ширине поля
                drawScaledText(ctx, searchText, sx + 6, textY, RenderUtil.TEXT, FONT_PX);
            }
            ctx.disableScissor();
        }
    }

    // ===== «Стекло» на колонках =====
    //
    // Редкие светящиеся линии, которые постоянно плывут и поворачиваются
    // (весь расчёт — в core/glass_panel.fsh). Время передаётся в секундах и
    // зацикливается на большом периоде: частоты в шейдере несоизмеримые,
    // поэтому рисунок и так не повторяется, а в точке зацикливания линии
    // стоят почти на месте и щелчка не видно.
    private static final long GLASS_TIME_WRAP_MS = 128_000L;

    /**
     * Стеклянная подложка одним GPU-quad'ом: SDF-скругление, линии и ободок
     * считает шейдер, поэтому никаких циклов ctx.fill здесь нет.
     *
     * @param accent RGB акцента — им шейдер красит линии и ободок
     * @param alpha  непрозрачность стеклянного слоя (0..1)
     */
    private void glassPanel(DrawContext ctx, int x, int y, int w, int h, int accent, float alpha) {
        if (w <= 0 || h <= 0 || alpha <= 0.0f) return;

        float time = (System.currentTimeMillis() % GLASS_TIME_WRAP_MS) / 1000.0f;

        Matrix3x2f pose = new Matrix3x2f(ctx.getMatrices());
        ScreenRect scissor = ctx.scissorStack.peekLast();
        ScreenRect transformed = new ScreenRect(x, y, w, h).transformEachVertex(pose);
        ScreenRect bounds = scissor == null ? transformed : transformed.intersection(scissor);
        ctx.state.addSimpleElement(new GlassPanelGuiElementRenderState(
                pose, x, y, w, h, accent, Math.min(1.0f, alpha * guiAlpha), time, scissor, bounds));
    }

    private void renderCategoryPanel(DrawContext ctx, int px, int py, Category cat, int mx, int my, int accent) {
        List<Module> mods = filteredModules(cat);

        int contentH = 0;
        for (Module mod : mods) {
            contentH += ROW_H + ROW_GAP;
            if (mod == selectedModule) {
                for (Setting<?> s : mod.getSettings()) {
                    if (s.isVisible()) contentH += settingH(s) + 2;
                }
            }
        }
        int viewH = PANEL_H - HEADER_H - M * 2;
        double maxScroll = Math.max(0.0, contentH - viewH);
        double scroll = panelScrolls.getOrDefault(cat, 0.0);
        scroll = Math.max(0.0, Math.min(maxScroll, scroll));
        panelScrolls.put(cat, scroll);

        // Подложка панели: полупрозрачное «матовое стекло». Фон уже размыт
        // штатным applyBlur() в renderBackground, поэтому сквозь панель виден
        // мягкий мир, а поверх него шейдер рисует бегущие волны и ободок
        // акцентом (glassPanel). Второй залитый прямоугольник здесь рисовать
        // нельзя — он накрыл бы стекло целиком, поэтому рамка живёт в шейдере.
        RenderUtil.roundRect(ctx, px, py, PANEL_W, PANEL_H, 8,
                withAlpha(RenderUtil.GUI_BG, 0.62f * guiAlpha));
        glassPanel(ctx, px, py, PANEL_W, PANEL_H, accent, 1.0f);

        // Заголовок категории: имя слева, иконка категории справа
        String title = cat.getDisplayName();
        int headerCenterY = py + HEADER_H / 2;
        float titleY = headerCenterY - FONT_PX / 2f - 0.5f;
        drawScaledText(ctx, title, px + M + 2, titleY, withAlpha(RenderUtil.TEXT, 0.95f * guiAlpha));
        String catIcon = RenderUtil.categoryIcon(cat);
        float iconW = RenderUtil.iconWidth(catIcon, 9f);
        RenderUtil.iconCentered(ctx, catIcon, px + PANEL_W - M - 2 - iconW,
                py, HEADER_H, 9f, withAlpha(accent, 0.95f * guiAlpha));

        ctx.fill(px + M, py + HEADER_H - 2, px + PANEL_W - M, py + HEADER_H - 1, withAlpha(accent, 0.3f * guiAlpha));

        int contentTop = py + HEADER_H + M;
        int contentBottom = py + PANEL_H - M;
        ctx.enableScissor(px + 2, contentTop, px + PANEL_W - 2, contentBottom);

        int y = contentTop - (int) scroll;
        for (Module mod : mods) {
            float anim = moduleAnim.getOrDefault(mod, 0f);
            anim = Math.min(1f, anim + dt * 4f);
            moduleAnim.put(mod, anim);

            boolean isSelected = mod == selectedModule;
            int settingsHeight = 0;
            if (isSelected) {
                for (Setting<?> s : mod.getSettings()) {
                    if (s.isVisible()) settingsHeight += settingH(s) + 2;
                }
            }
            int totalBlockH = ROW_H + settingsHeight;

            if (y + totalBlockH > contentTop && y < contentBottom) {
                if (isSelected && settingsHeight > 0) {
                    int blockX = px + M;
                    int blockY = y;
                    int blockW = PANEL_W - M * 2;
                    int blockH = totalBlockH;
                    boolean on = mod.isEnabled();
                    int setBg = on
                            ? withAlpha(accent, 0.08f * anim * guiAlpha)
                            : withAlpha(0xFFFFFFFF, 0.03f * anim * guiAlpha);
                    int setBorder = on
                            ? withAlpha(accent, 0.22f * anim * guiAlpha)
                            : withAlpha(0xFFFFFFFF, 0.08f * anim * guiAlpha);

                    // Единая соединённая плашка на весь блок (строка модуля + выпадающие настройки)
                    RenderUtil.roundRect(ctx, blockX, blockY, blockW, blockH, 4, setBg);
                    RenderUtil.roundBorderEdge(ctx, blockX, blockY, blockW, blockH, 4, setBorder);

                    // Тонкий разделитель между строкой модуля и его настройками
                    int divColor = on ? accent : 0xFFFFFFFF;
                    ctx.fill(blockX + 4, y + ROW_H, blockX + blockW - 4, y + ROW_H + 1,
                            withAlpha(divColor, 0.12f * anim * guiAlpha));
                }

                renderModuleRow(ctx, mod, px + M, y, PANEL_W - M * 2, mx, my, accent, anim, isSelected && settingsHeight > 0);

                // Наведение считаем только по ВИДИМОЙ части строки: у
                // подрезанных сверху/снизу строк описание не всплывает
                if (mx >= px + M && mx < px + PANEL_W - M
                        && my >= Math.max(y, contentTop) && my < Math.min(y + ROW_H, contentBottom)) {
                    hoveredModule = mod;
                }
            }
            y += ROW_H + ROW_GAP;

            if (isSelected) {
                float expand = expandAnim.getOrDefault(mod, 0f);
                expand = Math.min(1f, expand + dt * 5f);
                expandAnim.put(mod, expand);

                for (Setting<?> s : mod.getSettings()) {
                    if (!s.isVisible()) continue;
                    int sh = settingH(s);
                    if (y + sh > contentTop && y < contentBottom) {
                        renderSettingInline(ctx, s, px + M + 4, y, PANEL_W - M * 2 - 8, mx, my, accent, expand, sh);
                    }
                    y += sh + 2;
                }
            } else {
                float expand = expandAnim.getOrDefault(mod, 0f);
                if (expand > 0.01f) {
                    expand = Math.max(0f, expand - dt * 5f);
                    expandAnim.put(mod, expand);
                }
            }
        }
        ctx.disableScissor();

        if (maxScroll > 0.0) {
            int trackX = px + PANEL_W - 3;
            int thumbH = Math.max(10, (int) (viewH * ((double) viewH / contentH)));
            int thumbY = contentTop + (int) ((viewH - thumbH) * (scroll / maxScroll));
            ctx.fill(trackX, contentTop, trackX + 2, contentTop + viewH, withAlpha(accent, 0.15f * guiAlpha));
            ctx.fill(trackX, thumbY, trackX + 2, thumbY + thumbH, withAlpha(accent, guiAlpha));
        }
    }

    private void renderModuleRow(DrawContext ctx, Module mod, int rx, int ry, int w, int mx, int my, int accent, float anim, boolean hasExpandedSettings) {
        boolean on = mod.isEnabled();
        boolean hovered = mx >= rx && mx < rx + w && my >= ry && my < ry + ROW_H;
        boolean hasSettings = !mod.getSettings().isEmpty();
        boolean hasBind = mod.getKeyBind() != KeyNames.NONE;

        float center = ry + ROW_H / 2f;
        float rowTextY = center - FONT_PX / 2f - 0.5f;

        // Анимация переключателя (0.0f .. 1.0f)
        float tAnim = toggleAnim.getOrDefault(mod, on ? 1.0f : 0.0f);
        tAnim = on ? Math.min(1.0f, tAnim + dt * 6.0f) : Math.max(0.0f, tAnim - dt * 6.0f);
        toggleAnim.put(mod, tAnim);

        // ===== Подложка строки в стиле Delta =====
        int cellX = rx;
        int cellY = ry;
        int cellW = w;
        int cellH = ROW_H;
        if (!hasExpandedSettings) {
            if (on) {
                RenderUtil.roundRect(ctx, cellX, cellY, cellW, cellH, 4,
                        withAlpha(accent, 0.08f * anim * guiAlpha));
                RenderUtil.roundBorderEdge(ctx, cellX, cellY, cellW, cellH, 4,
                        withAlpha(accent, 0.22f * anim * guiAlpha));
            } else if (hovered) {
                RenderUtil.roundRect(ctx, cellX, cellY, cellW, cellH, 4,
                        withAlpha(0xFFFFFFFF, 0.04f * anim * guiAlpha));
            }
        } else if (hovered) {
            RenderUtil.roundRect(ctx, cellX, cellY, cellW, cellH, 4,
                    withAlpha(0xFFFFFFFF, 0.03f * anim * guiAlpha));
        }

        // ===== Имя модуля =====
        String moduleName = mod.getName();
        int nameColor = on ? 0xFFFFFFFF : RenderUtil.textOff();
        float nameX = rx + 4;
        drawScaledText(ctx, moduleName, nameX, rowTextY, withAlpha(nameColor, anim), FONT_PX);
        float nameEnd = nameX + getTextWidth(moduleName, FONT_PX);

        // ===== Чип бинда в стиле Delta: иконка «C» + код клавиши =====
        if (hasBind) {
            String bindText = mod.getBindName();
            float g = 5.5f;
            float chipH = 8.5f;
            float iconPart = RenderUtil.iconWidth("C", g);
            float chipW = 3f + iconPart + 2f + getTextWidth(bindText, 5.5f) + 3f;
            float chipX = nameEnd + 3f;
            float chipY = center - chipH / 2f;
            RenderUtil.roundRect(ctx, (int) chipX, (int) chipY, (int) chipW, (int) chipH, 2,
                    withAlpha(accent, 0.16f * anim * guiAlpha));
            RenderUtil.roundBorderEdge(ctx, (int) chipX, (int) chipY, (int) chipW, (int) chipH, 2,
                    withAlpha(accent, 0.45f * anim * guiAlpha));
            RenderUtil.icon(ctx, "C", chipX + 2.5f, chipY + (chipH - g) / 2f - 0.5f, g,
                    withAlpha(RenderUtil.TEXT, 0.9f * anim));
            drawScaledText(ctx, bindText, chipX + 2.5f + iconPart + 2f,
                    chipY + (chipH - 5.5f) / 2f - 0.5f, withAlpha(RenderUtil.TEXT, 0.9f * anim), 5.5f);
        }

        // ===== Delta Toggle Switch =====
        float toggleW = 15.0f;
        float toggleH = 8.0f;
        float toggleX = rx + w - 4.0f - toggleW;
        float toggleY = center - toggleH / 2f;

        // Фон переключателя
        int toggleTrackColor = withAlpha(accent, (0.15f + 0.40f * tAnim) * anim * guiAlpha);
        RenderUtil.roundRect(ctx, (int) toggleX, (int) toggleY, (int) toggleW, (int) toggleH, 4, toggleTrackColor);
        RenderUtil.roundBorderEdge(ctx, (int) toggleX, (int) toggleY, (int) toggleW, (int) toggleH, 4,
                withAlpha(accent, (0.25f + 0.35f * tAnim) * anim * guiAlpha));

        // Ползунок внутри: ровно по центру (отступы по 1px сверху, снизу и по краям)
        float knobSize = 6.0f;
        float knobX = toggleX + 1.0f + 7.0f * tAnim;
        float knobY = toggleY + 1.0f;
        int knobColor = withAlpha(0xFFFFFFFF, (0.60f + 0.40f * tAnim) * anim * guiAlpha);
        RenderUtil.roundRect(ctx, (int) knobX, (int) knobY, (int) knobSize, (int) knobSize, 3, knobColor);

        // ===== Точки «...» у модуля с настройками (слева от переключателя) =====
        if (hasSettings) {
            float dotsRight = toggleX - 3.0f;
            int dotColor = hovered ? accent : withAlpha(RenderUtil.textDim(), 0.7f);
            for (int i = 0; i < 3; i++) {
                int dotX = (int) (dotsRight - 7.0f + i * 3.0f);
                int dotY = (int) (center - 1.0f);
                ctx.fill(dotX, dotY, dotX + 2, dotY + 2, withAlpha(dotColor, anim * guiAlpha));
            }
        }
    }

    private void renderSettingInline(DrawContext ctx, Setting<?> s, int sx, int sy, int w, int mx, int my, int accent, float anim, int sh) {
        // Внутри настроек шрифт мельче основного (SETTING_FONT_PX) и текст
        // СТАТИЧЕН: бегущая строка осталась только у редактируемых значений
        // TextSetting — там строка бывает реально длинной (например Spammer).
        final float fs = SETTING_FONT_PX;
        float textY = sy + (sh - fs) / 2f - 0.5f;

        if (s instanceof BooleanSetting bs) {
            String name = bs.getName();
            int nameColor = bs.get() ? RenderUtil.TEXT : RenderUtil.textOff();
            drawClippedText(ctx, name, sx, textY, w - BOX_SIZE - 4, withAlpha(nameColor, anim), fs);

            // ===== Чекбокс в стиле Delta: скруглённый квадрат с галочкой =====
            int boxX = sx + w - BOX_SIZE;
            int boxY = sy + (sh - BOX_SIZE) / 2;
            RenderUtil.checkbox(ctx, boxX, boxY, BOX_SIZE, bs.get(), accent, anim * guiAlpha);

        } else if (s instanceof NumberSetting ns) {
            float numTextY = sy + 1.0f;
            String val = ns.format();
            float valW = getTextWidth(val, fs);
            String name = ns.getName();
            drawClippedText(ctx, name, sx, numTextY, w - valW - 6, withAlpha(RenderUtil.textOff(), anim), fs);
            drawClippedRight(ctx, val, sx + w, numTextY, valW, withAlpha(RenderUtil.TEXT, anim), fs);

            int trackY = sy + 12;
            int trackH = 2;
            int trackW = w - 6;
            RenderUtil.roundRect(ctx, sx + 2, trackY, trackW, trackH, 1,
                    withAlpha(accent, 0.25f * guiAlpha));
            int fillW = (int) (trackW * ns.fraction());
            if (fillW > 1) {
                RenderUtil.roundRect(ctx, sx + 2, trackY, fillW, trackH, 1,
                        withAlpha(accent, guiAlpha));
            }

            int knobRadius = 3;
            int knobCenterX = Math.max(sx + 2 + knobRadius,
                    Math.min(sx + 2 + trackW - knobRadius, sx + 2 + fillW));
            int knobCenterY = trackY + trackH / 2;
            RenderUtil.circle(ctx, knobCenterX, knobCenterY, knobRadius,
                    withAlpha(accent, guiAlpha));

        } else if (s instanceof ButtonSetting btn) {
            boolean hover = mx >= sx && mx < sx + w && my >= sy && my < sy + sh;
            RenderUtil.roundBorderRect(ctx, sx, (int) sy + 1, w, sh - 2, 3,
                    withAlpha(accent, (hover ? 0.9f : 0.5f) * anim), withAlpha(hover ? RenderUtil.bgHeader() : RenderUtil.bgInput(), anim));
            float bwid = getTextWidth(btn.getName(), fs);
            drawScaledText(ctx, btn.getName(), sx + (w - bwid) / 2f, textY, withAlpha(RenderUtil.TEXT, anim), fs);

        } else if (s instanceof ModeSetting ms) {
            String val = ms.get();
            float valW = getTextWidth(val, fs);
            String name = ms.getName() + ":";
            drawClippedText(ctx, name, sx, textY, w - valW - 6, withAlpha(RenderUtil.textOff(), anim), fs);
            drawClippedRight(ctx, val, sx + w, textY, valW, withAlpha(RenderUtil.TEXT, anim), fs);

        } else if (s instanceof KeyBindSetting ks) {
            drawClippedText(ctx, ks.getName(), sx, textY,
                    w - 60, withAlpha(RenderUtil.textOff(), anim), fs);

            boolean listening = settingBindListening == ks;
            String bindText = listening ? "..." : ks.getKeyName();
            float g = 6f;
            float chipH = 9f;
            float iconPart = RenderUtil.iconWidth("C", g);
            float chipW = 4f + iconPart + 2.5f + getTextWidth(bindText, 6f) + 4f;
            float chipX = sx + w - chipW;
            float chipY = sy + (sh - chipH) / 2f;
            float chipBgA = listening ? 0.22f : 0.12f;

            RenderUtil.roundRect(ctx, (int) chipX, (int) chipY, (int) chipW, (int) chipH, 2,
                    withAlpha(accent, chipBgA * anim * guiAlpha));
            RenderUtil.roundBorderEdge(ctx, (int) chipX, (int) chipY, (int) chipW, (int) chipH, 2,
                    withAlpha(accent, (listening ? 0.9f : 0.45f) * anim * guiAlpha));
            RenderUtil.icon(ctx, "C", chipX + 4f, chipY + (chipH - g) / 2f - 0.5f, g,
                    withAlpha(RenderUtil.TEXT, 0.9f * anim));
            drawScaledText(ctx, bindText, chipX + 4f + iconPart + 2.5f,
                    chipY + (chipH - 6f) / 2f - 0.5f, withAlpha(RenderUtil.TEXT, 0.9f * anim), 6f);

        } else if (s instanceof TextSetting ts) {
            boolean active = (activeTextSetting == ts);
            String displayVal = active ? activeTextBuffer : (ts.get() == null ? "" : ts.get());
            String name = ts.getName() + ":";

            // Ширина «пилюли» считается по обрезанному окну, иначе рамка уедет за панель.
            // В режиме ввода окно фиксировано, чтобы рамка не «дышала» на каждую букву.
            float valW = active
                    ? Math.max(EDIT_MIN_WINDOW, Math.min(w * 0.6f, w - getTextWidth(name, fs) - 14))
                    : Math.min(getTextWidth(displayVal, fs), w * 0.6f);

            drawClippedText(ctx, name, sx, textY, w - valW - 12, withAlpha(RenderUtil.textOff(), anim), fs);

            int pillX = (int) (sx + w - valW - 8);
            int pillW = (int) valW + 8;
            int valColor = withAlpha(active ? accent : RenderUtil.TEXT, anim);

            if (active) {
                RenderUtil.roundBorderRect(ctx, pillX, (int) sy + 1, pillW, sh - 2, 3, accent, RenderUtil.bgInput());
                // Запоминаем геометрию — по ней мышь ставит каретку
                activeTextFieldX = pillX + 4;
                activeTextFieldW = valW;
                activeTextFieldY = sy;
                textCaret = clampCaret(displayVal, textCaret);
                textViewOff = drawEditable(ctx, displayVal, textCaret, pillX + 4, textY,
                        valW, valColor, accent, textViewOff, fs);
            } else {
                // Единственное место, где бегущая строка осталась: значение
                // текстового поля бывает длиннее отведённой пилюли.
                drawMarqueeText(ctx, displayVal, pillX + 4, textY, valW, valColor, fs);
            }

        } else if (s instanceof ColorSetting cs) {
            int curColor = cs.get();
            boolean expanded = cs.isExpanded();

            float headerH = 15f;
            float headerTextY = sy + (headerH - fs) / 2f - 0.5f;
            String name = cs.getName();
            String hex = cs.getHex();
            float hexW = getTextWidth(hex, 6.0f);
            drawClippedText(ctx, name, sx, headerTextY, w - hexW - 28, withAlpha(RenderUtil.textOff(), anim), fs);

            // Квадрат превью цвета
            int swatchW = 14;
            int swatchH = 9;
            int swatchX = (int) (sx + w - swatchW - 10);
            int swatchY = (int) (sy + (headerH - swatchH) / 2f);
            RenderUtil.roundRect(ctx, swatchX, swatchY, swatchW, swatchH, 2, withAlpha(curColor, anim));
            RenderUtil.roundBorderEdge(ctx, swatchX, swatchY, swatchW, swatchH, 2, withAlpha(0xFFFFFFFF, 0.45f * anim));

            // Стрелка состояния (▼ или ▲)
            String arrow = expanded ? "▲" : "▼";
            drawScaledText(ctx, arrow, sx + w - 7, headerTextY, withAlpha(RenderUtil.textOff(), 0.8f * anim), 5.5f);

            // HEX код цвета
            drawClippedRight(ctx, hex, swatchX - 4, headerTextY, hexW, withAlpha(RenderUtil.TEXT, 0.85f * anim), 6.0f);

            if (expanded) {
                // Подложка под раскрывшуюся палитру
                int palY = (int) sy + 16;
                int palH = 88;
                RenderUtil.roundRect(ctx, sx, palY, w, palH, 3, withAlpha(0xFF0D0D12, 0.85f * anim));
                RenderUtil.roundBorderEdge(ctx, sx, palY, w, palH, 3, withAlpha(0xFFFFFFFF, 0.08f * anim));

                // 1. Поле оттенков (Shades Area: Saturation x Brightness)
                int shadesX = sx + 4;
                int shadesY = palY + 4;
                int shadesW = w - 24;
                int shadesH = 44;

                int hueColor = java.awt.Color.HSBtoRGB(cs.getHue(), 1.0f, 1.0f);
                RenderUtil.gradientBox(ctx, shadesX, shadesY, shadesW, shadesH,
                        withAlpha(0xFFFFFFFF, anim),
                        withAlpha(0xFF000000, anim),
                        withAlpha(0xFF000000, anim),
                        withAlpha(hueColor, anim));
                RenderUtil.roundBorderEdge(ctx, shadesX, shadesY, shadesW, shadesH, 2, withAlpha(0xFFFFFFFF, 0.22f * anim));

                // Маркер/курсор на оттенке
                float cursorX = shadesX + cs.getSaturation() * shadesW;
                float cursorY = shadesY + (1.0f - cs.getBrightness()) * shadesH;
                RenderUtil.circle(ctx, (int) cursorX, (int) cursorY, 2.5f, 0xFFFFFFFF);
                RenderUtil.roundBorderEdge(ctx, (int) cursorX - 3, (int) cursorY - 3, 6, 6, 3, 0xFF000000);

                // 2. Полоса цветов спектра (Hue rainbow bar)
                int hueX = shadesX + shadesW + 4;
                int hueY = shadesY;
                int hueW = 12;
                int hueH = shadesH;

                RenderUtil.hueBar(ctx, hueX, hueY, hueW, hueH);
                RenderUtil.roundBorderEdge(ctx, hueX, hueY, hueW, hueH, 2, withAlpha(0xFFFFFFFF, 0.22f * anim));

                // Бегунок на полосе оттенка
                int knobY = (int) (hueY + cs.getHue() * hueH);
                RenderUtil.roundRect(ctx, hueX - 1, knobY - 1, hueW + 2, 3, 1, 0xFFFFFFFF);
                RenderUtil.roundBorderEdge(ctx, hueX - 1, knobY - 1, hueW + 2, 3, 1, 0xFF000000);

                // 3. Слайдеры цветового кода (R, G, B: 0..255)
                int sliderY = shadesY + shadesH + 5;
                int rTrackX = sx + 14;
                int rTrackW = w - 38;

                // Красный (R)
                drawScaledText(ctx, "R", sx + 4, sliderY + 1, withAlpha(0xFFFF5555, anim), 6.0f);
                drawRgbSlider(ctx, rTrackX, sliderY + 3, rTrackW, 2, cs.getRed() / 255f, 0xFFFF4444, anim);
                drawScaledText(ctx, String.valueOf(cs.getRed()), sx + w - 20, sliderY + 1, withAlpha(RenderUtil.TEXT, anim), 6.0f);

                // Зелёный (G)
                sliderY += 11;
                drawScaledText(ctx, "G", sx + 4, sliderY + 1, withAlpha(0xFF55FF55, anim), 6.0f);
                drawRgbSlider(ctx, rTrackX, sliderY + 3, rTrackW, 2, cs.getGreen() / 255f, 0xFF44FF44, anim);
                drawScaledText(ctx, String.valueOf(cs.getGreen()), sx + w - 20, sliderY + 1, withAlpha(RenderUtil.TEXT, anim), 6.0f);

                // Синий (B)
                sliderY += 11;
                drawScaledText(ctx, "B", sx + 4, sliderY + 1, withAlpha(0xFF5588FF, anim), 6.0f);
                drawRgbSlider(ctx, rTrackX, sliderY + 3, rTrackW, 2, cs.getBlue() / 255f, 0xFF4488FF, anim);
                drawScaledText(ctx, String.valueOf(cs.getBlue()), sx + w - 20, sliderY + 1, withAlpha(RenderUtil.TEXT, anim), 6.0f);
            }
        }
    }

    private void drawRgbSlider(DrawContext ctx, int trackX, int trackY, int trackW, int trackH, float frac, int trackColor, float anim) {
        RenderUtil.roundRect(ctx, trackX, trackY, trackW, trackH, 1, withAlpha(0xFFFFFFFF, 0.15f * anim));
        int fillW = (int) (trackW * frac);
        if (fillW > 0) {
            RenderUtil.roundRect(ctx, trackX, trackY, fillW, trackH, 1, withAlpha(trackColor, anim));
        }
        int knobX = Math.max(trackX + 2, Math.min(trackX + trackW - 2, trackX + fillW));
        RenderUtil.circle(ctx, knobX, trackY + 1, 2.5f, withAlpha(0xFFFFFFFF, anim));
    }

    private void applyColorShades(ColorSetting cs, double mx, double my, int x, int y, int w, int h) {
        float sat = (float) Math.max(0.0, Math.min(1.0, (mx - x) / (double) w));
        float bri = (float) (1.0 - Math.max(0.0, Math.min(1.0, (my - y) / (double) h)));
        cs.setHsb(cs.getHue(), sat, bri);
    }

    private void applyColorHue(ColorSetting cs, double my, int y, int h) {
        float hue = (float) Math.max(0.0, Math.min(1.0, (my - y) / (double) h));
        cs.setHsb(hue, cs.getSaturation(), cs.getBrightness());
    }

    private void applyColorRgb(ColorSetting cs, double mx, int trackX, int trackW, ColorDragMode mode) {
        double f = Math.max(0.0, Math.min(1.0, (mx - trackX) / (double) trackW));
        int val = (int) Math.round(f * 255.0);
        switch (mode) {
            case RED -> cs.setRed(val);
            case GREEN -> cs.setGreen(val);
            case BLUE -> cs.setBlue(val);
            default -> {}
        }
    }

    // ===== Кнопка «Вернуться обратно» (только в окне бота, сверху по центру) =====
    private static final int BACK_BTN_W = 180;
    private static final int BACK_BTN_H = 18;

    private boolean isBotWindow() { return ru.neuclient.client.bot.BotManager.getInstance().isChildBot(); }
    private int backBtnX() { return (vW() - BACK_BTN_W) / 2; }
    private int backBtnY() { return 8; }

    private void renderBackButton(DrawContext ctx, int mx, int my, int accent) {
        if (!isBotWindow()) return;
        int bx = backBtnX(), by = backBtnY();
        boolean hover = inside(mx, my, bx, by, BACK_BTN_W, BACK_BTN_H);
        glassPanel(ctx, bx, by, BACK_BTN_W, BACK_BTN_H, accent, hover ? 1.0f : 0.8f);
        String label = "← Вернуться обратно  (" + ru.neuclient.client.bot.BotManager.getInstance().getBotNickname() + ")";
        float tw = getTextWidth(label);
        drawScaledText(ctx, label, bx + (BACK_BTN_W - tw) / 2f, by + (BACK_BTN_H - FONT_PX) / 2f - 0.5f, RenderUtil.TEXT);
    }

    // ===== Кнопка «Боты» (открывает BotManagerScreen) =====
    private static final int BOTS_BTN_W = 128;
    private static final int BOTS_BTN_H = 16;

    private int botsBtnX() { return vW() - BOTS_BTN_W - 6; }
    private int botsBtnY() { return 6; }

    private void renderBotsButton(DrawContext ctx, int mx, int my, int accent) {
        int bx = botsBtnX(), by = botsBtnY();
        boolean hover = inside(mx, my, bx, by, BOTS_BTN_W, BOTS_BTN_H);
        glassPanel(ctx, bx, by, BOTS_BTN_W, BOTS_BTN_H, accent, hover ? 0.9f : 0.6f);
        int running = 0;
        for (String n : ru.neuclient.client.bot.BotManager.getInstance().getSavedNicks()) {
            if (ru.neuclient.client.bot.BotManager.getInstance().isRunning(n)) running++;
        }
        String label = "Боты" + (running > 0 ? "  •  " + running + " онлайн" : "");
        float tw = getTextWidth(label);
        drawScaledText(ctx, label, bx + (BOTS_BTN_W - tw) / 2f, by + (BOTS_BTN_H - FONT_PX) / 2f - 0.5f,
                hover ? RenderUtil.TEXT : RenderUtil.textDim());
    }

    private List<Module> filteredModules(Category cat) {
        List<Module> base = NeuClient.getInstance().getModuleManager().getByCategory(cat);
        String q = searchText.trim().toLowerCase(Locale.ROOT);
        if (q.isEmpty()) return base;
        List<Module> out = new ArrayList<>();
        for (Module mod : base) {
            if (mod.getName().toLowerCase(Locale.ROOT).contains(q)) out.add(mod);
        }
        return out;
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (guiAlpha < 0.9f) return true;
        double mx = ScaleUtil.toVirtualX(click.x()), my = ScaleUtil.toVirtualY(click.y());
        int button = click.button();

        if (settingBindListening != null && KeyNames.isMouse(button)) {
            settingBindListening.set(button);
            NeuSounds.play(NeuSounds.BIND);
            settingBindListening = null;
            return true;
        }
        settingBindListening = null;

        if (activeTextSetting != null) {
            int curH = settingH(activeTextSetting);
            if (button == 0
                    && mx >= activeTextFieldX - 4 && mx <= activeTextFieldX + activeTextFieldW + 4
                    && my >= activeTextFieldY && my <= activeTextFieldY + curH) {
                textCaret = caretFromX(activeTextBuffer, activeTextFieldX - textViewOff, mx, SETTING_FONT_PX);
                markEdit();
                return true;
            }
            activeTextSetting.set(activeTextBuffer.trim());
            activeTextSetting = null;
            textCaret = 0;
            textViewOff = 0f;
        }

        if (button == 0 && isBotWindow() && inside(mx, my, backBtnX(), backBtnY(), BACK_BTN_W, BACK_BTN_H)) {
            NeuSounds.play(NeuSounds.TAB);
            MinecraftClient.getInstance().setScreen(null);
            ru.neuclient.client.bot.BotManager.getInstance().joinBot("main");
            return true;
        }
        if (button == 0 && inside(mx, my, botsBtnX(), botsBtnY(), BOTS_BTN_W, BOTS_BTN_H)) {
            NeuSounds.play(NeuSounds.TAB);
            MinecraftClient.getInstance().setScreen(new BotManagerScreen(this));
            return true;
        }

        Category[] cats = Category.values();
        int totalW = cats.length * PANEL_W + (cats.length - 1) * GAP;
        int startX = (vW() - totalW) / 2;
        int startY = (vH() - PANEL_H) / 2 - 10;

        int searchY = startY + PANEL_H + 12;
        int searchW = 120;
        int searchH = 20;
        int searchX = vW() / 2 - searchW / 2;
        if (button == 0) {
            if (mx >= searchX && mx < searchX + searchW && my >= searchY && my < searchY + searchH) {
                if (!searchFocused) {
                    searchFocused = true;
                    searchCaret = searchText.length();
                } else {
                    searchCaret = caretFromX(searchText, searchX + 6 - searchViewOff, mx);
                }
                markEdit();
                return true;
            }
            searchFocused = false;
        }

        if (button == 2) {
            for (int i = 0; i < cats.length; i++) {
                int px = startX + i * (PANEL_W + GAP);
                if (handleMiddleClick(mx, my, px, startY, cats[i])) return true;
            }
        }

        if (button == 1) {
            for (int i = 0; i < cats.length; i++) {
                int px = startX + i * (PANEL_W + GAP);
                if (handleRightClick(mx, my, px, startY, cats[i])) return true;
            }
        }

        if (button == 0) {
            for (int i = 0; i < cats.length; i++) {
                int px = startX + i * (PANEL_W + GAP);
                if (handleLeftClick(mx, my, px, startY, cats[i])) return true;
            }
        }

        return super.mouseClicked(click, doubled);
    }

    private boolean handleLeftClick(double mx, double my, int px, int py, Category cat) {
        List<Module> mods = filteredModules(cat);
        double scroll = panelScrolls.getOrDefault(cat, 0.0);
        int contentTop = py + HEADER_H + M;
        int y = contentTop - (int) scroll;

        for (Module mod : mods) {
            if (my >= y && my < y + ROW_H && mx >= px + M && mx < px + PANEL_W - M) {
                mod.toggle();
                NeuSounds.toggle(mod.isEnabled());
                return true;
            }
            y += ROW_H + ROW_GAP;

            if (mod == selectedModule) {
                for (Setting<?> s : mod.getSettings()) {
                    if (!s.isVisible()) continue;
                    int sh = settingH(s);
                    if (my >= y && my < y + sh && mx >= px + M && mx < px + PANEL_W - M) {
                        if (s instanceof BooleanSetting bs) {
                            bs.toggle();
                            NeuSounds.toggle(bs.get());
                            return true;
                        }
                        if (s instanceof NumberSetting ns) {
                            activeSlider = ns;
                            sliderDragging = true;
                            applySlider(ns, mx, px + M + 6, PANEL_W - M * 2 - 14);
                            return true;
                        }
                        if (s instanceof ButtonSetting btn) {
                            NeuSounds.play(NeuSounds.SETTINGS);
                            btn.press();
                            return true;
                        }
                        if (s instanceof ModeSetting ms) {
                            ms.next();
                            NeuSounds.play(NeuSounds.SETTINGS);
                            return true;
                        }
                        if (s instanceof KeyBindSetting ks) {
                            // Слушаем клавишу ДЛЯ НАСТРОЙКИ, а не для модуля
                            settingBindListening = ks;
                            bindListening = null;
                            activeTextSetting = null;
                            searchFocused = false;
                            NeuSounds.play(NeuSounds.BIND);
                            return true;
                        }
                        if (s instanceof TextSetting ts) {
                            activeTextSetting = ts;
                            activeTextBuffer = ts.get() != null ? ts.get() : "";
                            textCaret = activeTextBuffer.length();
                            textViewOff = 0f;
                            searchFocused = false;
                            markEdit();
                            NeuSounds.play(NeuSounds.SETTINGS);
                            return true;
                        }
                        if (s instanceof ColorSetting cs) {
                            if (my < y + 16 || !cs.isExpanded()) {
                                cs.toggleExpanded();
                                NeuSounds.play(NeuSounds.SETTINGS);
                                return true;
                            }
                            int sx = px + M + 4;
                            int w = PANEL_W - M * 2 - 8;
                            int palY = y + 16;
                            int shadesX = sx + 4;
                            int shadesY = palY + 4;
                            int shadesW = w - 24;
                            int shadesH = 44;
                            int hueX = shadesX + shadesW + 4;
                            int hueY = shadesY;
                            int hueW = 12;
                            int hueH = shadesH;

                            if (mx >= shadesX && mx <= shadesX + shadesW && my >= shadesY && my <= shadesY + shadesH) {
                                activeColorSetting = cs;
                                colorDragMode = ColorDragMode.SHADES;
                                colorDragX = shadesX;
                                colorDragY = shadesY;
                                colorDragW = shadesW;
                                colorDragH = shadesH;
                                applyColorShades(cs, mx, my, shadesX, shadesY, shadesW, shadesH);
                                return true;
                            }
                            if (mx >= hueX - 2 && mx <= hueX + hueW + 2 && my >= hueY && my <= hueY + hueH) {
                                activeColorSetting = cs;
                                colorDragMode = ColorDragMode.HUE;
                                colorDragX = hueX;
                                colorDragY = hueY;
                                colorDragW = hueW;
                                colorDragH = hueH;
                                applyColorHue(cs, my, hueY, hueH);
                                return true;
                            }
                            int sliderY = shadesY + shadesH + 5;
                            int rTrackX = sx + 14;
                            int rTrackW = w - 38;
                            if (my >= sliderY - 2 && my <= sliderY + 9) {
                                activeColorSetting = cs;
                                colorDragMode = ColorDragMode.RED;
                                colorDragX = rTrackX;
                                colorDragW = rTrackW;
                                applyColorRgb(cs, mx, rTrackX, rTrackW, ColorDragMode.RED);
                                return true;
                            }
                            sliderY += 11;
                            if (my >= sliderY - 2 && my <= sliderY + 9) {
                                activeColorSetting = cs;
                                colorDragMode = ColorDragMode.GREEN;
                                colorDragX = rTrackX;
                                colorDragW = rTrackW;
                                applyColorRgb(cs, mx, rTrackX, rTrackW, ColorDragMode.GREEN);
                                return true;
                            }
                            sliderY += 11;
                            if (my >= sliderY - 2 && my <= sliderY + 9) {
                                activeColorSetting = cs;
                                colorDragMode = ColorDragMode.BLUE;
                                colorDragX = rTrackX;
                                colorDragW = rTrackW;
                                applyColorRgb(cs, mx, rTrackX, rTrackW, ColorDragMode.BLUE);
                                return true;
                            }
                            return true;
                        }
                    }
                    y += sh + 2;
                }
            }
        }
        return false;
    }

    private boolean handleRightClick(double mx, double my, int px, int py, Category cat) {
        List<Module> mods = filteredModules(cat);
        double scroll = panelScrolls.getOrDefault(cat, 0.0);
        int contentTop = py + HEADER_H + M;
        int y = contentTop - (int) scroll;

        for (Module mod : mods) {
            if (my >= y && my < y + ROW_H && mx >= px + M && mx < px + PANEL_W - M) {
                if (!mod.getSettings().isEmpty()) {
                    if (selectedModule == mod) {
                        selectedModule = null;
                    } else {
                        selectedModule = mod;
                        expandAnim.put(mod, 0f);
                    }
                    NeuSounds.play(NeuSounds.SETTINGS);
                }
                return true;
            }
            y += ROW_H + ROW_GAP;
            if (mod == selectedModule) {
                for (Setting<?> s : mod.getSettings()) {
                    if (!s.isVisible()) continue;
                    y += settingH(s) + 2;
                }
            }
        }
        return false;
    }

    private boolean handleMiddleClick(double mx, double my, int px, int py, Category cat) {
        List<Module> mods = filteredModules(cat);
        double scroll = panelScrolls.getOrDefault(cat, 0.0);
        int contentTop = py + HEADER_H + M;
        int y = contentTop - (int) scroll;

        for (Module mod : mods) {
            if (my >= y && my < y + ROW_H && mx >= px + M && mx < px + PANEL_W - M) {
                bindListening = mod;
                NeuSounds.play(NeuSounds.BIND);
                return true;
            }
            y += ROW_H + ROW_GAP;
        }
        return false;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        double mx = ScaleUtil.toVirtualX(mouseX);
        double my = ScaleUtil.toVirtualY(mouseY);

        Category[] cats = Category.values();
        int totalW = cats.length * PANEL_W + (cats.length - 1) * GAP;
        int startX = (vW() - totalW) / 2;
        int startY = (vH() - PANEL_H) / 2 - 10;

        for (int i = 0; i < cats.length; i++) {
            Category cat = cats[i];
            int px = startX + i * (PANEL_W + GAP);
            if (mx >= px && mx < px + PANEL_W && my >= startY && my < startY + PANEL_H) {
                List<Module> mods = filteredModules(cat);
                int contentH = 0;
                for (Module mod : mods) {
                    contentH += ROW_H + ROW_GAP;
                    if (mod == selectedModule) {
                        for (Setting<?> s : mod.getSettings()) {
                            if (s.isVisible()) contentH += settingH(s) + 2;
                        }
                    }
                }
                int viewH = PANEL_H - HEADER_H - M * 2;
                double maxScroll = Math.max(0.0, contentH - viewH);
                double cur = panelScrolls.getOrDefault(cat, 0.0);
                panelScrolls.put(cat, Math.max(0.0, Math.min(maxScroll, cur - verticalAmount * 18.0)));
                return true;
            }
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean mouseDragged(Click click, double deltaX, double deltaY) {
        double mx = ScaleUtil.toVirtualX(click.x());
        double my = ScaleUtil.toVirtualY(click.y());
        if (activeColorSetting != null && colorDragMode != ColorDragMode.NONE) {
            switch (colorDragMode) {
                case SHADES -> applyColorShades(activeColorSetting, mx, my, colorDragX, colorDragY, colorDragW, colorDragH);
                case HUE -> applyColorHue(activeColorSetting, my, colorDragY, colorDragH);
                case RED, GREEN, BLUE -> applyColorRgb(activeColorSetting, mx, colorDragX, colorDragW, colorDragMode);
                default -> {}
            }
            return true;
        }
        if (sliderDragging && activeSlider != null) {
            Category cat = selectedModule != null ? selectedModule.getCategory() : null;
            if (cat != null) {
                Category[] cats = Category.values();
                int totalW = cats.length * PANEL_W + (cats.length - 1) * GAP;
                int startX = (vW() - totalW) / 2;
                for (int i = 0; i < cats.length; i++) {
                    if (cats[i] == cat) {
                        int px = startX + i * (PANEL_W + GAP);
                        applySlider(activeSlider, mx, px + M + 6, PANEL_W - M * 2 - 14);
                        return true;
                    }
                }
            }
        }
        return super.mouseDragged(click, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(Click click) {
        sliderDragging = false;
        activeSlider = null;
        colorDragMode = ColorDragMode.NONE;
        activeColorSetting = null;
        return super.mouseReleased(click);
    }

    private void applySlider(NumberSetting ns, double mx, int sx, int w) {
        double f = Math.max(0.0, Math.min(1.0, (mx - sx) / (double) w));
        ns.setClamped(ns.getMin() + f * (ns.getMax() - ns.getMin()));
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        int code = input.key();

        boolean ctrlDown = (input.modifiers() & GLFW.GLFW_MOD_CONTROL) != 0;

        if (activeTextSetting != null) {
            textCaret = clampCaret(activeTextBuffer, textCaret);

            if (code == GLFW.GLFW_KEY_ENTER || code == GLFW.GLFW_KEY_KP_ENTER || code == GLFW.GLFW_KEY_ESCAPE) {
                activeTextSetting.set(activeTextBuffer.trim());
                activeTextSetting = null;
                textCaret = 0;
                textViewOff = 0f;
                NeuSounds.play(NeuSounds.SETTINGS);
                return true;
            }
            // ← / → : движение каретки, с Ctrl — по словам
            if (code == GLFW.GLFW_KEY_LEFT) {
                textCaret = ctrlDown ? prevWord(activeTextBuffer, textCaret) : Math.max(0, textCaret - 1);
                markEdit();
                return true;
            }
            if (code == GLFW.GLFW_KEY_RIGHT) {
                textCaret = ctrlDown ? nextWord(activeTextBuffer, textCaret)
                        : Math.min(activeTextBuffer.length(), textCaret + 1);
                markEdit();
                return true;
            }
            if (code == GLFW.GLFW_KEY_HOME || code == GLFW.GLFW_KEY_UP) {
                textCaret = 0;
                markEdit();
                return true;
            }
            if (code == GLFW.GLFW_KEY_END || code == GLFW.GLFW_KEY_DOWN) {
                textCaret = activeTextBuffer.length();
                markEdit();
                return true;
            }
            // Backspace — удаляет символ ПЕРЕД кареткой
            if (code == GLFW.GLFW_KEY_BACKSPACE) {
                if (ctrlDown) {
                    int from = prevWord(activeTextBuffer, textCaret);
                    activeTextBuffer = activeTextBuffer.substring(0, from) + activeTextBuffer.substring(textCaret);
                    textCaret = from;
                } else if (textCaret > 0) {
                    activeTextBuffer = activeTextBuffer.substring(0, textCaret - 1) + activeTextBuffer.substring(textCaret);
                    textCaret--;
                }
                markEdit();
                return true;
            }
            // Delete — символ ПОСЛЕ каретки; Ctrl+Delete — очистить всё
            if (code == GLFW.GLFW_KEY_DELETE) {
                if (ctrlDown) {
                    activeTextBuffer = "";
                    textCaret = 0;
                } else if (textCaret < activeTextBuffer.length()) {
                    activeTextBuffer = activeTextBuffer.substring(0, textCaret) + activeTextBuffer.substring(textCaret + 1);
                }
                markEdit();
                return true;
            }
            if (code == GLFW.GLFW_KEY_V && ctrlDown) {
                String clip = MinecraftClient.getInstance().keyboard.getClipboard();
                if (clip != null && !clip.isEmpty()) {
                    clip = clip.replace("\n", "").replace("\r", "");
                    int remaining = activeTextSetting.getMaxLength() - activeTextBuffer.length();
                    if (remaining > 0) {
                        String add = clip.substring(0, Math.min(clip.length(), remaining));
                        activeTextBuffer = activeTextBuffer.substring(0, textCaret) + add + activeTextBuffer.substring(textCaret);
                        textCaret += add.length();
                    }
                }
                markEdit();
                return true;
            }
            if (code == GLFW.GLFW_KEY_C && ctrlDown) {
                MinecraftClient.getInstance().keyboard.setClipboard(activeTextBuffer);
                return true;
            }
            return true;
        }

        // Настройка-клавиша слушается ПЕРВОЙ и никогда не трогает бинд модуля
        if (settingBindListening != null) {
            if (code == GLFW.GLFW_KEY_ESCAPE) {
                settingBindListening.set(KeyBindSetting.NONE);
                NeuSounds.play(NeuSounds.BIND, 0.7f);
            } else {
                settingBindListening.set(code);
                NeuSounds.play(NeuSounds.BIND);
            }
            settingBindListening = null;
            Module.markConfigDirty();
            return true;
        }

        if (bindListening != null) {
            if (code == GLFW.GLFW_KEY_ESCAPE) {
                bindListening.setKeyBind(KeyNames.NONE);
                bindListening = null;
                NeuSounds.play(NeuSounds.BIND, 0.7f);
            } else {
                bindListening.setKeyBind(code);
                bindListening = null;
                NeuSounds.play(NeuSounds.BIND);
            }
            return true;
        }

        if (code == GLFW.GLFW_KEY_F && ctrlDown) {
            searchFocused = !searchFocused;
            if (searchFocused) {
                searchCaret = searchText.length();
                markEdit();
            }
            return true;
        }

        if (searchFocused) {
            searchCaret = clampCaret(searchText, searchCaret);

            if (code == GLFW.GLFW_KEY_LEFT) {
                searchCaret = ctrlDown ? prevWord(searchText, searchCaret) : Math.max(0, searchCaret - 1);
                markEdit();
                return true;
            }
            if (code == GLFW.GLFW_KEY_RIGHT) {
                searchCaret = ctrlDown ? nextWord(searchText, searchCaret)
                        : Math.min(searchText.length(), searchCaret + 1);
                markEdit();
                return true;
            }
            if (code == GLFW.GLFW_KEY_HOME) {
                searchCaret = 0;
                markEdit();
                return true;
            }
            if (code == GLFW.GLFW_KEY_END) {
                searchCaret = searchText.length();
                markEdit();
                return true;
            }
            if (code == GLFW.GLFW_KEY_BACKSPACE) {
                if (ctrlDown) {
                    int from = prevWord(searchText, searchCaret);
                    searchText = searchText.substring(0, from) + searchText.substring(searchCaret);
                    searchCaret = from;
                } else if (searchCaret > 0) {
                    searchText = searchText.substring(0, searchCaret - 1) + searchText.substring(searchCaret);
                    searchCaret--;
                }
                markEdit();
                return true;
            }
            if (code == GLFW.GLFW_KEY_DELETE) {
                if (ctrlDown) {
                    searchText = "";
                    searchCaret = 0;
                } else if (searchCaret < searchText.length()) {
                    searchText = searchText.substring(0, searchCaret) + searchText.substring(searchCaret + 1);
                }
                markEdit();
                return true;
            }
            if (code == GLFW.GLFW_KEY_V && ctrlDown) {
                String clip = MinecraftClient.getInstance().keyboard.getClipboard();
                if (clip != null && !clip.isEmpty()) {
                    clip = clip.replace("\n", "").replace("\r", "");
                    int remaining = 40 - searchText.length();
                    if (remaining > 0) {
                        String add = clip.substring(0, Math.min(clip.length(), remaining));
                        searchText = searchText.substring(0, searchCaret) + add + searchText.substring(searchCaret);
                        searchCaret += add.length();
                    }
                }
                markEdit();
                return true;
            }
            if (code == GLFW.GLFW_KEY_ESCAPE) {
                searchFocused = false;
                return true;
            }
        }

        if (code == GLFW.GLFW_KEY_ESCAPE || code == NeuClient.getInstance().getModuleManager().getGuiKey()) {
            if (!closing) { closing = true; }
            return true;
        }
        return super.keyPressed(input);
    }

    @Override
    public boolean charTyped(CharInput input) {
        boolean ctrl = (input.modifiers() & GLFW.GLFW_MOD_CONTROL) != 0;
        if (activeTextSetting != null && input.isValidChar() && !ctrl) {
            if (activeTextBuffer.length() < activeTextSetting.getMaxLength()) {
                // Вставка в позицию каретки, а не всегда в конец
                textCaret = clampCaret(activeTextBuffer, textCaret);
                String add = input.asString();
                activeTextBuffer = activeTextBuffer.substring(0, textCaret) + add + activeTextBuffer.substring(textCaret);
                textCaret += add.length();
                markEdit();
                return true;
            }
        }
        if (searchFocused && input.isValidChar() && !ctrl && searchText.length() < 40) {
            searchCaret = clampCaret(searchText, searchCaret);
            String add = input.asString();
            searchText = searchText.substring(0, searchCaret) + add + searchText.substring(searchCaret);
            searchCaret += add.length();
            markEdit();
            return true;
        }
        return false;
    }

    @Override
    public boolean shouldPause() { return false; }

    public boolean isSearchFocused() { return searchFocused; }
    public boolean isTextEditing() { return activeTextSetting != null; }
    public static void playClick() { NeuSounds.play(NeuSounds.TAB); }
}
