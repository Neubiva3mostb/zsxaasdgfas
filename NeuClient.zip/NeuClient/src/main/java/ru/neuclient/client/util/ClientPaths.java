package ru.neuclient.client.util;

import ru.neuclient.client.NeuClient;

import java.awt.Desktop;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;

/**
 * Утилита путей клиента.
 *
 * Теперь все конфиги живут в папке, выбранной в лаунчере (GameDir),
 * которая передается через -Dneuclient.baseDir.
 * Фолбэк — C:\NeuClient на Windows и ~/NeuClient на других ОС.
 */
public final class ClientPaths {

	private static Path base;

	private ClientPaths() {
	}

	/** Создаёт корневую папку клиента и подпапки configs/ и proxy/, если их ещё нет. */
	public static void init() {
		// 1. Пробуем взять путь из системного свойства, которое ставит лаунчер
		String prop = System.getProperty("neuclient.baseDir");
		if (prop != null && !prop.isBlank()) {
			base = Path.of(prop);
		} else {
			// 2. Пробуем взять runDirectory из MinecraftClient (если уже инициализирован)
			try {
				net.minecraft.client.MinecraftClient mc = net.minecraft.client.MinecraftClient.getInstance();
				if (mc != null && mc.runDirectory != null) {
					base = mc.runDirectory.toPath();
				}
			} catch (Throwable ignored) {
			}
		}

		// 3. Фолбэк — старый путь C:\NeuClient
		if (base == null) {
			String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
			if (os.contains("win")) {
				base = Path.of("C:\\NeuClient");
			} else {
				base = Path.of(System.getProperty("user.home"), "NeuClient");
			}
		}

		try {
			Files.createDirectories(base);
			Files.createDirectories(getConfigsDir());
			Files.createDirectories(getProxyDir());
			Files.createDirectories(base.resolve("profiles"));
			NeuClient.LOGGER.info("[NeuClient] Папка клиента (baseDir): {}", base.toAbsolutePath());
			if (prop != null) {
				NeuClient.LOGGER.info("[NeuClient] Используется GameDir из лаунчера: {}", prop);
			}
		} catch (IOException e) {
			NeuClient.LOGGER.error("[NeuClient] Не удалось создать папки {}", base, e);
		}
	}

	/** Корневая папка клиента (теперь = GameDir из лаунчера). */
	public static Path getBase() {
		return base;
	}

	/** Подпапка конфиг-профилей: <base>/configs. */
	public static Path getConfigsDir() {
		return base.resolve("configs");
	}

	/** Подпапка конфигурации прокси: <base>/proxy. */
	public static Path getProxyDir() {
		return base.resolve("proxy");
	}

	/** Файл внутри папки конфигов, например "default.json". */
	public static Path configFile(String fileName) {
		return getConfigsDir().resolve(fileName);
	}

	/** Файл в корне папки клиента (alts.json, friends.json и т.п.). */
	public static Path file(String fileName) {
		return base.resolve(fileName);
	}

	/** Временный файл (не конфиг) — в системной temp-папке. */
	public static Path tempFile(String fileName) {
		return Path.of(System.getProperty("java.io.tmpdir"), "NeuClient-" + fileName);
	}

	/**
	 * Открывает в проводнике папку с конфигами (команда ".cfg dir").
	 */
	public static boolean openInExplorer() {
		try {
			if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.OPEN)) {
				Desktop.getDesktop().open(getConfigsDir().toFile());
				return true;
			}
			String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
			if (os.contains("win")) {
				new ProcessBuilder("explorer.exe", getConfigsDir().toAbsolutePath().toString()).start();
				return true;
			}
		} catch (Exception e) {
			NeuClient.LOGGER.error("[NeuClient] Не удалось открыть проводник", e);
		}
		return false;
	}
}
