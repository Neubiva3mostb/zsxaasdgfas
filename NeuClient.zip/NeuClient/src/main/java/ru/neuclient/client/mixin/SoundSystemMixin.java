package ru.neuclient.client.mixin;

import net.minecraft.client.sound.SoundInstance;
import net.minecraft.client.sound.SoundSystem;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.impl.player.HitSoundsModule;

/**
 * HitSounds: глушилка ванильных звуков удара.
 * 
 * Когда модуль HitSounds включён, ВСЕ ванильные звуки
 * entity.player.attack.* отменяются на уровне SoundSystem.
 */
@Mixin(SoundSystem.class)
public abstract class SoundSystemMixin {

	@Inject(method = "play(Lnet/minecraft/client/sound/SoundInstance;)Lnet/minecraft/client/sound/SoundSystem$PlayResult;",
			at = @At("HEAD"), cancellable = true)
	private void pc$cancelVanillaHitSounds(SoundInstance sound, CallbackInfoReturnable<SoundSystem.PlayResult> cir) {
		if (sound == null) return;
		if (HitSoundsModule.isInsideHitsounds()) {
			return;
		}
		if (!HitSoundsModule.isActive()) {
			return;
		}
		try {
			net.minecraft.util.Identifier id = sound.getId();
			if (id != null && "minecraft".equals(id.getNamespace())) {
				if (id.getPath().startsWith("entity.player.attack.")) {
					cir.setReturnValue(SoundSystem.PlayResult.NOT_STARTED);
				} else if (id.getPath().startsWith("entity.warden.")) {
					// Агр-детект AutoWarden: варден подал голос рядом.
					ru.neuclient.client.module.impl.misc.AutoWardenModule
							.onWardenSound(sound.getX(), sound.getY(), sound.getZ());
				}
			}
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка HitSounds SoundSystem", t);
		}
	}

	@Inject(method = "play(Lnet/minecraft/client/sound/SoundInstance;I)V",
			at = @At("HEAD"), cancellable = true)
	private void pc$cancelDelayedHitSounds(SoundInstance sound, int delay, CallbackInfo ci) {
		if (sound == null) return;
		if (HitSoundsModule.isInsideHitsounds()) {
			return;
		}
		if (!HitSoundsModule.isActive()) {
			return;
		}
		try {
			net.minecraft.util.Identifier id = sound.getId();
			if (id != null && "minecraft".equals(id.getNamespace())
					&& id.getPath().startsWith("entity.player.attack.")) {
				ci.cancel();
			}
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка HitSounds SoundSystem delayed", t);
		}
	}
}
