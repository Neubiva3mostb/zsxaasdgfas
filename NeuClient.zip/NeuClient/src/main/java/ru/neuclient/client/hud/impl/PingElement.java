package ru.neuclient.client.hud.impl;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.PlayerListEntry;
import ru.neuclient.client.hud.HudElement;

/**
 * Пинг до сервера — карточка [Ping │ 24ms] в общем стиле HUD.
 * На одиночной игре показывает 0ms.
 */
public class PingElement extends HudElement {

	public PingElement() {
		super("ping", 4, 58);
	}

	@Override
	public boolean isVisible() {
		if (ru.neuclient.client.NeuClient.getInstance().getInterfaceModule().isElementVisible("watermark")) return false;
		return super.isVisible();
	}

	@Override
	protected void drawElement(DrawContext ctx, boolean editing) {
		int ping = 0;
		if (mc.player != null && mc.getNetworkHandler() != null) {
			PlayerListEntry entry = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
			if (entry != null) {
				ping = entry.getLatency();
			}
		}
		String value = ping + "ms";
		this.width = valueCardWidth("Ping", value);
		this.height = CARD_H;
		drawValueCard(ctx, getX(), getY(), width, "Ping", value);
	}
}
