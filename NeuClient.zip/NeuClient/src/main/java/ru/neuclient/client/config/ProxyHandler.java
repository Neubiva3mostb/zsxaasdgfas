package ru.neuclient.client.config;

import ru.neuclient.client.NeuClient;

/**
 * Управление SOCKS5-прокси для подключения к серверам.
 *
 * Хранит текущий конфиг прокси, который читается
 * миксином ClientConnectionMixin при установке соединения.
 */
public final class ProxyHandler {

	/** Текущий конфиг прокси. */
	private static ProxyConfig config = ProxyConfig.DEFAULT;

	private ProxyHandler() {
	}

	/** Инициализация: загрузка из файла. */
	public static void init() {
		config = ProxyConfig.load();
		NeuClient.LOGGER.info("[NeuClient] Proxy loaded");
	}

	/** Получить текущий конфиг. */
	public static ProxyConfig getConfig() {
		return config;
	}

	/** Сохранить новый конфиг. */
	public static void setConfig(ProxyConfig newConfig) {
		config = newConfig;
		ProxyConfig.save(config);
		NeuClient.LOGGER.info("[NeuClient] Proxy updated}",
				config.enabled(), config.proxyIp(), config.proxyPort());
	}

	/** Активен ли прокси сейчас. */
	public static boolean isActive() {
		return config != null && config.isActive();
	}
}
