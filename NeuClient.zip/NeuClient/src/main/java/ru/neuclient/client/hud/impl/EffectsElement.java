package ru.neuclient.client.hud.impl;

import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.util.Identifier;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.font.MsdfFontRenderer;
import ru.neuclient.client.font.MsdfFonts;
import ru.neuclient.client.hud.HudElement;
import ru.neuclient.client.util.RenderUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Виджет «Эффекты» NeuClient:
 *  - Шапка «Эффекты»
 *  - Плашки эффектов с иконкой, названием и таймером
 */
public class EffectsElement extends HudElement {

	private static final float HEADER_H = 13.5f;
	private static final float ROW_H = 11.5f;
	private static final float ROW_STEP = 13.5f;
	private static final float FONT_SIZE = 6.5f;
	private static final int HARMFUL_COLOR = 0xFFFF4C4C;

	public EffectsElement() {
		super("effects", 4, 191);
	}

	@Override
	protected int getDefaultX() {
		return 4;
	}

	@Override
	protected int getDefaultY() {
		return 120;
	}

	@Override
	protected void drawElement(DrawContext ctx, boolean editing) {
		List<StatusEffectInstance> list = new ArrayList<>();
		if (mc.player != null) {
			list.addAll(mc.player.getStatusEffects());
		}

		if (list.isEmpty() && !editing) {
			this.width = 0;
			this.height = 0;
			return;
		}

		var textFont = MsdfFonts.sfMedium();
		float targetWidth = MsdfFontRenderer.getWidth(textFont, "Эффекты", FONT_SIZE) + 16.0f;

		if (editing && list.isEmpty()) {
			float sampleW = 16.0f + MsdfFontRenderer.getWidth(textFont, "Speed 2", FONT_SIZE) + 8.0f
					+ MsdfFontRenderer.getWidth(textFont, "1:30", FONT_SIZE) + 8.0f;
			targetWidth = Math.max(targetWidth, sampleW);
		} else {
			for (StatusEffectInstance effect : list) {
				String name = nameOf(effect);
				String dur = timeOf(effect);
				float rowW = 16.0f + MsdfFontRenderer.getWidth(textFont, name, FONT_SIZE) + 8.0f
						+ MsdfFontRenderer.getWidth(textFont, dur, FONT_SIZE) + 8.0f;
				targetWidth = Math.max(targetWidth, rowW);
			}
		}

		this.width = (int) Math.ceil(targetWidth);
		int rowsCount = editing && list.isEmpty() ? 1 : list.size();
		this.height = (int) Math.ceil(HEADER_H + 3.0f + rowsCount * ROW_STEP);

		int x = getX();
		int y = getY();
		var im = NeuClient.getInstance().getInterfaceModule();
		int accent = im != null ? im.getEffectsColor() : RenderUtil.accent();
		int bg = 0xEE0B0B16;

		// Заголовок
		RenderUtil.roundRect(ctx, x, y, width, (int) HEADER_H, 4, bg);
		RenderUtil.roundBorderEdge(ctx, x, y, width, (int) HEADER_H, 4, withAlpha(accent, 0.33f));

		float headerTextY = y + (HEADER_H - FONT_SIZE) / 2f - 0.5f;
		MsdfFontRenderer.drawWithShadow(ctx, textFont, "Эффекты", x + 6.0f, headerTextY, 0xFFFFFFFF, FONT_SIZE);

		// Список эффектов
		float contentY = y + HEADER_H + 3.0f;

		if (editing && list.isEmpty()) {
			drawRow(ctx, x, (int) contentY, width, null, "Speed 2", "1:30", true, accent, bg);
			return;
		}

		for (StatusEffectInstance effect : list) {
			boolean beneficial = effect.getEffectType().value().isBeneficial();
			drawRow(ctx, x, (int) contentY, width, effect, nameOf(effect), timeOf(effect), beneficial, accent, bg);
			contentY += ROW_STEP;
		}
	}

	private void drawRow(DrawContext ctx, int rx, int ry, int rw, StatusEffectInstance effect,
						 String name, String dur, boolean beneficial, int accent, int bg) {
		RenderUtil.roundRect(ctx, rx, ry, rw, (int) ROW_H, 4, bg);
		RenderUtil.roundBorderEdge(ctx, rx, ry, rw, (int) ROW_H, 4, withAlpha(accent, 0.22f));

		var textFont = MsdfFonts.sfMedium();

		// Иконка эффекта
		int textX = rx + 6;
		if (effect != null) {
			Identifier icon = InGameHud.getEffectTexture(effect.getEffectType());
			if (icon != null) {
				ctx.drawGuiTexture(RenderPipelines.GUI_TEXTURED, icon, rx + 4, ry + 2, 8, 8);
				textX = rx + 15;
			}
		}

		// Название эффекта
		int textColor = beneficial ? 0xFFFFFFFF : HARMFUL_COLOR;
		float textY = ry + (ROW_H - FONT_SIZE) / 2.0f - 0.5f;
		MsdfFontRenderer.drawWithShadow(ctx, textFont, name, textX, textY, textColor, FONT_SIZE);

		// Длительность
		float durW = MsdfFontRenderer.getWidth(textFont, dur, FONT_SIZE);
		float durX = rx + rw - 6.0f - durW;
		MsdfFontRenderer.drawWithShadow(ctx, textFont, dur, durX, textY, withAlpha(0xFFFFFFFF, 0x8C), FONT_SIZE);
	}

	private String nameOf(StatusEffectInstance effect) {
		String name = effect.getEffectType().value().getName().getString();
		int amplifier = effect.getAmplifier() + 1;
		return amplifier > 1 ? name + " " + amplifier : name;
	}

	private String timeOf(StatusEffectInstance effect) {
		if (effect.isInfinite()) {
			return "\u221E";
		}
		int total = effect.getDuration() / 20;
		return String.format(Locale.ROOT, "%d:%02d", total / 60, total % 60);
	}
}
