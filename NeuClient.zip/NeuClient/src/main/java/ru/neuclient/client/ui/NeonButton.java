package ru.neuclient.client.ui;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.narration.NarrationMessageBuilder;
import net.minecraft.client.gui.screen.narration.NarrationPart;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.text.Text;
import ru.neuclient.client.font.MsdfFontRenderer;
import ru.neuclient.client.font.MsdfFonts;
import ru.neuclient.client.util.NeuSounds;
import ru.neuclient.client.util.RenderUtil;

/**
 * Кнопка в фирменном стиле NeuClient:
 *  - скруглённый прямоугольник на тёмном графитовом фоне;
 *  - ПЛАВНАЯ анимация наведения: свечение, рамка, акцентная заливка и текст
 *    перетекают мягко (экспоненциальный lerp), а не щёлкают мгновенно;
 *  - нативная отрисовка текста через MSDF (SF Pro Medium);
 *  - чёткая 8-зубчатая пиксельная шестерёнка для настроек.
 */
public class NeonButton extends ClickableWidget {

	public interface PressAction {
		void onPress(NeonButton button);
	}

	private final PressAction onPress;

	/** Прогресс анимации наведения 0..1 (плавно стремится к цели). */
	private float hoverAnim = 0f;
	private long lastMs = 0L;

	/** Абсолютное время (мс), когда кнопка начинает появляться; 0 = без анимации. */
	private long introStartMs = 0L;

	public NeonButton(int x, int y, int width, int height, Text message, PressAction onPress) {
		super(x, y, width, height, message);
		this.onPress = onPress;
	}

	/** Задать момент начала анимации появления (каскад в главном меню). */
	public void pc$setIntro(long absoluteMs) {
		this.introStartMs = absoluteMs;
	}

	@Override
	protected void renderWidget(DrawContext ctx, int mouseX, int mouseY, float deltaTicks) {
		// === Плавная анимация наведения ===
		long now = System.currentTimeMillis();
		float dt = (lastMs == 0L) ? 0.016f : Math.min((now - lastMs) / 1000.0f, 0.05f);
		lastMs = now;
		float target = (isHovered() && active) ? 1f : 0f;
		float k = 1.0f - (float) Math.exp(-dt * 13.0f);
		hoverAnim += (target - hoverAnim) * k;
		if (hoverAnim < 0.001f) hoverAnim = 0f;
		if (hoverAnim > 0.999f) hoverAnim = 1f;
		float t = hoverAnim;

		// === Плавное появление (каскад): прозрачность + сдвиг снизу вверх ===
		float intro = 1f;
		int dy = 0;
		if (introStartMs > 0L) {
			long elapsed = now - introStartMs;
			float p = elapsed < 0L ? 0f : Math.min(1f, elapsed / 260.0f);
			intro = 1f - (float) Math.pow(1f - p, 3.0); // ease-out cubic
			dy = Math.round((1f - intro) * 8f);
			if (intro <= 0.004f) return;
		}

		int x = getX(), y = getY() + dy, w = width, h = height, r = 6;

		// === Мягкое неоновое свечение (нарастает с наведением) ===
		if (t > 0.01f) {
			int rgb = RenderUtil.accent() & 0x00FFFFFF;
			RenderUtil.roundRect(ctx, x - 4, y - 4, w + 8, h + 8, r + 4, rgb | alpha(0x10, t * intro));
			RenderUtil.roundRect(ctx, x - 3, y - 3, w + 6, h + 6, r + 3, rgb | alpha(0x1A, t * intro));
			RenderUtil.roundRect(ctx, x - 1, y - 1, w + 2, h + 2, r + 1, rgb | alpha(0x2C, t * intro));
		}

		// === Корпус: как плашки ника/версии — просто прозрачная заливка.
		// Рамки в покое нет; на наведении мягко проявляется акцентная. ===
		int borderColor = fade(lerpColor(0x00FFFFFF, (RenderUtil.accent() & 0x00FFFFFF) | 0x59000000, t), intro);
		int innerColor = fade(lerpColor(BACKGROUND, accentDark(), t), intro);
		RenderUtil.roundBorderRect(ctx, x, y, w, h, r, borderColor, innerColor);

		// === Текст (и шестерёнка) — цвет тоже перетекает ===
		int color = !active ? RenderUtil.textDim() : fade(lerpColor(RenderUtil.TEXT, RenderUtil.accent(), t), intro);
		String text = getMessage().getString();

		if (text.startsWith("⚙")) {
			String remaining = text.replaceFirst("^⚙\\s*", "").trim();
			int iconW = 11;
			float remW = remaining.isEmpty() ? 0f : MsdfFontRenderer.getWidth(MsdfFonts.sfMedium(), remaining, 9.0f);
			float totalContentW = remaining.isEmpty() ? iconW : (iconW + 6f + remW);
			float startX = x + (w - totalContentW) / 2f;
			int iconY = y + (h - 11) / 2;

			drawGearIcon(ctx, (int) Math.round(startX), iconY, color, innerColor);

			if (!remaining.isEmpty()) {
				float textY = y + (h - 9.0f) / 2f - 0.5f;
				MsdfFontRenderer.drawWithShadow(ctx, MsdfFonts.sfMedium(), remaining,
						startX + iconW + 6f, textY, color, 9.0f);
			}
		} else {
			float textY = y + (h - 9.0f) / 2f - 0.5f;
			MsdfFontRenderer.drawCenteredWithShadow(ctx, MsdfFonts.sfMedium(), text,
					x + w / 2f, textY, color, 9.0f);
		}
	}

	/** Тёмный полупрозрачный фон кнопки (в тон плашкам меню). */
	private static final int BACKGROUND = 0x8A07070D;

	/** Тёмный вариант акцента для заливки наведённой кнопки (стеклянный). */
	private static int accentDark() {
		int acc = RenderUtil.accent();
		int ar = (acc >> 16) & 0xFF, ag = (acc >> 8) & 0xFF, ab = acc & 0xFF;
		return 0xA0000000 | ((int) (ar * 0.24f) << 16) | ((int) (ag * 0.24f) << 8) | (int) (ab * 0.24f);
	}

	/** Альфа-канал, масштабированный прогрессом анимации. */
	private static int alpha(int base, float t) {
		int a = (int) (base * t);
		return (a < 0 ? 0 : (a > 255 ? 255 : a)) << 24;
	}

	/** Линейная интерполяция двух ARGB-цветов. */
	private static int lerpColor(int a, int b, float t) {
		if (t <= 0f) return a;
		if (t >= 1f) return b;
		int aa = (a >> 24) & 0xFF, ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF;
		int ba = (b >> 24) & 0xFF, br = (b >> 16) & 0xFF, bg = (b >> 8) & 0xFF, bb = b & 0xFF;
		return ((int) (aa + (ba - aa) * t) << 24)
				| ((int) (ar + (br - ar) * t) << 16)
				| ((int) (ag + (bg - ag) * t) << 8)
				| (int) (ab + (bb - ab) * t);
	}

	/** Масштабирует альфа-канал цвета (для плавного появления). */
	private static int fade(int color, float m) {
		if (m >= 1f) return color;
		int a = (int) (((color >> 24) & 0xFF) * m);
		if (a < 0) a = 0;
		if (a > 255) a = 255;
		return (a << 24) | (color & 0x00FFFFFF);
	}

	/**
	 * Чёткая 8-зубчатая шестерёнка 11×11 с центральным отверстием.
	 * Цвет отверстия = заливке кнопки, чтобы зуб не «плавал».
	 */
	private void drawGearIcon(DrawContext ctx, int x, int y, int color, int holeColor) {
		ctx.fill(x + 3, y + 2, x + 8, y + 9, color);
		ctx.fill(x + 2, y + 3, x + 9, y + 8, color);

		ctx.fill(x + 4, y + 0, x + 7, y + 2, color);
		ctx.fill(x + 4, y + 9, x + 7, y + 11, color);
		ctx.fill(x + 0, y + 4, x + 2, y + 7, color);
		ctx.fill(x + 9, y + 4, x + 11, y + 7, color);

		ctx.fill(x + 1, y + 1, x + 3, y + 3, color);
		ctx.fill(x + 8, y + 1, x + 10, y + 3, color);
		ctx.fill(x + 1, y + 8, x + 3, y + 10, color);
		ctx.fill(x + 8, y + 8, x + 10, y + 10, color);

		ctx.fill(x + 4, y + 4, x + 7, y + 7, holeColor);
	}

	@Override
	public void onClick(Click click, boolean doubled) {
		NeuSounds.play(NeuSounds.TAB);
		this.onPress.onPress(this);
	}

	@Override
	protected void appendClickableNarrations(NarrationMessageBuilder builder) {
		builder.put(NarrationPart.TITLE, getMessage());
	}
}
