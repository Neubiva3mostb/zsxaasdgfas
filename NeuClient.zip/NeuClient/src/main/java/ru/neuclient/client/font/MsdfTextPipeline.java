package ru.neuclient.client.font;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;

/**
 * Кастомный RenderPipeline для MSDF-текста в GUI.
 *
 * Использует шейдеры из assets/neuclient/shaders/core/text/msdf_text.vsh/.fsh,
 * которые декодируют multi-channel signed distance field через median(R,G,B).
 * Формат вершин: POSITION_TEXTURE_COLOR.
 */
public final class MsdfTextPipeline {

	public static final RenderPipeline PIPELINE = RenderPipelines.register(
			RenderPipeline.builder()
					.withLocation(Identifier.of("perfstream", "pipeline/msdf_text"))
					.withVertexShader(Identifier.of("perfstream", "core/text/msdf_text"))
					.withFragmentShader(Identifier.of("perfstream", "core/text/msdf_text"))
					.withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR, VertexFormat.DrawMode.QUADS)
					.withSampler("Sampler0")
					.withUniform("DynamicTransforms", UniformType.UNIFORM_BUFFER)
					.withUniform("Projection", UniformType.UNIFORM_BUFFER)
					.withBlend(BlendFunction.TRANSLUCENT)
					.withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
					.withCull(false)
					.withColorWrite(true, true)
					.build()
	);

	/** Явная инициализация pipeline. */
	public static void touch() {
	}

	private MsdfTextPipeline() {
	}
}
