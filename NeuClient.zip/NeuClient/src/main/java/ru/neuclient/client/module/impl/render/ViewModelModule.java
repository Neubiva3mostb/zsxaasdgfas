package ru.neuclient.client.module.impl.render;

import net.minecraft.util.Hand;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.NumberSetting;

/**
 * ViewModel — кастомное положение предметов в руках от первого лица:
 * смещение по экрану (X/Y), по глубине (Z — ближе к камере / дальше)
 * и наклон. Для КАЖДОЙ руки свои отдельные настройки. Чистая косметика
 * (только матрицы рендера руки), на сервер никак не влияет.
 *
 * «Основная» — рука, выбранная в настройках игры как основная,
 * «Вторая» — оффхенд (щит/тотем/карта).
 */
public class ViewModelModule extends Module {

	/** Основная рука: смещение вправо/влево (доли пространства камеры). */
	private final NumberSetting mainX = new NumberSetting("Основная X", 0.0, -0.6, 0.6, 0.02);
	/** Основная рука: смещение вверх/вниз. */
	private final NumberSetting mainY = new NumberSetting("Основная Y", 0.0, -0.6, 0.6, 0.02);
	/** Основная рука: смещение по глубине (+ — ближе к камере, − — дальше/меньше). */
	private final NumberSetting mainZ = new NumberSetting("Основная Z", 0.0, -0.6, 0.6, 0.02);
	/** Основная рука: наклон в плоскости экрана (градусы, + — по часовой). */
	private final NumberSetting mainTilt = new NumberSetting("Основная наклон", 0, -45, 45, 1);

	/** Вторая рука (оффхенд). */
	private final NumberSetting offX = new NumberSetting("Вторая X", 0.0, -0.6, 0.6, 0.02);
	private final NumberSetting offY = new NumberSetting("Вторая Y", 0.0, -0.6, 0.6, 0.02);
	private final NumberSetting offZ = new NumberSetting("Вторая Z", 0.0, -0.6, 0.6, 0.02);
	private final NumberSetting offTilt = new NumberSetting("Вторая наклон", 0, -45, 45, 1);

	public ViewModelModule() {
		super("ViewModel", "Кастомные руки",
				Category.RENDER);
		addSettings(mainX, mainY, mainZ, mainTilt, offX, offY, offZ, offTilt);
	}

	/** Настройка по руке: всё, что не OFF_HAND, считаем основной. */
	private static NumberSetting pick(Hand hand, NumberSetting main, NumberSetting off) {
		return hand == Hand.OFF_HAND ? off : main;
	}

	public float getOffsetX(Hand hand) {
		return pick(hand, mainX, offX).get().floatValue();
	}

	public float getOffsetY(Hand hand) {
		return pick(hand, mainY, offY).get().floatValue();
	}

	public float getOffsetZ(Hand hand) {
		return pick(hand, mainZ, offZ).get().floatValue();
	}

	public float getTiltZ(Hand hand) {
		return pick(hand, mainTilt, offTilt).get().floatValue();
	}

	/** Активный экземпляр для миксина (null — модуль выключен). */
	public static ViewModelModule activeModule() {
		NeuClient c = NeuClient.getInstance();
		if (c == null || c.getModuleManager() == null) {
			return null;
		}
		ViewModelModule m = c.getModuleManager().get(ViewModelModule.class);
		return m != null && m.isEnabled() ? m : null;
	}
}
