package ru.neuclient.client.module.impl.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.entity.EntityType;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.render.ChamsRenderLayer;

/**
 * Chams — стеклянный силуэт сущностей сквозь стены.
 *
 * Работает на игроках и мобах. Себя не подсвечивает: в F5 свой силуэт
 * только мешал бы. Стойки для брони не трогаем — на BedWars-серверах из них
 * делают декор и таймеры, и подсветка превращалась бы в шум.
 *
 * Настроек нет намеренно.
 *
 * КАК РАБОТАЕТ. В LivingEntityRendererMixin подменяется слой, который
 * возвращает getRenderLayer, — на слой из ChamsRenderLayer с выключенным
 * тестом глубины. Ваниль сама рисует модель со всеми трансформациями,
 * а шейдер core/chams.fsh превращает её в стекло: светящаяся кромка
 * по силуэту и полупрозрачная сердцевина — тот же приём, что у Hands.
 *
 * Всё чисто клиентское: ни один пакет не меняется.
 */
public final class ChamsModule extends Module {

	/** Базовая прозрачность сердцевины; кромка в шейдере плотнее. */
	private static final float ALPHA = 0.85f;

	public ChamsModule() {
		super("Chams", "Стеклянные силуэты сквозь стены", Category.RENDER);
	}

	/** Активный модуль или null. */
	public static ChamsModule active() {
		NeuClient client = NeuClient.getInstance();
		if (client == null || client.getModuleManager() == null) {
			return null;
		}
		ChamsModule self = client.getModuleManager().get(ChamsModule.class);
		return self != null && self.isEnabled() ? self : null;
	}

	/**
	 * Нужно ли подсвечивать эту сущность.
	 *
	 * Слой запрашивается у живых сущностей (LivingEntityRenderer), поэтому
	 * предметы сюда не попадают в принципе.
	 */
	public boolean shouldCham(EntityRenderState state) {
		if (state == null || state.entityType == null) {
			return false;
		}

		if (state instanceof PlayerEntityRenderState playerState) {
			// Себя не подсвечиваем: id локального игрока совпадает
			MinecraftClient mc = MinecraftClient.getInstance();
			if (mc.player != null && playerState.id == mc.player.getId()) {
				return false;
			}
			return true;
		}

		// Стойка для брони — живая сущность, но не моб: это декор и таймеры
		if (state.entityType == EntityType.ARMOR_STAND) {
			return false;
		}

		// Всё остальное живое — мобы
		return true;
	}

	/** Слой подсветки. */
	public net.minecraft.client.render.RenderLayer layer() {
		return ChamsRenderLayer.get(ALPHA);
	}
}
