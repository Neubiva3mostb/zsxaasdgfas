package ru.neuclient.client.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.text.MutableText;
import net.minecraft.text.PlainTextContent;
import net.minecraft.text.Text;
import net.minecraft.text.TextContent;
import net.minecraft.text.TranslatableTextContent;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.impl.render.NameProtectModule;

import java.util.ArrayList;
import java.util.List;

/**
 * NameProtect — подмена собственного ника ТОЛЬКО на твоём экране.
 * Сеть, сервер и логи не затрагиваются: для сервера твой ник прежний,
 * меняется только то, что РЕНДЕРИТСЯ у тебя (чат и килл-фид, таб-лист,
 * над головой от третьего лица). Для скринов и стримов.
 *
 * Подмена идёт рекурсивным обходом дерева компонента текста: литерал
 * подстроки, аргументы переводных нод (в них приезжают ники в сообщениях
 * смертей и килл-фида), сиблинги с сохранением стилей.
 */
public final class NameProtectUtil {

	private NameProtectUtil() {
	}

	/** true — модуль включён и доступен менеджер модулей. */
	public static boolean active() {
		NameProtectModule m = module();
		return m != null && m.isEnabled();
	}

	/** Настоящий ник игрока сессии (пустая строка, если вдруг недоступен). */
	public static String realName() {
		try {
			MinecraftClient mc = MinecraftClient.getInstance();
			return mc != null && mc.getSession() != null ? mc.getSession().getUsername() : "";
		} catch (Throwable t) {
			return "";
		}
	}

	/** Отображаемый ник из настройки модуля. */
	public static String fakeName() {
		NameProtectModule m = module();
		return m != null ? m.getFakeName() : "NeuClient";
	}

	private static NameProtectModule module() {
		NeuClient c = NeuClient.getInstance();
		return c == null || c.getModuleManager() == null ? null : c.getModuleManager().get(NameProtectModule.class);
	}

	/** Подмена в компоненте текста, если модуль активен (иначе — как было). */
	public static Text transformIfActive(Text text) {
		if (text == null || !active()) {
			return text;
		}
		String real = realName();
		if (real.isEmpty()) {
			return text;
		}
		return transform(text, real, fakeName());
	}

	// ===== Рекурсивный обход дерева компонента =====

	private static Text transform(Text text, String real, String fake) {
		if (text == null) {
			return null;
		}
		MutableText rebuilt = null;
		TextContent content = text.getContent();

		// 1. Литерал: прямая замена подстроки
		if (content instanceof PlainTextContent.Literal literal && literal.string().contains(real)) {
			rebuilt = Text.literal(literal.string().replace(real, fake));
		}
		// 2. Переводная нода (смерти, килл-фид, системные): ник внутри аргументов
		else if (content instanceof TranslatableTextContent translatable) {
			Object[] args = translatable.getArgs();
			Object[] newArgs = null;
			for (int i = 0; i < args.length; i++) {
				Object arg = args[i];
				Object replaced = null;
				if (arg instanceof String s && s.contains(real)) {
					replaced = s.replace(real, fake);
				} else if (arg instanceof Text t) {
					Text nt = transform(t, real, fake);
					if (nt != t) {
						replaced = nt;
					}
				}
				if (replaced != null) {
					if (newArgs == null) {
						newArgs = args.clone();
					}
					newArgs[i] = replaced;
				}
			}
			if (newArgs != null) {
				rebuilt = Text.translatable(translatable.getKey(), newArgs);
			}
		}

		// 3. Сиблинги: обходим рекурсивно; пересобираем ноду, если что-то поменялось
		List<Text> siblings = text.getSiblings();
		List<Text> newSiblings = new ArrayList<>(siblings.size());
		boolean siblingsChanged = false;
		for (Text sibling : siblings) {
			Text ns = transform(sibling, real, fake);
			newSiblings.add(ns);
			if (ns != sibling) {
				siblingsChanged = true;
			}
		}

		if (rebuilt != null || siblingsChanged) {
			if (rebuilt == null) {
				rebuilt = MutableText.of(content);
			}
			for (Text ns : newSiblings) {
				rebuilt.append(ns);
			}
			rebuilt.setStyle(text.getStyle());
			return rebuilt;
		}
		return text;
	}
}
