package ru.neuclient.client.module.impl.misc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.world.GameMode;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.util.InventoryUtil;
import ru.neuclient.client.util.SwapUtil;

/**
 * MiddleClickPearl — мгновенный бросок жемчуга средней кнопкой мыши,
 * полностью легитными игровыми действиями (как в Nursultan).
 *
 * Старт клика — из MouseMixin (сырой перехват): ваниль сама дренит очередь
 * нажатий pickItemKey до наших тиков, опросами клавиши среднюю кнопку не
 * поймать. Режим игры проверяем через interactionManager.getCurrentGameMode()
 * — player.isCreative()/isSpectator() у клиентского игрока берутся из
 * PlayerListEntry и на серверах могут врать.
 *
 * Приоритет источника жемчуга:
 *  1. уже в выбранной руке → сразу бросок;
 *  2. другая ячейка хотбара → переключаем слот (с мгновенной синкой серверу);
 *  3. вторая рука → бросаем левой;
 *  4. основной инвентарь → легитный свап клавишей-цифрой в текущий слот.
 *
 * После броска всё ВОЗВРАЩАЕТСЯ: выбранный слот обратно, а если жемчуг
 * доставали из инвентаря — обратный свап кладёт предметы на свои места.
 * Шаги идут с паузой в тик (выбор/свап → бросок → возврат), чтобы пакеты
 * выглядели как у живого игрока и не беспокоить античит.
 *
 * В креативе и при открытых экранах не вмешиваемся: там средняя кнопка —
 * ванильный pick block.
 */
public class MiddleClickPearlModule extends Module {

	/** Пауза перед свапом жемчуга ИЗ ИНВЕНТАРЯ (правило всех свапперов), мс. */
	/**
	 * Пауза перед свапом из глубокого инвентаря.
	 *
	 * Была настройкой «Задержка». Убрана по той же причине, что и в
	 * остальных свапперах: пауза не останавливала игрока, а сервер
	 * отклоняет инвентарь на ходу. Движение гасит SwapPause — ровно на
	 * один пакет вокруг клика.
	 */
	private static final long SWAP_PAUSE_MS = 250L;

	/** 0 = ждём клика, 1 = бросок, 2 = возврат, 3 = пауза перед свапом из инвентаря. */
	private int stage;
	/** Пауза в тиках между шагами. */
	private int delay;
	/** Слот хотбара, выбранный до макроса (для возврата). */
	private int prevSlot;
	/** Слот инвентаря, с которым делали свап (-1 = свапа не было). */
	private int invSlot = -1;
	/**
	 * Ячейка хотбара, куда клали жемчуг.
	 *
	 * Возврат обязан идти именно в неё. Раньше бралcя «текущий
	 * выбранный слот»: если игрок крутнул колесо, пока жемчуг летел,
	 * обратный SWAP уносил предмет в чужую ячейку.
	 */
	private int invHotbarSlot = -1;
	/** true = бросок идёт из второй руки (возвращать слот не нужно). */
	private boolean offhand;

	public MiddleClickPearlModule() {
		super("MiddleClickPearl", "Бросает перку на колесико мыши", Category.MISC);

	}

	/**
	 * Старт макроса из хука мыши (средняя кнопка, сырым событием).
	 * @return true — макрос запущен (клик потреблён, ваниль его не увидит).
	 */
	public boolean tryStart(MinecraftClient client) {
		if (stage != 0) {
			return true; // макрос уже идёт — повторные клики игнорируем и глушим
		}
		ClientPlayerEntity player = client.player;
		if (player == null || client.world == null || client.interactionManager == null) {
			return false;
		}
		// Только истинный креатив блокируем: там средняя кнопка — pick block
		if (client.interactionManager.getCurrentGameMode() == GameMode.CREATIVE) {
			return false;
		}
		if (!hasPearl(player)) {
			return false; // жемчуга нет — пусть клик пройдёт в ваниль (в выживании ничего не сделает)
		}
		start(client, player);
		return stage != 0;
	}

	/** Есть ли жемчуг где-либо: рука, хотбар, вторая рука, инвентарь. */
	private boolean hasPearl(ClientPlayerEntity player) {
		PlayerInventory inv = player.getInventory();
		return inv.getStack(inv.getSelectedSlot()).isOf(Items.ENDER_PEARL)
				|| InventoryUtil.findInHotbar(player, s -> s.isOf(Items.ENDER_PEARL)) >= 0
				|| player.getOffHandStack().isOf(Items.ENDER_PEARL)
				|| InventoryUtil.findInInventory(player, s -> s.isOf(Items.ENDER_PEARL)) >= 0;
	}

	@Override
	public void onTick(MinecraftClient client) {
		ClientPlayerEntity player = client.player;
		if (player == null || client.world == null || client.interactionManager == null) {
			reset();
			return;
		}
		if (stage == 0) {
			return; // старт — только из хука мыши, в тике лишь крутим стадии
		}

		// Смена слота и свап уходят на сервер отложенно — на тик позже
		// вызова, вместе с пакетом стоящего игрока (см. SwapPause).
		// Пока это не отработало, жемчуга в руке ещё нет, и бросок ушёл
		// бы предыдущим предметом. Этот барьер и заменяет прежние
		// ручные delay после selectSlot/swapToHotbar.
		if (ru.neuclient.client.util.SwapPause.isBusy()) {
			return;
		}

		if (delay > 0) {
			delay--;
			return;
		}

		switch (stage) {
			case 1 -> { // бросок
				Hand hand = offhand ? Hand.OFF_HAND : Hand.MAIN_HAND;
				client.interactionManager.interactItem(player, hand);
				player.swingHand(hand); // ванильная анимация замаха (+ пакет, как у игрока)
				stage = 2;
				delay = 1;
			}
			case 2 -> { // возврат
				restore(client, player);
				stage = 0;
			}
			default -> reset();
		}
	}

	/** Выбираем легитный путь до жемчуга и встаём на бросок. */
	private void start(MinecraftClient client, ClientPlayerEntity player) {
		PlayerInventory inv = player.getInventory();
		int current = inv.getSelectedSlot();
		prevSlot = current;
		invSlot = -1;
		invHotbarSlot = -1;
		offhand = false;

		// 1) жемчуг уже в выбранной руке — бросаем без подготовки
		if (inv.getStack(current).isOf(Items.ENDER_PEARL)) {
			stage = 1;
			delay = 0;
			return;
		}

		// 2) жемчуг в другой ячейке хотбара — переключаем слот (синкаем серверу)
		int hotbarPearl = InventoryUtil.findInHotbar(player, s -> s.isOf(Items.ENDER_PEARL));
		if (hotbarPearl >= 0) {
			InventoryUtil.selectSlot(player, hotbarPearl, client.interactionManager);
			stage = 1;
			delay = 0; // паузу выдерживает барьер SwapPause в onTick
			return;
		}

		// 3) жемчуг во второй руке — бросаем левой рукой
		if (player.getOffHandStack().isOf(Items.ENDER_PEARL)) {
			offhand = true;
			stage = 1;
			delay = 0;
			return;
		}

		// 4) жемчуг только в инвентаре — единый механизм клиента (SwapUtil):
		// три клика PICKUP прямо из мира, без открытия экрана;
		// остановку на один тик (50 мс) берёт сам SwapUtil
		int inventoryPearl = InventoryUtil.findInInventory(player, s -> s.isOf(Items.ENDER_PEARL));
		if (inventoryPearl >= 0
				&& SwapUtil.swapToHotbar(client, player, inventoryPearl, current)) {
			invSlot = inventoryPearl;   // обратный свап вернёт всё на место
			invHotbarSlot = current;
			stage = 1;
			delay = 0; // паузу выдерживает барьер SwapPause в onTick
		}
	}

	/**
	 * Возвращаем всё как было: предметы на места, слот обратно.
	 * Зовётся сразу после броска — жемчуг отработал.
	 */
	private void restore(MinecraftClient client, ClientPlayerEntity player) {
		PlayerInventory inv = player.getInventory();
		if (invSlot >= 0 && invHotbarSlot >= 0) {
			// Обратный свап тем же механизмом и в ТУ ЖЕ ячейку хотбара:
			// остаток жемчуга уезжает в инвентарь, вытесненный предмет
			// возвращается в хотбар.
			SwapUtil.restoreSwap(client, player, invSlot, invHotbarSlot);
			invSlot = -1;
			invHotbarSlot = -1;
			// После обмена возвращаем и выбранную ячейку.
			if (inv.getSelectedSlot() != prevSlot) {
				InventoryUtil.selectSlot(player, prevSlot, client.interactionManager);
			}
		} else if (!offhand && inv.getSelectedSlot() != prevSlot) {
			InventoryUtil.selectSlot(player, prevSlot, client.interactionManager);
		}
		offhand = false;
	}


	private void reset() {
		stage = 0;
		delay = 0;
		invSlot = -1;
		invHotbarSlot = -1;
		offhand = false;
	}

	@Override
	protected void onDisable() {
		reset();
	}
}
