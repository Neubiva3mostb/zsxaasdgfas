package ru.neuclient.client.mixin;

import net.minecraft.client.gui.hud.PlayerListHud;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.neuclient.client.util.NameProtectUtil;

/**
 * NameProtect: подмена СОБСТВЕННОГО ника в таб-листе.
 * Трогаем только свою строку (совпадение по имени профиля GameProfile),
 * форматирование префиксов/команды сохраняется — меняется сам ник внутри.
 */
@Mixin(PlayerListHud.class)
public abstract class PlayerListHudMixin {

	@Inject(method = "getPlayerName(Lnet/minecraft/client/network/PlayerListEntry;)Lnet/minecraft/text/Text;",
			at = @At("RETURN"), cancellable = true)
	private void pc$nameProtectTab(PlayerListEntry entry, CallbackInfoReturnable<Text> cir) {
		if (!NameProtectUtil.active() || entry == null || entry.getProfile() == null) {
			return;
		}
		// Только СВОЯ строка таба, чужие ники не трогаем
		if (!NameProtectUtil.realName().equals(entry.getProfile().name())) {
			return;
		}
		cir.setReturnValue(NameProtectUtil.transformIfActive(cir.getReturnValue()));
	}
}
