package ru.neuclient.client.util;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import ru.neuclient.client.NeuClient;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;

/**
 * MediaBridge — «что сейчас играет» с системного уровня Windows (SMTC)
 * + управление (пауза/назад/вперёд) через виртуальные медиа-клавиши.
 *
 * Видит Spotify, Яндекс Музыку (десктоп и веб), VK, YouTube — любой плеер,
 * который регистрирует трек в системных медиа-контролах.
 *
 * Чтение: скрытый PowerShell (WinRT, только PS 5.1) раз в 2 секунды пишет
 * строку JSON в stdout:
 * {"title":"...","artist":"...","status":"Playing","pos":"12345","dur":"200000"}
 * pos/dur — сырые значения таймлайна строкой; интерполяция позиции — на
 * Java-стороне (ограничена интервалом опроса, runaway невозможен).
 *
 * Управление: sendCommand() жмёт виртуальные медиа-клавиши (keybd_event),
 * их понимают все SMTC-плееры.
 *
 * Диагностика: PowerShell пишет %TEMP%\neuclient_media.log.
 */
public final class MediaBridge {

	private static volatile MediaBridge instance;

	/** Снимок состояния медиа-плеера. */
	public static final class State {
		public final String title;
		public final String artist;
		public final boolean playing;
		/** Сглаженная позиция (мс), монотонная между апдейтами. */
		public final long posMs;
		/** Длительность из таймлайна SMTC (мс), 0 если плеер не отдаёт. */
		public final long durMs;

		State(String title, String artist, boolean playing, long posMs, long durMs) {
			this.title = title;
			this.artist = artist;
			this.playing = playing;
			this.posMs = posMs;
			this.durMs = durMs;
		}
	}

	// ===== Сглаживание позиции (скоростной фильтр) =====
	/** Отображаемая (сглаженная) позиция, мс. */
	private long smoothPosMs;
	/** Время последнего обновления сглаженной позиции. */
	private long smoothUpdatedAt;
	/** Ключ текущего трека (для сброса фильтра). */
	private String smoothTrackKey = "";
	/** Последний СЫРОЙ pos от плеера и время его получения. */
	private long lastRawPos = Long.MIN_VALUE;
	private long lastRawAt;

	private volatile State state = null;
	private volatile Process process;
	private volatile long lastSpawnAttempt;
	private volatile long lastCommandMs;
	private volatile boolean started;

	private MediaBridge() {
	}

	public static MediaBridge get() {
		if (instance == null) {
			synchronized (MediaBridge.class) {
				if (instance == null) {
					instance = new MediaBridge();
				}
			}
		}
		return instance;
	}

	private static boolean isWindows() {
		return System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win");
	}

	/** Ленивый запуск: вызывается из модуля/элемента. */
	public void ensureStarted() {
		if (started || !isWindows()) {
			return;
		}
		started = true;
		spawn();
	}

	/** Перезапуск при падении PowerShell (не чаще раза в 10 секунд). */
	public void tickKeepAlive() {
		if (!started || !isWindows()) {
			return;
		}
		Process p = process;
		if ((p == null || !p.isAlive()) && System.currentTimeMillis() - lastSpawnAttempt > 10_000L) {
			spawn();
		}
	}

	private void spawn() {
		lastSpawnAttempt = System.currentTimeMillis();
		try {
			Path script = Path.of(System.getProperty("java.io.tmpdir", "."), "neuclient_media.ps1");
			Files.writeString(script, buildScript(), StandardCharsets.UTF_8);
			ProcessBuilder pb = new ProcessBuilder(
					"powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
					"-WindowStyle", "Hidden", "-File", script.toString());
			pb.redirectErrorStream(false);
			Process p = pb.start();
			process = p;

			Thread reader = new Thread(() -> readLoop(p), "NeuClient-MediaBridge");
			reader.setDaemon(true);
			reader.start();
		} catch (Throwable ignored) {
		}
	}

	/**
	 * Управление плеером: "playpause", "next", "prev".
	 * Жмёт системные медиа-клавиши (работает для всех SMTC-плееров).
	 */
	public void sendCommand(String action) {
		if (!isWindows()) {
			return;
		}
		long now = System.currentTimeMillis();
		if (now - lastCommandMs < 350L) {
			return;
		}
		lastCommandMs = now;
		try {
			Path script = Path.of(System.getProperty("java.io.tmpdir", "."), "neuclient_mediakeys.ps1");
			Files.writeString(script, buildKeysScript(), StandardCharsets.UTF_8);
			new ProcessBuilder("powershell.exe", "-NoProfile", "-NonInteractive",
							"-ExecutionPolicy", "Bypass", "-WindowStyle", "Hidden",
							"-File", script.toString(), "-Action", action)
					.redirectErrorStream(true).redirectOutput(ProcessBuilder.Redirect.DISCARD).start();
		} catch (Throwable ignored) {
		}
	}

	private void readLoop(Process p) {
		try (BufferedReader r = new BufferedReader(
				new InputStreamReader(p.getInputStream(), StandardCharsets.UTF_8))) {
			String line;
			while ((line = r.readLine()) != null) {
				line = line.trim();
				if (line.startsWith("{") && line.endsWith("}")) {
					apply(line);
				}
			}
		} catch (Throwable ignored) {
		}
	}

	private void apply(String json) {
		try {
			JsonObject o = JsonParser.parseString(json).getAsJsonObject();
			String title = opt(o, "title");
			String artist = opt(o, "artist");
			String status = opt(o, "status");
			long rawPos = Math.max(0L, ol(o, "pos"));
			long dur = Math.max(0L, ol(o, "dur"));
			if (title == null || title.isBlank()) {
				return;
			}
			boolean playing = "Playing".equalsIgnoreCase(status);

			long now = System.currentTimeMillis();
			String trackKey = title + "|" + (artist == null ? "" : artist);

			// ===== Скоростной фильтр позиции =====
			// Плееры ведут себя по-разному: Spotify-веб шлёт честный pos,
			// но иногда мусорный ноль; десктопная ЯМ — почти всегда ноль;
			// некоторые шлют ЗАСТЫВШИЙ снапшот. Смотрим на СКОРОСТЬ изменения
			// raw (dPos за dT между опросами) и решаем, верить ли плееру:
			//   течёт (dPos ≈ dT)  → мягко подтягиваемся к raw;
			//   стоит/мусор        → игнорируем raw, тикаем сами;
			//   скачок (сик)       → принимаем raw сразу.
			if (!trackKey.equals(smoothTrackKey)) {
				// Новый трек: база — что сказал плеер (обычно 0 или честный старт).
				smoothTrackKey = trackKey;
				smoothPosMs = rawPos;
				smoothUpdatedAt = now;
				lastRawPos = rawPos;
				lastRawAt = now;
			} else {
				// 1) Самотик: позиция ползёт сама, пока играет.
				long dt = now - smoothUpdatedAt;
				if (dt < 0L) dt = 0L;
				if (dt > 5000L) dt = 5000L; // лаг/сворачивание — не доматываем далеко
				if (playing) {
					smoothPosMs += dt;
				}
				smoothUpdatedAt = now;

				// 2) Фильтр мусора: почти-ноль посреди трека — не верим.
				boolean garbage = rawPos <= 1500L
						&& smoothPosMs > 5000L
						&& (dur <= 0L || dur - smoothPosMs > 10_000L);

				if (!garbage && lastRawAt != 0L) {
					long dPos = rawPos - lastRawPos;
					long dT = now - lastRawAt;
					if (dT > 0L) {
						if (Math.abs(dPos) >= 3000L && (dPos > 0 || !playing || smoothPosMs < 4000L)) {
							// Сик (обычно вперёд): принимаем сразу.
							smoothPosMs = rawPos;
						} else if (Math.abs(dPos - dT) <= 1200L) {
							// Плеер течёт со скоростью времени: мягкая подтяжка
							// (не скачок — до 1 c за опрос, половинный шаг).
							long target = rawPos + (playing ? (now - lastRawAt) : 0L);
							long correction = target - smoothPosMs;
							if (correction > 1000L) correction = 1000L;
							if (correction < -1000L) correction = -1000L;
							smoothPosMs += correction / 2;
						}
						// Иначе (dPos ≈ 0 — застывший снапшот или нули): тикаем сами.
					}
				}
				lastRawPos = rawPos;
				lastRawAt = now;
			}

			if (smoothPosMs < 0L) {
				smoothPosMs = 0L;
			}
			if (dur > 0L && smoothPosMs > dur) {
				smoothPosMs = dur;
			}

			state = new State(title, artist, playing, smoothPosMs, dur);
		} catch (Throwable ignored) {
		}
	}

	private static String opt(JsonObject o, String key) {
		try {
			return o.has(key) && !o.get(key).isJsonNull() ? o.get(key).getAsString() : null;
		} catch (Throwable t) {
			return null;
		}
	}

	private static long ol(JsonObject o, String key) {
		try {
			if (!o.has(key) || o.get(key).isJsonNull()) {
				return 0L;
			}
			return Long.parseLong(o.get(key).getAsString().trim());
		} catch (Throwable ignoredParsingAsString) {
			try {
				return (long) o.get(key).getAsDouble();
			} catch (Throwable t) {
				return 0L;
			}
		}
	}

	/** Текущий снимок (может быть null — медиа ещё не замечено). */
	public State state() {
		return state;
	}

	/**
	 * PowerShell-скрипт моста. Работает ТОЛЬКО в Windows PowerShell 5.1
	 * (powershell.exe) — в pwsh 7 нет WinRT-проекции.
	 */
	private static String buildScript() {
		StringBuilder s = new StringBuilder();
		s.append("$ErrorActionPreference='SilentlyContinue'\n");
		s.append("try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}\n");
		// Проецируем WinRT и учимся ждать IAsyncOperation/IAsyncAction.
		s.append("Add-Type -AssemblyName System.Runtime.WindowsRuntime\n");
		s.append("$asOps = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]\n");
		s.append("function AwaitOp($op, $t) { $m = $asOps.MakeGenericMethod($t); $task = $m.Invoke($null, @($op)); $task.Wait(-1) | Out-Null; $task.Result }\n");
		// SMTC-менеджер + лог.
		s.append("[Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager,Windows.Media.Control,ContentType=WindowsRuntime] | Out-Null\n");
		s.append("$logPath = Join-Path $env:TEMP 'neuclient_media.log'\n");
		s.append("try { if ((Get-Item $logPath -ErrorAction SilentlyContinue).Length -gt 262144) { Remove-Item $logPath -Force } } catch {}\n");
		s.append("function MLog($m) { try { (\"$(Get-Date -Format HH:mm:ss) $m\") | Out-File $logPath -Append -Encoding UTF8 } catch {} }\n");
		s.append("try { $script:mgr = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]::RequestAsync(); } catch { MLog \"manager ERR: $($_.Exception.Message)\" }\n");
		s.append("$mgr = AwaitOp ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]::RequestAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager])\n");
		s.append("$lastTrack = ''\n");
		// Основной цикл.
		s.append("while ($true) {\n");
		s.append("  try {\n");
		s.append("    $best = $null\n");
		s.append("    foreach ($ses in $mgr.GetSessions()) { if ($ses.SourceAppUserModelId -match 'Spotify|Yandex') { $best = $ses; break } }\n");
		s.append("    if (-not $best) { foreach ($ses in $mgr.GetSessions()) { if ($ses.SourceAppUserModelId -notmatch 'Microsoft\\.Windows|SystemTray|immersive|Shell') { $best = $ses; break } } }\n");
		s.append("    if ($best) {\n");
		s.append("      $props = AwaitOp ($best.TryGetMediaPropertiesAsync()) ([Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties])\n");
		s.append("      if ($props -and $props.Title) {\n");
		s.append("        $status = '' + $best.GetPlaybackInfo().PlaybackStatus\n");
		// Таймлайн в ОТДЕЛЬНОМ try: у части плееров он отсутствует.
		// Отдаём СЫРЫЕ значения строкой, без всякой интерполяции.
		s.append("        $pos = '0'\n");
		s.append("        $dur = '0'\n");
		s.append("        try {\n");
		s.append("          $tl = $best.GetTimelineProperties()\n");
		s.append("          $pos = [string][long]$tl.Position.TotalMilliseconds\n");
		s.append("          $dur = [string][long]$tl.EndTime.TotalMilliseconds\n");
		s.append("        } catch {\n");
		s.append("          MLog \"timeline ERR: $($_.Exception.Message)\"\n");
		s.append("        }\n");
		s.append("        $track = ('' + $props.Title) + '|' + ('' + $props.Artist)\n");
		s.append("        if ($track -ne $lastTrack) { MLog \"track: $track status=$status pos=$pos dur=$dur src=$($best.SourceAppUserModelId)\" }\n");
		s.append("        $lastTrack = $track\n");
		s.append("        $o = @{ title = [string]$props.Title; artist = [string]$props.Artist; status = $status; pos = $pos; dur = $dur }\n");
		s.append("        [Console]::Out.WriteLine(($o | ConvertTo-Json -Compress))\n");
		s.append("        [Console]::Out.Flush()\n");
		s.append("      }\n");
		s.append("    }\n");
		s.append("  } catch {}\n");
		s.append("  Start-Sleep -Milliseconds 2000\n");
		s.append("}\n");
		return s.toString();
	}

	/**
	 * Скрипт нажатия системных медиа-клавиш.
	 * Обязательно со скан-кодом (MapVirtualKey) и KEYEVENTF_EXTENDEDKEY:
	 * без этого часть программ принимает медиа-клавишу за соседнюю обычную
	 * (например, next 0xB0 без extended-бита выглядела как Tab и открывала
	 * внутриигровое «социальное меню»).
	 */
	private static String buildKeysScript() {
		StringBuilder s = new StringBuilder();
		s.append("param([string]$Action = 'playpause')\n");
		s.append("$ErrorActionPreference = 'SilentlyContinue'\n");
		s.append("Add-Type -Namespace NC -Name MK -MemberDefinition '\n");
		s.append("[DllImport(\"user32.dll\")] public static extern void keybd_event(byte vk, byte scan, uint flags, UIntPtr extra);\n");
		s.append("[DllImport(\"user32.dll\")] public static extern uint MapVirtualKey(uint code, uint map);\n");
		s.append("' -ErrorAction SilentlyContinue\n");
		s.append("$vk = [byte]0xB3\n");           // VK_MEDIA_PLAY_PAUSE
		s.append("if ($Action -eq 'next') { $vk = [byte]0xB0 }\n");  // VK_MEDIA_NEXT_TRACK
		s.append("if ($Action -eq 'prev') { $vk = [byte]0xB1 }\n");  // VK_MEDIA_PREV_TRACK
		s.append("$scan = [byte]([NC.MK]::MapVirtualKey([uint32]$vk, 0) -band 0xFF)\n");
		s.append("$EXT = [uint32]1\n");           // KEYEVENTF_EXTENDEDKEY
		s.append("$UP  = [uint32]3\n");           // EXTENDEDKEY | KEYEVENTF_KEYUP
		s.append("[NC.MK]::keybd_event($vk, $scan, $EXT, [UIntPtr]::Zero)\n");
		s.append("Start-Sleep -Milliseconds 40\n");
		s.append("[NC.MK]::keybd_event($vk, $scan, $UP, [UIntPtr]::Zero)\n");
		return s.toString();
	}
}
