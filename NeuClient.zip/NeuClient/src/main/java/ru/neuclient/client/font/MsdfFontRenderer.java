package ru.neuclient.client.font;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.ScreenRect;
import org.joml.Matrix3x2f;

/**
 * Высокопроизводительная отрисовка строк MSDF-шрифтом в GUI.
 *
 * Каждая строка отправляется единым элементом {@link MsdfTextGuiElementRenderState}
 * в конвейер {@link DrawContext#state}. Это даёт:
 *  - 0 аллокаций на глиф (1 элемент на строку вместо сотен);
 *  - субпиксельные float-координаты для идеального рендеринга без дрожания букв;
 *  - полное сохранение порядка отрисовки со scissor-обрезкой и альфа-анимациями.
 */
public final class MsdfFontRenderer {

	public static final float DEFAULT_SIZE = 11.0f;

	public static final int[] COLOR_CODES = new int[16];
	static {
		for (int i = 0; i < 16; i++) {
			int base = (i >> 3 & 1) * 85;
			int r = (i >> 2 & 1) * 170 + base;
			int g = (i >> 1 & 1) * 170 + base;
			int b = (i & 1) * 170 + base;
			if (i == 6) r += 85;
			COLOR_CODES[i] = (r << 16) | (g << 8) | b;
		}
	}

	private MsdfFontRenderer() {
	}

	// ===== Метрики =====

	public static float getWidth(MsdfFont font, String text) {
		return getWidth(font, text, DEFAULT_SIZE);
	}

	public static float getWidth(MsdfFont font, String text, float size) {
		if (font == null || text == null || text.isEmpty()) {
			return 0f;
		}
		float pen = 0f;
		int prev = -1;
		for (int i = 0; i < text.length(); i++) {
			char c = text.charAt(i);
			if (c == '§' && i + 1 < text.length()) {
				i++;
				continue;
			}
			int cp = text.codePointAt(i);
			if (Character.isSupplementaryCodePoint(cp)) i++;
			if (prev >= 0) {
				pen += font.kerning(prev, cp) * size;
			}
			MsdfFont.Glyph g = font.glyph(cp);
			if (g != null) {
				pen += g.advance * size;
			}
			prev = cp;
		}
		return pen;
	}

	public static float getHeight(MsdfFont font, float size) {
		return font == null ? size : font.lineHeight() * size;
	}

	public static float getHeight(MsdfFont font) {
		return getHeight(font, DEFAULT_SIZE);
	}

	// ===== Отрисовка =====

	public static float draw(DrawContext ctx, MsdfFont font, String text,
							 float x, float y, int color) {
		return draw(ctx, font, text, x, y, color, DEFAULT_SIZE, false);
	}

	public static float drawWithShadow(DrawContext ctx, MsdfFont font, String text,
									   float x, float y, int color) {
		return draw(ctx, font, text, x, y, color, DEFAULT_SIZE, true);
	}

	public static float draw(DrawContext ctx, MsdfFont font, String text,
							 float x, float y, int color, float size) {
		return draw(ctx, font, text, x, y, color, size, false);
	}

	public static float drawWithShadow(DrawContext ctx, MsdfFont font, String text,
									   float x, float y, int color, float size) {
		return draw(ctx, font, text, x, y, color, size, true);
	}

	public static float drawCentered(DrawContext ctx, MsdfFont font, String text,
									 float centerX, float y, int color, float size) {
		float w = getWidth(font, text, size);
		return draw(ctx, font, text, centerX - w / 2f, y, color, size, false);
	}

	public static float drawCentered(DrawContext ctx, MsdfFont font, String text,
									 float centerX, float y, int color) {
		return drawCentered(ctx, font, text, centerX, y, color, DEFAULT_SIZE);
	}

	public static float drawCenteredWithShadow(DrawContext ctx, MsdfFont font, String text,
											   float centerX, float y, int color, float size) {
		float w = getWidth(font, text, size);
		return draw(ctx, font, text, centerX - w / 2f, y, color, size, true);
	}

	public static float drawCenteredWithShadow(DrawContext ctx, MsdfFont font, String text,
											   float centerX, float y, int color) {
		return drawCenteredWithShadow(ctx, font, text, centerX, y, color, DEFAULT_SIZE);
	}

	public static float draw(DrawContext ctx, MsdfFont font, String text,
							 float x, float y, int argb, float size, boolean shadow) {
		if (font == null || text == null || text.isEmpty()) {
			return x;
		}
		int a = (argb >>> 24);
		if (a == 0) {
			return x + getWidth(font, text, size);
		}

		int shadowColor = 0;
		if (shadow) {
			int shadowA = (int) (a * 0.7f);
			shadowColor = (shadowA << 24) | ((argb & 0xFCFCFC) >> 2);
		}

		float width = getWidth(font, text, size);
		float height = font.lineHeight() * size;

		Matrix3x2f pose = new Matrix3x2f(ctx.getMatrices());
		ScreenRect scissor = ctx.scissorStack.peekLast();
		ScreenRect rawBounds = new ScreenRect((int) Math.floor(x), (int) Math.floor(y), (int) Math.ceil(width) + 2, (int) Math.ceil(height) + 2);
		ScreenRect transformed = rawBounds.transformEachVertex(pose);
		ScreenRect bounds = (scissor != null) ? transformed.intersection(scissor) : transformed;

		ctx.state.addSimpleElement(new MsdfTextGuiElementRenderState(
				font,
				text,
				pose,
				x,
				y,
				size,
				argb,
				shadow,
				shadowColor,
				scissor,
				bounds
		));

		return x + width;
	}
}
