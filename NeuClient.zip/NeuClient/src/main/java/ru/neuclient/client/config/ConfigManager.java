package ru.neuclient.client.config;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.hud.HudElement;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.Setting;
import ru.neuclient.client.util.ClientPaths;
import ru.neuclient.client.util.RenderUtil;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;

/**
 * Система конфигов клиента (JSON + Gson), папка configs/ внутри C:\NeuClient.
 *
 * Важная логика:
 *  - при КАЖДОМ запуске клиента загружается default.json;
 *  - при КАЖДОМ изменении состояния (модули, параметры, бинды, HUD, тема)
 *    default.json автоматически перезаписывается (сглаживание 1 сек,
 *    чтобы не дёргать диск сто раз подряд);
 *  - ".cfg load <name>" применяет настройки из <name>.json, но цель
 *    автосохранения при этом остаётся default.json;
 *  - ".cfg save <name>" вручную записывает слепок состояния в <name>.json.
 */
public class ConfigManager {

	private static final String DEFAULT_NAME = "default";

	private final Gson gson = new GsonBuilder().setPrettyPrinting().create();

	/** Файл, в который идут ВСЕ автосохранения. Не меняется после init(). */
	private Path defaultFile;

	/** true, пока применяется конфиг из файла (тогда изменения не помечаем). */
	private boolean loading;

	/** Флаг «состояние поменялось — надо сохраниться». */
	private boolean dirty;

	/** Отсчёт тиков до фактической записи (сглаживание частых изменений). */
	private int saveCooldown;

	/**
	 * Закреплённые («пиннутые») конфиги — они всегда идут первыми в
	 * панели конфигов ClickGUI. Чисто интерфейсное состояние, живёт
	 * в default.json рядом с остальным.
	 */
	private final Set<String> pinned = new LinkedHashSet<>();

	public void init() {
		defaultFile = ClientPaths.configFile(DEFAULT_NAME + ".json");
		if (!Files.exists(defaultFile)) {
			NeuClient.LOGGER.info("[NeuClient] default.json не найден — создаём с дефолтом");
			saveDefault();
		}
		// При каждом запуске грузим именно default.json
		loadDefault();
	}

	// ===== Автосохранение при любом изменении =====

	/**
	 * Помечает, что состояние изменилось. Вызывается сеттерами модулей,
	 * настроек, HUD и т.д. Во время применения конфига пометка игнорируется.
	 */
	public void markDirty() {
		if (loading || isPanicked()) {
			return;
		}
		dirty = true;
		saveCooldown = 15; // ~0.75 с — пачка изменений запишется одним файлом
	}

	/** Паника (.panic): диск стал «чужим» — никаких записей до перезапуска. */
	private static boolean isPanicked() {
		NeuClient c = NeuClient.getInstance();
		return c != null && c.isPanicked();
	}

	/** Вызывается каждый клиентский тик: пишет default.json, если были изменения. */
	public void tickSave() {
		if (!dirty) {
			return;
		}
		if (--saveCooldown <= 0) {
			dirty = false;
			saveDefault();
		}
	}

	// ===== Публичные операции =====

	/** Автосохранение (при выходе и в любой другой момент) — всегда в default.json. */
	public void saveDefault() {
		if (isPanicked()) {
			return; // при панике папка клиента уехала/прячется — на диск не лезем
		}
		try {
			write(defaultFile);
		} catch (IOException e) {
			NeuClient.LOGGER.error("[NeuClient] Не удалось сохранить default.json", e);
		}
	}

	/** Загрузка основного конфига (вызывается при старте). */
	public void loadDefault() {
		try {
			read(defaultFile);
		} catch (IOException e) {
			NeuClient.LOGGER.error("[NeuClient] Не удалось прочитать default.json", e);
		}
	}

	/** ".cfg save <name>" — ручное сохранение в отдельный файл. */
	public void saveNamed(String name) throws IOException {
		write(namedFile(name));
	}

	/**
	 * ".cfg load <name>" — применить конфиг из файла.
	 * Обратите внимание: defaultFile здесь НЕ меняется — последующие
	 * автосохранения по-прежнему пишутся в default.json.
	 */
	public void loadNamed(String name) throws IOException {
		read(namedFile(name));
		NeuClient.LOGGER.info("[NeuClient] Config loaded: {}.json", name);
	}

	/** Список доступных конфигов в папке configs/ (для ".cfg list"). */
	public List<String> listConfigs() {
		List<String> result = new ArrayList<>();
		try (Stream<Path> stream = Files.list(ClientPaths.getConfigsDir())) {
			stream.filter(p -> p.getFileName().toString().endsWith(".json"))
					.map(p -> p.getFileName().toString().replace(".json", ""))
					.filter(n -> !n.equals("alts") && !n.equals("friends") && !n.equals("proxy") && !n.equals("gps"))
					.sorted()
					.forEach(result::add);
		} catch (IOException e) {
			NeuClient.LOGGER.error("[NeuClient] Не удалось перечислить конфиги", e);
		}
		return result;
	}

	public boolean exists(String name) {
		return Files.exists(namedFile(name));
	}

	/** ".cfg rem <name>" — удалить конфиг. */
	public boolean deleteNamed(String name) {
		try {
			Path file = namedFile(name);
			boolean removed = Files.deleteIfExists(file);
			if (removed && pinned.remove(name)) {
				markDirty();
			}
			return removed;
		} catch (IOException e) {
			NeuClient.LOGGER.error("[NeuClient] Не удалось удалить конфиг {}", name, e);
			return false;
		}
	}

	// ===== Закрепление конфигов (для панели в ClickGUI) =====

	public boolean isPinned(String name) {
		return pinned.contains(name);
	}

	/** Переключить «закреплённость». Возвращает новое состояние. */
	public boolean togglePinned(String name) {
		boolean now;
		if (pinned.remove(name)) {
			now = false;
		} else {
			pinned.add(name);
			now = true;
		}
		markDirty();
		return now;
	}

	/**
	 * Список конфигов для панели: сначала закреплённые (в алфавитном
	 * порядке), затем остальные. Так закреплённые не «уезжают» вниз,
	 * когда конфигов становится много.
	 */
	public List<String> listConfigsPinnedFirst() {
		List<String> all = listConfigs();
		List<String> out = new ArrayList<>();
		for (String n : all) {
			if (pinned.contains(n)) {
				out.add(n);
			}
		}
		for (String n : all) {
			if (!pinned.contains(n)) {
				out.add(n);
			}
		}
		return out;
	}

	/** Проверка имени без выброса исключения — для поля ввода в GUI. */
	public static boolean isValidName(String name) {
		return name != null && name.matches("[A-Za-z0-9_\\-]{1,32}");
	}

	private Path namedFile(String name) {
		return ClientPaths.configFile(sanitize(name) + ".json");
	}

	/** В имени файла разрешаем только безопасные символы. */
	private String sanitize(String name) {
		if (name == null || !name.matches("[A-Za-z0-9_\\-]{1,32}")) {
			throw new IllegalArgumentException("Имя конфига: только латиница, цифры, '_' и '-'");
		}
		return name;
	}

	// ===== Сериализация =====

	/** Собирает JSON всего состояния клиента и пишет в файл. */
	private void write(Path file) throws IOException {
		JsonObject root = new JsonObject();
		root.addProperty("client", NeuClient.NAME + " " + NeuClient.VERSION);

		// Клавиша открытия ClickGUI
		root.addProperty("guiKey", NeuClient.getInstance().getModuleManager().getGuiKey());

		// Модули: включённость, бинд, настройки
		JsonObject modulesJson = new JsonObject();
		for (Module m : NeuClient.getInstance().getModuleManager().getModules()) {
			JsonObject moduleJson = new JsonObject();
			moduleJson.addProperty("enabled", m.isEnabled());
			moduleJson.addProperty("bind", m.getKeyBind());
			JsonObject settingsJson = new JsonObject();
			for (Setting<?> s : m.getSettings()) {
				settingsJson.add(s.getName(), s.toJson());
			}
			moduleJson.add("settings", settingsJson);
			modulesJson.add(m.getName(), moduleJson);
		}
		root.add("modules", modulesJson);

		// HUD-элементы: позиция (если перемещали) и масштаб (если менялся)
		JsonObject hudJson = new JsonObject();
		for (HudElement e : NeuClient.getInstance().getHudManager().getElements()) {
			boolean moved = e.hasCustomPosition();
			boolean resized = Math.abs(e.getScale() - 1.0f) > 0.001f;
			if (!moved && !resized) {
				continue;
			}
			JsonObject entry = new JsonObject();
			if (moved) {
				entry.addProperty("x", e.getX());
				entry.addProperty("y", e.getY());
			}
			if (resized) {
				entry.addProperty("scale", e.getScale());
			}
			hudJson.add(e.getId(), entry);
		}
		root.add("hud", hudJson);

		// Палитра целиком (раньше цвет жил настройками модуля Interface)
		JsonObject themeJson = new JsonObject();
		for (String key : RenderUtil.THEME_KEYS) {
			themeJson.addProperty(key, RenderUtil.getThemeColor(key));
		}
		themeJson.addProperty("brightness", RenderUtil.getBrightness());
		root.add("theme", themeJson);

		// Закреплённые конфиги
		JsonArray pinnedJson = new JsonArray();
		for (String name : pinned) {
			pinnedJson.add(name);
		}
		root.add("pinnedConfigs", pinnedJson);

		try (Writer writer = Files.newBufferedWriter(file)) {
			gson.toJson(root, writer);
		}
	}

	/** Читает JSON-файл и применяет всё состояние (интерфейс обновится сам). */
	private void read(Path file) throws IOException {
		JsonObject root;
		try (Reader reader = Files.newBufferedReader(file)) {
			root = JsonParser.parseReader(reader).getAsJsonObject();
		} catch (IllegalStateException | com.google.gson.JsonSyntaxException e) {
			throw new IOException("Файл " + file.getFileName() + " повреждён", e);
		}

		// Пока применяем конфиг, изменения НЕ считаем ручными —
		// чтобы загрузка .cfg не перезаписывала default.json сама по себе
		loading = true;
		try {
			apply(root);
		} finally {
			loading = false;
			dirty = false;
		}
	}

	/** Применение распарсенного состояния к менеджерам. */
	private void apply(JsonObject root) {

		// Клавиша GUI
		if (root.has("guiKey")) {
			NeuClient.getInstance().getModuleManager().setGuiKey(root.get("guiKey").getAsInt());
		}

		// Модули
		if (root.has("modules")) {
			JsonObject modulesJson = root.getAsJsonObject("modules");
			for (Module m : NeuClient.getInstance().getModuleManager().getModules()) {
				if (!modulesJson.has(m.getName())) {
					continue;
				}
				JsonObject moduleJson = modulesJson.getAsJsonObject(m.getName());
				try {
					if (moduleJson.has("enabled")) {
						m.setEnabled(moduleJson.get("enabled").getAsBoolean());
					}
					if (moduleJson.has("bind")) {
						m.setKeyBind(moduleJson.get("bind").getAsInt());
					}
					if (moduleJson.has("settings")) {
						JsonObject settingsJson = moduleJson.getAsJsonObject("settings");
						for (Setting<?> s : m.getSettings()) {
							if (settingsJson.has(s.getName())) {
								s.fromJson(settingsJson.get(s.getName()));
							}
						}
					}
				} catch (Exception e) {
					NeuClient.LOGGER.error("[NeuClient] Ошибка применения модуля {}", m.getName(), e);
				}
			}
		}

		// Позиции и масштабы HUD
		if (root.has("hud")) {
			JsonObject hudJson = root.getAsJsonObject("hud");
			for (HudElement e : NeuClient.getInstance().getHudManager().getElements()) {
				if (!hudJson.has(e.getId())) {
					// В конфиге записи нет — дефолтные позиция и масштаб
					e.resetPosition();
					e.setScale(1.0f);
					continue;
				}
				JsonObject entry = hudJson.getAsJsonObject(e.getId());
				if (entry.has("x") && entry.has("y")) {
					e.setPosition(entry.get("x").getAsInt(), entry.get("y").getAsInt());
				} else {
					e.resetPosition();
				}
				e.setScale(entry.has("scale") ? entry.get("scale").getAsFloat() : 1.0f);
			}
		}

		// Палитра. Если секции нет (старый конфиг) — заводские цвета,
		// иначе накопится каша из наполовину применённой темы.
		RenderUtil.resetTheme();
		if (root.has("theme")) {
			JsonObject themeJson = root.getAsJsonObject("theme");
			for (String key : RenderUtil.THEME_KEYS) {
				if (themeJson.has(key)) {
					try {
						RenderUtil.setThemeColor(key, themeJson.get(key).getAsInt());
					} catch (Exception ignored) {
						// битое значение — оставляем заводское
					}
				}
			}
			if (themeJson.has("brightness")) {
				try {
					RenderUtil.setBrightness(themeJson.get("brightness").getAsFloat());
				} catch (Exception ignored) {
				}
			}
		}

		// Закреплённые конфиги. Секции нет (старый конфиг) — пины не трогаем.
		if (root.has("pinnedConfigs")) {
			pinned.clear();
			try {
				for (var el : root.getAsJsonArray("pinnedConfigs")) {
					String name = el.getAsString();
					if (isValidName(name)) {
						pinned.add(name);
					}
				}
			} catch (Exception ignored) {
			}
		}
	}

}
