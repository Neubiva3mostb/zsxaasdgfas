package ru.neuclient.client.module.impl.render;

import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.ModeSetting;

/**
 * Aspect Ratio — меняет соотношение сторон камеры.
 *
 * Ванильная проекция строится в GameRenderer#getBasicProjectionMatrix как
 * perspective(fov, framebufferWidth / framebufferHeight, 0.05, far).
 * Миксин GameRendererMixin подменяет это отношение на выбранное:
 * картинка «растягивается» по горизонтали или сужается, как на мониторе
 * с другим соотношением.
 *
 * Зачем это в PvP: на 21:9 в кадр попадает заметно больше по горизонтали
 * (шире периферийный обзор), на 4:3 — наоборот, всё крупнее и цель кажется
 * ближе, как на старых мониторах у квейкеров.
 *
 * Режимы: 16:9 (1.778) / 16:10 (1.6) / 21:9 (2.333) / 4:3 (1.333).
 * Чистый рендер: на сервер ничего не влияет и ничего не отправляется.
 *
 * Учтите: HUD и GUI рисуются отдельной ортографической проекцией и
 * НЕ растягиваются — меняется только 3D-мир.
 */
public final class AspectRatioModule extends Module {

	private static final String R_16_9 = "16:9";
	private static final String R_16_10 = "16:10";
	private static final String R_21_9 = "21:9";
	private static final String R_4_3 = "4:3";

	private final ModeSetting ratio = new ModeSetting("Соотношение", R_16_9,
			R_16_9, R_16_10, R_21_9, R_4_3);

	public AspectRatioModule() {
		super("Aspect Ratio", "Изменяет соотношение сторон экрана",
				Category.RENDER);
		addSettings(ratio);
	}

	/** Выбранное соотношение сторон для матрицы проекции. */
	public float getAspect() {
		return switch (ratio.get()) {
			case R_16_10 -> 16.0f / 10.0f;
			case R_21_9 -> 21.0f / 9.0f;
			case R_4_3 -> 4.0f / 3.0f;
			default -> 16.0f / 9.0f;
		};
	}

	/** Активный экземпляр для миксина (null — модуль выключен). */
	public static AspectRatioModule active() {
		ru.neuclient.client.NeuClient c = ru.neuclient.client.NeuClient.getInstance();
		if (c == null || c.getModuleManager() == null) {
			return null;
		}
		AspectRatioModule m = c.getModuleManager().get(AspectRatioModule.class);
		return m != null && m.isEnabled() ? m : null;
	}
}
