package ru.neuclient.client.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonNull;

/** Кнопка в ClickGUI: по клику выполняет действие, в конфиг не пишется. */
public class ButtonSetting extends Setting<Boolean> {

	private final Runnable action;

	public ButtonSetting(String name, Runnable action) {
		super(name, false);
		this.action = action;
	}

	public void press() {
		if (action != null) action.run();
	}

	@Override
	public JsonElement toJson() {
		return JsonNull.INSTANCE;
	}

	@Override
	public void fromJson(JsonElement element) {
	}
}
