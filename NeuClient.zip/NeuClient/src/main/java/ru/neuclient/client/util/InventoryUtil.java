package ru.neuclient.client.util;

import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import ru.neuclient.client.mixin.ClientPlayerInteractionManagerInvoker;

import java.util.function.Predicate;

/**
 * Утилиты «легитных» манипуляций с инвентарём: только действия, которые
 * живой игрок тоже может выполнить (выбор слота хотбара, свап ячейки
 * инвентаря с хотбаром клавишей-цифрой). Никакой магии — только те же
 * пакеты, что шлёт ванильный клиент.
 *
 * Раскладка слотов: PlayerInventory 0–8 = хотбар, 9–35 = основной
 * инвентарь (индексы совпадают со слотами PlayerScreenHandler, syncId = 0).
 */
public final class InventoryUtil {

	private InventoryUtil() {
	}

	/** Первый подходящий стак в хотбаре, -1 если нет. */
	public static int findInHotbar(PlayerEntity player, Predicate<ItemStack> filter) {
		PlayerInventory inv = player.getInventory();
		for (int i = 0; i < 9; i++) {
			ItemStack stack = inv.getStack(i);
			if (!stack.isEmpty() && filter.test(stack)) {
				return i;
			}
		}
		return -1;
	}

	/** Первый подходящий стак в основном инвентаре (слоты 9–35), -1 если нет. */
	public static int findInInventory(PlayerEntity player, Predicate<ItemStack> filter) {
		PlayerInventory inv = player.getInventory();
		for (int i = 9; i <= 35; i++) {
			ItemStack stack = inv.getStack(i);
			if (!stack.isEmpty() && filter.test(stack)) {
				return i;
			}
		}
		return -1;
	}


	/**
	 * Переключить выбранный слот хотбара так, чтобы СЕРВЕР сразу увидел
	 * предмет в руке: setSelectedSlot меняет слот лишь локально, а пакет
	 * UpdateSelectedSlotC2SPacket сам по себе улетает «когда-нибудь» при
	 * следующем взаимодействии. syncSelectedSlot() шлёт его мгновенно —
	 * на сервере бросок/удар точно пойдёт с уже выбранного слота.
	 *
	 * ОСТАНОВКА НА ОДИН ТИК (50 мс) ВХОДИТ В ЦЕНУ СМЕНЫ СЛОТА.
	 *
	 * Раньше пауза висела только на clickSlot внутри {@link SwapUtil},
	 * то есть на пути «предмет лежит в глубоком инвентаре». Если нужный
	 * предмет уже был в хотбаре, модуль просто дёргал слот и никакой
	 * остановки не происходило. Со стороны сервера это две РАЗНЫЕ
	 * картины поведения одного игрока, и именно расхождение заметно:
	 * тотем из рюкзака — стоя, топор из хотбара — на полном бегу.
	 *
	 * Теперь цена одинаковая. Любая смена слота = один погашенный пакет
	 * движения, независимо от того, откуда пришёл предмет.
	 *
	 * Пауза берётся ТОЛЬКО когда слот реально меняется: повторный вызов
	 * с тем же слотом (а модули зовут его и просто ради ре-синка) ничего
	 * не двигает и тормозить не должен.
	 *
	 * ВНИМАНИЕ: с паузой слот меняется НЕ МГНОВЕННО, а через тик — когда
	 * серверу уже ушёл пакет стоящего игрока. Сразу после вызова
	 * getSelectedSlot() вернёт ещё старое значение. Модулям, которым
	 * важно действовать уже выбранным предметом, нужно дождаться
	 * {@code !SwapPause.isBusy()}.
	 */
	public static void selectSlot(PlayerEntity player, int slot, ClientPlayerInteractionManager interaction) {
		selectSlot(player, slot, interaction, true);
	}

	/**
	 * Вариант с явным управлением паузой.
	 *
	 * @param pause false — сменить слот без остановки. Нужен модулям, для
	 *              которых пауза ломает саму механику: WallClimb гасил бы
	 *              себе прыжок ровно в тот тик, когда ставит блок под ноги.
	 */
	public static void selectSlot(PlayerEntity player, int slot,
			ClientPlayerInteractionManager interaction, boolean pause) {
		PlayerInventory inv = player.getInventory();
		if (inv.getSelectedSlot() == slot) {
			// Слот уже нужный: это ре-синк, тормозить незачем.
			((ClientPlayerInteractionManagerInvoker) interaction).pc$syncSelectedSlot();
			return;
		}
		if (!pause) {
			inv.setSelectedSlot(slot);
			((ClientPlayerInteractionManagerInvoker) interaction).pc$syncSelectedSlot();
			return;
		}
		// Сама смена слота тоже ОТКЛАДЫВАЕТСЯ на тик остановки: серверу
		// важен порядок «пакет стоящего игрока → смена слота», а не сам
		// факт того, что где-то рядом был обнулён ввод.
		SwapPause.submit(() -> {
			inv.setSelectedSlot(slot);
			((ClientPlayerInteractionManagerInvoker) interaction).pc$syncSelectedSlot();
		});
	}
}
