package ru.neuclient.client.module.impl.render;

import ru.neuclient.client.module.impl.combat.AttackAuraModule;

import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.render.WorldRenderUtil;
import ru.neuclient.client.setting.ColorSetting;
import ru.neuclient.client.setting.ModeSetting;

/**
 * Target ESP — цель AttackAura или игрок, которого ударили за последние 2 секунды.
 *
 * Режимы метки:
 *  • «Мишень» — тактический 3D-прицел с захватом цели, шевронами и ромбом
 *  • «Кубы» — вращающиеся объемные микро-кубики
 *  • «Сканер» — лазерный сканер с объемным светящимся градиентным шлейфом (Delta-стиль)
 *  • «Руны» — магическая руническая печать на земле с 8-конечной звездой и световыми колоннами
 */
public final class TargetEspModule extends Module {

	private static final String TARGET = "Мишень";
	private static final String CUBES = "Кубы";
	private static final String SCANNER = "Сканер";
	private static final String RUNES = "Руны";

	private static final long FADE_MS = 250;

	private final ModeSetting mode = new ModeSetting("Метка", TARGET, TARGET, CUBES, SCANNER, RUNES);
	private final ColorSetting color = new ColorSetting("Цвет", 0xFF7A5CFF);

	private final RecentHitTarget<PlayerEntity> recentHit = new RecentHitTarget<>();
	private ClientWorld trackedWorld;
	private LivingEntity lastTarget;
	private long lastSeenMs;

	public TargetEspModule() {
		super("TargetESP", "Метка на цели", Category.RENDER);
		addSettings(mode, color);
	}

	@Override
	protected void onDisable() {
		clearTargets();
		trackedWorld = null;
	}

	private void clearTargets() {
		lastTarget = null;
		lastSeenMs = 0L;
		recentHit.clear();
	}

	@Override
	public void onTick(MinecraftClient client) {
		syncWorld(client);
	}

	private void syncWorld(MinecraftClient client) {
		if (client.player == null || trackedWorld != client.world) {
			clearTargets();
			trackedWorld = client.world;
		}
	}

	/** Общий хук: ЛКМ, TriggerBot и AttackAura проходят через attackEntity. */
	public static void onAttack(Entity target) {
		MinecraftClient client = MinecraftClient.getInstance();
		NeuClient neu = NeuClient.getInstance();
		if (neu == null || neu.getModuleManager() == null || client.player == null || client.world == null
				|| !(target instanceof PlayerEntity player) || !validTarget(player, client)) return;
		TargetEspModule self = neu.getModuleManager().get(TargetEspModule.class);
		if (self == null || !self.isEnabled()) return;
		self.syncWorld(client);
		self.recentHit.record(player, nowMs());
	}

	private static long nowMs() {
		return System.nanoTime() / 1_000_000L;
	}

	private static boolean validTarget(LivingEntity target, MinecraftClient client) {
		return target != null && target != client.player && target.isAlive() && !target.isRemoved()
				&& target.getEntityWorld() == client.world;
	}

	public void renderWorld(WorldRenderContext context, MinecraftClient client) {
		if (client.world == null || client.player == null || context.commandQueue() == null) {
			return;
		}

		syncWorld(client);
		long now = nowMs();
		LivingEntity current = auraTarget();
		if (validTarget(current, client)) {
			lastTarget = current;
			lastSeenMs = now;
		} else {
			current = null;
		}
		PlayerEntity hit = recentHit.get(now);
		if (!validTarget(hit, client)) {
			recentHit.clear();
			hit = null;
		}

		LivingEntity target;
		float fade;
		if (hit != null) {
			// Повторный удар обновляет таймер. После 2000 мс нет лишнего
			// хвоста FADE_MS; при активной ауре остаётся её обычная метка.
			target = hit;
			fade = current == hit ? 1.0f : recentHit.opacity(now);
		} else {
			long since = now - lastSeenMs;
			if (!validTarget(lastTarget, client) || (current == null && since >= FADE_MS)) {
				lastTarget = null;
				return;
			}
			target = lastTarget;
			fade = current != null ? 1.0f : Math.max(0.0f, 1.0f - (float) since / FADE_MS);
		}

		float tickDelta = client.getRenderTickCounter().getTickProgress(false);
		Camera camera = client.gameRenderer.getCamera();
		Vec3d cam = camera.getCameraPos();
		Vec3d pos = target.getLerpedPos(tickDelta);
		Box box = target.getBoundingBox();

		double height = box.getLengthY();
		double radius = Math.max(box.getLengthX(), box.getLengthZ()) * 0.78;
		radius *= 0.35 + 0.65 * fade;

		int accent = color.get();
		float r = WorldRenderUtil.red(accent);
		float g = WorldRenderUtil.green(accent);
		float b = WorldRenderUtil.blue(accent);
		float width = 3.0f;

		double time = (System.currentTimeMillis() % 1000000L) / 1000.0;
		var layer = WorldRenderUtil.LINES_NO_DEPTH;

		MatrixStack matrices = context.matrices();
		matrices.push();
		try {
			matrices.translate(-cam.x, -cam.y, -cam.z);
	
			final double fRadius = radius;
			final double fHeight = height;
			final float fFade = fade;
			final Box fBox = box.offset(pos.x - target.getX(), pos.y - target.getY(), pos.z - target.getZ());
			final String selectedMode = mode.get();
	
			if (CUBES.equals(selectedMode)) {
				context.commandQueue().submitCustom(matrices, WorldRenderUtil.QUADS, (entry, buffer) ->
					drawCubes(buffer, entry, pos, fRadius, fHeight, time, r, g, b, fFade));
			} else if (SCANNER.equals(selectedMode)) {
				// Лазерный сканер с объемным шлейфом (QUADS) + контурные кольца (LINES)
				context.commandQueue().submitCustom(matrices, WorldRenderUtil.QUADS, (entry, buffer) ->
					drawLaserSkirt(buffer, entry, pos, fRadius, fHeight, time, r, g, b, fFade));
				context.commandQueue().submitCustom(matrices, layer, (entry, buffer) ->
					drawLaserRings(buffer, entry, pos, fRadius, fHeight, time, r, g, b, fFade, width));
			} else if (RUNES.equals(selectedMode)) {
				// Магическая руническая печать на земле (QUADS градиент лучей + LINES узоры)
				context.commandQueue().submitCustom(matrices, WorldRenderUtil.QUADS, (entry, buffer) ->
					drawRunePillars(buffer, entry, pos, fRadius, fHeight, time, r, g, b, fFade));
				context.commandQueue().submitCustom(matrices, layer, (entry, buffer) ->
					drawRuneCircle(buffer, entry, pos, fRadius, fHeight, time, r, g, b, fFade, width));
			} else {
				// TARGET («Мишень») по умолчанию
				context.commandQueue().submitCustom(matrices, layer, (entry, buffer) ->
					drawTargetBox(buffer, entry, fBox, pos, fHeight, camera, time, r, g, b, fFade, width));
			}
		} finally {
			matrices.pop();
		}
	}

	private LivingEntity auraTarget() {
		var modules = NeuClient.getInstance().getModuleManager();
		if (modules == null) return null;
		AttackAuraModule aura = modules.get(AttackAuraModule.class);
		if (aura == null || !aura.isEnabled()) return null;
		LivingEntity t = aura.getTarget();
		return t != null && t.isAlive() ? t : null;
	}

	// ===== 1. СКАНЕР (SCANNER - DELTA LASER SCANNER) =====
	private void drawLaserSkirt(net.minecraft.client.render.VertexConsumer buffer,
			net.minecraft.client.util.math.MatrixStack.Entry entry,
			Vec3d pos, double radius, double height, double time,
			float r, float g, float b, float fade) {
		Matrix4f m = entry.getPositionMatrix();
		float scanHeight = (float) height + 0.15f;
		float scanRadius = (float) radius * 0.95f;

		double cycle = (System.currentTimeMillis() % 1750L) / 1750.0;
		boolean down = cycle > 0.5;
		double p = down ? (cycle - 0.5) * 2.0 : (0.5 - cycle) * 2.0;
		double ease = p < 0.5 ? 2.0 * p * p : 1.0 - Math.pow(-2.0 * p + 2.0, 2.0) / 2.0;

		float curY = (float) (pos.y + scanHeight * ease);
		float yOffset = (float) (scanHeight * 0.45 * Math.min(ease, 1.0 - ease) * (down ? 1.0 : -1.0));
		float a = fade * 0.55f;

		int segs = 48;
		for (int i = 0; i < segs; i++) {
			double a0 = Math.PI * 2.0 * i / segs;
			double a1 = Math.PI * 2.0 * (i + 1) / segs;
			double x0 = pos.x + Math.cos(a0) * scanRadius;
			double z0 = pos.z + Math.sin(a0) * scanRadius;
			double x1 = pos.x + Math.cos(a1) * scanRadius;
			double z1 = pos.z + Math.sin(a1) * scanRadius;

			WorldRenderUtil.quadGradient(buffer, m,
					x0, curY, z0, a,
					x1, curY, z1, a,
					x1, curY + yOffset, z1, 0.0f,
					x0, curY + yOffset, z0, 0.0f,
					r, g, b);
			WorldRenderUtil.quadGradient(buffer, m,
					x0, curY + yOffset, z0, 0.0f,
					x1, curY + yOffset, z1, 0.0f,
					x1, curY, z1, a,
					x0, curY, z0, a,
					r, g, b);
		}
	}

	private void drawLaserRings(net.minecraft.client.render.VertexConsumer buffer,
			net.minecraft.client.util.math.MatrixStack.Entry entry,
			Vec3d pos, double radius, double height, double time,
			float r, float g, float b, float fade, float width) {
		float scanHeight = (float) height + 0.15f;
		float scanRadius = (float) radius * 0.95f;

		double cycle = (System.currentTimeMillis() % 1750L) / 1750.0;
		boolean down = cycle > 0.5;
		double p = down ? (cycle - 0.5) * 2.0 : (0.5 - cycle) * 2.0;
		double ease = p < 0.5 ? 2.0 * p * p : 1.0 - Math.pow(-2.0 * p + 2.0, 2.0) / 2.0;
		double curY = pos.y + scanHeight * ease;

		// Главный лазерный скан-диск
		WorldRenderUtil.circle(buffer, entry, pos.x, curY, pos.z, scanRadius, 48, r, g, b, fade * 0.95f, width);

		// 4 внешние вращающиеся лазерные дуги
		double outR = scanRadius * 1.15;
		int arcs = 4;
		int perArc = 6;
		double spin = time * 2.0;
		for (int a = 0; a < arcs; a++) {
			double a0 = Math.PI * 2.0 * a / arcs + spin;
			Vec3d prev = null;
			for (int j = 0; j <= perArc; j++) {
				double ang = a0 + (Math.PI * 2.0 / arcs * 0.5) * ((double) j / perArc);
				Vec3d pt = new Vec3d(pos.x + Math.cos(ang) * outR, curY, pos.z + Math.sin(ang) * outR);
				if (prev != null) {
					WorldRenderUtil.line(buffer, entry, prev.x, prev.y, prev.z, pt.x, pt.y, pt.z, r, g, b, fade * 0.75f, width);
				}
				prev = pt;
			}
		}

		// Тонкое опорное кольцо на уровне ног
		WorldRenderUtil.circle(buffer, entry, pos.x, pos.y + 0.04, pos.z, scanRadius * 0.85, 36, r, g, b, fade * 0.40f, width);
	}

	// ===== 2. РУНЫ (RUNES - MAGIC SEAL & ASCENDING LIGHT PILLARS) =====
	private void drawRunePillars(net.minecraft.client.render.VertexConsumer buffer,
			net.minecraft.client.util.math.MatrixStack.Entry entry,
			Vec3d pos, double radius, double height, double time,
			float r, float g, float b, float fade) {
		Matrix4f m = entry.getPositionMatrix();
		double sealR = radius * 1.35;
		double groundY = pos.y + 0.02;

		// Мягкое свечение на земле под целью (радиальный градиент)
		int groundSegs = 28;
		float centerA = fade * 0.20f;
		for (int i = 0; i < groundSegs; i++) {
			double a0 = Math.PI * 2.0 * i / groundSegs;
			double a1 = Math.PI * 2.0 * (i + 1) / groundSegs;
			double x0 = pos.x + Math.cos(a0) * sealR;
			double z0 = pos.z + Math.sin(a0) * sealR;
			double x1 = pos.x + Math.cos(a1) * sealR;
			double z1 = pos.z + Math.sin(a1) * sealR;
			WorldRenderUtil.quadGradient(buffer, m,
					pos.x, groundY, pos.z, centerA,
					pos.x, groundY, pos.z, centerA,
					x1, groundY, z1, 0.0f,
					x0, groundY, z0, 0.0f,
					r, g, b);
		}

		// Вертикальные восходящие световые колонны по окружности рунического круга
		int pillarCount = 8;
		double pillarW = 0.055;
		for (int p = 0; p < pillarCount; p++) {
			double ang = Math.PI * 2.0 * p / pillarCount + time * 0.6;
			double px = pos.x + Math.cos(ang) * (sealR * 0.88);
			double pz = pos.z + Math.sin(ang) * (sealR * 0.88);
			double pHeight = height * (0.65 + 0.35 * Math.sin(time * 3.5 + p * 1.25));
			float bottomA = fade * 0.45f;

			// Плоскость X
			WorldRenderUtil.quadGradient(buffer, m,
					px - pillarW, groundY, pz, bottomA,
					px + pillarW, groundY, pz, bottomA,
					px + pillarW, groundY + pHeight, pz, 0.0f,
					px - pillarW, groundY + pHeight, pz, 0.0f,
					r, g, b);
			WorldRenderUtil.quadGradient(buffer, m,
					px - pillarW, groundY + pHeight, pz, 0.0f,
					px + pillarW, groundY + pHeight, pz, 0.0f,
					px + pillarW, groundY, pz, bottomA,
					px - pillarW, groundY, pz, bottomA,
					r, g, b);

			// Плоскость Z (крестообразно для видимости со всех ракурсов)
			WorldRenderUtil.quadGradient(buffer, m,
					px, groundY, pz - pillarW, bottomA,
					px, groundY, pz + pillarW, bottomA,
					px, groundY + pHeight, pz + pillarW, 0.0f,
					px, groundY + pHeight, pz - pillarW, 0.0f,
					r, g, b);
			WorldRenderUtil.quadGradient(buffer, m,
					px, groundY + pHeight, pz - pillarW, 0.0f,
					px, groundY + pHeight, pz + pillarW, 0.0f,
					px, groundY, pz + pillarW, bottomA,
					px, groundY, pz - pillarW, bottomA,
					r, g, b);
		}
	}

	private void drawRuneCircle(net.minecraft.client.render.VertexConsumer buffer,
			net.minecraft.client.util.math.MatrixStack.Entry entry,
			Vec3d pos, double radius, double height, double time,
			float r, float g, float b, float fade, float width) {
		double sealR = radius * 1.35;
		double gy = pos.y + 0.035;

		// 1. Внешнее сегментированное кольцо (вращение по часовой)
		int arcs = 8;
		int segsPerArc = 6;
		double spinOuter = time * 0.6;
		for (int a = 0; a < arcs; a++) {
			double a0 = Math.PI * 2.0 * a / arcs + spinOuter;
			Vec3d prev = null;
			for (int j = 0; j <= segsPerArc; j++) {
				double ang = a0 + (Math.PI * 2.0 / arcs * 0.72) * ((double) j / segsPerArc);
				Vec3d pt = new Vec3d(pos.x + Math.cos(ang) * sealR, gy, pos.z + Math.sin(ang) * sealR);
				if (prev != null) {
					WorldRenderUtil.line(buffer, entry, prev.x, prev.y, prev.z, pt.x, pt.y, pt.z, r, g, b, fade * 0.85f, width);
				}
				prev = pt;
			}
		}

		// 2. Среднее кольцо (противоход)
		double midR = sealR * 0.88;
		WorldRenderUtil.circle(buffer, entry, pos.x, gy, pos.z, midR, 48, r, g, b, fade * 0.65f, width * 0.8f);

		// 3. Внутреннее кольцо
		double innerR = sealR * 0.62;
		WorldRenderUtil.circle(buffer, entry, pos.x, gy, pos.z, innerR, 40, r, g, b, fade * 0.75f, width * 0.8f);

		// 4. Священная 8-конечная звезда (Octagram) внутри кольца
		double starSpin = -time * 0.75;
		Vec3d[] starVerts = new Vec3d[8];
		for (int i = 0; i < 8; i++) {
			double ang = Math.PI * 2.0 * i / 8 + starSpin;
			starVerts[i] = new Vec3d(pos.x + Math.cos(ang) * innerR, gy, pos.z + Math.sin(ang) * innerR);
		}
		for (int i = 0; i < 8; i++) {
			Vec3d p1 = starVerts[i];
			Vec3d p2 = starVerts[(i + 3) % 8];
			WorldRenderUtil.line(buffer, entry, p1.x, gy, p1.z, p2.x, gy, p2.z, r, g, b, fade * 0.90f, width);
		}

		// 5. Рунические ромбы на вершинах звезды
		double diamondSize = 0.045;
		for (int i = 0; i < 8; i++) {
			Vec3d sv = starVerts[i];
			WorldRenderUtil.line(buffer, entry, sv.x - diamondSize, gy, sv.z, sv.x, gy, sv.z + diamondSize, r, g, b, fade * 0.95f, width);
			WorldRenderUtil.line(buffer, entry, sv.x, gy, sv.z + diamondSize, sv.x + diamondSize, gy, sv.z, r, g, b, fade * 0.95f, width);
			WorldRenderUtil.line(buffer, entry, sv.x + diamondSize, gy, sv.z, sv.x, gy, sv.z - diamondSize, r, g, b, fade * 0.95f, width);
			WorldRenderUtil.line(buffer, entry, sv.x, gy, sv.z - diamondSize, sv.x - diamondSize, gy, sv.z, r, g, b, fade * 0.95f, width);
		}

		// 6. Парящий рунический нимб над головой
		double topY = pos.y + height + 0.18;
		double haloR = radius * 0.55;
		WorldRenderUtil.circle(buffer, entry, pos.x, topY, pos.z, haloR, 36, r, g, b, fade * 0.80f, width);

		// 4 шеврона на верхнем кольце
		double haloSpin = time * 1.6;
		double chevLen = 0.08;
		for (int i = 0; i < 4; i++) {
			double ha = Math.PI / 2.0 * i + haloSpin;
			double hx = pos.x + Math.cos(ha) * haloR;
			double hz = pos.z + Math.sin(ha) * haloR;
			double hxOut = pos.x + Math.cos(ha) * (haloR + chevLen);
			double hzOut = pos.z + Math.sin(ha) * (haloR + chevLen);
			WorldRenderUtil.line(buffer, entry, hx, topY, hz, hxOut, topY, hzOut, r, g, b, fade * 0.90f, width + 0.5f);
		}
	}

	// ===== 3. МИШЕНЬ (TARGET - TACTICAL 3D LOCK) =====
	private void drawTargetBox(net.minecraft.client.render.VertexConsumer buffer,
			net.minecraft.client.util.math.MatrixStack.Entry entry,
			Box box, Vec3d pos, double height, Camera camera, double time,
			float r, float g, float b, float fade, float width) {

		double pulse = 0.02 * Math.sin(time * 4.0);
		Box bBox = box.expand(pulse, pulse, pulse);

		double minX = bBox.minX, minY = bBox.minY, minZ = bBox.minZ;
		double maxX = bBox.maxX, maxY = bBox.maxY, maxZ = bBox.maxZ;
		double cx = Math.min((maxX - minX) * 0.28, 0.35);
		double cy = Math.min((maxY - minY) * 0.28, 0.35);
		double cz = Math.min((maxZ - minZ) * 0.28, 0.35);

		float cornerAlpha = 0.90f * fade;
		for (int i = 0; i < 8; i++) {
			boolean hx = (i & 1) != 0;
			boolean hy = (i & 2) != 0;
			boolean hz = (i & 4) != 0;
			double x = hx ? maxX : minX;
			double y = hy ? maxY : minY;
			double z = hz ? maxZ : minZ;
			double dx = hx ? -cx : cx;
			double dy = hy ? -cy : cy;
			double dz = hz ? -cz : cz;

			WorldRenderUtil.line(buffer, entry, x, y, z, x + dx, y, z, r, g, b, cornerAlpha, width);
			WorldRenderUtil.line(buffer, entry, x, y, z, x, y + dy, z, r, g, b, cornerAlpha, width);
			WorldRenderUtil.line(buffer, entry, x, y, z, x, y, z + dz, r, g, b, cornerAlpha, width);
		}

		Vec3d center = new Vec3d((minX + maxX) * 0.5, pos.y + height * 0.55, (minZ + maxZ) * 0.5);

		float yawRad = (float) Math.toRadians(camera.getYaw());
		float pitchRad = (float) Math.toRadians(camera.getPitch());
		Vec3d right = new Vec3d(Math.cos(yawRad), 0, Math.sin(yawRad));
		Vec3d up = new Vec3d(-Math.sin(yawRad) * Math.sin(pitchRad), Math.cos(pitchRad), Math.cos(yawRad) * Math.sin(pitchRad));

		double outerR = 0.38;
		double spin = time * 1.5;
		int outerArcs = 4;
		int pts = 8;
		for (int a = 0; a < outerArcs; a++) {
			double a0 = Math.PI * 2.0 * a / outerArcs + spin;
			Vec3d prev = null;
			for (int j = 0; j <= pts; j++) {
				double ang = a0 + (Math.PI * 2.0 / outerArcs * 0.65) * ((double) j / pts);
				double u = Math.cos(ang) * outerR;
				double v = Math.sin(ang) * outerR;
				Vec3d p = center.add(right.multiply(u)).add(up.multiply(v));
				if (prev != null) {
					WorldRenderUtil.line(buffer, entry,
							prev.x, prev.y, prev.z, p.x, p.y, p.z,
							r, g, b, fade * 0.85f, width);
				}
				prev = p;
			}
		}

		double pointerDist = 0.48;
		double pointerLen = 0.12;
		for (int i = 0; i < 4; i++) {
			double ang = Math.PI / 2.0 * i;
			double u1 = Math.cos(ang) * pointerDist;
			double v1 = Math.sin(ang) * pointerDist;
			double u2 = Math.cos(ang) * (pointerDist - pointerLen);
			double v2 = Math.sin(ang) * (pointerDist - pointerLen);
			Vec3d p1 = center.add(right.multiply(u1)).add(up.multiply(v1));
			Vec3d p2 = center.add(right.multiply(u2)).add(up.multiply(v2));
			WorldRenderUtil.line(buffer, entry, p1.x, p1.y, p1.z, p2.x, p2.y, p2.z, r, g, b, fade * 0.95f, width + 0.5f);
		}

		double diamondR = 0.16 + 0.02 * Math.sin(time * 5.0);
		double dSpin = -time * 2.0;
		Vec3d[] dCorners = new Vec3d[4];
		for (int i = 0; i < 4; i++) {
			double ang = Math.PI / 4.0 + Math.PI / 2.0 * i + dSpin;
			double u = Math.cos(ang) * diamondR;
			double v = Math.sin(ang) * diamondR;
			dCorners[i] = center.add(right.multiply(u)).add(up.multiply(v));
		}
		for (int i = 0; i < 4; i++) {
			Vec3d p1 = dCorners[i];
			Vec3d p2 = dCorners[(i + 1) % 4];
			WorldRenderUtil.line(buffer, entry, p1.x, p1.y, p1.z, p2.x, p2.y, p2.z, r, g, b, fade * 0.95f, width);
		}

		double crossR = 0.05;
		Vec3d cL = center.add(right.multiply(-crossR));
		Vec3d cR = center.add(right.multiply(crossR));
		Vec3d cD = center.add(up.multiply(-crossR));
		Vec3d cU = center.add(up.multiply(crossR));
		WorldRenderUtil.line(buffer, entry, cL.x, cL.y, cL.z, cR.x, cR.y, cR.z, r, g, b, fade, width);
		WorldRenderUtil.line(buffer, entry, cD.x, cD.y, cD.z, cU.x, cU.y, cU.z, r, g, b, fade, width);
	}

	// ===== 4. РЕЖИМ «КУБЫ» (CUBES) =====
	private void drawCubes(net.minecraft.client.render.VertexConsumer buffer,
			MatrixStack.Entry entry, Vec3d pos, double radius, double height, double time,
			float r, float g, float b, float fade) {
		Matrix4f matrix = entry.getPositionMatrix();
		double centerY = pos.y + height * 0.5;
		int cubes = 12;
		for (int i = 0; i < cubes; i++) {
			double phase = time * (1.15 + (i & 1) * 0.22) + Math.PI * 2.0 * i / cubes;
			double orbitRadius = radius * (1.25 + 0.12 * Math.sin(time * 1.4 + i));
			double x = pos.x + Math.cos(phase) * orbitRadius;
			double z = pos.z + Math.sin(phase) * orbitRadius;
			double y = centerY + Math.sin(time * 1.7 + i * 1.31) * height * 0.42;
			double size = Math.max(0.10, radius * (0.22 + 0.03 * Math.sin(i * 2.0))) * 1.3;
			float alpha = fade * (0.72f + (i % 3) * 0.08f);
			drawCube(buffer, matrix, x, y, z, size,
					(float) (time * (1.8 + i * 0.11) + i),
					(float) (time * (1.35 - i * 0.04) + i * 0.7),
					(float) (time * (1.55 + i * 0.06) - i),
					r, g, b, alpha);
		}
	}

	private static Vec3d cubePoint(double cx, double cy, double cz, double x, double y, double z,
			float yaw, float pitch, float roll) {
		double cosYaw = Math.cos(yaw);
		double sinYaw = Math.sin(yaw);
		double rx = x * cosYaw - z * sinYaw;
		double rz = x * sinYaw + z * cosYaw;
		double cosPitch = Math.cos(pitch);
		double sinPitch = Math.sin(pitch);
		double ry = y * cosPitch - rz * sinPitch;
		rz = y * sinPitch + rz * cosPitch;
		double cosRoll = Math.cos(roll);
		double sinRoll = Math.sin(roll);
		double finalX = rx * cosRoll - ry * sinRoll;
		double finalY = rx * sinRoll + ry * cosRoll;
		return new Vec3d(cx + finalX, cy + finalY, cz + rz);
	}

	private static void drawCube(net.minecraft.client.render.VertexConsumer buffer, Matrix4f matrix,
			double cx, double cy, double cz, double size, float yaw, float pitch, float roll,
			float r, float g, float b, float a) {
		double h = size * 0.5;
		Vec3d p000 = cubePoint(cx, cy, cz, -h, -h, -h, yaw, pitch, roll);
		Vec3d p100 = cubePoint(cx, cy, cz, h, -h, -h, yaw, pitch, roll);
		Vec3d p110 = cubePoint(cx, cy, cz, h, h, -h, yaw, pitch, roll);
		Vec3d p010 = cubePoint(cx, cy, cz, -h, h, -h, yaw, pitch, roll);
		Vec3d p001 = cubePoint(cx, cy, cz, -h, -h, h, yaw, pitch, roll);
		Vec3d p101 = cubePoint(cx, cy, cz, h, -h, h, yaw, pitch, roll);
		Vec3d p111 = cubePoint(cx, cy, cz, h, h, h, yaw, pitch, roll);
		Vec3d p011 = cubePoint(cx, cy, cz, -h, h, h, yaw, pitch, roll);
		WorldRenderUtil.quad(buffer, matrix, p000.x, p000.y, p000.z, p100.x, p100.y, p100.z,
				p110.x, p110.y, p110.z, p010.x, p010.y, p010.z, r, g, b, a);
		WorldRenderUtil.quad(buffer, matrix, p001.x, p001.y, p001.z, p011.x, p011.y, p011.z,
				p111.x, p111.y, p111.z, p101.x, p101.y, p101.z, r, g, b, a);
		WorldRenderUtil.quad(buffer, matrix, p000.x, p000.y, p000.z, p001.x, p001.y, p001.z,
				p101.x, p101.y, p101.z, p100.x, p100.y, p100.z, r, g, b, a);
		WorldRenderUtil.quad(buffer, matrix, p010.x, p010.y, p010.z, p110.x, p110.y, p110.z,
				p111.x, p111.y, p111.z, p011.x, p011.y, p011.z, r, g, b, a);
		WorldRenderUtil.quad(buffer, matrix, p000.x, p000.y, p000.z, p010.x, p010.y, p010.z,
				p011.x, p011.y, p011.z, p001.x, p001.y, p001.z, r, g, b, a);
		WorldRenderUtil.quad(buffer, matrix, p100.x, p100.y, p100.z, p101.x, p101.y, p101.z,
				p111.x, p111.y, p111.z, p110.x, p110.y, p110.z, r, g, b, a);
	}

	public static void renderAllWorld(WorldRenderContext context) {
		var modules = NeuClient.getInstance().getModuleManager();
		if (modules == null) return;
		TargetEspModule self = modules.get(TargetEspModule.class);
		if (self != null && self.isEnabled()) {
			self.renderWorld(context, MinecraftClient.getInstance());
		}
	}
}
