package ru.neuclient.client.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.CreativeInventoryScreen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import ru.neuclient.client.NeuClient;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Кнопки и серверные действия для открытых контейнеров. */
public final class StorageActions {

	private static final int BUTTON_WIDTH = 92;
	private static final int BUTTON_HEIGHT = 18;
	private static final int BUTTON_GAP = 4;
	// Шаги выполняются мгновенно (все слоты за один тик), поэтому задержки нет.
	private static final long STEP_DELAY_MS = 0L;

	private static final String[] LABELS = {"Сортировать", "Выбросить всё", "Сложить", "Забрать"};

	private static Job job;

	private enum JobType {
		SORT,
		THROW,
		DEPOSIT,
		WITHDRAW
	}

	private record SortEntry(String key, String typeKey) {
	}

	private static final class Job {
		final JobType type;
		final int syncId;
		final int containerSlots;
		final List<String> desired;
		int index;
		long nextStepAt;

		Job(JobType type, int syncId, int containerSlots, List<String> desired) {
			this.type = type;
			this.syncId = syncId;
			this.containerSlots = containerSlots;
			this.desired = desired;
		}
	}

	private StorageActions() {
	}

	/** Обработать один шаг текущей очереди в конце клиентского тика. */
	public static void tick(MinecraftClient client) {
		if (NeuClient.getInstance() != null && NeuClient.getInstance().isPanicked()) {
			job = null;
			return;
		}
		if (job == null) return;
		if (!(client.currentScreen instanceof HandledScreen<?> screen)
				|| screen instanceof InventoryScreen
				|| client.player == null
				|| client.player.currentScreenHandler == client.player.playerScreenHandler
				|| client.interactionManager == null) {
			job = null;
			return;
		}
		ScreenHandler handler = client.player.currentScreenHandler;
		if (handler.syncId != job.syncId || handler.slots.size() <= job.containerSlots) {
			job = null;
			return;
		}
		if (SwapPause.isBusy() || System.currentTimeMillis() < job.nextStepAt) return;

		boolean done = switch (job.type) {
			case SORT -> sortStep(client, handler);
			case THROW -> throwStep(client, handler);
			case DEPOSIT -> transferStep(client, handler, true);
			case WITHDRAW -> transferStep(client, handler, false);
		};
		if (done) {
			job = null;
		} else {
			job.nextStepAt = System.currentTimeMillis() + STEP_DELAY_MS;
		}
	}

	/** Добавить кнопки под любой контейнерный HandledScreen. */
	public static void renderButtons(DrawContext context, HandledScreen<?> screen,
			int screenY, int backgroundHeight, int mouseX, int mouseY) {
		if (NeuClient.getInstance() != null && NeuClient.getInstance().isPanicked()) return;
		if (!isStorageScreen(screen)) return;
		MinecraftClient client = MinecraftClient.getInstance();
		int totalWidth = LABELS.length * BUTTON_WIDTH + (LABELS.length - 1) * BUTTON_GAP;
		int left = (client.getWindow().getScaledWidth() - totalWidth) / 2;
		int top = screenY + backgroundHeight + 4;
		if (top + BUTTON_HEIGHT > client.getWindow().getScaledHeight()) {
			top = screenY - BUTTON_HEIGHT - 4;
		}
		int accent = RenderUtil.accent();
		for (int i = 0; i < LABELS.length; i++) {
			int x = left + i * (BUTTON_WIDTH + BUTTON_GAP);
			boolean hover = inside(mouseX, mouseY, x, top, BUTTON_WIDTH, BUTTON_HEIGHT);
			RenderUtil.roundRect(context, x, top, BUTTON_WIDTH, BUTTON_HEIGHT, 4,
					hover ? accent : RenderUtil.GUI_BG);
			context.drawCenteredTextWithShadow(client.textRenderer, Text.literal(LABELS[i]),
					x + BUTTON_WIDTH / 2, top + 5, RenderUtil.TEXT);
		}
	}

	/** Перехватить ЛКМ по кнопке. */
	public static boolean handleButtonClick(HandledScreen<?> screen,
			double mouseX, double mouseY, int button, int screenY, int backgroundHeight) {
		if (button != 0) return false;
		if (NeuClient.getInstance() != null && NeuClient.getInstance().isPanicked()) return false;
		if (!isStorageScreen(screen)) return false;
		MinecraftClient client = MinecraftClient.getInstance();
		if (client.player == null) return false;
		int totalWidth = LABELS.length * BUTTON_WIDTH + (LABELS.length - 1) * BUTTON_GAP;
		int left = (client.getWindow().getScaledWidth() - totalWidth) / 2;
		int top = screenY + backgroundHeight + 4;
		if (top + BUTTON_HEIGHT > client.getWindow().getScaledHeight()) {
			top = screenY - BUTTON_HEIGHT - 4;
		}
		for (int i = 0; i < LABELS.length; i++) {
			int x = left + i * (BUTTON_WIDTH + BUTTON_GAP);
			if (!inside(mouseX, mouseY, x, top, BUTTON_WIDTH, BUTTON_HEIGHT)) continue;
			startJob(client, switch (i) {
				case 0 -> JobType.SORT;
				case 1 -> JobType.THROW;
				case 2 -> JobType.DEPOSIT;
				default -> JobType.WITHDRAW;
			});
			return true;
		}
		return false;
	}

	private static boolean isStorageScreen(HandledScreen<?> screen) {
		// CreativeInventoryScreen тоже является HandledScreen и имеет много
		// слотов, поэтому простой size() проверки недостаточно.
		return !(screen instanceof InventoryScreen)
				&& !(screen instanceof CreativeInventoryScreen)
				&& screen.getScreenHandler() != null
				&& screen.getScreenHandler().slots.size() > 36;
	}

	private static void startJob(MinecraftClient client, JobType type) {
		ClientPlayerEntity player = client.player;
		if (player == null || player.currentScreenHandler == player.playerScreenHandler) return;
		ScreenHandler handler = player.currentScreenHandler;
		int containerSlots = handler.slots.size() - 36;
		if (containerSlots <= 0) return;
		List<String> desired = type == JobType.SORT ? snapshotSortedKeys(handler, containerSlots) : List.of();
		job = new Job(type, handler.syncId, containerSlots, desired);
		job.nextStepAt = 0L;
	}

	/**
	 * Снимок сортировки: сначала тип предмета, затем полный registry id.
	 * Порядок групп: мечи → топоры → копья → дерево → остальные типы
	 * по алфавиту. Внутри группы предметы идут от a до z.
	 */
	private static List<String> snapshotSortedKeys(ScreenHandler handler, int containerSlots) {
		List<SortEntry> entries = new ArrayList<>();
		for (int i = 0; i < containerSlots; i++) {
			ItemStack stack = handler.getSlot(i).getStack();
			String key = stack.isEmpty() ? "" : itemKey(stack);
			entries.add(new SortEntry(key, itemTypeKey(stack)));
		}
		entries.sort(Comparator.comparing(SortEntry::typeKey).thenComparing(SortEntry::key));
		List<String> keys = new ArrayList<>();
		for (SortEntry entry : entries) {
			keys.add(entry.key());
		}
		return keys;
	}

	private static String itemTypeKey(ItemStack stack) {
		if (stack.isEmpty()) return "99_empty";
		String key = itemKey(stack);
		String path = key.contains(":") ? key.substring(key.indexOf(':') + 1) : key;

		if (path.endsWith("_sword")) return "01_swords";
		if (path.endsWith("_axe")) return "02_axes";
		if (path.equals("trident") || path.contains("spear")) return "03_spears";
		if (path.contains("log") || path.contains("wood") || path.contains("plank")
				|| path.contains("sapling") || path.contains("leaves")) return "04_wood";
		if (path.endsWith("_helmet") || path.endsWith("_chestplate")
				|| path.endsWith("_leggings") || path.endsWith("_boots")
				|| path.equals("elytra")) return "05_armor";
		if (path.endsWith("_pickaxe") || path.endsWith("_shovel")
				|| path.endsWith("_hoe") || path.equals("shears")) return "06_tools";
		if (stack.contains(DataComponentTypes.FOOD)) return "07_food";
		if (path.contains("potion") || path.equals("milk_bucket")) return "08_potions";
		if (stack.getItem() instanceof BlockItem) return "09_blocks";
		if (path.contains("ore") || path.contains("ingot") || path.contains("nugget")
				|| path.contains("raw_") || path.equals("diamond") || path.equals("emerald")) {
			return "10_resources";
		}
		return "11_" + path;
	}

	private static boolean sortStep(MinecraftClient client, ScreenHandler handler) {
		// Мгновенно: проходим все слоты за один тик.
		while (job.index < job.containerSlots) {
			String wanted = job.desired.get(job.index);
			String current = itemKey(handler.getSlot(job.index).getStack());
			if (!wanted.equals(current)) {
				int source = findItemSlot(handler, job.index + 1, job.containerSlots, wanted);
				if (source >= 0) {
					swapSlots(client, handler, source, job.index);
				}
			}
			job.index++;
		}
		return true;
	}

	private static int findItemSlot(ScreenHandler handler, int from, int to, String key) {
		for (int i = from; i < to; i++) {
			if (key.equals(itemKey(handler.getSlot(i).getStack()))) return i;
		}
		return -1;
	}

	/** Сортировка через PICKUP — те же клики, что делает игрок вручную. */
	private static void swapSlots(MinecraftClient client, ScreenHandler handler,
			int source, int target) {
		ClientPlayerEntity player = client.player;
		client.interactionManager.clickSlot(handler.syncId, handler.getSlot(source).id,
				0, SlotActionType.PICKUP, player);
		client.interactionManager.clickSlot(handler.syncId, handler.getSlot(target).id,
				0, SlotActionType.PICKUP, player);
		if (!handler.getCursorStack().isEmpty()) {
			client.interactionManager.clickSlot(handler.syncId, handler.getSlot(source).id,
					0, SlotActionType.PICKUP, player);
		}
	}

	private static boolean throwStep(MinecraftClient client, ScreenHandler handler) {
		// Мгновенно: выбрасываем все занятые слоты за один тик.
		while (job.index < job.containerSlots) {
			Slot slot = handler.getSlot(job.index++);
			if (!slot.getStack().isEmpty()) {
				// THROW button 1 = выбросить весь стак.
				client.interactionManager.clickSlot(handler.syncId, slot.id, 1,
						SlotActionType.THROW, client.player);
			}
		}
		return true;
	}

	/** Shift+ЛКМ по каждому слоту: deposit=true — игрок → хранилище. */
	private static boolean transferStep(MinecraftClient client, ScreenHandler handler,
			boolean deposit) {
		int from = deposit ? job.containerSlots : 0;
		int to = deposit ? handler.slots.size() : job.containerSlots;
		// Мгновенно: переносим все подходящие слоты за один тик.
		while (job.index < to - from) {
			int listIndex = from + job.index++;
			Slot slot = handler.getSlot(listIndex);
			if (slot.getStack().isEmpty()) continue;
			if (deposit && slot.inventory != client.player.getInventory()) continue;
			if (!deposit && listIndex >= job.containerSlots) continue;
			client.interactionManager.clickSlot(handler.syncId, slot.id, 0,
					SlotActionType.QUICK_MOVE, client.player);
		}
		return true;
	}

	private static String itemKey(ItemStack stack) {
		return stack.isEmpty() ? "" : Registries.ITEM.getId(stack.getItem()).toString();
	}

	private static boolean inside(double x, double y, int left, int top, int width, int height) {
		return x >= left && x < left + width && y >= top && y < top + height;
	}
}
