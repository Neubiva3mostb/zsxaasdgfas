package ru.neuclient.client.mixin;

import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.neuclient.client.module.impl.combat.AttackAuraModule;

/**
 * Легитный сброс спринта для AttackAura («Сброс спринта»).
 *
 * КАК В ЖИВОЙ ИГРОК: тот на мгновение «отжимает» кнопку спринта и не даёт
 * ему начаться заново. Здесь это выражено двумя ванильными решениями:
 *  - canSprint(false) -> false: спринт невозможно НАЧАТЬ (и удерживать);
 *  - shouldStopSprinting() -> true: текущий спринт ваниль сама останавливает.
 *
 * ПАКЕТЫ НЕ ТРОГАЕМ: ни STOP_SPRINTING, ни START_SPRINTING руками не
 * отправляются — sendSprintingPacket сам синхронизирует флаг, когда ваниль
 * в обычном порядке меняет isSprinting(). Для анти-чита это неотличимо от
 * того, что игрок на долю секунды отпустил кнопку.
 */
@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerEntitySprintMixin {

	@Inject(method = "canSprint(Z)Z", at = @At("HEAD"), cancellable = true)
	private void pc$disallowSprint(boolean sprinting, CallbackInfoReturnable<Boolean> cir) {
		AttackAuraModule aura = AttackAuraModule.active();
		if ((aura != null && aura.shouldPreventSprinting())
				|| ru.neuclient.client.module.impl.combat.TriggerBotModule.shouldHoldSprintForCrit()) {
			cir.setReturnValue(false);
		}
	}

	@Inject(method = "shouldStopSprinting()Z", at = @At("HEAD"), cancellable = true)
	private void pc$stopSprint(CallbackInfoReturnable<Boolean> cir) {
		AttackAuraModule aura = AttackAuraModule.active();
		if ((aura != null && aura.shouldPreventSprinting())
				|| ru.neuclient.client.module.impl.combat.TriggerBotModule.shouldHoldSprintForCrit()) {
			cir.setReturnValue(true);
		}
	}
}
