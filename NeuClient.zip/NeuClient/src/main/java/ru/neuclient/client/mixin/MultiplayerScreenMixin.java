package ru.neuclient.client.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerServerListWidget;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.client.option.ServerList;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.config.ProxyHandler;
import ru.neuclient.client.ui.ProxyConfigScreen;

/**
 * Добавляет кнопку «Proxy» и гарантирует наличие серверов FunTime, HollyWorld, ReallyWorld
 * в списке сетевой игры (MultiplayerScreen).
 * При панике (.panic) ничего лишнего на экран не добавляется.
 */
@Mixin(MultiplayerScreen.class)
public abstract class MultiplayerScreenMixin extends Screen {

	@Shadow
	private ServerList serverList;

	@Shadow
	protected MultiplayerServerListWidget serverListWidget;

	protected MultiplayerScreenMixin(Text title) {
		super(title);
	}

	@Inject(method = "init", at = @At("TAIL"))
	private void pc$initMultiplayer(CallbackInfo ci) {
		if (NeuClient.getInstance() != null && NeuClient.getInstance().isPanicked()) {
			return;
		}
		try {
			// 1. Кнопка Proxy
			String label = ProxyHandler.isActive() ? "§aProxy" : "Proxy";
			this.addDrawableChild(ButtonWidget.builder(Text.literal(label), button -> {
				MinecraftClient.getInstance().setScreen(
						new ProxyConfigScreen((MultiplayerScreen) (Object) this));
			}).dimensions(this.width / 2 + 154 + 4, this.height - 28, 74, 20).build());

			// 2. Гарантированное добавление серверов FunTime, HollyWorld, ReallyWorld
			if (this.serverList != null) {
				boolean modified = false;
				if (pc$ensureServer("FunTime", "neo.funtime.sh")) {
					modified = true;
				}
				if (pc$ensureServer("HollyWorld", "hub.holyworld.ru")) {
					modified = true;
				}
				if (pc$ensureServer("ReallyWorld", "mc.reallyworld.me")) {
					modified = true;
				}

				if (modified) {
					this.serverList.saveFile();
					if (this.serverListWidget != null) {
						this.serverListWidget.setServers(this.serverList);
					}
				}
			}
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Не удалось инициализировать MultiplayerScreen", t);
		}
	}

	/**
	 * Гарантирует сервер с точным именем и адресом: добавляет, если нет,
	 * и обновляет адрес при смене IP (миграция ReallyWorld → mc.reallyworld.me).
	 */
	private boolean pc$ensureServer(String name, String address) {
		for (int i = 0; i < this.serverList.size(); i++) {
			ServerInfo s = this.serverList.get(i);
			if (s != null && name.equalsIgnoreCase(s.name)) {
				if (s.address == null || !address.trim().equalsIgnoreCase(s.address.trim())) {
					s.address = address;
					return true;
				}
				return false;
			}
		}
		this.serverList.add(new ServerInfo(name, address, ServerInfo.ServerType.OTHER), false);
		return true;
	}
}
