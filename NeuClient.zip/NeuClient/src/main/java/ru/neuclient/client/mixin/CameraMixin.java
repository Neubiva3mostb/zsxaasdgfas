package ru.neuclient.client.mixin;

import net.minecraft.client.render.Camera;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.impl.player.FreeCamModule;
import ru.neuclient.client.module.impl.render.NoRenderModule;

/**
 * Надстройки камеры:
 *  - NoRender «Свободная камера»: камера от третьего лица не упирается в блоки (clipToSpace);
 *  - FreeCam: свободный полет камеры;
 */
@Mixin(Camera.class)
public abstract class CameraMixin {

	@Inject(method = "clipToSpace", at = @At("HEAD"), cancellable = true)
	private void pc$freeCamera(float desiredCameraDistance, CallbackInfoReturnable<Float> cir) {
		NeuClient client = NeuClient.getInstance();
		if (client == null || client.getModuleManager() == null) {
			return;
		}
		NoRenderModule module = client.getModuleManager().get(NoRenderModule.class);
		if (module != null && module.freeCamera()) {
			cir.setReturnValue(desiredCameraDistance);
		}
	}

	@Inject(method = "update", at = @At("TAIL"))
	private void pc$freeCamPosition(World world, Entity focusedEntity, boolean thirdPerson,
			boolean inverseView, float tickDelta, CallbackInfo ci) {
		try {
			NeuClient client = NeuClient.getInstance();
			if (client == null || client.getModuleManager() == null) {
				return;
			}
			FreeCamModule module = client.getModuleManager().get(FreeCamModule.class);
			if (module != null && module.isEnabled() && module.isInitialized()) {
				CameraAccessor accessor = (CameraAccessor) this;
				Vec3d pos = new Vec3d(module.getCamX(tickDelta), module.getCamY(tickDelta),
						module.getCamZ(tickDelta));
				accessor.pc$setPos(pos);
				accessor.pc$getBlockPos().set(pos.x, pos.y, pos.z);
				// Свободные углы камеры: мышь крутит камеру, а не тело игрока.
				accessor.pc$setRotation(module.getCamYaw(), module.getCamPitch());
			}
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка FreeCam камеры", t);
		}
	}
}
