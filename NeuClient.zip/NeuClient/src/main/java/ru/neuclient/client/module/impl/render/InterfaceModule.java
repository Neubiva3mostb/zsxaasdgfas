package ru.neuclient.client.module.impl.render;

import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.BooleanSetting;
import ru.neuclient.client.setting.ColorSetting;
import ru.neuclient.client.util.RenderUtil;

/**
 * Interface — визуальный модуль интерфейса игрока.
 * Хранит настройки видимости элементов HUD и общий цвет интерфейса/HUD/ClickGUI.
 */
public class InterfaceModule extends Module {

	private final BooleanSetting nickname = new BooleanSetting("Никнейм", true);
	private final BooleanSetting uid = new BooleanSetting("UID", true);
	private final BooleanSetting coordinates = new BooleanSetting("Координаты", true);
	private final BooleanSetting ping = new BooleanSetting("Пинг", true);
	private final BooleanSetting fps = new BooleanSetting("FPS", true);
	private final BooleanSetting tps = new BooleanSetting("TPS", true);
	private final BooleanSetting bps = new BooleanSetting("BPS", true);
	private final BooleanSetting armor = new BooleanSetting("Броня", true);
	private final BooleanSetting effects = new BooleanSetting("Эффекты", true);
	private final BooleanSetting activeModules = new BooleanSetting("Бинды", true);
	private final BooleanSetting targetHud = new BooleanSetting("Таргет худ", true);

	// Единый цвет интерфейса: меняет цвет и в ClickGUI, и во всём HUD
	private final ColorSetting general = new ColorSetting("Общий", 0xFF7A5CFF);

	public InterfaceModule() {
		super("Interface", "Интерфейс NeuClient", Category.RENDER);
		general.onChange(() -> {
			RenderUtil.setThemeColor("accent", general.get());
		});
		addSettings(
				nickname, uid, coordinates, ping, fps, tps, bps, armor, effects, activeModules, targetHud,
				general
		);

		// HUD включён из коробки
		setEnabled(true);
	}

	public int getGeneralColor() {
		return general.get();
	}

	public int getWatermarkColor() {
		return general.get();
	}

	public int getBindsColor() {
		return general.get();
	}

	public int getTargetHudColor() {
		return general.get();
	}

	public int getArmorColor() {
		return general.get();
	}

	public int getEffectsColor() {
		return general.get();
	}

	public int getGeneralAccent() {
		return general.get();
	}

	/** Видимость элемента HUD по его идентификатору. */
	public boolean isElementVisible(String id) {
		return switch (id) {
			case "watermark" -> true;
			case "nickname" -> nickname.get();
			case "uid" -> uid.get();
			case "coordinates" -> coordinates.get();
			case "ping" -> ping.get();
			case "fps" -> fps.get();
			case "tps" -> tps.get();
			case "bps" -> bps.get();
			case "armor" -> armor.get();
			case "effects" -> effects.get();
			case "activemodules" -> activeModules.get();
			case "targethud" -> targetHud.get();
			default -> true;
		};
	}
}
