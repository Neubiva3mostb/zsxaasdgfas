package ru.neuclient.client.render;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.minecraft.client.gui.ScreenRect;
import net.minecraft.client.gui.render.state.SimpleGuiElementRenderState;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.texture.TextureSetup;
import org.joml.Matrix3x2f;

/** GUI-элемент скруглённого прямоугольника с настоящим SDF-антиалиасингом. */
public record RoundedRectGuiElementRenderState(
		Matrix3x2f pose,
		float x,
		float y,
		float width,
		float height,
		float radius,
		int argb,
		ScreenRect scissorArea,
		ScreenRect bounds
) implements SimpleGuiElementRenderState {

	@Override
	public void setupVertices(VertexConsumer buffer) {
		// UV — нормированные координаты внутри quad. Фрагментный shader
		// восстанавливает размер quad через fwidth и считает SDF в пикселях.
		// Matrix3x2f — это GUI-поза без отдельной Z-координаты.
		buffer.vertex(pose, x, y).texture(0.0f, 0.0f).color(argb);
		buffer.vertex(pose, x, y + height).texture(0.0f, 1.0f).color(argb);
		buffer.vertex(pose, x + width, y + height).texture(1.0f, 1.0f).color(argb);
		buffer.vertex(pose, x + width, y).texture(1.0f, 0.0f).color(argb);
	}

	@Override
	public RenderPipeline pipeline() {
		return RoundedRectPipeline.PIPELINE;
	}

	@Override
	public TextureSetup textureSetup() {
		return TextureSetup.empty();
	}
}
