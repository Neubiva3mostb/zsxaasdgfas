package ru.neuclient.client.render;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.LayeringTransform;
import net.minecraft.client.render.OutputTarget;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderSetup;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;
import ru.neuclient.client.mixin.RenderLayerAccessor;

/**
 * Слои отрисовки Chams — силуэт сущности сквозь стены.
 *
 * Как это работает. Слой подменяется в {@code LivingEntityRenderer#getRenderLayer}
 * (см. LivingEntityRendererMixin): ваниль сама рисует модель, со всеми
 * трансформациями, позой и частями тела, но в наш пайплайн. От ванильного
 * слоя он отличается двумя вещами:
 *
 *  • {@code DepthTestFunction.NO_DEPTH_TEST} — тест глубины выключен,
 *    поэтому силуэт рисуется поверх блоков и виден сквозь стену;
 *  • шейдер core/chams игнорирует текстуру и свет, оставляя сплошной цвет.
 *
 * Прозрачность зашита в шейдере числом (почему — см. комментарий в
 * core/chams.fsh), поэтому на каждый шаг прозрачности создан отдельный
 * RenderLayer. Десять слоёв по 0.1 создают один раз при инициализации
 * клиента и дальше только переиспользуются.
 *
 * Цель вывода — MAIN_TARGET: сущности рисуются в основной фреймбуфер, а не
 * в отдельный ITEM_ENTITY_TARGET, которым пользуются GUI-слои клиента.
 */
public final class ChamsRenderLayer {

	/** Сколько шагов прозрачности поддерживается (0.1 … 1.0). */
	public static final int ALPHA_STEPS = 10;

	private static final RenderPipeline PIPELINE = RenderPipelines.register(
			RenderPipeline.builder()
					.withLocation(Identifier.of("perfstream", "pipeline/chams"))
					.withVertexShader(Identifier.of("perfstream", "core/chams"))
					.withFragmentShader(Identifier.of("perfstream", "core/chams"))
					.withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR, VertexFormat.DrawMode.QUADS)
					.withUniform("DynamicTransforms", UniformType.UNIFORM_BUFFER)
					.withUniform("Projection", UniformType.UNIFORM_BUFFER)
					.withBlend(BlendFunction.TRANSLUCENT)
					.withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
					.withCull(false)
					.withColorWrite(true, true)
					.build()
	);

	/** Слои по шагам прозрачности; индекс 0 = 0.1, индекс 9 = 1.0. */
	private static final RenderLayer[] LAYERS = new RenderLayer[ALPHA_STEPS];

	static {
		for (int i = 0; i < ALPHA_STEPS; i++) {
			LAYERS[i] = RenderLayerAccessor.pc$of("neuclient_chams_" + ((i + 1) * 10),
					RenderSetup.builder(PIPELINE)
							.layeringTransform(LayeringTransform.NO_LAYERING)
							.outputTarget(OutputTarget.MAIN_TARGET)
							.build());
		}
	}

	/**
	 * Слой под запрошенную прозрачность.
	 *
	 * @param alpha 0.0 … 1.0; значение округляется до ближайшего шага 0.1
	 */
	public static RenderLayer get(float alpha) {
		int index = Math.round(Math.max(0.0f, Math.min(1.0f, alpha)) * ALPHA_STEPS) - 1;
		if (index < 0) {
			index = 0;
		}
		if (index >= ALPHA_STEPS) {
			index = ALPHA_STEPS - 1;
		}
		return LAYERS[index];
	}

	/** Явная инициализация pipeline и слоёв. */
	public static void touch() {
	}

	private ChamsRenderLayer() {
	}
}
