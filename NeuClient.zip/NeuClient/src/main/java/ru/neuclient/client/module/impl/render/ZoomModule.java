package ru.neuclient.client.module.impl.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.KeyBindSetting;
import ru.neuclient.client.setting.NumberSetting;

/**
 * Zoom — плавное приближение на зажатой клавише (как OptiFine/Zoomify).
 *
 * Клавиша — настоящий бинд: в настройках ЛКМ по строке «Клавиша» → жмёшь
 * любую кнопку (Esc снимает). Базово Z.
 *
 * Пока держится клавиша, FOV плавно сжимается до значения, заданного
 * \"Дальность приближения\" (процент глубины зума: 0 — почти без эффекта,
 * 100 — максимальный телескоп). Чисто клиентский рендер-сайд хук
 * (GameRenderer.getFov), серверу ничего не шлётся.
 */
public final class ZoomModule extends Module {

	private final KeyBindSetting key = new KeyBindSetting("Клавиша", GLFW.GLFW_KEY_Z);
	private final NumberSetting speed = new NumberSetting("Дальность приближения", 20.0, 0.0, 100.0, 1.0);

	/** Текущий множитель FOV (1.0 = без зума). Плавно движется к цели. */
	private float current = 1.0f;

	/**
	 * Множитель на ПРОШЛОМ тике.
	 *
	 * Зум пересчитывается раз в тик, а кадров рисуется больше. Без
	 * интерполяции проекция для меток (NameTags и прочее) обновлялась бы
	 * скачками раз в 50 мс, отставая от плавно наезжающей картинки —
	 * метки заметно «плыли» бы во время наезда.
	 */
	private float previous = 1.0f;

	public ZoomModule() {
		super("Zoom", "Приближение экрана", Category.RENDER);
		addSettings(key, speed);
	}

	@Override
	public void onTick(MinecraftClient client) {
		previous = current;
		// В ClickGUI/инвентаре/чате зум не работает (клавиша игнорируется,
		// текущий зум плавно возвращается к 1.0)
		float target = !blockingScreen(client) && isKeyHeld(client) ? targetMultiplier() : 1.0f;
		// Плавность: экспоненциальное приближение к цели каждый тик
		current = MathHelper.lerp(0.35f, current, target);
		if (Math.abs(target - current) < 0.001f) {
			current = target;
		}
	}

	/** Целевой множитель FOV при полностью зажатой клавише. */
	private float targetMultiplier() {
		double depth = speed.get() / 100.0; // 0..1
		return (float) (1.0 - 0.95 * depth);
	}

	/** Множитель FOV для GameRenderer-хука (1.0 — без изменений). */
	public float getFovMultiplier() {
		// Не ждём следующего тика: при открытии GUI зум должен исчезнуть сразу.
		return blockingScreen(mc) ? 1.0f : current;
	}

	/**
	 * Множитель, сглаженный внутри кадра.
	 *
	 * @param tickDelta доля текущего тика (0..1)
	 */
	public float getFovMultiplier(float tickDelta) {
		return blockingScreen(mc) ? 1.0f : MathHelper.lerp(tickDelta, previous, current);
	}

	private boolean isKeyHeld(MinecraftClient client) {
		if (client.getWindow() == null || key.get() == KeyBindSetting.NONE) {
			return false;
		}
		return InputUtil.isKeyPressed(client.getWindow(), key.get());
	}

	@Override
	protected void onDisable() {
		current = 1.0f;
		previous = 1.0f;
	}
}
