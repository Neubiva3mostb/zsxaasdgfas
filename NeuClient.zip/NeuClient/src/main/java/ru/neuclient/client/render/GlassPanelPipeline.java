package ru.neuclient.client.render;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;

/**
 * Пайплайн «стеклянной» подложки колонок ClickGUI.
 *
 * Один quad на панель: SDF-скругление, бегущие волны и подсветка гребней
 * акцентом считаются во фрагментном шейдере (core/glass_panel), поэтому
 * никаких циклов ctx.fill и дополнительных слоёв не нужно.
 *
 * Текстура не используется — эффект синтезируется, поэтому здесь нет
 * withSampler, а элемент рендера возвращает TextureSetup.empty().
 */
public final class GlassPanelPipeline {

	public static final RenderPipeline PIPELINE = RenderPipelines.register(
			RenderPipeline.builder()
					.withLocation(Identifier.of("perfstream", "pipeline/glass_panel"))
					.withVertexShader(Identifier.of("perfstream", "core/glass_panel"))
					.withFragmentShader(Identifier.of("perfstream", "core/glass_panel"))
					.withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR, VertexFormat.DrawMode.QUADS)
					.withUniform("DynamicTransforms", UniformType.UNIFORM_BUFFER)
					.withUniform("Projection", UniformType.UNIFORM_BUFFER)
					.withBlend(BlendFunction.TRANSLUCENT)
					.withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
					.withCull(false)
					.withColorWrite(true, true)
					.build()
	);

	/** Явная инициализация pipeline. */
	public static void touch() {
	}

	private GlassPanelPipeline() {
	}
}
