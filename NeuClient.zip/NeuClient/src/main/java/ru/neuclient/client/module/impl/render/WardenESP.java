package ru.neuclient.client.module.impl.render;

import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.render.LayeringTransform;
import net.minecraft.client.render.OutputTarget;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderSetup;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.mixin.RenderLayerAccessor;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.render.WorldRenderUtil;
import ru.neuclient.client.render.WorldToScreen;
import ru.neuclient.client.setting.NumberSetting;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class WardenESP extends Module {

    private static final Pattern TIMER_PATTERN = Pattern.compile("(\\d{1,2})[:.](\\d{1,2})");

    private final NumberSetting showSeconds = new NumberSetting("Показывать за (сек)", 30, 5, 120, 5);
    private final ru.neuclient.client.setting.BooleanSetting highlightWarden =
            new ru.neuclient.client.setting.BooleanSetting("Подсветка вардена", true);
    private final ru.neuclient.client.setting.BooleanSetting wardenGlow =
            new ru.neuclient.client.setting.BooleanSetting("Свечение вардена", true);

    /** Вардены, которым мы включили glow (чтобы снять при выключении). */
    private final Set<net.minecraft.entity.mob.WardenEntity> glowing = new HashSet<>();

    private final Map<BlockPos, long[]> activeChests = new HashMap<>();
    private long lastMessageTime = 0;

    private static final double ACTIVATION_DISTANCE = 50.0;
    /** Дистанция «стоим вплотную»: здесь отсутствие стойки значит, что таймер снят. */
    private static final double CLOSE_CHECK_DISTANCE = 8.0;
    /** Раз в сколько тиков принудительно перечитываем таймеры у близких сундуков. */
    private static final int RESYNC_INTERVAL = 20;
    /** Дальше этого расстояния ре-синк не делаем (стойки всё равно не видны). */
    private static final double RESYNC_DISTANCE = 40.0;
    /** Счётчик тиков до следующего ре-синка. */
    private int resyncTimer;

    // === Память таймеров по анархиям (перезаход не сбрасывает) ===
    /** В сайдбаре сервер пишет «Анархия-N» — по нему и раскладываем таймеры. */
    private static final Pattern ANARCHY_PATTERN = Pattern.compile("(?iu)анархия\\s*[-—#:]?\\s*(\\d+)");
    private static final java.nio.file.Path timersFile =
            ru.neuclient.client.util.ClientPaths.file("warden_timers.json");
    /** Ключ текущей анархии ("" — ещё не определили по скорборду). */
    private String currentAnarchy = "";
    /** Анархия -> (сундук -> [timestampMs, seconds]) — живёт и после перезахода. */
    private final Map<String, Map<BlockPos, long[]>> anarchyTimers = new HashMap<>();
    private int anarchyCheckTimer;
    private net.minecraft.client.world.ClientWorld espLastWorld;
    /** Когда последний раз сменился мир: в первые ~15 с сундуки не вычищаем (чанки/стойки ещё едут). */
    private long espWorldChangedAt;

    // === ТОЧНО КАК В GpsManager ===
    private static final double BEAM_HALF = 0.3;
    private static final double GLOW_HALF = 1.0;
    private static final float BEAM_ALPHA = 0.45f;
    private static final float GLOW_ALPHA = 0.10f;

    /** Залитые боксы без глубины (луч виден сквозь блоки). */
    private static final RenderLayer BEAM_LAYER = RenderLayerAccessor.pc$of("neuclient_warden_beam",
            RenderSetup.builder(RenderPipelines.DEBUG_FILLED_BOX)
                    .layeringTransform(LayeringTransform.VIEW_OFFSET_Z_LAYERING)
                    .outputTarget(OutputTarget.ITEM_ENTITY_TARGET)
                    .build());

    public WardenESP() {
        super("WardenESP", "Таймер на сундуках вардена", Category.RENDER);
        addSettings(showSeconds, highlightWarden, wardenGlow);
        loadTimersFile();
    }

    /** Номер анархии из скорборда («Анархия-N» в заголовке или строках) или null. */
    private String detectAnarchy() {
        try {
            net.minecraft.scoreboard.Scoreboard sb = mc.world.getScoreboard();
            // §-коды обязаны быть убраны ДО регэкспа: «Анархия§c-2» без чистки не матчится
            net.minecraft.scoreboard.ScoreboardDisplaySlot[] slots;
            try {
                slots = net.minecraft.scoreboard.ScoreboardDisplaySlot.values();
            } catch (Throwable t) {
                slots = new net.minecraft.scoreboard.ScoreboardDisplaySlot[]{
                        net.minecraft.scoreboard.ScoreboardDisplaySlot.SIDEBAR};
            }

            for (net.minecraft.scoreboard.ScoreboardDisplaySlot slot : slots) {
                net.minecraft.scoreboard.ScoreboardObjective obj = sb.getObjectiveForSlot(slot);
                if (obj == null) continue;

                Matcher m = ANARCHY_PATTERN.matcher(
                        obj.getDisplayName().getString().replaceAll("§.", ""));
                if (m.find()) return m.group(1);

                for (net.minecraft.scoreboard.ScoreboardEntry e : sb.getScoreboardEntries(obj)) {
                    Matcher m2 = ANARCHY_PATTERN.matcher(e.display().getString().replaceAll("§.", ""));
                    if (m2.find()) return m2.group(1);
                }
            }
        } catch (Throwable ignored) {}
        return null;
    }

    /** Копия активных таймеров (только живые, с остатком > 0). */
    private Map<BlockPos, long[]> snapshot() {
        Map<BlockPos, long[]> out = new HashMap<>();
        for (Map.Entry<BlockPos, long[]> e : activeChests.entrySet()) {
            if (getRemainingSeconds(e.getValue()) > 0) out.put(e.getKey(), e.getValue());
        }
        return out;
    }

    /**
     * Смена анархии по скорборду: текущие таймеры убираем в память под старым
     * номером, под новым — восстанавливаем сохранённые (отсчёт продолжается,
     * т.к. храним метку времени + секунды на момент записи).
     */
    private void checkAnarchy(boolean worldChanged) {
        String an = detectAnarchy();
        if (an != null && !an.equals(currentAnarchy)) {
            if (!currentAnarchy.isEmpty()) anarchyTimers.put(currentAnarchy, snapshot());
            currentAnarchy = an;
        }

        if (worldChanged) {
            // Перезаход (в т.ч. на ТУ ЖЕ анархию): всегда разворачиваем
            // сохранённый снимок — раньше ветка «an == current» выходила
            // раньше восстановления, и таймеры пропадали.
            if (!currentAnarchy.isEmpty()) {
                activeChests.clear();
                Map<BlockPos, long[]> saved = anarchyTimers.get(currentAnarchy);
                if (saved != null) {
                    for (Map.Entry<BlockPos, long[]> e : saved.entrySet()) {
                        if (getRemainingSeconds(e.getValue()) > 0) {
                            activeChests.put(e.getKey(), e.getValue());
                        }
                    }
                }
            }
            espWorldChangedAt = System.currentTimeMillis();
            saveTimersFile();
        }
    }

    /** Раз в 20 с освежаем снимок текущей анархии (ресинк уточняет отсчёты). */
    private void periodicSave() {
        if (currentAnarchy.isEmpty()) return;
        anarchyTimers.put(currentAnarchy, snapshot());
        saveTimersFile();
    }

    private void saveTimersFile() {
        try {
            com.google.gson.JsonObject root = new com.google.gson.JsonObject();
            for (Map.Entry<String, Map<BlockPos, long[]>> an : anarchyTimers.entrySet()) {
                com.google.gson.JsonArray list = new com.google.gson.JsonArray();
                for (Map.Entry<BlockPos, long[]> e : an.getValue().entrySet()) {
                    if (getRemainingSeconds(e.getValue()) <= 0) continue;
                    com.google.gson.JsonArray a = new com.google.gson.JsonArray();
                    a.add(e.getKey().getX());
                    a.add(e.getKey().getY());
                    a.add(e.getKey().getZ());
                    a.add(e.getValue()[0]);
                    a.add(e.getValue()[1]);
                    list.add(a);
                }
                root.add(an.getKey(), list);
            }
            java.nio.file.Files.writeString(timersFile, root.toString());
        } catch (Throwable ignored) {}
    }

    private void loadTimersFile() {
        try {
            if (!java.nio.file.Files.exists(timersFile)) return;
            com.google.gson.JsonElement el = com.google.gson.JsonParser.parseString(
                    java.nio.file.Files.readString(timersFile));
            if (!el.isJsonObject()) return;
            for (Map.Entry<String, com.google.gson.JsonElement> an : el.getAsJsonObject().entrySet()) {
                Map<BlockPos, long[]> map = new HashMap<>();
                for (com.google.gson.JsonElement e : an.getValue().getAsJsonArray()) {
                    com.google.gson.JsonArray a = e.getAsJsonArray();
                    BlockPos pos = new BlockPos(a.get(0).getAsInt(), a.get(1).getAsInt(), a.get(2).getAsInt());
                    map.put(pos, new long[]{a.get(3).getAsLong(), a.get(4).getAsLong()});
                }
                anarchyTimers.put(an.getKey(), map);
            }
        } catch (Throwable ignored) {}
    }

    @Override
    public void onEnable() {
        activeChests.clear();
        lastMessageTime = 0;
        espWorldChangedAt = System.currentTimeMillis();
        // Перезаход/перезапуск не должен терять таймеры: если анархия уже
        // известна — сразу возвращаем её сохранённые отсчёты.
        if (!currentAnarchy.isEmpty()) {
            Map<BlockPos, long[]> saved = anarchyTimers.get(currentAnarchy);
            if (saved != null) {
                for (Map.Entry<BlockPos, long[]> e : saved.entrySet()) {
                    if (getRemainingSeconds(e.getValue()) > 0) activeChests.put(e.getKey(), e.getValue());
                }
            }
        }
    }

    @Override
    public void onDisable() {
        periodicSave();
        activeChests.clear();
        for (net.minecraft.entity.mob.WardenEntity w : glowing) w.setGlowing(false);
        glowing.clear();
    }

    /** Вардены в загруженном мире. */
    private List<net.minecraft.entity.mob.WardenEntity> wardens() {
        List<net.minecraft.entity.mob.WardenEntity> out = new ArrayList<>();
        if (mc.world == null) return out;
        for (Entity e : mc.world.getEntities()) {
            if (e instanceof net.minecraft.entity.mob.WardenEntity w && w.isAlive()) out.add(w);
        }
        return out;
    }

    private void tickWardenGlow() {
        List<net.minecraft.entity.mob.WardenEntity> now = wardens();
        Iterator<net.minecraft.entity.mob.WardenEntity> it = glowing.iterator();
        while (it.hasNext()) {
            net.minecraft.entity.mob.WardenEntity w = it.next();
            if (!wardenGlow.get() || w.isRemoved() || !now.contains(w)) {
                w.setGlowing(false);
                it.remove();
            }
        }
        if (wardenGlow.get()) {
            for (net.minecraft.entity.mob.WardenEntity w : now) {
                if (glowing.add(w)) w.setGlowing(true);
            }
        }
    }

    @Override
    public void onTick(net.minecraft.client.MinecraftClient client) {
        if (mc.player == null || mc.world == null) return;

        // Смена мира/анархии: прячем одни таймеры, достаём другие.
        if (mc.world != espLastWorld) {
            espLastWorld = mc.world;
            anarchyCheckTimer = 0;
            checkAnarchy(true);
        }
        if (++anarchyCheckTimer >= 20) {
            anarchyCheckTimer = 0;
            checkAnarchy(false);
            periodicSave();
        }

        tickWardenGlow();

        // Агрегация за тик. У сундука может быть НЕСКОЛЬКО стоек с таймером:
        // сервер иногда не убирает старую стойку/спавнит дубль. Прежняя логика
        // «кто последний обработан, тот и прав» мигала: у одной стойки 12:21,
        // у протухшего дубля 0:21 — и ESP показывал 21 сек вместо 12 мин.
        // Берём МАКСИМАЛЬНЫЙ таймер среди стоек: протухшая всегда занижена.
        Map<BlockPos, Integer> tickTimers = new HashMap<>();
        for (Entity entity : mc.world.getEntities()) {
            if (!(entity instanceof ArmorStandEntity stand)) continue;
            if (!stand.isCustomNameVisible()) continue;

            int timer = parseTimer(stand);
            if (timer < 0) continue;

            BlockPos chestPos = findChestNear(stand.getBlockPos());
            if (chestPos == null) continue;

            tickTimers.merge(chestPos, timer, Math::max);
        }

        java.util.Set<BlockPos> seen = new java.util.HashSet<>();
        for (Map.Entry<BlockPos, Integer> e : tickTimers.entrySet()) {
            BlockPos chestPos = e.getKey();

            // Новые сундуки добавляем только в радиусе ACTIVATION_DISTANCE.
            // Уже отслеживаемые синхронизируем, пока стойка видна, на любом
            // расстоянии — отсчёт остаётся точным и после отхода.
            if (!activeChests.containsKey(chestPos)) {
                double distance = mc.player.squaredDistanceTo(chestPos.getX() + 0.5,
                        chestPos.getY() + 0.5, chestPos.getZ() + 0.5);
                if (distance > ACTIVATION_DISTANCE * ACTIVATION_DISTANCE) continue;
            }

            seen.add(chestPos);
            // Каждый тик синхронизируем с реальной табличкой — так таймер всегда точный
            activeChests.put(chestPos, new long[]{System.currentTimeMillis(), e.getValue()});
        }

        // Убираем сундук из отслеживания ТОЛЬКО когда таймер реально истёк,
        // сундук разобрали или сервер снял таймер. Само по себе отсутствие
        // стойки-таблички признаком не служит: стойки — сущности, и при
        // отходе сервер перестаёт их слать раньше, чем пропадает сундук.
        // (Старая логика «нет стойки в 42 блоках → снять подсветку» на этом
        // и ломалась: отошёл — и таймеры пропали, хотя сундуки на месте.)
        activeChests.entrySet().removeIf(entry -> {
            BlockPos c = entry.getKey();
            if (seen.contains(c)) return false;
            // Время вышло по локальному отсчёту
            if (getRemainingSeconds(entry.getValue()) < 0) return true;
            // Чанк не загружен — решение откладываем до его загрузки
            if (!mc.world.isChunkLoaded(c)) return false;
            // Первые 15 с после релога ничего не вычищаем: чанк может быть
            // «загружен», но блока и стойки ещё нет — раньше именно это
            // вытирало все таймеры при перезаходе.
            boolean joinGrace = System.currentTimeMillis() - espWorldChangedAt < 15000;
            if (joinGrace) return false;
            // Сундук разобрали/заменили — таймера больше нет
            if (!isChestBlockEntity(c)) return true;
            // Стойки с таймером нет, а мы вплотную (< 8 блоков): на такой
            // дистанции стойки гарантированно приходят с сервера, значит
            // таймер действительно снят, а не «ушёл из зоны трекинга».
            double d = mc.player.squaredDistanceTo(c.getX() + 0.5, c.getY() + 0.5, c.getZ() + 0.5);
            return d < CLOSE_CHECK_DISTANCE * CLOSE_CHECK_DISTANCE && !hasTimerStandNear(c);
        });

        // Гарантированный ре-синк при подходе: даже если общий обход стоек
        // что-то пропустил (флаг имени мигнул, стойка появилась позже),
        // раз в секунду заново перечитываем время у всех близких сундуков.
        if (++resyncTimer >= RESYNC_INTERVAL) {
            resyncTimer = 0;
            resyncNearbyTimers();
        }
    }

    /**
     * Принудительный перечит таймеров: для каждого отслеживаемого сундука
     * в радиусе RESYNC_DISTANCE ищем стойки вокруг НЕГО и берём максимум.
     * Так таймер всегда актуален на момент, когда вы стоите у сундука,
     * а не «запомнен один раз».
     */
    private void resyncNearbyTimers() {
        Map<BlockPos, long[]> updates = new HashMap<>();

        for (Map.Entry<BlockPos, long[]> entry : activeChests.entrySet()) {
            BlockPos chest = entry.getKey();
            double d = mc.player.squaredDistanceTo(chest.getX() + 0.5,
                    chest.getY() + 0.5, chest.getZ() + 0.5);
            if (d > RESYNC_DISTANCE * RESYNC_DISTANCE) continue;

            int best = bestTimerStandNear(chest);
            if (best > 0) {
                updates.put(chest, new long[]{System.currentTimeMillis(), best});
            }
        }

        activeChests.putAll(updates);
    }

	/** Публичный доступ к активным сундукам (для внешних модулей). */
	public Map<BlockPos, long[]> getActiveChests() {
		return new HashMap<>(activeChests);
	}

	public int getRemainingSeconds(long[] data) {
        long activatedTime = data[0];
        int initialTimer = (int) data[1];
        long elapsed = (System.currentTimeMillis() - activatedTime) / 1000;
        return (int) (initialTimer - elapsed);
    }

    private int parseTimer(ArmorStandEntity stand) {
        Text name = stand.getCustomName();
        if (name == null) return -1;

        String text = name.getString().replaceAll("§.", "");
        Matcher matcher = TIMER_PATTERN.matcher(text);
        int found = -1;
        // Берём ПОСЛЕДНЕЕ время в строке: в начале имени бывают числа,
        // не относящиеся к отсчёту («Сундук 7 — 12:21»).
        while (matcher.find()) {
            found = Integer.parseInt(matcher.group(1)) * 60
                    + Integer.parseInt(matcher.group(2));
        }
        return found;
    }

    private BlockPos findChestNear(BlockPos center) {
        if (mc.world == null) return null;

        // Ближайший контейнер, а не первый при обходе: стойка часто стоит
        // между двумя сундуками, и «первый попавшийся» раз за разом мог
        // привязывать её таймер к чужому сундуку.
        BlockPos best = null;
        double bd = Double.MAX_VALUE;

        for (int x = -2; x <= 2; x++) {
            for (int y = -2; y <= 2; y++) {
                for (int z = -2; z <= 2; z++) {
                    BlockPos pos = center.add(x, y, z);
                    BlockEntity be = mc.world.getBlockEntity(pos);
                    if (be != null &&
                            (be.getType() == BlockEntityType.CHEST ||
                                    be.getType() == BlockEntityType.TRAPPED_CHEST ||
                                    be.getType() == BlockEntityType.BARREL ||
                                    be.getType() == BlockEntityType.SHULKER_BOX)) {
                        double d = pos.getSquaredDistance(center);
                        if (d < bd) {
                            bd = d;
                            best = pos;
                        }
                    }
                }
            }
        }
        return best;
    }

    /** Остался ли по этому адресу контейнер, на который вешается таймер. */
    private boolean isChestBlockEntity(BlockPos pos) {
        BlockEntity be = mc.world.getBlockEntity(pos);
        return be != null &&
                (be.getType() == BlockEntityType.CHEST ||
                        be.getType() == BlockEntityType.TRAPPED_CHEST ||
                        be.getType() == BlockEntityType.BARREL ||
                        be.getType() == BlockEntityType.SHULKER_BOX);
    }

    /** Есть ли рядом с сундуком стойка с таймером на имени. */
    private boolean hasTimerStandNear(BlockPos chest) {
        return bestTimerStandNear(chest) >= 0;
    }

    /** Максимальный таймер среди стоек с именем-временем вокруг сундука (±8 блоков), -1 если нет. */
    private int bestTimerStandNear(BlockPos chest) {
        double x = chest.getX() + 0.5;
        double y = chest.getY() + 0.5;
        double z = chest.getZ() + 0.5;
        Box area = new Box(x - 8, y - 8, z - 8, x + 8, y + 8, z + 8);
        int best = -1;
        for (ArmorStandEntity stand : mc.world.getEntitiesByClass(ArmorStandEntity.class, area,
                stand -> stand.isCustomNameVisible())) {
            int t = parseTimer(stand);
            if (t > best) {
                best = t;
            }
        }
        return best;
    }

    /** Рисуем луч ТОЧНО как в GpsManager */
    public static void renderWardenBeams(WorldRenderContext context) {
        WardenESP module = NeuClient.getInstance().getModuleManager().get(WardenESP.class);
        if (module == null || !module.isEnabled() || module.activeChests.isEmpty()) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || context.commandQueue() == null) return;

        Vec3d cam = mc.gameRenderer.getCamera().getCameraPos();
        MatrixStack matrices = context.matrices();

        for (Map.Entry<BlockPos, long[]> entry : module.activeChests.entrySet()) {
            BlockPos pos = entry.getKey();
            int remaining = module.getRemainingSeconds(entry.getValue());

            if (remaining <= 0 || remaining > module.showSeconds.get().intValue()) continue;

            double cx = pos.getX() + 0.5;
            double cz = pos.getZ() + 0.5;
            double y0 = mc.world.getTopY(net.minecraft.world.Heightmap.Type.MOTION_BLOCKING, pos.getX(), pos.getZ());
            double y1 = Math.min(mc.world.getBottomY() + mc.world.getHeight(), y0 + 320.0);

            matrices.push();
            matrices.translate(-cam.x, -cam.y, -cam.z);

            float r = 1.0f;
            float g = 0.3f;
            float b = 0.3f;

            context.commandQueue().submitCustom(matrices, BEAM_LAYER, (entryStack, buffer) -> {
                // Ядро луча
                box(entryStack, buffer, cx - BEAM_HALF, y0, cz - BEAM_HALF,
                        cx + BEAM_HALF, y1, cz + BEAM_HALF, r, g, b, BEAM_ALPHA);
                // Свечение
                box(entryStack, buffer, cx - GLOW_HALF, y0, cz - GLOW_HALF,
                        cx + GLOW_HALF, y1, cz + GLOW_HALF, r, g, b, GLOW_ALPHA);
            });

            matrices.pop();
        }
    }

    /** Красная обводка вокруг сундуков (видна сквозь стены). */
    /** Рамка вокруг самого вардена — сквозь стены, всегда пока он в зоне прогрузки. */
    public static void renderWardenBoxes(WorldRenderContext context) {
        WardenESP module = NeuClient.getInstance().getModuleManager().get(WardenESP.class);
        if (module == null || !module.isEnabled() || !module.highlightWarden.get()) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || context.commandQueue() == null) return;
        List<net.minecraft.entity.mob.WardenEntity> list = module.wardens();
        if (list.isEmpty()) return;

        float delta = ru.neuclient.client.render.WorldToScreen.frameDelta;
        Vec3d cam = mc.gameRenderer.getCamera().getCameraPos();
        MatrixStack matrices = context.matrices();
        matrices.push();
        matrices.translate(-cam.x, -cam.y, -cam.z);

        // Пульсирующий сине-голубой (цвет вардена) контур
        float pulse = 0.75f + 0.25f * (float) Math.sin(System.currentTimeMillis() / 250.0);
        float r = 0.15f, g = 0.85f * pulse, b = 1.0f, a = 0.95f, width = 2.5f;

        context.commandQueue().submitCustom(matrices, WorldRenderUtil.LINES_NO_DEPTH, (entry, buffer) -> {
            for (net.minecraft.entity.mob.WardenEntity w : list) {
                double ix = net.minecraft.util.math.MathHelper.lerp(delta, w.lastRenderX, w.getX());
                double iy = net.minecraft.util.math.MathHelper.lerp(delta, w.lastRenderY, w.getY());
                double iz = net.minecraft.util.math.MathHelper.lerp(delta, w.lastRenderZ, w.getZ());
                net.minecraft.util.math.Box bb = w.getBoundingBox();
                double hw = (bb.maxX - bb.minX) / 2.0 + 0.05;
                double h = (bb.maxY - bb.minY) + 0.05;
                double x = ix - hw, x1 = ix + hw;
                double y = iy - 0.02, y1 = iy + h;
                double z = iz - hw, z1 = iz + hw;

                WorldRenderUtil.line(buffer, entry, x, y, z, x1, y, z, r, g, b, a, width);
                WorldRenderUtil.line(buffer, entry, x1, y, z, x1, y, z1, r, g, b, a, width);
                WorldRenderUtil.line(buffer, entry, x1, y, z1, x, y, z1, r, g, b, a, width);
                WorldRenderUtil.line(buffer, entry, x, y, z1, x, y, z, r, g, b, a, width);
                WorldRenderUtil.line(buffer, entry, x, y1, z, x1, y1, z, r, g, b, a, width);
                WorldRenderUtil.line(buffer, entry, x1, y1, z, x1, y1, z1, r, g, b, a, width);
                WorldRenderUtil.line(buffer, entry, x1, y1, z1, x, y1, z1, r, g, b, a, width);
                WorldRenderUtil.line(buffer, entry, x, y1, z1, x, y1, z, r, g, b, a, width);
                WorldRenderUtil.line(buffer, entry, x, y, z, x, y1, z, r, g, b, a, width);
                WorldRenderUtil.line(buffer, entry, x1, y, z, x1, y1, z, r, g, b, a, width);
                WorldRenderUtil.line(buffer, entry, x1, y, z1, x1, y1, z1, r, g, b, a, width);
                WorldRenderUtil.line(buffer, entry, x, y, z1, x, y1, z1, r, g, b, a, width);
            }
        });
        matrices.pop();
    }

    public static void renderChestOutlines(WorldRenderContext context) {
        WardenESP module = NeuClient.getInstance().getModuleManager().get(WardenESP.class);
        if (module == null || !module.isEnabled() || module.activeChests.isEmpty()) return;

        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || context.commandQueue() == null) return;

        Vec3d cam = mc.gameRenderer.getCamera().getCameraPos();
        MatrixStack matrices = context.matrices();

        matrices.push();
        matrices.translate(-cam.x, -cam.y, -cam.z);

        float r = 1.0f;
        float g = 0.15f;
        float b = 0.15f;
        float a = 0.85f;
        float width = 2.0f;

        context.commandQueue().submitCustom(matrices, WorldRenderUtil.LINES_NO_DEPTH, (entry, buffer) -> {
            for (Map.Entry<BlockPos, long[]> chestEntry : module.activeChests.entrySet()) {
                BlockPos pos = chestEntry.getKey();
                double x = pos.getX();
                double y = pos.getY();
                double z = pos.getZ();
                double x1 = x + 1.0;
                double y1 = y + 1.0;
                double z1 = z + 1.0;

                // 4 нижних ребра
                WorldRenderUtil.line(buffer, entry, x, y, z, x1, y, z, r, g, b, a, width);
                WorldRenderUtil.line(buffer, entry, x1, y, z, x1, y, z1, r, g, b, a, width);
                WorldRenderUtil.line(buffer, entry, x1, y, z1, x, y, z1, r, g, b, a, width);
                WorldRenderUtil.line(buffer, entry, x, y, z1, x, y, z, r, g, b, a, width);
                // 4 верхних ребра
                WorldRenderUtil.line(buffer, entry, x, y1, z, x1, y1, z, r, g, b, a, width);
                WorldRenderUtil.line(buffer, entry, x1, y1, z, x1, y1, z1, r, g, b, a, width);
                WorldRenderUtil.line(buffer, entry, x1, y1, z1, x, y1, z1, r, g, b, a, width);
                WorldRenderUtil.line(buffer, entry, x, y1, z1, x, y1, z, r, g, b, a, width);
                // 4 вертикальных ребра
                WorldRenderUtil.line(buffer, entry, x, y, z, x, y1, z, r, g, b, a, width);
                WorldRenderUtil.line(buffer, entry, x1, y, z, x1, y1, z, r, g, b, a, width);
                WorldRenderUtil.line(buffer, entry, x1, y, z1, x1, y1, z1, r, g, b, a, width);
                WorldRenderUtil.line(buffer, entry, x, y, z1, x, y1, z1, r, g, b, a, width);
            }
        });

        matrices.pop();
    }

    private static void box(MatrixStack.Entry entry, VertexConsumer buffer,
                            double minX, double minY, double minZ, double maxX, double maxY, double maxZ,
                            float r, float g, float b, float a) {
        org.joml.Matrix4f m = entry.getPositionMatrix();
        face(buffer, m, minX, minY, minZ, minX, minY, maxZ, minX, maxY, maxZ, minX, maxY, minZ, r, g, b, a);
        face(buffer, m, maxX, minY, minZ, maxX, maxY, minZ, maxX, maxY, maxZ, maxX, minY, maxZ, r, g, b, a);
        face(buffer, m, minX, minY, minZ, maxX, minY, minZ, maxX, minY, maxZ, minX, minY, maxZ, r, g, b, a);
        face(buffer, m, minX, maxY, minZ, minX, maxY, maxZ, maxX, maxY, maxZ, maxX, maxY, minZ, r, g, b, a);
        face(buffer, m, minX, minY, minZ, minX, maxY, minZ, minX, maxY, maxZ, minX, minY, maxZ, r, g, b, a);
        face(buffer, m, minX, minY, maxZ, maxX, minY, maxZ, maxX, maxY, maxZ, minX, maxY, maxZ, r, g, b, a);
    }

    private static void face(VertexConsumer buffer, org.joml.Matrix4f m,
                             double x1, double y1, double z1, double x2, double y2, double z2,
                             double x3, double y3, double z3, double x4, double y4, double z4,
                             float r, float g, float b, float a) {
        buffer.vertex(m, (float) x1, (float) y1, (float) z1).color(r, g, b, a);
        buffer.vertex(m, (float) x2, (float) y2, (float) z2).color(r, g, b, a);
        buffer.vertex(m, (float) x3, (float) y3, (float) z3).color(r, g, b, a);
        buffer.vertex(m, (float) x4, (float) y4, (float) z4).color(r, g, b, a);
    }

    /** Отрисовка уведомления */
    public static void renderAlert(net.minecraft.client.gui.DrawContext context) {
        NeuClient client = NeuClient.getInstance();
        if (client == null || client.getModuleManager() == null) return;

        WardenESP module = client.getModuleManager().get(WardenESP.class);
        if (module == null || !module.isEnabled()) return;

        var mc = net.minecraft.client.MinecraftClient.getInstance();
        if (mc.player == null || mc.textRenderer == null) return;

        boolean shouldShowMessage = false;

        for (long[] data : module.activeChests.values()) {
            int remaining = module.getRemainingSeconds(data);
            if (remaining > 0 && remaining <= module.showSeconds.get().intValue()) {
                shouldShowMessage = true;
                if (module.lastMessageTime == 0) module.lastMessageTime = System.currentTimeMillis();
                break;
            }
        }

        if (!shouldShowMessage) {
            module.lastMessageTime = 0;
            return;
        }

        if (System.currentTimeMillis() - module.lastMessageTime > 1500) return;

        String text = "Скоро откроется сундук";

        int x = context.getScaledWindowWidth() / 2;
        int y = context.getScaledWindowHeight() / 2 - 30;

        ru.neuclient.client.font.MsdfFontRenderer.drawCenteredWithShadow(context,
                ru.neuclient.client.font.MsdfFonts.sfMedium(), text, x, y, 0xFFFF3333, 10.0f);
    }

    /** Время над сундуком */
    public static void renderWardenMarkers(net.minecraft.client.gui.DrawContext ctx) {
        NeuClient client = NeuClient.getInstance();
        if (client == null || client.getModuleManager() == null) return;

        WardenESP module = client.getModuleManager().get(WardenESP.class);
        if (module == null || !module.isEnabled() || module.activeChests.isEmpty()) return;

        var mc = net.minecraft.client.MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;

        for (Map.Entry<BlockPos, long[]> entry : module.activeChests.entrySet()) {
            BlockPos pos = entry.getKey();
            int remaining = module.getRemainingSeconds(entry.getValue());

            if (remaining <= 0 || remaining > module.showSeconds.get().intValue()) continue;

            String timeText = String.format("%02d:%02d", remaining / 60, remaining % 60);

            Vec3d worldPos = new Vec3d(pos.getX() + 0.5, pos.getY() + 2.2, pos.getZ() + 0.5);
            double[] screen = WorldToScreen.project(worldPos, mc);

            if (screen != null) {
                float x = (float) screen[0];
                float y = (float) screen[1];

                ru.neuclient.client.font.MsdfFontRenderer.drawCenteredWithShadow(ctx,
                        ru.neuclient.client.font.MsdfFonts.sfMedium(), timeText, x, y, 0xFFFF4444, 9.0f);
            }
        }
    }
}