package ru.neuclient.client.mixin;

import net.minecraft.block.enums.CameraSubmersionType;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.fog.FogRenderer;
import net.minecraft.entity.effect.StatusEffects;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.impl.render.CustomFogModule;
import ru.neuclient.client.module.impl.render.NoRenderModule;

/**
 * NoRender: убирает туман — мировой, воды/лавы и туман от плохих эффектов
 * (слепота/тьма).
 *
 * В 1.21.11 вся математика тумана — «модификаторы» (атмосфера, вода, лава,
 * слепота, тьма...), которые проставляют дистанции, записываемые в туман-буфер.
 * Мы перехватываем САМУ ЗАПИСЬ (внутренний applyFog) и подменяем дистанции
 * на «очень далеко» по тем же самым правилам, что в NoRender:
 *  - \"Туман мира\"        → камера в атмосфере;
 *  - \"Оверлей воды/лавы\" → камера под водой/в лаве;
 *  - \"Плохие эффекты\"    → на игроке слепота или тьма.
 *
 * ВНИМАНИЕ: у @ModifyArg index считается по АБСОЛЮТНОЙ позиции аргумента
 * в вызове (ByteBuffer=0, int=1, Vector4f=2, затем шесть float = 3..8).
 */
@Mixin(FogRenderer.class)
public abstract class FogRendererMixin {

	/** Дистанция «тумана нет» — дальше любого возможного рендера. */
	private static final float FAR_FOG = 1.0E7f;

	private static final String OUTER =
			"applyFog(Lnet/minecraft/client/render/Camera;ILnet/minecraft/client/render/RenderTickCounter;"
					+ "FLnet/minecraft/client/world/ClientWorld;)Lorg/joml/Vector4f;";
	private static final String INNER =
			"Lnet/minecraft/client/render/fog/FogRenderer;applyFog(Ljava/nio/ByteBuffer;ILorg/joml/Vector4f;FFFFFF)V";

	@ModifyArg(method = OUTER, at = @At(value = "INVOKE", target = INNER), index = 2)
	private org.joml.Vector4f pc$fogColor(org.joml.Vector4f color) {
		CustomFogModule customFog = CustomFogModule.get();
		if (customFog != null && customFog.shouldOverrideColor()) {
			return new org.joml.Vector4f(customFog.getRed(), customFog.getGreen(), customFog.getBlue(), 1.0f);
		}
		return color;
	}

	@ModifyArg(method = OUTER, at = @At(value = "INVOKE", target = INNER), index = 3)
	private float pc$fogEnvStart(float value) {
		CustomFogModule customFog = CustomFogModule.get();
		if (customFog != null) return 0.0f;
		return pc$killFog() ? FAR_FOG : value;
	}

	@ModifyArg(method = OUTER, at = @At(value = "INVOKE", target = INNER), index = 4)
	private float pc$fogEnvEnd(float value) {
		CustomFogModule customFog = CustomFogModule.get();
		if (customFog != null) return customFog.getDistance();
		return pc$killFog() ? FAR_FOG * 1.1f : value;
	}

	@ModifyArg(method = OUTER, at = @At(value = "INVOKE", target = INNER), index = 5)
	private float pc$fogRdStart(float value) {
		CustomFogModule customFog = CustomFogModule.get();
		if (customFog != null) return 0.0f;
		return pc$killFog() ? FAR_FOG : value;
	}

	@ModifyArg(method = OUTER, at = @At(value = "INVOKE", target = INNER), index = 6)
	private float pc$fogRdEnd(float value) {
		CustomFogModule customFog = CustomFogModule.get();
		if (customFog != null) return customFog.getDistance() * 1.1f;
		return pc$killFog() ? FAR_FOG * 1.1f : value;
	}

	@ModifyArg(method = OUTER, at = @At(value = "INVOKE", target = INNER), index = 7)
	private float pc$fogSkyEnd(float value) {
		CustomFogModule customFog = CustomFogModule.get();
		if (customFog != null) return customFog.getDistance() * 1.1f;
		return pc$killFog() ? FAR_FOG * 1.1f : value;
	}

	@ModifyArg(method = OUTER, at = @At(value = "INVOKE", target = INNER), index = 8)
	private float pc$fogCloudEnd(float value) {
		CustomFogModule customFog = CustomFogModule.get();
		if (customFog != null) return customFog.getDistance() * 1.1f;
		return pc$killFog() ? FAR_FOG * 1.1f : value;
	}

	/** true, если по текущему контексту (камера/эффекты) туман надо убрать. */
	@Unique
	private static boolean pc$killFog() {
		NeuClient client = NeuClient.getInstance();
		if (client == null || client.getModuleManager() == null) {
			return false;
		}
		NoRenderModule module = client.getModuleManager().get(NoRenderModule.class);
		if (module == null || !module.isEnabled()) {
			return false;
		}
		MinecraftClient mc = MinecraftClient.getInstance();
		Camera camera = mc.gameRenderer != null ? mc.gameRenderer.getCamera() : null;
		CameraSubmersionType submersion = camera != null ? camera.getSubmersionType() : null;

		if (module.noWorldFog()
				&& (submersion == null
				|| submersion == CameraSubmersionType.ATMOSPHERIC
				|| submersion == CameraSubmersionType.NONE)) {
			return true;
		}
		if (module.noLiquidOverlay()
				&& (submersion == CameraSubmersionType.WATER || submersion == CameraSubmersionType.LAVA)) {
			return true;
		}
		return module.noBadEffects()
				&& mc.player != null
				&& (mc.player.hasStatusEffect(StatusEffects.BLINDNESS)
				|| mc.player.hasStatusEffect(StatusEffects.DARKNESS));
	}
}
