package ru.neuclient.client.render;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.minecraft.client.gui.ScreenRect;
import net.minecraft.client.gui.render.state.SimpleGuiElementRenderState;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.texture.TextureSetup;
import org.joml.Matrix3x2f;
import org.joml.Vector2f;

/**
 * GUI-элемент «стеклянной» панели: один quad, весь эффект считает шейдер.
 *
 * Формат POSITION_TEXTURE_COLOR даёт Position(Float×3), UV0(Float×2) и
 * Color(UB×4), причём color(int,int,int,int) у BufferBuilder урезает каждый
 * канал до байта (i2b) — упаковать туда что-то кроме цвета нельзя. Поэтому:
 *
 * <ul>
 *   <li>UV0 — нормированные координаты внутри quad (по ним шейдер через
 *       fwidth восстанавливает размер панели и считает SDF-скругление);</li>
 *   <li>Color — цвет акцента для линий и ободка, альфа обычная;
 *       упаковывать в альфу время НЕЛЬЗЯ;</li>
 *   <li>Position.z — время в секундах. В GUI Position.z не используется
 *       (ванильный vertex(Matrix3x2f, x, y) пишет туда 0), а орто-проекция
 *       GUI сдвинута на translate(0, 0, 512), так что z в пределах 0..128
 *       ни на клиппинг, ни на глубину не влияет. Ровно тот же приём, что
 *       в GlassHandPipeline, где в Position.z едет радиус и фаза.</li>
 * </ul>
 *
 * Время кладётся в вершину, а не в static-поле, потому что GUI-элементы
 * складываются в GuiRenderState и рисуются позже: static-значение могло бы
 * устареть к моменту отрисовки, и линии встали бы.
 */
public record GlassPanelGuiElementRenderState(
		Matrix3x2f pose,
		float x,
		float y,
		float width,
		float height,
		int accentRgb,
		float alpha,
		float time,
		ScreenRect scissorArea,
		ScreenRect bounds
) implements SimpleGuiElementRenderState {

	@Override
	public void setupVertices(VertexConsumer buffer) {
		int a = Math.max(0, Math.min(255, Math.round(alpha * 255.0f)));
		int argb = 0xFF000000 | (accentRgb & 0x00FFFFFF);

		// GUI-поза применяется вручную, чтобы остаться в 3-компонентной
		// vertex(float, float, float) и положить время в z.
		Vector2f p = new Vector2f();
		emit(buffer, p, x, y, 0.0f, 0.0f, argb, a);
		emit(buffer, p, x, y + height, 0.0f, 1.0f, argb, a);
		emit(buffer, p, x + width, y + height, 1.0f, 1.0f, argb, a);
		emit(buffer, p, x + width, y, 1.0f, 0.0f, argb, a);
	}

	private void emit(VertexConsumer buffer, Vector2f out, float vx, float vy,
			float u, float v, int argb, int a) {
		pose.transformPosition(vx, vy, out);
		buffer.vertex(out.x, out.y, time)
				.texture(u, v)
				.color((argb >> 16) & 0xFF, (argb >> 8) & 0xFF, argb & 0xFF, a);
	}

	@Override
	public RenderPipeline pipeline() {
		return GlassPanelPipeline.PIPELINE;
	}

	@Override
	public TextureSetup textureSetup() {
		return TextureSetup.empty();
	}
}
