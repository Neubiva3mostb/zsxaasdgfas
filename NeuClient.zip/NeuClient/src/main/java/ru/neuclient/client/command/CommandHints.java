package ru.neuclient.client.command;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.TextFieldWidget;
import ru.neuclient.client.font.MsdfFontRenderer;
import ru.neuclient.client.font.MsdfFonts;

import java.util.List;

/**
 * Подсказки точка-команд прямо в открытом чате с нативным MSDF-шрифтом.
 */
public final class CommandHints {

	private static final int LINE_H = 12;
	private static final int VANILLA_BG = 0xE0000000;
	private static final int VANILLA_HIGHLIGHT = 0xE0303040;
	private static final int VANILLA_TEXT = 0xFFFFFFFF;
	private static final int VANILLA_TEXT_DIM = 0xFFAAAAAA;

	private CommandHints() {
	}

	public static void render(DrawContext ctx, TextFieldWidget field) {
		List<String> suggestions = CommandManager.suggest(field.getText());
		if (suggestions.isEmpty()) {
			return;
		}

		float maxW = 0;
		for (String s : suggestions) {
			maxW = Math.max(maxW, MsdfFontRenderer.getWidth(MsdfFonts.sfRegular(), s, 9.0f));
		}
		int boxW = (int) Math.ceil(maxW) + 12;
		int boxH = suggestions.size() * LINE_H + 4;

		int x = field.getX() + 2;
		int y2 = field.getY() - 3;
		int y1 = Math.max(2, y2 - boxH);

		ctx.fill(x, y1, x + boxW, y2, VANILLA_BG);

		int ty = y1 + 3;
		boolean first = true;
		for (String s : suggestions) {
			if (first) {
				ctx.fill(x + 1, ty - 1, x + boxW - 1, ty + LINE_H - 1, VANILLA_HIGHLIGHT);
			}
			MsdfFontRenderer.drawWithShadow(ctx, MsdfFonts.sfRegular(), s, x + 5, ty, first ? VANILLA_TEXT : VANILLA_TEXT_DIM, 9.0f);
			ty += LINE_H;
			first = false;
		}
	}

	public static boolean complete(TextFieldWidget field) {
		String next = CommandManager.complete(field.getText());
		if (next == null) {
			return false;
		}
		field.setText(next);
		field.setCursorToEnd(false);
		return true;
	}
}
