package ru.neuclient.client.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.util.ClientPaths;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Конфигурация SOCKS5-прокси для подключения к серверам.
 *
 * Хранит: IP прокси, порт, логин, пароль, включён ли.
 * Файл: proxy.json в папке конфигов NeuClient.
 */
public record ProxyConfig(
		String proxyIp,
		int proxyPort,
		String proxyLogin,
		String proxyPassword,
		boolean enabled
) {

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

	/** Пустой (выключенный) конфиг по умолчанию. */
	public static ProxyConfig DEFAULT = new ProxyConfig("", 1080, "", "", false);

	/** Есть ли валидный IP — без него прокси не будет работать. */
	public boolean hasProxy() {
		return proxyIp != null && !proxyIp.isBlank();
	}

	/** Включён ли прокси и есть ли IP. */
	public boolean isActive() {
		return enabled && hasProxy();
	}

	/**
	 * Разбор строки вида ip:port, ip:port:login:pass или login:pass@ip:port.
	 * Пустая строка / "off" / "none" — прокси выключен.
	 */
	public static ProxyConfig parse(String raw) {
		if (raw == null) return DEFAULT;
		raw = raw.trim();
		if (raw.isEmpty() || raw.equalsIgnoreCase("off") || raw.equalsIgnoreCase("none")) return DEFAULT;
		if (raw.startsWith("socks5://")) raw = raw.substring("socks5://".length());
		String login = "", pass = "", hostPort = raw;
		int at = raw.lastIndexOf('@');
		if (at > 0) {
			String cred = raw.substring(0, at);
			hostPort = raw.substring(at + 1);
			int c = cred.indexOf(':');
			login = c >= 0 ? cred.substring(0, c) : cred;
			pass = c >= 0 ? cred.substring(c + 1) : "";
		}
		String[] p = hostPort.split(":");
		if (p.length < 2) return DEFAULT;
		int port;
		try { port = Integer.parseInt(p[1].trim()); } catch (NumberFormatException e) { return DEFAULT; }
		if (p.length >= 4 && login.isEmpty()) { login = p[2]; pass = p[3]; }
		return new ProxyConfig(p[0].trim(), port, login, pass, true);
	}

	/** Обратно в строку ip:port[:login:pass] (для bots.json и -D свойства). */
	public String toCompact() {
		if (!hasProxy()) return "";
		String s = proxyIp + ":" + proxyPort;
		if (proxyLogin != null && !proxyLogin.isEmpty()) s += ":" + proxyLogin + ":" + (proxyPassword == null ? "" : proxyPassword);
		return s;
	}

	// ===== Сохранение / загрузка =====

	/** Загрузить конфиг прокси из файла (C:\NeuClient\proxy\proxy.json). */
	public static ProxyConfig load() {
		Path file = ClientPaths.getProxyDir().resolve("proxy.json");
		if (!Files.exists(file)) {
			// Проверяем старое расположение в configs/ для обратной совместимости
			Path legacyFile = ClientPaths.getConfigsDir().resolve("proxy.json");
			if (Files.exists(legacyFile)) {
				file = legacyFile;
			} else {
				return DEFAULT;
			}
		}
		try (Reader reader = Files.newBufferedReader(file)) {
			JsonObject root = JsonParser.parseReader(reader).getAsJsonObject();
			String ip = root.has("proxyIp") ? root.get("proxyIp").getAsString() : "";
			int port = root.has("proxyPort") ? root.get("proxyPort").getAsInt() : 1080;
			String login = root.has("proxyLogin") ? root.get("proxyLogin").getAsString() : "";
			String password = root.has("proxyPassword") ? root.get("proxyPassword").getAsString() : "";
			boolean enabled = root.has("enabled") && root.get("enabled").getAsBoolean();
			return new ProxyConfig(ip, port, login, password, enabled);
		} catch (Exception e) {
			NeuClient.LOGGER.error("[NeuClient] Не удалось загрузить proxy.json", e);
			return DEFAULT;
		}
	}

	/** Сохранить конфиг прокси в файл (C:\NeuClient\proxy\proxy.json). */
	public static void save(ProxyConfig config) {
		Path file = ClientPaths.getProxyDir().resolve("proxy.json");
		try {
			Files.createDirectories(file.getParent());
			JsonObject root = new JsonObject();
			root.addProperty("proxyIp", config.proxyIp());
			root.addProperty("proxyPort", config.proxyPort());
			root.addProperty("proxyLogin", config.proxyLogin());
			root.addProperty("proxyPassword", config.proxyPassword());
			root.addProperty("enabled", config.enabled());
			try (Writer writer = Files.newBufferedWriter(file)) {
				GSON.toJson(root, writer);
			}
		} catch (IOException e) {
			NeuClient.LOGGER.error("[NeuClient] Не удалось сохранить proxy.json", e);
		}
	}
}
