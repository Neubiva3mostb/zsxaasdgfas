package ru.neuclient.client.module.impl.render;

import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.module.impl.player.FreeCamModule;
import ru.neuclient.client.render.WorldRenderUtil;
import ru.neuclient.client.setting.ColorSetting;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

/**
 * Trails — объёмный шлейф-лента за СВОИМ игроком во всю высоту хитбокса.
 *
 * Визуал (без настроек — только цвет):
 *  • Залитая градиентная лента: альфа плавно спадает к хвосту и к земле.
 *  • Позиция головы интерполируется между тиками (getLerpedPos + tickDelta),
 *    весь путь сглаживается сплайном Catmull-Rom — лента течёт плавно.
 *  • Хвост «кометой»: высота и альфа осыпаются к концу следа.
 *  • Двойной контур: яркое ядро + мягкое свечение вокруг силуэта.
 *  • Линии рисуются с обычным тестом глубины (за стенами не видно).
 *
 * От первого лица лента не рисуется (лезла бы в камеру), но при включённом
 * FreeCam камера отвязана — след остаётся виден.
 *
 * Полностью клиентский эффект, пакетов не шлёт.
 */
public final class TrailsModule extends Module {

	/** Тиков в секунду — для лимита истории. */
	private static final int TICKS_PER_SECOND = 20;
	/** Длина следа, секунд. */
	private static final double LENGTH_SECONDS = 3.0;
	/** Общая яркость ленты (0..1). */
	private static final float BASE_ALPHA = 0.8f;
	/** Толщина линий контура. */
	private static final float LINE_WIDTH = 2.0f;
	/** Максимум точек сплайна — защита от перегруза. */
	private static final int MAX_SPLINE_POINTS = 420;

	/** Единственная настройка. */
	private final ColorSetting color = new ColorSetting("Цвет", 0xFF7A5CFF);

	/** История: точка ног + рост + время. Голова очереди — свежая. */
	private final Deque<Step> steps = new ArrayDeque<>();

	/** Один кадр следа: позиция ног, высота хитбокса, время записи. */
	private record Step(Vec3d foot, double height, long time) {
	}

	/** Точка сглаженной кривой: позиция, рост и прогресс к хвосту (0..1). */
	private record SplinePoint(Vec3d pos, double height, float t) {
	}

	public TrailsModule() {
		super("Trails", "Объёмный шлейф за игроком", Category.RENDER);
		addSettings(color);
	}

	@Override
	protected void onEnable() {
		steps.clear();
	}

	@Override
	protected void onDisable() {
		steps.clear();
	}

	@Override
	public void onTick(MinecraftClient client) {
		ClientPlayerEntity player = client.player;
		if (client.world == null || player == null) {
			steps.clear();
			return;
		}

		long now = System.currentTimeMillis();
		steps.addFirst(new Step(player.getEntityPos(), player.getHeight(), now));

		long maxAgeMs = (long) (LENGTH_SECONDS * 1000.0);
		int maxPoints = (int) Math.ceil(LENGTH_SECONDS * TICKS_PER_SECOND) + 4;
		while (!steps.isEmpty()
				&& (now - steps.peekLast().time() > maxAgeMs || steps.size() > maxPoints)) {
			steps.removeLast();
		}
	}

	/** Мировой рендер (AFTER_ENTITIES). */
	public void renderWorld(WorldRenderContext context, MinecraftClient client) {
		ClientPlayerEntity player = client.player;
		if (player == null || context.commandQueue() == null) {
			return;
		}
		// От первого лица лента упиралась бы в камеру — не рисуем.
		// Но FreeCam отвязывает камеру от тела: след должен остаться.
		if (client.options != null
				&& client.options.getPerspective().isFirstPerson()
				&& !isFreecamActive()) {
			return;
		}
		if (steps.isEmpty()) {
			return;
		}

		float tickDelta = client.getRenderTickCounter().getTickProgress(false);
		List<SplinePoint> curve = buildCurve(player, tickDelta);
		if (curve.size() < 2) {
			return;
		}

		Vec3d cam = client.gameRenderer.getCamera().getCameraPos();
		MatrixStack matrices = context.matrices();

		int argb = color.get();
		float r = WorldRenderUtil.red(argb);
		float g = WorldRenderUtil.green(argb);
		float b = WorldRenderUtil.blue(argb);

		matrices.push();
		matrices.translate(-cam.x, -cam.y, -cam.z);

		submitFill(context, matrices, curve, r, g, b);
		submitLines(context, matrices, curve, r, g, b);

		matrices.pop();
	}

	/** Залитая градиентная лента: QUADS с разной альфой на вершинах. */
	private void submitFill(WorldRenderContext context, MatrixStack matrices,
			List<SplinePoint> curve, float baseR, float baseG, float baseB) {
		context.commandQueue().submitCustom(matrices, WorldRenderUtil.QUADS, (entry, buffer) -> {
			org.joml.Matrix4f m = entry.getPositionMatrix();
			int n = curve.size();
			for (int i = 0; i < n - 1; i++) {
				SplinePoint a = curve.get(i);
				SplinePoint b = curve.get(i + 1);

				float alphaA = BASE_ALPHA * ease(a.t());
				float alphaB = BASE_ALPHA * ease(b.t());
				if (alphaA <= 0.004f && alphaB <= 0.004f) {
					continue;
				}

				// Хвост «осыпается»: высота силуэта уменьшается к концу.
				double topA = a.pos().y + a.height() * heightScale(a.t());
				double topB = b.pos().y + b.height() * heightScale(b.t());

				// Вертикальный градиент: верх ярче низа — след «светится» на уровне тела.
				WorldRenderUtil.quadGradient(buffer, m,
						a.pos().x, a.pos().y + 0.02, a.pos().z, alphaA * 0.45f,
						b.pos().x, b.pos().y + 0.02, b.pos().z, alphaB * 0.45f,
						b.pos().x, topB, b.pos().z, alphaB,
						a.pos().x, topA, a.pos().z, alphaA,
						baseR, baseG, baseB);
			}
		});
	}

	/** Двойной контур: мягкое свечение вокруг + яркое ядро силуэта. */
	private void submitLines(WorldRenderContext context, MatrixStack matrices,
			List<SplinePoint> curve, float baseR, float baseG, float baseB) {
		context.commandQueue().submitCustom(matrices, WorldRenderUtil.LINES_DEPTH, (entry, buffer) -> {
			int n = curve.size();

			// Свечение: толстая слабая обводка вокруг силуэта.
			float haloWidth = LINE_WIDTH * 2.8f;
			for (int i = 0; i < n - 1; i++) {
				SplinePoint a = curve.get(i);
				SplinePoint b = curve.get(i + 1);
				float alpha = BASE_ALPHA * 0.16f;
				double topA = a.pos().y + a.height() * heightScale(a.t());
				double topB = b.pos().y + b.height() * heightScale(b.t());
				WorldRenderUtil.line(buffer, entry,
						a.pos().x, a.pos().y + 0.02, a.pos().z,
						b.pos().x, b.pos().y + 0.02, b.pos().z,
						baseR, baseG, baseB, alpha, haloWidth);
				WorldRenderUtil.line(buffer, entry,
						a.pos().x, topA, a.pos().z,
						b.pos().x, topB, b.pos().z,
						baseR, baseG, baseB, alpha, haloWidth);
			}

			// Ядро силуэта: низ и верх, с сужением к хвосту.
			for (int i = 0; i < n - 1; i++) {
				SplinePoint a = curve.get(i);
				SplinePoint b = curve.get(i + 1);
				float alpha = BASE_ALPHA * 0.75f * ease(a.t());
				float w = LINE_WIDTH * 0.85f * (1.0f - 0.6f * a.t());
				double topA = a.pos().y + a.height() * heightScale(a.t());
				double topB = b.pos().y + b.height() * heightScale(b.t());
				WorldRenderUtil.line(buffer, entry,
						a.pos().x, a.pos().y + 0.02, a.pos().z,
						b.pos().x, b.pos().y + 0.02, b.pos().z,
						baseR, baseG, baseB, alpha, w);
				WorldRenderUtil.line(buffer, entry,
						a.pos().x, topA, a.pos().z,
						b.pos().x, topB, b.pos().z,
						baseR, baseG, baseB, alpha, w);
			}
		});
	}

	/**
	 * Сглаженная кривая: голова — интерполированная позиция игрока,
	 * дальше тиковые точки, всё прогнано через Catmull-Rom.
	 */
	private List<SplinePoint> buildCurve(ClientPlayerEntity player, float tickDelta) {
		List<Step> raw = new ArrayList<>(steps.size() + 2);
		// Голова следа — плавная позиция МЕЖДУ тиками.
		raw.add(new Step(player.getLerpedPos(tickDelta), player.getHeight(), System.currentTimeMillis()));
		raw.addAll(steps);

		int segments = raw.size() - 1;
		if (segments <= 0) {
			return List.of();
		}

		// Адаптивное разбиение: много точек — меньше subdivisions.
		int subdiv = segments > 160 ? 1 : 2;

		List<SplinePoint> out = new ArrayList<>(segments * subdiv + 2);
		float totalT = segments;
		for (int i = 0; i < segments; i++) {
			Step p0 = raw.get(Math.max(0, i - 1));
			Step p1 = raw.get(i);
			Step p2 = raw.get(i + 1);
			Step p3 = raw.get(Math.min(raw.size() - 1, i + 2));

			float t1 = i / totalT;
			float t2 = (i + 1) / totalT;

			for (int s = 0; s < subdiv; s++) {
				float u = s / (float) subdiv;
				out.add(new SplinePoint(
						catmullPos(p0, p1, p2, p3, u),
						catmull(p0.height(), p1.height(), p2.height(), p3.height(), u),
						t1 + (t2 - t1) * u));
			}
		}
		Step last = raw.get(raw.size() - 1);
		out.add(new SplinePoint(last.foot(), last.height(), 1.0f));

		// Жёсткий потолок на случай очень длинного шлейфа.
		if (out.size() > MAX_SPLINE_POINTS) {
			List<SplinePoint> capped = new ArrayList<>(MAX_SPLINE_POINTS);
			double stride = (double) (out.size() - 1) / (MAX_SPLINE_POINTS - 1);
			for (int i = 0; i < MAX_SPLINE_POINTS; i++) {
				capped.add(out.get((int) Math.round(i * stride)));
			}
			return capped;
		}
		return out;
	}

	/** Catmull-Rom по позиции ног. */
	private static Vec3d catmullPos(Step p0, Step p1, Step p2, Step p3, float u) {
		return new Vec3d(
				catmull(p0.foot().x, p1.foot().x, p2.foot().x, p3.foot().x, u),
				catmull(p0.foot().y, p1.foot().y, p2.foot().y, p3.foot().y, u),
				catmull(p0.foot().z, p1.foot().z, p2.foot().z, p3.foot().z, u));
	}

	/** Классический Catmull-Rom по одному компоненту. */
	private static double catmull(double p0, double p1, double p2, double p3, float u) {
		double u2 = u * u;
		double u3 = u2 * u;
		return 0.5 * ((2.0 * p1)
				+ (-p0 + p2) * u
				+ (2.0 * p0 - 5.0 * p1 + 4.0 * p2 - p3) * u2
				+ (-p0 + 3.0 * p1 - 3.0 * p2 + p3) * u3);
	}

	/** Плавное затухание к хвосту (сильнее в конце, чем линейное). */
	private static float ease(float t) {
		float inv = 1.0f - t;
		return inv * inv * (3.0f - 2.0f * inv) * 0.85f + 0.15f * inv;
	}

	/** Высота силуэта: у хвоста «комета» сжимается до трети роста. */
	private static float heightScale(float t) {
		return 0.3f + 0.7f * (1.0f - t);
	}

	private static boolean isFreecamActive() {
		var modules = ru.neuclient.client.NeuClient.getInstance().getModuleManager();
		if (modules == null) {
			return false;
		}
		FreeCamModule freecam = modules.get(FreeCamModule.class);
		return freecam != null && freecam.isEnabled();
	}

	/** Диспетчер мирового рендера (вызывается из NeuClient). */
	public static void renderAllWorld(WorldRenderContext context) {
		var modules = ru.neuclient.client.NeuClient.getInstance().getModuleManager();
		if (modules == null) {
			return;
		}
		TrailsModule self = modules.get(TrailsModule.class);
		if (self != null && self.isEnabled()) {
			self.renderWorld(context, MinecraftClient.getInstance());
		}
	}
}
