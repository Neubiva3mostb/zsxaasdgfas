package ru.neuclient.client.module.impl.render;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.render.LayeringTransform;
import net.minecraft.client.render.OutputTarget;
import net.minecraft.client.render.RenderSetup;
import ru.neuclient.client.mixin.RenderLayerAccessor;
import ru.neuclient.client.mixin.RenderPipelinesAccessor;

import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.FireballEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.entity.projectile.ProjectileEntity;
import net.minecraft.entity.projectile.TridentEntity;
import net.minecraft.entity.projectile.thrown.EggEntity;
import net.minecraft.entity.projectile.thrown.EnderPearlEntity;
import net.minecraft.entity.projectile.thrown.ExperienceBottleEntity;
import net.minecraft.entity.projectile.thrown.PotionEntity;
import net.minecraft.entity.projectile.thrown.SnowballEntity;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.BooleanSetting;
import ru.neuclient.client.setting.NumberSetting;
import ru.neuclient.client.util.RenderUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Predictions — траектории УЖЕ ЛЕТЯЩИХ снарядов:
 *  1. «Свои в полёте» — продолжение реальных траекторий твоих снарядов
 *     (цвет — акцент темы);
 *  2. Вражеские снаряды — белые траектории с подсветкой «угрозы»: если
 *     линия проходит сквозь твой хитбок (прилетит прямо в тебя), краснеет
 *     вся линия и точка падения.
 *
 * Предпросмотра «что в руке» НЕТ (вырезан по запросу — рисуем только
 * реально кинутые снаряды).
 *
 * Симуляция — ванильная физика в воздухе (драг 0.99, гравитация по типу;
 * огненные шары летят прямо без гравитации). В воду не ныряем (там драг
 * другой) — линия показывает верхнюю оценку дальности. Рендер — пайплайновым
 * API: LINES без глубины (видно сквозь стены) + DEBUG_FILLED_BOX в точке
 * падения. Пакетов не шлём — чистый клиент, работает на любых серверах.
 */
public class PredictionsModule extends Module {

	// Все настройки удалены — всё всегда on, дальность 64
	private static final double RANGE = 64.0;

	/** Драг скорости в воздухе (как у ваниллы). */
	private static final double DRAG = 0.99;
	/** Максимум тиков прогноза на летящий снаряд. */
	private static final int MAX_TICKS = 160;
	/** Максимум вражеских снарядов за кадр (страховка перфа). */
	private static final int MAX_PATHS = 24;
	/** Максимум своих летящих снарядов за кадр. */
	private static final int MAX_OWN_PATHS = 8;
	/** Хитбок угрозы: линия внутри него — летит прямо в тебя. */
	private static final double THREAT_EXPAND_H = 0.85;
	private static final double THREAT_EXPAND_V = 0.35;

	private static final float LINE_WIDTH = 2.0f;
	private static final float BOX_HALF = 0.09f;

	// Цвета вражеских траекторий (обычная / угроза)
	private static final float R_NORMAL = 0.95f, G_NORMAL = 0.95f, B_NORMAL = 0.95f;
	private static final float A_NORMAL = 0.55f;
	private static final float R_THREAT = 1.0f, G_THREAT = 0.33f, B_THREAT = 0.33f;
	private static final float A_THREAT = 0.9f;
	private static final float BOX_ALPHA_NORMAL = 0.25f;
	private static final float BOX_ALPHA_THREAT = 0.4f;
	/** Альфы своих траекторий (цвет — акцент темы). */
	private static final float A_OWN_LINE = 0.85f;
	private static final float A_OWN_BOX = 0.35f;

	/** Линии без глубины (сквозь стены). */
	private static final RenderLayer LINES_LAYER = RenderLayerAccessor.pc$of("neuclient_predictions_lines",
			RenderSetup.builder(RenderPipeline.builder(new RenderPipeline.Snippet[]{RenderPipelinesAccessor.pc$getLinesSnippet()})
							.withLocation("neuclient/predictions_lines")
							.withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
							.build())
					.layeringTransform(LayeringTransform.VIEW_OFFSET_Z_LAYERING)
					.outputTarget(OutputTarget.ITEM_ENTITY_TARGET)
					.build());

	/** Залитый бокс без глубины. */
	private static final RenderLayer BOX_LAYER = RenderLayerAccessor.pc$of("neuclient_predictions_box",
			RenderSetup.builder(RenderPipelines.DEBUG_FILLED_BOX)
					.layeringTransform(LayeringTransform.VIEW_OFFSET_Z_LAYERING)
					.outputTarget(OutputTarget.ITEM_ENTITY_TARGET)
					.build());

	public PredictionsModule() {
		super("Predictions", "Траектории летящих снарядов",
				Category.RENDER);
		addSettings(color);
	}

	private final ru.neuclient.client.setting.ColorSetting color = new ru.neuclient.client.setting.ColorSetting("Цвет", 0xFF7A5CFF);

	/** Мировой рендер (AFTER_ENTITIES, из NeuClient). */
	public void renderWorld(WorldRenderContext context, MinecraftClient client) {
		ClientPlayerEntity self = client.player;
		if (self == null || client.world == null || context.commandQueue() == null) {
			return;
		}
		Vec3d cam = client.gameRenderer.getCamera().getCameraPos();
		MatrixStack matrices = context.matrices();
		float tickDelta = client.getRenderTickCounter().getTickProgress(false);
		double maxRange = RANGE;
		double maxRangeSq = maxRange * maxRange;

		Box threatBox = self.getBoundingBox().expand(THREAT_EXPAND_H, THREAT_EXPAND_V, THREAT_EXPAND_H);

		// Цвет своих траекторий
		int accent = color.get();
		float ar = ((accent >> 16) & 0xFF) / 255.0f;
		float ag = ((accent >> 8) & 0xFF) / 255.0f;
		float ab = (accent & 0xFF) / 255.0f;

		// Летящие снаряды: свои (акцент) и вражеские (белый/красный)
		int enemyPaths = 0;
		int ownPaths = 0;
		for (Entity entity : client.world.getEntities()) {
			if (!(entity instanceof ProjectileEntity projectile)) {
				continue;
			}
			boolean own = projectile.getOwner() == self;
			if (own) {
				if (ownPaths >= MAX_OWN_PATHS) {
					continue;
				}
			} else {
				if (enemyPaths >= MAX_PATHS || self.squaredDistanceTo(entity) > maxRangeSq) {
					continue;
				}
				if (!typeAccepted(entity)) {
					continue;
				}
			}
			Vec3d vel = entity.getVelocity();
			if (vel.lengthSquared() < 1.0E-4) {
				continue; // застрял в блоке/лёг на землю — не летит
			}
			double gravity = gravityOf(entity);
			double drag = entity instanceof FireballEntity ? 1.0 : DRAG;

			Vec3d start = entity.getLerpedPos(tickDelta);
			// Своим снарядам «угрозу» не считаем: они спавнятся ВНУТРИ твоего
			// хитбока (из точки глаз) и краснели бы всегда
			List<Vec3d> path = trace(client, self, start, vel.x, vel.y, vel.z, gravity, drag,
					MAX_TICKS, own ? null : threatBox);
			if (path.size() < 2) {
				continue;
			}

			if (own) {
				if (drawPath(context, matrices, cam, path, ar, ag, ab, A_OWN_LINE, A_OWN_BOX)) {
					ownPaths++;
				}
			} else {
				boolean threat = lastThreatHit;
				float r = threat ? R_THREAT : R_NORMAL;
				float g = threat ? G_THREAT : G_NORMAL;
				float b = threat ? B_THREAT : B_NORMAL;
				float la = threat ? A_THREAT : A_NORMAL;
				float ba = threat ? BOX_ALPHA_THREAT : BOX_ALPHA_NORMAL;
				if (drawPath(context, matrices, cam, path, r, g, b, la, ba)) {
					enemyPaths++;
				}
			}
		}
	}

	/** Все типы снарядов всегда включены. */
	private boolean typeAccepted(Entity entity) {
		return entity instanceof ProjectileEntity;
	}

	/** Гравитация по типу снаряда (огненный шар летит прямо — 0). */
	private static double gravityOf(Entity entity) {
		if (entity instanceof TridentEntity || entity instanceof PersistentProjectileEntity) {
			return 0.05;
		}
		if (entity instanceof PotionEntity) {
			return 0.05;
		}
		if (entity instanceof FireballEntity) {
			return 0.0;
		}
		return 0.03; // жемчуг/снежок/яйцо/пузырёк опыта
	}

	/** Прогон ванильной физики; по желанию проверяет пролёт сквозь хитбок игрока. */
	private boolean lastThreatHit;

	private List<Vec3d> trace(MinecraftClient client, ClientPlayerEntity self, Vec3d start,
			double vx, double vy, double vz, double gravity, double drag, int maxTicks, Box threatBox) {
		List<Vec3d> path = new ArrayList<>();
		Vec3d pos = start;
		path.add(pos);
		lastThreatHit = false;

		for (int tick = 0; tick < maxTicks; tick++) {
			Vec3d next = pos.add(vx, vy, vz);
			if (threatBox != null && !lastThreatHit && threatBox.contains(next)) {
				lastThreatHit = true;
			}
			BlockHitResult hit = client.world.raycast(new RaycastContext(
					pos, next,
					RaycastContext.ShapeType.COLLIDER,
					RaycastContext.FluidHandling.NONE,
					self));
			if (hit != null && hit.getType() == HitResult.Type.BLOCK) {
				path.add(hit.getPos()); // точная точка контакта — финал линии
				break;
			}
			pos = next;
			path.add(pos);
			// Ванильный порядок: перенос позиции, потом драг и гравитация скорости
			vx *= drag;
			vz *= drag;
			vy = vy * drag - gravity;
		}
		return path;
	}

	// ===== Рисование =====

	/** Линия по точкам + бокс в точке падения. false — путь пустой. */
	private static boolean drawPath(WorldRenderContext context, MatrixStack matrices, Vec3d cam,
			List<Vec3d> path, float r, float g, float b, float lineA, float boxA) {
		if (path.size() < 2) {
			return false;
		}

		// Стек в координатах «мир − камера» (как у ваниллы в рендере мира)
		matrices.push();
		matrices.translate(-cam.x, -cam.y, -cam.z);

		// --- Линия (толстая, сквозь стены) ---
		context.commandQueue().submitCustom(matrices, LINES_LAYER, (entry, buffer) -> {
			for (int i = 1; i < path.size(); i++) {
				Vec3d a = path.get(i - 1);
				Vec3d c = path.get(i);
				Vec3d dir = c.subtract(a);
				double len = dir.length();
				if (len < 1.0E-5) {
					continue;
				}
				dir = dir.multiply(1.0 / len);
				buffer.vertex(entry, (float) a.x, (float) a.y, (float) a.z)
						.color(r, g, b, lineA)
						.normal(entry, (float) dir.x, (float) dir.y, (float) dir.z)
						.lineWidth(LINE_WIDTH);
				buffer.vertex(entry, (float) c.x, (float) c.y, (float) c.z)
						.color(r, g, b, lineA)
						.normal(entry, (float) dir.x, (float) dir.y, (float) dir.z)
						.lineWidth(LINE_WIDTH);
			}
		});

		// --- Бокс в точке падения ---
		Vec3d end = path.get(path.size() - 1);
		context.commandQueue().submitCustom(matrices, BOX_LAYER, (entry, buffer) -> {
			org.joml.Matrix4f m = entry.getPositionMatrix();
			double minX = end.x - BOX_HALF, minY = end.y - BOX_HALF, minZ = end.z - BOX_HALF;
			double maxX = end.x + BOX_HALF, maxY = end.y + BOX_HALF, maxZ = end.z + BOX_HALF;
			face(buffer, m, minX, minY, minZ, minX, minY, maxZ, minX, maxY, maxZ, minX, maxY, minZ, r, g, b, boxA);
			face(buffer, m, maxX, minY, minZ, maxX, maxY, minZ, maxX, maxY, maxZ, maxX, minY, maxZ, r, g, b, boxA);
			face(buffer, m, minX, minY, minZ, maxX, minY, minZ, maxX, minY, maxZ, minX, minY, maxZ, r, g, b, boxA);
			face(buffer, m, minX, maxY, maxZ, maxX, maxY, maxZ, maxX, maxY, minZ, minX, maxY, minZ, r, g, b, boxA);
			face(buffer, m, minX, minY, minZ, minX, maxY, minZ, minX, maxY, maxZ, minX, maxY, maxZ, r, g, b, boxA);
			face(buffer, m, minX, minY, maxZ, maxX, minY, maxZ, maxX, maxY, maxZ, minX, maxY, maxZ, r, g, b, boxA);
		});

		matrices.pop();
		return true;
	}

	/** Одна грань залитого бокса (позиция+цвет, без нормалей). */
	private static void face(net.minecraft.client.render.VertexConsumer buffer, org.joml.Matrix4f m,
			double x1, double y1, double z1, double x2, double y2, double z2,
			double x3, double y3, double z3, double x4, double y4, double z4,
			float r, float g, float b, float a) {
		buffer.vertex(m, (float) x1, (float) y1, (float) z1).color(r, g, b, a);
		buffer.vertex(m, (float) x2, (float) y2, (float) z2).color(r, g, b, a);
		buffer.vertex(m, (float) x3, (float) y3, (float) z3).color(r, g, b, a);
		buffer.vertex(m, (float) x4, (float) y4, (float) z4).color(r, g, b, a);
	}

	/** Диспетчер (AFTER_ENTITIES, из NeuClient). */
	public static void renderAllWorld(WorldRenderContext context) {
		var modules = ru.neuclient.client.NeuClient.getInstance().getModuleManager();
		if (modules == null) {
			return;
		}
		PredictionsModule self = modules.get(PredictionsModule.class);
		if (self != null && self.isEnabled()) {
			self.renderWorld(context, MinecraftClient.getInstance());
		}
	}
}
