package ru.neuclient.client.mixin;

import io.netty.channel.ChannelPipeline;
import io.netty.handler.proxy.Socks5ProxyHandler;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.NetworkSide;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.Coerce;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.config.ProxyConfig;
import ru.neuclient.client.config.ProxyHandler;

import java.net.InetSocketAddress;

@Mixin(ClientConnection.class)
public abstract class ClientConnectionMixin {

	@Inject(method = "addHandlers", at = @At("TAIL"))
	private static void pc$injectSocks5Proxy(ChannelPipeline pipeline, NetworkSide side,
			boolean local, @Nullable @Coerce Object packetSizeLogger, CallbackInfo ci) {

		if (side != NetworkSide.CLIENTBOUND || local) {
			// Интегрированный сервер использует LocalChannel и не должен
			// проходить через внешний SOCKS5-прокси. Иначе Minecraft пытается
			// подключить одиночный мир к адресу прокси и падает с
			// Connection refused.
			return;
		}

		ProxyConfig config = ProxyHandler.getConfig();
		if (config == null || !config.isActive()) {
			return;
		}

		NeuClient.LOGGER.info("[NeuClient] SOCKS5 proxy: {}:{} для подключения",
				config.proxyIp(), config.proxyPort());

		InetSocketAddress proxyAddress = new InetSocketAddress(config.proxyIp(), config.proxyPort());
		Socks5ProxyHandler socksHandler;

		if (config.proxyLogin() != null && !config.proxyLogin().isEmpty()) {
			socksHandler = new Socks5ProxyHandler(proxyAddress, config.proxyLogin(), config.proxyPassword());
		} else {
			socksHandler = new Socks5ProxyHandler(proxyAddress);
		}

		pipeline.addFirst("socks5proxy", socksHandler);
	}
}
