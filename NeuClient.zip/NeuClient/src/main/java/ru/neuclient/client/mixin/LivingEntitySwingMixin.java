package ru.neuclient.client.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.impl.render.AttackAnimationsModule;

/**
 * Attack Animations — настройка «Скорость».
 *
 * LivingEntity#getHandSwingDuration() возвращает, сколько тиков длится
 * взмах руки (ваниль берёт значение из компонента предмета, обычно 6,
 * плюс поправки на спешку/усталость). Подменяем результат для НАШЕГО
 * игрока: чем выше «Скорость», тем короче взмах и тем быстрее рука
 * возвращается в исходное положение.
 *
 * На реальную скорость атаки и пакеты это не влияет — только на то,
 * как быстро проигрывается анимация.
 */
@Mixin(LivingEntity.class)
public abstract class LivingEntitySwingMixin {

	@Inject(method = "getHandSwingDuration", at = @At("RETURN"), cancellable = true)
	private void pc$swingSpeed(CallbackInfoReturnable<Integer> cir) {
		try {
			// Только своя рука: чужие анимации не трогаем
			if ((Object) this != MinecraftClient.getInstance().player) {
				return;
			}
			AttackAnimationsModule module = AttackAnimationsModule.active();
			if (module != null) {
				cir.setReturnValue(module.getSwingDuration());
			}
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка Attack Animations (скорость)", t);
		}
	}
}
