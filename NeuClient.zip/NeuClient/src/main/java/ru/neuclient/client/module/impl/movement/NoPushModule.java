package ru.neuclient.client.module.impl.movement;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.BooleanSetting;

/**
 * NoPush — игрока не толкают.
 *
 * Две независимые галочки (обе включены по умолчанию):
 *
 *  • «Игроки» — ванильный Entity#pushAwayFrom раздаёт обеим сущностям
 *    addVelocity(±0.05) при пересечении хитбоксов. Миксин EntityPushMixin
 *    отменяет вызов целиком, если одна из сторон — наш игрок. Толпа больше
 *    не выдавливает из точки, где стоишь.
 *
 *  • «Вода» — Entity#updateMovementInFluid добавляет скорость течения только
 *    при isPushedByFluids() == true. У PlayerEntity этот метод возвращает
 *    !abilities.flying; миксин PlayerFluidPushMixin подменяет ответ на false,
 *    и течение реки/водопада перестаёт сносить. Плавать это не мешает:
 *    гребля идёт через travelInFluid, к толчку течения отношения не имеет.
 *
 * Обе части — чисто клиентские: сервер по-прежнему считает толчки по-своему,
 * поэтому при сильном течении возможна коррекция позиции. Против игроков
 * работает надёжно (там толчок применяется на каждой стороне отдельно).
 */
public final class NoPushModule extends Module {

	private final BooleanSetting players = new BooleanSetting("Игроки", true);
	private final BooleanSetting water = new BooleanSetting("Вода", true);

	public NoPushModule() {
		super("NoPush", "Не даёт толкать себя", Category.MOVEMENT);
		addSettings(players, water);
	}

	/** Вызывается из EntityPushMixin: гасить ли взаимный толчок сущностей. */
	public boolean shouldCancelEntityPush(Entity a, Entity b) {
		if (!players.get()) {
			return false;
		}
		PlayerEntity self = mc.player;
		if (self == null) {
			return false;
		}
		// Толчок гасим, только если он касается НАС (чужие пусть толкаются)
		return a == self || b == self;
	}

	/** Вызывается из PlayerFluidPushMixin: игнорировать ли течение жидкости. */
	public boolean shouldIgnoreFluidPush(PlayerEntity player) {
		return water.get() && player == mc.player;
	}
}
