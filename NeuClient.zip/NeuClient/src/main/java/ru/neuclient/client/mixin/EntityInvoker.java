package ru.neuclient.client.mixin;

import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

/**
 * Доступ к protected-методам Entity.
 *
 * {@code unsetRemoved()} в yarn-маппингах 1.21.11 protected: снаружи его
 * не вызвать напрямую, а для Air Stuck (режим «Удаляющий игрока») нужно
 * возвращать сущность игрока в мир при выключении модуля.
 */
@Mixin(Entity.class)
public interface EntityInvoker {

	@Invoker("unsetRemoved")
	void pc$invokeUnsetRemoved();
}
