package ru.neuclient.client.util;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Человеческий шум для ротаций: немонотонный гейн наведения, микро-залипания
 * и осевой тремор.
 *
 * ЗАЧЕМ. Аналитический доворот (строгая функция ошибки прицела) и ровный
 * периодический блуждательный сигнал — самые дешёвые признаки бота в
 * статистике ротации. Здесь всё наоборот:
 *  - {@link #pursuitGain} — гейн зависит от ошибки НЕ монотонно (волна со
 *    своей фазой на каждую цель), в ноль не проваливается;
 *  - {@link #microStall} — редкие «залипания» руки на 1–2 тика ломают
 *    постоянство интервалов;
 *  - {@link #axisDelta} — плавный OU-тремор по оси: шум проходит весь
 *    конвейер дельт (кламп → GCD), как у настоящей руки.
 */
public final class HumanNoise {

	private HumanNoise() {
	}

	/**
	 * Погонный гейн доворота (доля ошибки, закрываемая за тик).
	 *
	 * @param err   модуль ошибки прицела в градусах
	 * @param speed базовая скорость наведения из настроек
	 * @param phase фаза профиля — своя на каждую цель, чтобы кривая
	 *              «разгон → доводка» не повторялась от цели к цели
	 */
	public static float pursuitGain(float err, float speed, float phase) {
		// Базовая пропорция: быстрее наведение — больше доля за тик.
		float base = Math.min(0.45f, 0.18f + speed * 0.16f);
		// Немонотонность: волна по фазе и по логарифму ошибки — на маленьких
		// и больших ошибках темп доворота различается, монотонной функции нет.
		float wave = 0.85f + 0.30f * (float) Math.sin(
				phase * 6.2831853f + Math.log(1.0 + err) * 1.7f);
		float g = base * wave;
		// В ноль не проваливаемся (иначе «hover» на цели), вверх не рвёмся.
		return Math.max(0.08f, Math.min(g, 0.6f));
	}

	/**
	 * Пора ли «залипнуть»: true — рука приостановила доворот на 1–2 тика.
	 * Не чаще, чем раз в ~0.6 секунды, вероятность растёт с тишиной.
	 *
	 * @param ticksSince тиков с последнего залипания
	 */
	public static boolean microStall(int ticksSince) {
		if (ticksSince < 12) {
			return false;
		}
		return ThreadLocalRandom.current().nextDouble() < 0.015 + ticksSince * 0.0004;
	}

	/**
	 * Осевой тремор: плавный OU-процесс (Ornstein–Uhlenbeck), состояние
	 * хранится в переданном массиве (привычка проекта — float[1]).
	 *
	 * @param state   состояние оси (мутируется)
	 * @param strength сила шума (например, значение ползунка «Джиттер»)
	 * @param scale    доля силы для данной оси (yaw шумит сильнее pitch)
	 */
	public static float axisDelta(float[] state, float strength, float scale) {
		ThreadLocalRandom rnd = ThreadLocalRandom.current();
		state[0] = state[0] * 0.86f + (float) rnd.nextGaussian() * 0.28f;
		return state[0] * strength * scale;
	}
}
