package ru.neuclient.client.module.impl.combat;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.BooleanSetting;
import ru.neuclient.client.setting.NumberSetting;

import java.util.concurrent.ThreadLocalRandom;

/**
 * TriggerBot — сам бьёт, когда ПРИЦЕЛ наведён на хитбокс цели.
 *
 * Логика как у живого игрока: наводишь сам (или AimBot), а модуль
 * только «кликает». Попадание по хитбоксу определяет ванильный raycast
 * прицела (MinecraftClient#targetedEntity) — он же гарантирует, что цель
 * видна (через стены не бьёт). Дальность — до 2.9 блоков от глаз до
 * ближайшей точки хитбокса.
 *
 * Настройки:
 *  Бить только критами — удар только в падении (как крит);
 *  Игроки / Враждебные мобы / Мирные мобы / Невидимые игроки — фильтры;
 *  Рандом атаки — после готовности кулдауна удар откладывается на
 *    случайные 0..N тиков (N = настройка), чтобы интервал между
 *    ударами плавал и не был «тик в тик» с перезарядкой;
 *  Сброс спринта — сброс спринта через SprintControl при атаке.
 */
public class TriggerBotModule extends Module {

	/** Дальность: прицел должен быть на хитбоксе не дальше этого (блоки). */
	private static final double REACH = 2.9;

	private final BooleanSetting adaptive = new BooleanSetting("Адаптивный", true);
	private final BooleanSetting onlyCrit = new BooleanSetting("Бить только критами", true);
	private final BooleanSetting players = new BooleanSetting("Игроки", true);
	private final BooleanSetting hostileMobs = new BooleanSetting("Враждебные мобы", true);
	private final BooleanSetting peacefulMobs = new BooleanSetting("Мирные мобы", false);
	private final BooleanSetting invisiblePlayers = new BooleanSetting("Невидимые игроки", false);
	private final NumberSetting attackRandom = new NumberSetting("Рандом атаки", 2.0, 0.0, 5.0, 1.0);
	private final BooleanSetting sprintReset = new BooleanSetting("Сброс спринта", true);

	private final SprintControl sprintControl = new SprintControl();

	/** Оставшиеся случайные тики задержки до удара. */
	private int attackWaitTicks;

	public TriggerBotModule() {
		super("TriggerBot", "Бьёт сам, когда прицел на хитбоксе цели", Category.COMBAT);
		addSettings(onlyCrit, adaptive, players, hostileMobs, peacefulMobs, invisiblePlayers, attackRandom, sprintReset);
	}

	@Override
	protected void onDisable() {
		attackWaitTicks = 0;
		sprintControl.reset();
	}

	@Override
	public void onTick(MinecraftClient client) {
		sprintControl.onTick(client);

		if (client.player == null || client.world == null || client.interactionManager == null) {
			return;
		}

		// Цель под прицелом (ванильный raycast: хитбокс + видимость)
		Entity crosshair = client.targetedEntity;
		if (!(crosshair instanceof LivingEntity living) || !isValid(client, living)
				|| distanceToHitbox(client.player, living) > REACH) {
			attackWaitTicks = 0; // увёл прицел — при новом наведении задержка с нуля
			return;
		}

		// Как у AttackAura: земля — обычный удар, в воздухе ждём крита.
		// Спринт снимается заранее, а не только после уже нанесённого удара.
		if (needsSprintOffForCrit() && client.player.isSprinting()) {
			client.player.setSprinting(false);
			return; // ваниль успеет отправить STOP_SPRINTING перед атакой следующего тика
		}
		if (!AttackTiming.allowsAttack(onlyCrit.get(), adaptive.get(),
				client.player.isOnGround(), canCrit(client))) return;
		// Удар только при полном кулдауне оружия (полный урон)
		if (client.player.getAttackCooldownProgress(0.5f) < 1.0f) {
			return;
		}
		// Случайная задержка после готовности (анти-паттерн «тик в тик»)
		if (attackWaitTicks > 0) {
			attackWaitTicks--;
			return;
		}

		client.interactionManager.attackEntity(client.player, living);
		// Взмах рукой — как в ванилле (MinecraftClient#doAttack): анимация
		// у нас и пакет замаха на сервер
		client.player.swingHand(Hand.MAIN_HAND);

		if (sprintReset.get()) {
			sprintControl.resetSprint();
		}

		int max = attackRandom.get().intValue();
		attackWaitTicks = max <= 0 ? 0 : ThreadLocalRandom.current().nextInt(0, max + 1);
	}

	public SprintControl getSprintControl() {
		return sprintControl;
	}

	/** Крит возможен только в падении (fallDistance > 0, не на земле). */
	private boolean canCrit(MinecraftClient client) {
		ClientPlayerEntity player = client.player;
		return player.fallDistance > 0.0 && !player.isOnGround()
				&& !player.isClimbing() && !player.isTouchingWater()
				&& !player.hasBlindnessEffect() && !player.hasVehicle() && !player.isSprinting();
	}

	/** Снять спринт на время прыжка с подходящей целью под прицелом. */
	public boolean needsSprintOffForCrit() {
		ClientPlayerEntity player = mc.player;
		if (!isEnabled() || player == null || mc.world == null || player.isOnGround()
				|| (!onlyCrit.get() && !adaptive.get())) return false;
		if (!(mc.targetedEntity instanceof LivingEntity living) || !isValid(mc, living)
				|| distanceToHitbox(player, living) > REACH) return false;
		return !player.isClimbing() && !player.isTouchingWater()
				&& !player.hasBlindnessEffect() && !player.hasVehicle();
	}

	public static boolean shouldHoldSprintForCrit() {
		NeuClient neu = NeuClient.getInstance();
		if (neu == null || neu.getModuleManager() == null) return false;
		TriggerBotModule trigger = neu.getModuleManager().get(TriggerBotModule.class);
		return trigger != null && trigger.needsSprintOffForCrit();
	}

	/** Фильтр типов целей (дружба из .friend — не трогаем). */
	private boolean isValid(MinecraftClient client, LivingEntity entity) {
		ClientPlayerEntity self = client.player;
		if (entity == null || entity == self || entity.getId() == self.getId() || !entity.isAlive()) {
			return false;
		}
		if (ru.neuclient.client.bot.BotManager.getInstance().isBot(entity.getName().getString())) {
			return false;
		}
		if (entity instanceof PlayerEntity other) {
			if (other.isSpectator()) {
				return false;
			}
			if (!players.get()) {
				return false;
			}
			if (NeuClient.getInstance().getFriendManager().isFriend(other.getName().getString())) {
				return false;
			}
			if (other.isInvisible() && !invisiblePlayers.get()) {
				return false;
			}
			return true;
		}
		if (entity instanceof HostileEntity) {
			return hostileMobs.get();
		}
		if (entity instanceof AnimalEntity) {
			return peacefulMobs.get();
		}
		return false; // остальных существ (големы, жители и т.п.) не трогаем
	}

	/** Дальность от глаз игрока до ближайшей точки хитбокса цели. */
	private static double distanceToHitbox(ClientPlayerEntity self, Entity entity) {
		Vec3d eyes = self.getEyePos();
		Box box = entity.getBoundingBox();
		double dx = Math.max(box.minX - eyes.x, Math.max(0.0, eyes.x - box.maxX));
		double dy = Math.max(box.minY - eyes.y, Math.max(0.0, eyes.y - box.maxY));
		double dz = Math.max(box.minZ - eyes.z, Math.max(0.0, eyes.z - box.maxZ));
		return Math.sqrt(dx * dx + dy * dy + dz * dz);
	}
}
