package ru.neuclient.client.ui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.config.FriendManager;
import ru.neuclient.client.font.MsdfFontRenderer;
import ru.neuclient.client.font.MsdfFonts;
import ru.neuclient.client.util.RenderUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Список друзей с удалением по крестику.
 *
 * Открывается командой .friend list (вместо текстового вывода в чат).
 * Каждый ник — отдельная строка, справа от неё крестик: клик по нему убирает
 * друга из списка и сразу сохраняет friends.json.
 *
 * Чисто интерфейсный экран: никакой логики друзей тут нет, всё делегируется
 * {@link FriendManager}.
 */
public class FriendListScreen extends Screen {

	private static final int LIST_W = 240;
	private static final int ROW_H = 16;
	private static final int CROSS_W = 14;

	/** Скролл в строках. */
	private int scroll;

	/** Короткое сообщение под списком («Удалён: …»). */
	private String status = "";
	private long statusUntil;

	/** Последний наведённый индекс — чтобы убрать крестик при уходе мыши. */
	private int hoveredRow = -1;

	public FriendListScreen() {
		super(Text.literal("Друзья"));
	}

	private FriendManager friends() {
		return NeuClient.getInstance().getFriendManager();
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	@Override
	public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
		super.renderBackground(ctx, mouseX, mouseY, delta);
		ctx.fill(0, 0, width, height, 0x6606090F);
	}

	@Override
	public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
		super.render(ctx, mouseX, mouseY, delta);

		int cx = width / 2;
		int listX = cx - LIST_W / 2;
		int listY = 64;

		List<String> names = new ArrayList<>(friends().list());
		int maxRows = Math.max(1, (height - listY - 28) / ROW_H);

		// Держим скролл в допустимых границах — список мог измениться снаружи.
		int pages = Math.max(0, names.size() - maxRows);
		if (scroll > pages) {
			scroll = pages;
		}
		if (scroll < 0) {
			scroll = 0;
		}

		RenderUtil.drawWaveTextCentered(ctx, "ДРУЗЬЯ", cx, 14);

		String count = names.isEmpty() ? "Список пуст" : "Всего: " + names.size();
		RenderUtil.textCentered(ctx, count, cx, 42, RenderUtil.textDim());

		int visible = Math.min(names.size() - scroll, maxRows);
		int listH = Math.max(visible, 1) * ROW_H + 4;
		RenderUtil.roundBorderRect(ctx, listX, listY, LIST_W, listH, 4, RenderUtil.BORDER, RenderUtil.bg());

		if (names.isEmpty()) {
			RenderUtil.textCentered(ctx, "Добавь через .friend add <ник>", cx, listY + 5, RenderUtil.textDim());
		}

		hoveredRow = -1;
		int ry = listY + 2;
		for (int i = 0; i < visible; i++) {
			int index = i + scroll;
			String name = names.get(index);

			boolean rowHover = mouseX >= listX && mouseX < listX + LIST_W
					&& mouseY >= ry && mouseY < ry + ROW_H;
			int crossX = listX + LIST_W - CROSS_W - 4;
			boolean crossHover = rowHover && mouseX >= crossX && mouseX < crossX + CROSS_W;

			if (rowHover) {
				hoveredRow = index;
				RenderUtil.fill(ctx, listX + 1, ry, LIST_W - 2, ROW_H, 0x183FB4FF);
			}
			if (crossHover) {
				// Подсветка самого крестика — видно, что клик сработает
				RenderUtil.fill(ctx, crossX, ry + 1, CROSS_W, ROW_H - 2, 0x55FF5252);
			}

			MsdfFontRenderer.drawWithShadow(ctx, MsdfFonts.sfRegular(), name,
					listX + 7, ry + 3.5f, crossHover ? RenderUtil.TEXT : RenderUtil.TEXT, 9.0f);

			// Крестик
			int cxC = crossX + CROSS_W / 2;
			int cyC = ry + ROW_H / 2;
			int col = crossHover ? RenderUtil.DANGER : RenderUtil.textOff();
			RenderUtil.fill(ctx, cxC - 3, cyC, 7, 1, col);
			RenderUtil.fill(ctx, cxC, cyC - 3, 1, 7, col);

			// Разделитель
			if (i < visible - 1) {
				RenderUtil.fill(ctx, listX + 4, ry + ROW_H - 1, LIST_W - 8, 1, 0x22FFFFFF);
			}
			ry += ROW_H;
		}

		// Индикатор прокрутки
		if (names.size() > maxRows) {
			String hint = (scroll + 1) + "–" + (scroll + visible) + " / " + names.size() + "  (колесо)";
			RenderUtil.textCentered(ctx, hint, cx, listY + listH + 6, RenderUtil.textDim());
		}

		if (!status.isEmpty() && System.currentTimeMillis() < statusUntil) {
			RenderUtil.textCentered(ctx, status, cx, height - 22, RenderUtil.DANGER);
		} else {
			RenderUtil.textCentered(ctx, "ESC — закрыть", cx, height - 22, RenderUtil.textOff());
		}
	}

	@Override
	public boolean mouseClicked(Click click, boolean doubled) {
		if (click.button() != 0) {
			return super.mouseClicked(click, doubled);
		}

		int cx = width / 2;
		int listX = cx - LIST_W / 2;
		int listY = 64;
		int crossX = listX + LIST_W - CROSS_W - 4;

		double mx = click.x();
		double my = click.y();

		if (mx < crossX || mx >= crossX + CROSS_W || my < listY + 2) {
			return super.mouseClicked(click, doubled);
		}

		int row = (int) ((my - (listY + 2)) / ROW_H);
		List<String> names = new ArrayList<>(friends().list());
		int maxRows = Math.max(1, (height - listY - 28) / ROW_H);
		int visible = Math.min(names.size() - scroll, maxRows);

		if (row < 0 || row >= visible) {
			return super.mouseClicked(click, doubled);
		}

		String name = names.get(row + scroll);
		if (friends().remove(name)) {
			ClickGuiScreen.playClick();
			status = "Удалён: " + name;
			statusUntil = System.currentTimeMillis() + 2000L;
			// После удаления строки съезжают вверх — скролл может выйти за край
			int pages = Math.max(0, (names.size() - 1) - maxRows);
			if (scroll > pages) {
				scroll = pages;
			}
		}
		return true;
	}

	@Override
	public boolean mouseScrolled(double mouseX, double mouseY, double scrollX, double scrollY) {
		scroll -= (int) Math.signum(scrollY);
		if (scroll < 0) {
			scroll = 0;
		}
		return true;
	}

	@Override
	public boolean keyPressed(KeyInput input) {
		if (input.key() == GLFW.GLFW_KEY_ESCAPE) {
			close();
			return true;
		}
		return super.keyPressed(input);
	}

	@Override
	public void close() {
		MinecraftClient client = MinecraftClient.getInstance();
		if (client != null) {
			client.setScreen(null);
		}
	}
}
