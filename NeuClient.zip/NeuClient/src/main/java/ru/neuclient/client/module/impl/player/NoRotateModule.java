package ru.neuclient.client.module.impl.player;

import net.minecraft.client.network.ClientPlayerEntity;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;

/**
 * NoRotate — предотвращает принудительный доворот камеры сервером при телепортации,
 * сохраняя валидное подтверждение пакета телепортации.
 *
 * Настройки убраны — всегда включён. Перемещён в категорию Player.
 */
public final class NoRotateModule extends Module {

    private float savedYaw = 0f;
    private float savedPitch = 0f;
    private boolean hasSaved = false;

    public NoRotateModule() {
        super("NoRotate", "Игнорирует принудительный поворот от сервера", Category.PLAYER);
        // Настройки убраны — всегда on
    }

    public void saveRotation(float yaw, float pitch) {
        if (!isEnabled()) return;
        this.savedYaw = yaw;
        this.savedPitch = pitch;
        this.hasSaved = true;
    }

    public void restoreRotation(ClientPlayerEntity player) {
        if (!isEnabled() || !hasSaved || player == null) return;
        // Всегда отменяем оба (Yaw и Pitch)
        player.setYaw(savedYaw);
        player.setPitch(savedPitch);
        this.hasSaved = false;
    }
}
