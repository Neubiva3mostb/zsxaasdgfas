package ru.neuclient.client.font;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;

import java.util.function.Supplier;

/**
 * Текстура MSDF-атласа с линейной фильтрацией.
 *
 * Для signed-distance-field критично билинейное сэмплирование,
 * иначе края глифов получаются резкими/пиксельными.
 */
public final class MsdfTexture extends NativeImageBackedTexture {

	public MsdfTexture(Supplier<String> name, NativeImage image) {
		super(name, image);
		this.sampler = RenderSystem.getSamplerCache().get(FilterMode.LINEAR);
	}
}
