package ru.neuclient.client.module.impl.player;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.Perspective;
import net.minecraft.util.math.MathHelper;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;

/**
 * FreeCam — камера отделяется от тела и летает сама по себе.
 *
 * ТЕЛО. Позиция и повороты игрока ЗАМОРАЖИВАЮТСЯ на момент включения:
 *  - сервер каждый тик получает одну и ту же голову (yaw/pitch не меняются);
 *  - клиентское тело тоже стоит с исходным поворотом;
 *  - мышь вращает ТОЛЬКО свободную камеру: каждый кадр после ванильного
 *    updateMouse дельта мыши переносится в camYaw/camPitch, а телу тут же
 *    возвращаются замороженные углы (страховочный перенос — ещё и в тик).
 *
 * ВИДНО СЕБЯ. Пока модуль активен, клиент принудительно переводится в
 * вид от третьего лица (THIRD_PERSON_BACK): тело рендерится ванилью там,
 * где стоит, а рука от первого лица исчезает. Камеру при этом мы всё
 * равно ставим СВОЮ (CameraMixin перетирает позицию и поворот после
 * ванильного update), так что отъезд «за спину» не чувствуется.
 *
 * ПОЛЁТ: WASD — горизонт (по направлению свободной камеры), Space — вверх,
 * Shift — вниз, спринт — быстрее. Сквозь блоки камера летит свободно.
 *
 * Всё чисто клиентское: сервер видит стоящего на месте игрока с
 * неподвижной головой.
 */
public final class FreeCamModule extends Module {

	/** Обычная скорость камеры (блоков/тик). */
	private static final double WALK_SPEED = 0.5;
	/** Множитель при зажатом спринте. */
	private static final double SPRINT_MULT = 2.5;

	/** Позиция камеры НА ТЕКУЩИЙ тик (мировые координаты). */
	private double x;
	private double y;
	private double z;
	/** Позиция камеры НА ПРОШЛЫЙ тик — для плавной интерполяции между тиками. */
	private double prevX;
	private double prevY;
	private double prevZ;
	/** true, пока позиция ещё не захвачена из камеры. */
	private boolean initialized = false;

	/** Свободные углы камеры (крутятся мышью, телу не передаются). */
	private float camYaw;
	private float camPitch;
	/** Замороженные повороты ТЕЛА (их видят сервер и клиентский рендер). */
	private float bodyYaw;
	private float bodyPitch;
	/** Было ли 1-е лицо до включения (чтобы вернуть при выключении). */
	private boolean savedFirstPerson = true;

	public FreeCamModule() {
		super("FreeCam", "Камера отделяется от тела и свободно летает", Category.PLAYER);
	}

	@Override
	protected void onEnable() {
		initialized = false; // позицию/углы возьмём у реальной камеры на первом тике

		MinecraftClient client = MinecraftClient.getInstance();
		if (client.options != null) {
			// Третье лицо: тело игрока рендерится, рука от 1-го лица исчезает.
			savedFirstPerson = client.options.getPerspective().isFirstPerson();
			if (savedFirstPerson) {
				client.options.setPerspective(Perspective.THIRD_PERSON_BACK);
			}
		}
	}

	@Override
	public void onTick(MinecraftClient client) {
		ClientPlayerEntity player = client.player;
		if (player == null || client.world == null) {
			return;
		}

		if (!initialized) {
			// Стартуем от глаз игрока с его текущими углами.
			x = player.getX();
			y = player.getY() + player.getStandingEyeHeight();
			z = player.getZ();
			prevX = x;
			prevY = y;
			prevZ = z;
			camYaw = player.getYaw();
			camPitch = player.getPitch();
			bodyYaw = player.getYaw();
			bodyPitch = player.getPitch();
			initialized = true;
		}

		// Страховка раз в тик: если покадровый перенос ещё не сработал,
		// дельта за кадры этого тика уйдёт в камеру здесь (дубля не будет —
		// transferMouseLook каждый кадр уже заморозил тело, диффы нулевые).
		transferMouseLook();

		// Фиксируем прошлый тик ДО движения: камера интерполируется между
		// prev и текущим с дробным шагом кадра — полёт плавный на любом FPS.
		prevX = x;
		prevY = y;
		prevZ = z;

		// --- Полёт камеры по сырым клавишам (игровой ввод при этом 0) ---
		double speed = WALK_SPEED * (client.options.sprintKey.isPressed() ? SPRINT_MULT : 1.0);

		double forward = 0.0;
		double strafe = 0.0;
		if (client.options.forwardKey.isPressed()) forward += 1.0;
		if (client.options.backKey.isPressed()) forward -= 1.0;
		if (client.options.leftKey.isPressed()) strafe += 1.0;
		if (client.options.rightKey.isPressed()) strafe -= 1.0;

		// Движение по направлению СВОБОДНОЙ камеры.
		double yaw = Math.toRadians(camYaw);
		double sin = Math.sin(yaw);
		double cos = Math.cos(yaw);
		x += (-sin * forward + cos * strafe) * speed;
		z += (cos * forward + sin * strafe) * speed;

		if (client.options.jumpKey.isPressed()) y += speed;
		if (client.options.sneakKey.isPressed()) y -= speed;
	}

	/**
	 * Перенос поворота мыши в свободную камеру. Вызывается КАЖДЫЙ КАДР из
	 * MouseMixin сразу после ванильного updateMouse: ваниль уже применила
	 * дельту мыши к телу игрока — забираем её в camYaw/camPitch и тут же
	 * возвращаем телу замороженные углы. Сервер и рендер тела видят
	 * неподвижную голову, а камера крутится в тот же кадр, без лага тика.
	 */
	public void transferMouseLook() {
		MinecraftClient client = MinecraftClient.getInstance();
		ClientPlayerEntity player = client.player;
		if (player == null || client.world == null || !initialized) {
			return;
		}
		if (client.currentScreen != null) {
			return;
		}
		float deltaYaw = MathHelper.wrapDegrees(player.getYaw() - bodyYaw);
		float deltaPitch = player.getPitch() - bodyPitch;
		if (deltaYaw == 0.0f && deltaPitch == 0.0f) {
			return;
		}
		camYaw = MathHelper.wrapDegrees(camYaw + deltaYaw);
		camPitch = MathHelper.clamp(camPitch + deltaPitch, -89.9f, 89.9f);
		freezeBody(player);
	}

	/** Возвращает телу замороженные углы (для сервера и клиентского рендера). */
	private void freezeBody(ClientPlayerEntity player) {
		player.setYaw(bodyYaw);
		player.setPitch(bodyPitch);
		player.setHeadYaw(bodyYaw);
		player.setBodyYaw(bodyYaw);
	}

	/** Лерп-позиция камеры для ЭТОГО КАДРА (CameraMixin зовёт с tickDelta 0..1). */
	public double getCamX(float tickDelta) {
		return prevX + (x - prevX) * tickDelta;
	}

	public double getCamY(float tickDelta) {
		return prevY + (y - prevY) * tickDelta;
	}

	public double getCamZ(float tickDelta) {
		return prevZ + (z - prevZ) * tickDelta;
	}

	/** Свободный поворот камеры (крутится мышью, независим от тела). */
	public float getCamYaw() {
		return camYaw;
	}

	public float getCamPitch() {
		return camPitch;
	}

	public boolean isInitialized() {
		return initialized;
	}

	@Override
	protected void onDisable() {
		initialized = false;

		MinecraftClient client = MinecraftClient.getInstance();
		// Возвращаем вид от первого лица, если сами его меняли.
		if (client.options != null && savedFirstPerson) {
			client.options.setPerspective(Perspective.FIRST_PERSON);
		}
	}
}
