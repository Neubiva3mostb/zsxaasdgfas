package ru.neuclient.client.module.impl.combat;

import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;

/**
 * NoSlotChange — не даёт серверу принудительно менять активный слот в хотбаре.
 *
 * Работает как в aethereal: при получении UpdateSelectedSlotS2CPacket
 * пакет отменяется, а серверу отправляется UpdateSelectedSlotC2SPacket
 * с нашим реальным слотом.
 *
 * Также блокирует подмену инвентаря сервером (ScreenHandlerSlotUpdate,
 * InventoryS2CPacket) для инвентаря игрока (syncId 0).
 */
public final class NoSlotChangeModule extends Module {

	public NoSlotChangeModule() {
		super("NoSlotChange", "Не даёт серверу переключать слот руки и подменять предметы в инвентаре",
				Category.COMBAT);
		// Настроек нет — всегда работает на все слоты + возврат слота
	}

	/**
	 * Блокировать ли точечное обновление слота в инвентаре.
	 * Только для инвентаря игрока (syncId 0) и только когда НЕ открыт контейнер.
	 */
	public boolean blockSlotUpdate(int syncId) {
		if (!isEnabled()) return false;
		if (syncId != 0) return false;
		return isInventoryIdle();
	}

	/** Блокировать ли массовую переотправку всего инвентаря. */
	public boolean blockFullInventory(int syncId) {
		if (!isEnabled()) return false;
		if (syncId != 0) return false;
		return isInventoryIdle();
	}

	/** true — контейнер не открыт, работает только собственный инвентарь игрока. */
	private boolean isInventoryIdle() {
		var player = mc.player;
		if (player == null) return false;
		return player.currentScreenHandler == player.playerScreenHandler;
	}
}
