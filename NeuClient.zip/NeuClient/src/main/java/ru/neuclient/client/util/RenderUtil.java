package ru.neuclient.client.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.ScreenRect;
import org.joml.Matrix3x2f;
import ru.neuclient.client.render.RoundedRectGuiElementRenderState;
import ru.neuclient.client.font.MsdfFontRenderer;
import ru.neuclient.client.font.MsdfFonts;
import ru.neuclient.client.module.Category;

/**
 * Визуальная палитра и примитивы отрисовки NeuClient.
 *
 * Все текстовые примитивы используют нативный MSDF-шрифт с субпиксельным сглаживанием.
 */
public final class RenderUtil {

	// ===== Статичный цвет (управляется через HUD) =====
	private static int customR = 122;
	private static int customG = 92;
	private static int customB = 255;
	private static float brightness = 1.0f;

	/** Установить RGB цвет. */
	public static void setColor(int r, int g, int b) {
		customR = Math.max(0, Math.min(255, r));
		customG = Math.max(0, Math.min(255, g));
		customB = Math.max(0, Math.min(255, b));
	}

	/** Установить яркость. */
	public static void setBrightness(float b) {
		brightness = Math.max(0.2f, Math.min(2.0f, b));
	}

	/** Получить RGB. */
	public static int[] getColor() {
		return new int[]{customR, customG, customB};
	}

	/** Получить яркость. */
	public static float getBrightness() {
		return brightness;
	}

	// ===== Палитра (редактируется в ClickGUI → панель «Цвета») =====
	//
	// Раньше это были final-константы, а RGB акцента жил настройками модуля
	// Interface. Теперь ВСЕ цвета клиента правятся в одном месте — в панели
	// цветов в левом нижнем углу ClickGUI, — поэтому поля стали изменяемыми,
	// а доступ к ним продублирован строковым ключом (его используют панель
	// и конфиг). Значения по умолчанию совпадают с прежними константами,
	// так что «из коробки» вид клиента не изменился.
	public static int GUI_BG    = 0x900B1018; // подложка панелей ClickGUI (полупрозрачная)
	public static int BORDER    = 0xFF2A3A55; // спокойная рамка
	public static int TEXT      = 0xFFF2F6FF; // основной текст
	public static int TOGGLE_OFF = 0xFF404858; // тумблер в положении «выкл»
	public static int DANGER    = 0xFFFF5252; // ошибки и удаление
	public static int PARTICLES = 0xFF7A5CFF; // частицы модуля Particles
	public static int CROSSHAIR = 0xFFFFFFFF; // цвет прицела CrossHair
	public static int CUSTOMFOG = 0xFF99B3FF; // цвет тумана CustomFog

	// ===== Производные цвета =====
	//
	// Раньше «Фон», «Шапка», «Поля», «Тусклый», «Выкл» и «Тёмный» были
	// отдельными чипами в панели цветов. Настраивать шесть почти одинаковых
	// оттенков вручную бессмысленно, поэтому теперь они ВЫЧИСЛЯЮТСЯ из двух
	// базовых: «Панели» (фон) и «Текст». Меняешь один чип — вся производная
	// гамма едет за ним и остаётся согласованной.

	/** Тело непрозрачных плашек: RGB «Панелей», но почти без прозрачности. */
	public static int bg() {
		return 0xF2000000 | (GUI_BG & 0x00FFFFFF);
	}

	/** Заголовочная полоса — на треть светлее тела панели. */
	public static int bgHeader() {
		return 0xF2000000 | (shade(GUI_BG, 1.35f) & 0x00FFFFFF);
	}

	/** Поля ввода и треки слайдеров — чуть темнее тела панели. */
	public static int bgInput() {
		return 0xFF000000 | (shade(GUI_BG, 0.85f) & 0x00FFFFFF);
	}

	/** Приглушённый текст — «Текст», притушенный до 64 %. */
	public static int textDim() {
		return shade(TEXT, 0.64f);
	}

	/** Текст выключенного элемента — «Текст», притушенный до 53 %. */
	public static int textOff() {
		return shade(TEXT, 0.53f);
	}

	/** Ключи цветов — порядок задаёт порядок чипов в панели цветов. */
	public static final String[] THEME_KEYS = {
			"accent", "gui", "border", "text", "toggle", "danger", "particles", "crosshair", "customfog"
	};

	/** Короткие подписи чипов (влезают в половину ширины панели). */
	public static final String[] THEME_LABELS = {
			"Акцент", "Панели", "Рамка", "Текст", "Тумблер", "Ошибка", "Партиклы", "Прицел", "Туман"
	};

	private static final int[] THEME_DEFAULTS = {
			0xFF7A5CFF, 0x900B1018, 0xFF2A3A55, 0xFFF2F6FF, 0xFF404858, 0xFFFF5252, 0xFF7A5CFF, 0xFFFFFFFF, 0xFF99B3FF
	};

	public static final String[] COLOR_PALETTE = {
			"Фиолетовый", "Синий", "Бирюзовый", "Зелёный", "Жёлтый", "Оранжевый", "Красный", "Розовый", "Белый"
	};

	public static int parseColor(String name) {
		return switch (name) {
			case "Синий" -> 0xFF4A88FF;
			case "Бирюзовый" -> 0xFF2EE6D6;
			case "Зелёный" -> 0xFF4CD964;
			case "Жёлтый" -> 0xFFFFD60A;
			case "Оранжевый" -> 0xFFFF9500;
			case "Красный" -> 0xFFFF3B30;
			case "Розовый" -> 0xFFFF2D55;
			case "Белый" -> 0xFFFFFFFF;
			default -> 0xFF7A5CFF; // Фиолетовый
		};
	}

	private RenderUtil() {
	}

	/** Индекс ключа в THEME_KEYS или -1. */
	public static int themeIndex(String key) {
		for (int i = 0; i < THEME_KEYS.length; i++) {
			if (THEME_KEYS[i].equals(key)) {
				return i;
			}
		}
		return -1;
	}

	/** Цвет по ключу. Для акцента — «чистый» RGB, без множителя яркости. */
	public static int getThemeColor(String key) {
		return switch (key) {
			case "accent" -> 0xFF000000 | (customR << 16) | (customG << 8) | customB;
			case "gui" -> GUI_BG;
			case "border" -> BORDER;
			case "text" -> TEXT;
			case "toggle" -> TOGGLE_OFF;
			case "danger" -> DANGER;
			case "particles" -> PARTICLES;
			case "crosshair" -> CROSSHAIR;
			case "customfog" -> CUSTOMFOG;
			default -> 0xFFFFFFFF;
		};
	}

	/** Установка цвета по ключу (у акцента альфа игнорируется — за неё отвечает яркость). */
	public static void setThemeColor(String key, int argb) {
		switch (key) {
			case "accent" -> setColor((argb >> 16) & 0xFF, (argb >> 8) & 0xFF, argb & 0xFF);
			case "gui" -> GUI_BG = argb;
			case "border" -> BORDER = argb;
			case "text" -> TEXT = argb;
			case "toggle" -> TOGGLE_OFF = argb;
			case "danger" -> DANGER = argb;
			case "particles" -> PARTICLES = argb;
			case "crosshair" -> CROSSHAIR = argb;
			case "customfog" -> CUSTOMFOG = argb;
			default -> { }
		}
	}

	/** У акцента вместо альфы регулируется яркость. */
	public static boolean themeHasAlpha(String key) {
		return !"accent".equals(key);
	}

	/** Вернуть всю палитру к заводским значениям. */
	public static void resetTheme() {
		for (int i = 0; i < THEME_KEYS.length; i++) {
			setThemeColor(THEME_KEYS[i], THEME_DEFAULTS[i]);
		}
		setBrightness(1.0f);
	}

	/** Умножение RGB на коэффициент (альфа сохраняется) — для «ещё тусклее». */
	public static int shade(int color, float k) {
		int a = color >>> 24;
		int r = Math.min(255, (int) (((color >> 16) & 0xFF) * k));
		int g = Math.min(255, (int) (((color >> 8) & 0xFF) * k));
		int b = Math.min(255, (int) ((color & 0xFF) * k));
		return (a << 24) | (r << 16) | (g << 8) | b;
	}

	// ===== Статичный акцент =====

	/** Акцентный цвет (статичный, RGB + яркость). */
	public static int accent() {
		var client = ru.neuclient.client.NeuClient.getInstance();
		if (client != null) {
			var im = client.getInterfaceModule();
			if (im != null) {
				return im.getGeneralColor();
			}
		}
		int r = (int) (customR * brightness);
		int g = (int) (customG * brightness);
		int b = (int) (customB * brightness);
		return 0xFF000000 | (Math.min(255, r) << 16) | (Math.min(255, g) << 8) | Math.min(255, b);
	}

	/** Второй цвет (противофаза) — для градиентных надписей. */
	public static int accent2() {
		int r = (int) (customR * brightness * 0.7f);
		int g = (int) (customG * brightness * 0.7f);
		int b = (int) (customB * brightness * 0.7f);
		return 0xFF000000 | (Math.min(255, r) << 16) | (Math.min(255, g) << 8) | Math.min(255, b);
	}

	/** Полупрозрачный акцент для заливок и свечения. */
	public static int accentDim() {
		return (accent() & 0x00FFFFFF) | 0x55000000;
	}

	/** Цвет текста ПОВЕРХ акцента. */
	public static int onAccent() {
		return 0xFFF4F6FA;
	}

	/** Приглушённый вариант onAccent. */
	public static int onAccentDim() {
		return 0xFFC9D1E0;
	}

	/** Акцент с фазовым сдвигом. */
	public static int accentAt(float phase) {
		return accent();
	}

	// ===== Базовые примитивы =====

	public static TextRenderer font() {
		return MinecraftClient.getInstance().textRenderer;
	}

	public static void fill(DrawContext ctx, int x, int y, int w, int h, int color) {
		ctx.fill(x, y, x + w, y + h, color);
	}

	public static void border(DrawContext ctx, int x, int y, int w, int h, int color) {
		ctx.fill(x, y, x + w, y + 1, color);
		ctx.fill(x, y + h - 1, x + w, y + h, color);
		ctx.fill(x, y, x + 1, y + h, color);
		ctx.fill(x + w - 1, y, x + w, y + h, color);
	}

	public static void text(DrawContext ctx, String s, int x, int y, int color) {
		MsdfFontRenderer.drawWithShadow(ctx, MsdfFonts.sfRegular(), s, x, y, color, 9.0f);
	}

	public static int textWidth(String s) {
		return (int) Math.ceil(MsdfFontRenderer.getWidth(MsdfFonts.sfRegular(), s, 9.0f));
	}

	public static void textCentered(DrawContext ctx, String s, int centerX, int y, int color) {
		MsdfFontRenderer.drawCenteredWithShadow(ctx, MsdfFonts.sfRegular(), s, centerX, y, color, 9.0f);
	}

	// ===== Скруглённые прямоугольники =====

	/**
	 * Скруглённый прямоугольник одним GPU-quad'ом.
	 *
	 * Геометрия считается SDF-шейдером, поэтому здесь нет циклов ctx.fill
	 * по пикселям и нет лесенки из квадратов. Один вызов = один quad.
	 */
	public static void roundRect(DrawContext ctx, int x, int y, int w, int h, int r, int color) {
		if (w <= 0 || h <= 0) return;
		r = Math.max(0, Math.min(r, Math.min(w, h) / 2));
		if (r == 0) {
			ctx.fill(x, y, x + w, y + h, color);
			return;
		}

		Matrix3x2f pose = new Matrix3x2f(ctx.getMatrices());
		ScreenRect scissor = ctx.scissorStack.peekLast();
		ScreenRect rawBounds = new ScreenRect(x, y, w, h);
		ScreenRect transformed = rawBounds.transformEachVertex(pose);
		ScreenRect bounds = scissor == null ? transformed : transformed.intersection(scissor);
		ctx.state.addSimpleElement(new RoundedRectGuiElementRenderState(
				pose, x, y, w, h, r, color, scissor, bounds));
	}

	public static void gradientBox(DrawContext ctx, float x, float y, float width, float height,
			int cTopLeft, int cBottomLeft, int cBottomRight, int cTopRight) {
		Matrix3x2f pose = new Matrix3x2f(ctx.getMatrices());
		ScreenRect scissor = ctx.scissorStack.peekLast();
		ScreenRect rawBounds = new ScreenRect((int) x, (int) y, (int) width, (int) height);
		ScreenRect transformed = rawBounds.transformEachVertex(pose);
		ScreenRect bounds = scissor == null ? transformed : transformed.intersection(scissor);
		ctx.state.addSimpleElement(new ru.neuclient.client.render.GradientRectRenderState(
				pose, x, y, width, height, cTopLeft, cBottomLeft, cBottomRight, cTopRight, scissor, bounds));
	}

	private static final int[] HUE_COLORS = {
			0xFFFF0000, 0xFFFFFF00, 0xFF00FF00, 0xFF00FFFF, 0xFF0000FF, 0xFFFF00FF, 0xFFFF0000
	};

	public static void hueBar(DrawContext ctx, int x, int y, int w, int h) {
		for (int i = 0; i < 6; i++) {
			int y0 = y + (int) Math.floor(i * (float) h / 6f);
			int y1 = y + (int) Math.ceil((i + 1) * (float) h / 6f);
			ctx.fillGradient(x, y0, x + w, y1, HUE_COLORS[i], HUE_COLORS[i + 1]);
		}
	}

	/** Настоящий круг через тот же SDF-quad, без построчного fill(). */
	public static void circle(DrawContext ctx, int cx, int cy, float radius, int color) {
		if (radius <= 0.0f) return;
		int diameter = Math.max(1, Math.round(radius * 2.0f));
		int left = Math.round(cx - diameter / 2.0f);
		int top = Math.round(cy - diameter / 2.0f);
		roundRect(ctx, left, top, diameter, diameter, diameter / 2, color);
	}

	/** Рамка 1px со скруглением. */
	public static void roundBorderRect(DrawContext ctx, int x, int y, int w, int h, int r, int borderColor, int innerColor) {
		roundRect(ctx, x, y, w, h, r, borderColor);
		roundRect(ctx, x + 1, y + 1, w - 2, h - 2, Math.max(0, r - 1), innerColor);
	}

	/** Мягкое неоновое свечение вокруг области. */
	public static void glow(DrawContext ctx, int x, int y, int w, int h, int r) {
		int rgb = accent() & 0x00FFFFFF;
		roundRect(ctx, x - 3, y - 3, w + 6, h + 6, r + 3, rgb | 0x12000000);
		roundRect(ctx, x - 2, y - 2, w + 6 - 2, h + 6 - 2, r + 2, rgb | 0x1E000000);
		roundRect(ctx, x - 1, y - 1, w + 6 - 4, h + 6 - 4, r + 1, rgb | 0x2E000000);
	}

	/** Маленький круглый ползунок. */
	public static void knob(DrawContext ctx, int cx, int cy, int color) {
		circle(ctx, cx, cy, 2.5f, color);
	}

	// ===== Текст поверх акцента (пилюли, тумблеры) =====

	public static void textContrast(DrawContext ctx, String s, int x, int y, int color) {
		MsdfFontRenderer.drawWithShadow(ctx, MsdfFonts.sfRegular(), s, x, y, color, 9.0f);
	}

	public static void knobContrast(DrawContext ctx, int cx, int cy) {
		ctx.fill(cx - 2, cy - 3, cx + 3, cy + 4, 0xCC000000);
		ctx.fill(cx - 3, cy - 2, cx + 4, cy + 3, 0xCC000000);
		ctx.fill(cx - 1, cy - 2, cx + 2, cy + 3, 0xFFF4F6FA);
		ctx.fill(cx - 2, cy - 1, cx + 3, cy + 2, 0xFFF4F6FA);
	}

	// ===== «Волновой» текст =====

	/**
	 * Строка с градиентной волной акцентных цветов.
	 */
	public static int drawWaveText(DrawContext ctx, String s, int x, int y) {
		float tx = x;
		for (int i = 0; i < s.length(); i++) {
			String ch = String.valueOf(s.charAt(i));
			MsdfFontRenderer.drawWithShadow(ctx, MsdfFonts.sfMedium(), ch, tx, y, accentAt((tx - x) * 0.12f), 9.0f);
			tx += MsdfFontRenderer.getWidth(MsdfFonts.sfMedium(), ch, 9.0f);
		}
		return (int) Math.ceil(tx);
	}

	/** Волновой текст, отцентрованный по X. */
	public static void drawWaveTextCentered(DrawContext ctx, String s, int centerX, int y) {
		float totalW = MsdfFontRenderer.getWidth(MsdfFonts.sfMedium(), s, 9.0f);
		drawWaveText(ctx, s, (int) Math.round(centerX - totalW / 2f), y);
	}

	/**
	 * Увеличенный заголовок «NeuClient».
	 */
	public static void bigTitle(DrawContext ctx, int centerX, int y, float scale) {
		String title = "NeuClient";
		float size = 9.0f * scale;
		float total = MsdfFontRenderer.getWidth(MsdfFonts.sfMedium(), title, size);
		float left = centerX - total / 2f;
		float tx = left;
		for (int i = 0; i < title.length(); i++) {
			String ch = String.valueOf(title.charAt(i));
			MsdfFontRenderer.drawWithShadow(ctx, MsdfFonts.sfMedium(), ch, tx, y, accentAt((tx - left) * 0.12f), size);
			tx += MsdfFontRenderer.getWidth(MsdfFonts.sfMedium(), ch, size);
		}
	}

	// ===== Иконочный шрифт (набор глифов Delta) =====
	//
	// Глифы в атласе icons привязаны к ASCII: один символ = одна иконка.
	// Так же, как это делает Delta, категории и элементы GUI рисуют иконки
	// «буквами» (Combat = "V", Movement = "I", Render = "t", Player = "L",
	// Misc = "D"; чекбокс — "u"/"m"; иконка перед заголовком — "g").

	/** Иконка категории в стиле Delta. */
	public static String categoryIcon(Category category) {
		return switch (category) {
			case COMBAT -> "V";
			case MOVEMENT -> "I";
			case RENDER -> "t";
			case PLAYER -> "L";
			case MISC -> "D";
		};
	}

	/** Ширина иконки заданным размером. */
	public static float iconWidth(String glyph, float size) {
		return MsdfFontRenderer.getWidth(MsdfFonts.icons(), glyph, size);
	}

	/** Отрисовка иконки без тени (иконки — плоские). */
	public static void icon(DrawContext ctx, String glyph, float x, float y, float size, int color) {
		MsdfFontRenderer.draw(ctx, MsdfFonts.icons(), glyph, x, y, color, size);
	}

	/** Отрисовка иконки, вертикально отцентрованной в строке высотой {@code rowH}. */
	public static void iconCentered(DrawContext ctx, String glyph, float x, float rowY, float rowH, float size, int color) {
		float ty = rowY + (rowH - MsdfFontRenderer.getHeight(MsdfFonts.icons(), size)) / 2f;
		MsdfFontRenderer.draw(ctx, MsdfFonts.icons(), glyph, x, ty, color, size);
	}

	/**
	 * Чекбокс в стиле Delta: скруглённый квадрат с иконкой-галочкой.
	 *
	 * @param size    сторона квадрата, px
	 * @param checked включён ли
	 * @param alpha   непрозрачность 0..1 (для плавного раскрытия настроек)
	 */
	public static void checkbox(DrawContext ctx, int x, int y, int size, boolean checked, int accent, float alpha) {
		int bgFill = checked ? withAlphaStatic(accent, 0.22f * alpha) : withAlphaStatic(0x22FFFFFF, 0.12f * alpha);
		roundRect(ctx, x, y, size, size, 2, bgFill);
		roundBorderEdge(ctx, x, y, size, size, 2, withAlphaStatic(accent, (checked ? 0.85f : 0.30f) * alpha));
		if (checked) {
			roundRect(ctx, x + 2, y + 2, size - 4, size - 4, 1, withAlphaStatic(accent, alpha));
		}
	}

	/** 1px-ободок скруглённого прямоугольника (без внутренней заливки). */
	public static void roundBorderEdge(DrawContext ctx, int x, int y, int w, int h, int r, int color) {
		roundRect(ctx, x, y, w, h, r, color);
		roundRect(ctx, x + 1, y + 1, w - 2, h - 2, Math.max(0, r - 1), 0x00000000);
	}

	/** Применить альфу 0..1 к цвету, не трогая его RGB. */
	public static int withAlphaStatic(int color, float alpha) {
		int a = Math.max(0, Math.min(255, (int) (((color >>> 24) & 0xFF) * alpha)));
		if (a == 0 && alpha > 0f) a = Math.max(1, Math.min(255, (int) (alpha * 255f)));
		return (a << 24) | (color & 0x00FFFFFF);
	}

	// ===== «Стекло» (тот же шейдер, что у модуля Hands и колонок ClickGUI) =====

	/** Период зацикливания времени стекла, мс. */
	private static final long GLASS_TIME_WRAP_MS = 128_000L;

	/**
	 * Стеклянная подложка одним GPU-quad'ом: SDF-скругление, плывущие линии
	 * и ободок считает шейдер ({@link ru.neuclient.client.render.GlassPanelPipeline}).
	 *
	 * Тот же эффект, что у «стеклянных» колонок ClickGUI и рук из модуля Hands,
	 * только в экранных координатах и с низкой непрозрачностью — годится
	 * под HUD-карточки, чтобы они смотрелись как матовое стекло.
	 *
	 * @param accent RGB акцента — им шейдер красит линии и ободок
	 * @param alpha  непрозрачность стеклянного слоя (0..1)
	 */
	public static void glass(DrawContext ctx, int x, int y, int w, int h, int accent, float alpha) {
		if (w <= 0 || h <= 0 || alpha <= 0.0f) return;
		float time = (System.currentTimeMillis() % GLASS_TIME_WRAP_MS) / 1000.0f;
		Matrix3x2f pose = new Matrix3x2f(ctx.getMatrices());
		ScreenRect scissor = ctx.scissorStack.peekLast();
		ScreenRect transformed = new ScreenRect(x, y, w, h).transformEachVertex(pose);
		ScreenRect bounds = scissor == null ? transformed : transformed.intersection(scissor);
		ctx.state.addSimpleElement(new ru.neuclient.client.render.GlassPanelGuiElementRenderState(
				pose, x, y, w, h, accent & 0x00FFFFFF, Math.min(1.0f, alpha), time, scissor, bounds));
	}
}
