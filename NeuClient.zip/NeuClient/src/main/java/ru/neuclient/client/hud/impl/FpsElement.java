package ru.neuclient.client.hud.impl;

import net.minecraft.client.gui.DrawContext;
import ru.neuclient.client.hud.HudElement;

/**
 * Счётчик кадров — карточка [FPS │ 240] в общем стиле HUD.
 */
public class FpsElement extends HudElement {

	public FpsElement() {
		super("fps", 4, 76);
	}

	@Override
	public boolean isVisible() {
		if (ru.neuclient.client.NeuClient.getInstance().getInterfaceModule().isElementVisible("watermark")) return false;
		return super.isVisible();
	}

	@Override
	protected void drawElement(DrawContext ctx, boolean editing) {
		String value = String.valueOf(mc.getCurrentFps());
		this.width = valueCardWidth("FPS", value);
		this.height = CARD_H;
		drawValueCard(ctx, getX(), getY(), width, "FPS", value);
	}
}
