package ru.neuclient.client.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.impl.combat.HitboxModule;

/**
 * Клиентское расширение хитбоксов чужих игроков (модуль Hitbox).
 * Подменяется ТОЛЬКО то, что видит клиент: трассировка прицела
 * (targetedEntity) цепляет игрока раньше — легче попадать мышью
 * и легче срабатывает TriggerBot. Никаких пакетов это не шлёт,
 * серверный хитбокс остаётся ванильным.
 * Себя не трогаем: свой бокс влияет на коллизию/пуш — не нужно.
 */
@Mixin(Entity.class)
public abstract class EntityHitboxMixin {

	@Inject(method = "getBoundingBox", at = @At("RETURN"), cancellable = true)
	private void pc$expandPlayerHitbox(CallbackInfoReturnable<Box> cir) {
		Entity self = (Entity) (Object) this;
		MinecraftClient mc = MinecraftClient.getInstance();
		if (!(self instanceof PlayerEntity) || self == mc.player) {
			return;
		}
		NeuClient client = NeuClient.getInstance();
		if (client == null || client.getModuleManager() == null) {
			return;
		}
		HitboxModule module = client.getModuleManager().get(HitboxModule.class);
		if (module == null || !module.isEnabled()) {
			return;
		}
		double e = module.getExpand();
		cir.setReturnValue(cir.getReturnValue().expand(e, 0.0, e));
	}
}
