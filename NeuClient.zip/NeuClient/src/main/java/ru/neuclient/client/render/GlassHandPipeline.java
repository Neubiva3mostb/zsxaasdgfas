package ru.neuclient.client.render;

import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderPass;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.AddressMode;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.GpuSampler;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;
import org.lwjgl.system.MemoryUtil;

import java.nio.ByteBuffer;
import java.util.OptionalDouble;
import java.util.OptionalInt;

/**
 * Пайплайны эффекта «стеклянных рук» (модуль Hands).
 *
 * Кадр руки захватывается в отдельную текстуру (см. HandsModule), а этот
 * класс рисует её обратно на главный фреймбуфер одним фуллскрин-квадом:
 *
 *  • BLUR    — мягкое «матовое стекло»: сэмплы диском двух радиусов;
 *  • OUTLINE — контур: кольцо из 16 сэмплов вокруг точки;
 *  • GLASS   — «Стекло»: размытие с бегущими волнами и подсветкой
 *              гребней цветом акцента (фаза волн едет в дробной части Param);
 *  • радиус 0 у BLUR превращает его в резкую копию руки.
 *
 * Отрисовка выполняется прямым RenderPass — как ванильный RenderLayer.draw:
 * вершины в NDC без матриц, поэтому эффект независим от текущей проекции
 * и работает в мировом проходе (руки), куда DrawContext ещё недоступен.
 */
public final class GlassHandPipeline {

	/** Размытие / резкая копия (радиус 0). */
	public static final RenderPipeline BLUR = RenderPipelines.register(
			RenderPipeline.builder()
					.withLocation(Identifier.of("perfstream", "pipeline/glass_hand_blur"))
					.withVertexShader(Identifier.of("perfstream", "core/glass_hand"))
					.withFragmentShader(Identifier.of("perfstream", "core/glass_hand_blur"))
					.withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR, VertexFormat.DrawMode.QUADS)
					.withSampler("Sampler0")
					.withBlend(BlendFunction.TRANSLUCENT)
					.withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
					.withCull(false)
					.withColorWrite(true, true)
					.build()
	);

	/** Контур (обводка). */
	public static final RenderPipeline OUTLINE = RenderPipelines.register(
			RenderPipeline.builder()
					.withLocation(Identifier.of("perfstream", "pipeline/glass_hand_outline"))
					.withVertexShader(Identifier.of("perfstream", "core/glass_hand"))
					.withFragmentShader(Identifier.of("perfstream", "core/glass_hand_outline"))
					.withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR, VertexFormat.DrawMode.QUADS)
					.withSampler("Sampler0")
					.withBlend(BlendFunction.TRANSLUCENT)
					.withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
					.withCull(false)
					.withColorWrite(true, true)
					.build()
	);

	/** «Стекло»: размытие с бегущими волнами и подсветкой гребней акцентом. */
	public static final RenderPipeline GLASS = RenderPipelines.register(
			RenderPipeline.builder()
					.withLocation(Identifier.of("perfstream", "pipeline/glass_hand_glass"))
					.withVertexShader(Identifier.of("perfstream", "core/glass_hand"))
					.withFragmentShader(Identifier.of("perfstream", "core/glass_hand_glass"))
					.withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR, VertexFormat.DrawMode.QUADS)
					.withSampler("Sampler0")
					.withBlend(BlendFunction.TRANSLUCENT)
					.withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
					.withCull(false)
					.withColorWrite(true, true)
					.build()
	);

	private static GpuSampler linearSampler;

	static {
		// Ресурсы GC не собирает — выгружаем при закрытии игры
		Runtime.getRuntime().addShutdownHook(new Thread(() -> {
			if (linearSampler != null) {
				linearSampler.close();
			}
		}));
	}

	public static void touch() {
	}

	private GlassHandPipeline() {
	}

	/**
	 * Рисует фуллскрин-квад поверх главного фреймбуфера.
	 *
	 * @param pipeline BLUR, OUTLINE или GLASS
	 * @param source   текстура с кадром руки
	 * @param radius   радиус эффекта в пикселях (Position.z → Param в шейдере);
	 *                 в GLASS дробная часть трактуется как фаза волн 0..1
	 * @param r,g,b    цвет эффекта (0..1)
	 * @param alpha    интенсивность (0..1)
	 */
	public static void drawFullscreen(RenderPipeline pipeline, GpuTextureView source,
			float radius, float r, float g, float b, float alpha) {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.getFramebuffer() == null) {
			return;
		}

		if (linearSampler == null) {
			linearSampler = RenderSystem.getDevice().createSampler(
					AddressMode.CLAMP_TO_EDGE, AddressMode.CLAMP_TO_EDGE,
					FilterMode.LINEAR, FilterMode.LINEAR, 1, OptionalDouble.empty());
		}

		// Квад: NDC + UV, радиус едет в Position.z (24 байта на вершину)
		ByteBuffer buf = MemoryUtil.memAlloc(4 * 24);
		putVertex(buf, -1.0f, -1.0f, radius, 0.0f, 0.0f, r, g, b, alpha);
		putVertex(buf, 1.0f, -1.0f, radius, 1.0f, 0.0f, r, g, b, alpha);
		putVertex(buf, 1.0f, 1.0f, radius, 1.0f, 1.0f, r, g, b, alpha);
		putVertex(buf, -1.0f, 1.0f, radius, 0.0f, 1.0f, r, g, b, alpha);
		buf.flip();

		GpuBuffer vertexBuffer = null;
		RenderPass pass = null;
		try {
			// ВАЖНО: буфер кэшируется внутри VertexFormat и переиспользуется
			// (immediateDrawVertexBuffer) — его НЕЛЬЗЯ закрывать после draw,
			// иначе следующий кадр упадёт с «Buffer already closed».
			// Ровно так же поступает ванильный RenderLayer.draw.
			vertexBuffer = pipeline.getVertexFormat().uploadImmediateVertexBuffer(buf);
			RenderSystem.ShapeIndexBuffer indices = RenderSystem.getSequentialBuffer(VertexFormat.DrawMode.QUADS);
			GpuBuffer indexBuffer = indices.getIndexBuffer(6);

			CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
			pass = encoder.createRenderPass(() -> "neuclient glass hand",
					mc.getFramebuffer().getColorAttachmentView(), OptionalInt.empty(), null, OptionalDouble.empty());
			pass.setPipeline(pipeline);
			// Обязательные дефолтные юниформы — ровно как в RenderLayer.draw:
			// без них бэкенд может молча не отрисовать пасс
			RenderSystem.bindDefaultUniforms(pass);
			pass.setVertexBuffer(0, vertexBuffer);
			pass.bindTexture("Sampler0", source, linearSampler);
			pass.setIndexBuffer(indexBuffer, indices.getIndexType());
			pass.drawIndexed(0, 0, 6, 1);
		} finally {
			if (pass != null) {
				pass.close();
			}
			// vertexBuffer не закрываем: им владеет VertexFormat (кэш)
			MemoryUtil.memFree(buf);
		}
	}

	private static void putVertex(ByteBuffer buf, float x, float y, float z,
			float u, float v, float r, float g, float b, float a) {
		buf.putFloat(x).putFloat(y).putFloat(z);
		buf.putFloat(u).putFloat(v);
		buf.put((byte) (r * 255.0f)).put((byte) (g * 255.0f))
				.put((byte) (b * 255.0f)).put((byte) (a * 255.0f));
	}
}
