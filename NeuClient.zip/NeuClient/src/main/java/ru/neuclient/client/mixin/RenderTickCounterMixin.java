package ru.neuclient.client.mixin;

import it.unimi.dsi.fastutil.floats.FloatUnaryOperator;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.impl.movement.TimerModule;

/**
 * Timer.
 *
 * RenderTickCounter.Dynamic#beginRenderTick(long) считает, сколько игровых
 * тиков отыграть в этом кадре:
 *
 *     dynamicDeltaTicks = (now - lastTimeMillis) / targetMillisPerTick.apply(tickTime);
 *
 * где targetMillisPerTick.apply(50f) обычно и даёт 50 мс. Перехватываем
 * ровно этот вызов и делим результат на множитель модуля: при множителе 2
 * «тик» становится 25 мс, и клиент прокручивает вдвое больше игровых тиков
 * за то же реальное время — игра ускоряется.
 *
 * Множитель 1.0 (модуль выключен, игрок в меню, «только в движении» без
 * движения) возвращает ванильное значение без изменений.
 */
@Mixin(RenderTickCounter.Dynamic.class)
public abstract class RenderTickCounterMixin {

	@Redirect(method = "beginRenderTick(J)I",
			at = @At(value = "INVOKE",
					target = "Lit/unimi/dsi/fastutil/floats/FloatUnaryOperator;apply(F)F"))
	private float pc$timer(FloatUnaryOperator operator, float tickTime) {
		float vanilla = operator.apply(tickTime);
		try {
			TimerModule timer = NeuClient.getInstance().getModuleManager().get(TimerModule.class);
			if (timer != null && timer.isEnabled()) {
				float speed = timer.getTimerSpeed();
				if (speed > 0.0f && speed != 1.0f) {
					return vanilla / speed;
				}
			}
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка Timer", t);
		}
		return vanilla;
	}
}
