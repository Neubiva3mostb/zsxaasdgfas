package ru.neuclient.client.mixin;

import net.minecraft.client.render.SkyRendering;
import net.minecraft.client.render.state.SkyRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.world.MoonPhase;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.impl.render.NoRenderModule;

/**
 * NoRender: выключает небо целиком — купол, светила, звёзды, зарю и
 * энд-небо. Рисуется только ландшафт (и то, что поверх него).
 */
@Mixin(SkyRendering.class)
public abstract class SkyRenderingMixin {

	@Inject(method = "renderTopSky", at = @At("HEAD"), cancellable = true)
	private void pc$noTopSky(int skyColor, CallbackInfo ci) {
		if (pc$noSky()) {
			ci.cancel();
		}
	}

	@Inject(method = "renderSkyDark", at = @At("HEAD"), cancellable = true)
	private void pc$noSkyDark(CallbackInfo ci) {
		if (pc$noSky()) {
			ci.cancel();
		}
	}

	@Inject(method = "renderCelestialBodies", at = @At("HEAD"), cancellable = true)
	private void pc$noCelestial(MatrixStack matrices, float ticks, float skyboxAngle, float moonAngle,
			MoonPhase moonPhase, float rain, float starBrightness, CallbackInfo ci) {
		if (pc$noSky()) {
			ci.cancel();
		}
	}

	@Inject(method = "renderGlowingSky", at = @At("HEAD"), cancellable = true)
	private void pc$noGlowingSky(MatrixStack matrices, float angle, int color, CallbackInfo ci) {
		if (pc$noSky()) {
			ci.cancel();
		}
	}

	@Inject(method = "renderEndSky", at = @At("HEAD"), cancellable = true)
	private void pc$noEndSky(CallbackInfo ci) {
		if (pc$noSky()) {
			ci.cancel();
		}
	}

	private static boolean pc$noSky() {
		NeuClient client = NeuClient.getInstance();
		if (client == null || client.getModuleManager() == null) {
			return false;
		}
		NoRenderModule module = client.getModuleManager().get(NoRenderModule.class);
		return module != null && module.noSky();
	}
}
