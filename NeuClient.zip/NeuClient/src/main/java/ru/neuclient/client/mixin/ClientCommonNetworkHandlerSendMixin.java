package ru.neuclient.client.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientCommonNetworkHandler;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.Packet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.impl.player.BlinkModule;
import ru.neuclient.client.module.impl.movement.AirStruckModule;
import ru.neuclient.client.module.impl.movement.InvMoveModule;

/**
 * Перехват ИСХОДЯЩИХ пакетов на уровне сетевого обработчика.
 *
 * Используется двумя потребителями:
 *   - Blink задерживает только PlayerMoveC2SPacket на дополнительный
 *     интервал и выпускает его напрямую в канал;
 *   - InvMove переносит клики по слотам и повторное закрытие своего
 *     инвентаря на правильный момент.
 */
@Mixin(ClientCommonNetworkHandler.class)
public abstract class ClientCommonNetworkHandlerSendMixin {

	@Inject(method = "sendPacket", at = @At("HEAD"), cancellable = true)
	private void pc$holdInventoryPackets(Packet<?> packet, CallbackInfo ci) {
		try {
			MinecraftClient mc = MinecraftClient.getInstance();
			// Применяем модули только к основному обработчику клиента, не к ботам
			if (mc == null || mc.getNetworkHandler() != (Object) this) {
				return;
			}

			NeuClient neu = NeuClient.getInstance();
			if (neu == null || neu.getModuleManager() == null) {
				return;
			}
			BlinkModule blink = neu.getModuleManager().get(BlinkModule.class);
			if (blink != null && blink.isEnabled()) {
				blink.flushBeforeAction(packet);
				if (blink.shouldDelayPacket(packet)) {
					ci.cancel();
					return;
				}
			}

			InvMoveModule invMove = neu.getModuleManager().get(InvMoveModule.class);
			if (invMove != null && invMove.isEnabled() && invMove.shouldHoldPacket(packet)) {
				ci.cancel();
			}

			// Air Stuck: в зависе сервер не должен получать движение/ввод/действия.
			AirStruckModule airStruck = neu.getModuleManager().get(AirStruckModule.class);
			if (airStruck != null && airStruck.shouldHoldPacket(packet)) {
				ci.cancel();
			}

			if (packet instanceof net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket command) {
				ru.neuclient.client.module.impl.combat.AttackAuraModule aura = neu.getModuleManager().get(ru.neuclient.client.module.impl.combat.AttackAuraModule.class);
				if (aura != null) {
					aura.getSprintControl().onPacket(command);
				}
				ru.neuclient.client.module.impl.combat.TriggerBotModule trigger = neu.getModuleManager().get(ru.neuclient.client.module.impl.combat.TriggerBotModule.class);
				if (trigger != null) {
					trigger.getSprintControl().onPacket(command);
				}
			}
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка удержания пакета инвентаря", t);
		}
	}
}
