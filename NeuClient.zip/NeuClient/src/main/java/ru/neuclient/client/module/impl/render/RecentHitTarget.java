package ru.neuclient.client.module.impl.render;

/** Одна цель на две секунды с затуханием ВНУТРИ этого интервала. */
final class RecentHitTarget<T> {
    static final long DURATION_MS = 2000L;
    private static final long FADE_MS = 250L;
    private T target;
    private long hitAtMs;

    void record(T target, long nowMs) {
        this.target = target;
        hitAtMs = nowMs;
    }

    T get(long nowMs) {
        if (target != null && nowMs - hitAtMs >= DURATION_MS) clear();
        return target;
    }

    float opacity(long nowMs) {
        if (get(nowMs) == null) return 0.0f;
        long remaining = DURATION_MS - (nowMs - hitAtMs);
        return Math.max(0.0f, Math.min(1.0f, (float) remaining / FADE_MS));
    }

    void clear() {
        target = null;
        hitAtMs = 0L;
    }
}
