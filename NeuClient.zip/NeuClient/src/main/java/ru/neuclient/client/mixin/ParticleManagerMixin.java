package ru.neuclient.client.mixin;

import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.particle.ParticleEffect;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.impl.render.NoRenderModule;

/**
 * NoRender: полностью глушит спавн частиц (все типы сразу).
 * Визуальный мусор пропадает, логика частиц сервера не меняется.
 */
@Mixin(ParticleManager.class)
public abstract class ParticleManagerMixin {

	@Inject(method = "addParticle(Lnet/minecraft/particle/ParticleEffect;DDDDDD)Lnet/minecraft/client/particle/Particle;",
			at = @At("HEAD"), cancellable = true)
	private void pc$noEffectParticle(ParticleEffect effect, double x, double y, double z,
			double velocityX, double velocityY, double velocityZ,
			CallbackInfoReturnable<Particle> cir) {
		if (pc$noParticles()) {
			cir.setReturnValue(null);
		}
	}

	@Inject(method = "addParticle(Lnet/minecraft/client/particle/Particle;)V",
			at = @At("HEAD"), cancellable = true)
	private void pc$noParticle(Particle particle, CallbackInfo ci) {
		if (pc$noParticles()) {
			ci.cancel();
		}
	}

	private static boolean pc$noParticles() {
		NeuClient client = NeuClient.getInstance();
		if (client == null || client.getModuleManager() == null) {
			return false;
		}
		NoRenderModule module = client.getModuleManager().get(NoRenderModule.class);
		return module != null && module.noParticles();
	}
}
