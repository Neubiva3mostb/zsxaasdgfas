package ru.neuclient.client.module.impl.movement;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.BooleanSetting;
import ru.neuclient.client.setting.ModeSetting;

/**
 * NoWeb — быстрое перемещение в паутине.
 *
 * Как замедляет ваниль: CobwebBlock#onEntityCollision вызывает
 * Entity#slowMovement(state, new Vec3d(0.25, 0.05, 0.25)), а тот просто
 * кладёт вектор в поле movementMultiplier — на следующем тике движение
 * умножается на эти коэффициенты (то есть остаётся 25 % скорости по
 * горизонтали и 5 % по вертикали). Ещё slowMovement дёргает onLanding(),
 * из-за чего в паутине нельзя нормально прыгать.
 *
 * Режимы:
 *  • «Отмена» (по умолчанию) — миксин EntitySlowMovementMixin просто не даёт
 *    выставить movementMultiplier: паутина перестаёт существовать для физики.
 *    Самый чистый и самый заметный для античита вариант.
 *  • «Смягчение» — множитель не отменяем, а ослабляем (0.25 → 0.7):
 *    в паутине двигаешься заметно быстрее ванили, но не пролетаешь её
 *    насквозь. Мягче для серверных проверок скорости.
 *
 * Галочка «Прыжок в паутине» дополнительно подталкивает вверх, пока стоишь
 * в паутине и держишь пробел — ванильный прыжок там гасится множителем 0.05.
 */
public final class NoWebModule extends Module {

	/** Насколько ослабляем ванильный множитель в режиме «Смягчение». */
	private static final double SOFT_HORIZONTAL = 0.7;
	private static final double SOFT_VERTICAL = 0.5;

	private final ModeSetting mode = new ModeSetting("Режим", "Отмена", "Отмена", "Смягчение");
	private final BooleanSetting allowJump = new BooleanSetting("Прыжок в паутине", true);

	public NoWebModule() {
		super("NoWeb", "Позволяет быстро перемещаться в паутине", Category.MOVEMENT);
		addSettings(mode, allowJump);
	}

	/** Паутина ли это (учитываем и обычную, и «липкую» из модов через класс блока). */
	public static boolean isWeb(BlockState state) {
		Block block = state.getBlock();
		return block == Blocks.COBWEB || block instanceof net.minecraft.block.CobwebBlock;
	}

	/**
	 * Вызывается из миксина slowMovement.
	 * @return true — замедление отменить целиком.
	 */
	public boolean shouldCancelSlowdown(BlockState state) {
		return isWeb(state) && "Отмена".equals(mode.get());
	}

	/**
	 * Вызывается из миксина slowMovement в режиме «Смягчение».
	 *
	 * Работает по самому вектору замедления: паутина зовёт slowMovement
	 * ровно с (0.25, 0.05, 0.25), поэтому проверять BlockState не нужно —
	 * это позволило убрать рекурсивный повторный вызов, из-за которого
	 * режим «Смягчение» вешал игру в паутине.
	 *
	 * @return ослабленный множитель, либо null — оставить ванильный
	 */
	public net.minecraft.util.math.Vec3d softenMultiplier(net.minecraft.util.math.Vec3d vanilla) {
		if (!"Смягчение".equals(mode.get())) {
			return null;
		}
		// Реагируем только на «паутинное» замедление: сильное по горизонтали
		// и очень сильное по вертикали. Другие источники (мёд, снег) не трогаем.
		if (vanilla.x > 0.5 || vanilla.y > 0.2) {
			return null;
		}
		return new net.minecraft.util.math.Vec3d(
				Math.max(vanilla.x, SOFT_HORIZONTAL),
				Math.max(vanilla.y, SOFT_VERTICAL),
				Math.max(vanilla.z, SOFT_HORIZONTAL));
	}

	@Override
	public void onTick(MinecraftClient client) {
		if (!allowJump.get()) {
			return;
		}
		ClientPlayerEntity player = client.player;
		if (player == null || client.world == null || player.hasVehicle()) {
			return;
		}
		// Стоим в паутине и держим пробел — помогаем прыгнуть
		if (client.options.jumpKey.isPressed() && inWeb(client, player) && player.getVelocity().y < 0.2) {
			player.setVelocity(player.getVelocity().x, 0.42, player.getVelocity().z);
		}
	}

	/** Пересекается ли хитбокс игрока с блоком паутины. */
	private boolean inWeb(MinecraftClient client, ClientPlayerEntity player) {
		net.minecraft.util.math.Box box = player.getBoundingBox();
		int minX = net.minecraft.util.math.MathHelper.floor(box.minX);
		int maxX = net.minecraft.util.math.MathHelper.floor(box.maxX);
		int minY = net.minecraft.util.math.MathHelper.floor(box.minY);
		int maxY = net.minecraft.util.math.MathHelper.floor(box.maxY);
		int minZ = net.minecraft.util.math.MathHelper.floor(box.minZ);
		int maxZ = net.minecraft.util.math.MathHelper.floor(box.maxZ);
		net.minecraft.util.math.BlockPos.Mutable pos = new net.minecraft.util.math.BlockPos.Mutable();
		for (int x = minX; x <= maxX; x++) {
			for (int y = minY; y <= maxY; y++) {
				for (int z = minZ; z <= maxZ; z++) {
					if (isWeb(client.world.getBlockState(pos.set(x, y, z)))) {
						return true;
					}
				}
			}
		}
		return false;
	}
}
