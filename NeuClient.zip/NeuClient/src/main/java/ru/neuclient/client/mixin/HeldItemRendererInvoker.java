package ru.neuclient.client.mixin;

import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Arm;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

/**
 * Доступ к приватным методам HeldItemRenderer для Attack Animations.
 *
 * Оба @Redirect в HeldItemRendererMixin обязаны уметь честно позвать
 * оригинал, когда модуль выключен или рука не основная — вот через эти
 * инвокеры.
 */
@Mixin(HeldItemRenderer.class)
public interface HeldItemRendererInvoker {

	@Invoker("swingArm")
	void pc$swingArm(float swingProgress, MatrixStack matrices, int light, Arm arm);

	@Invoker("applyEquipOffset")
	void pc$applyEquipOffset(MatrixStack matrices, Arm arm, float equipProgress);
}
