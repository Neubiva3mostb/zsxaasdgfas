package ru.neuclient.client.mixin;

import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Доступ к привязанной клавише бинда (нужно SafeWalk-у, чтобы восстанавливать
 * состояние шифта ровно так, как его держит рука игрока).
 */
@Mixin(KeyBinding.class)
public interface KeyBindingAccessor {

	@Accessor("boundKey")
	InputUtil.Key pc$getBoundKey();
}
