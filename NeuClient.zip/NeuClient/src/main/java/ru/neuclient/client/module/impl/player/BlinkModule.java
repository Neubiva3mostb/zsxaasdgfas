package ru.neuclient.client.module.impl.player;

import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.ChatMessageC2SPacket;
import net.minecraft.network.packet.c2s.play.CommandExecutionC2SPacket;
import net.minecraft.network.packet.c2s.play.ClickSlotC2SPacket;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.render.WorldRenderUtil;
import ru.neuclient.client.setting.BooleanSetting;
import ru.neuclient.client.setting.ColorSetting;
import ru.neuclient.client.setting.NumberSetting;
import ru.neuclient.client.util.RenderUtil;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;

/**
 * Blink/Fake Lags — задерживает только движение игрока.
 *
 * Пакеты движения складываются в очередь и выпускаются пачкой через
 * заданное количество тиков. Атаки, клики по блокам/инвентарю, использование
 * предметов, смена слота, взмах рукой и чат не задерживаются. Перед таким
 * действием накопленное движение сначала выпускается, чтобы сервер увидел
 * корректный порядок событий.
 */
public final class BlinkModule extends Module {

	private static final int MAX_QUEUE_SIZE = 4096;

	/** Задержка движения в тиках: 20 тиков = примерно 1 секунда. */
	private final NumberSetting delay = new NumberSetting("Задержка", 20.0, 1.0, 40.0, 1.0);
	private final BooleanSetting showServerPosition = new BooleanSetting("Показывать позицию", false);
	private final ColorSetting color = new ColorSetting("Цвет", 0xFF7A5CFF);

	private final Deque<Packet<?>> movementQueue = new ArrayDeque<>();
	private int ticksSinceFlush;
	private Vec3d serverPosition;
	private float serverYaw;
	private float serverPitch;

	public BlinkModule() {
		super("Blink", "Задерживает движение, имитируя лаги", Category.PLAYER);
		addSettings(delay, showServerPosition, color);
	}

	@Override
	protected void onEnable() {
		clearQueue();
		ticksSinceFlush = 0;
		MinecraftClient client = MinecraftClient.getInstance();
		if (client.player != null) {
			serverPosition = new Vec3d(client.player.getX(), client.player.getY(), client.player.getZ());
			serverYaw = client.player.getYaw();
			serverPitch = client.player.getPitch();
		} else {
			serverPosition = null;
		}
	}

	@Override
	protected void onDisable() {
		flushAll(MinecraftClient.getInstance());
		clearQueue();
		ticksSinceFlush = 0;
		serverPosition = null;
	}

	@Override
	public void onTick(MinecraftClient client) {
		if (client.player == null || client.player.networkHandler == null) {
			return;
		}
		if (movementQueue.isEmpty()) {
			ticksSinceFlush = 0;
			return;
		}

		if (++ticksSinceFlush >= delayTicks()) {
			flushAll(client);
			ticksSinceFlush = 0;
		}
	}

	/**
	 * Вызывается перед обычной отправкой пакета. true означает, что пакет
	 * поставлен в очередь и ваниль не должна отправлять его второй раз.
	 */
	public boolean shouldDelayPacket(Packet<?> packet) {
		if (!isEnabled() || !(packet instanceof PlayerMoveC2SPacket)) {
			return false;
		}

		synchronized (movementQueue) {
			if (movementQueue.size() >= MAX_QUEUE_SIZE) {
				Packet<?> oldest = movementQueue.pollFirst();
				if (oldest != null) {
					sendDirect(oldest);
				}
			}
			movementQueue.addLast(packet);
		}
		return true;
	}

	/** Выпустить накопленное движение перед атакой/другим действием. */
	public void flushBeforeAction(Packet<?> packet) {
		if (!isEnabled() || !isImmediateActionPacket(packet)) {
			return;
		}
		flushAll(MinecraftClient.getInstance());
		ticksSinceFlush = 0;
	}

	/** Принудительный выпуск перед атакой из interaction manager. */
	public void flushForAttack() {
		if (isEnabled()) {
			flushAll(MinecraftClient.getInstance());
			ticksSinceFlush = 0;
		}
	}

	/** Выпуск движения при получении velocity-пакета для локального игрока. */
	public void onIncomingVelocity(int entityId) {
		MinecraftClient client = MinecraftClient.getInstance();
		if (isEnabled() && client.player != null && client.player.getId() == entityId) {
			flushAll(client);
			ticksSinceFlush = 0;
		}
	}

	private int delayTicks() {
		return Math.max(1, Math.min(40, (int) Math.round(delay.get())));
	}

	private boolean isImmediateActionPacket(Packet<?> packet) {
		return packet instanceof ChatMessageC2SPacket
				|| packet instanceof CommandExecutionC2SPacket
				|| packet instanceof ClickSlotC2SPacket
				|| packet instanceof PlayerInteractEntityC2SPacket
				|| packet instanceof UpdateSelectedSlotC2SPacket
				|| packet instanceof HandSwingC2SPacket
				|| packet instanceof PlayerInteractBlockC2SPacket
				|| packet instanceof PlayerInteractItemC2SPacket;
	}

	private void flushAll(MinecraftClient client) {
		List<Packet<?>> pending = new ArrayList<>();
		synchronized (movementQueue) {
			while (!movementQueue.isEmpty()) {
				pending.add(movementQueue.removeFirst());
			}
		}
		for (Packet<?> packet : pending) {
			sendDirect(packet);
		}
	}

	private void sendDirect(Packet<?> packet) {
		MinecraftClient client = MinecraftClient.getInstance();
		if (client.player == null || client.player.networkHandler == null) {
			return;
		}
		client.player.networkHandler.getConnection().send(packet);
		recordSent(packet);
	}

	private void recordSent(Packet<?> packet) {
		if (!(packet instanceof PlayerMoveC2SPacket move)) {
			return;
		}
		MinecraftClient client = MinecraftClient.getInstance();
		if (serverPosition == null && client.player != null) {
			serverPosition = new Vec3d(client.player.getX(), client.player.getY(), client.player.getZ());
			serverYaw = client.player.getYaw();
			serverPitch = client.player.getPitch();
		}
		if (serverPosition == null) {
			return;
		}
		serverPosition = new Vec3d(
				move.getX(serverPosition.x),
				move.getY(serverPosition.y),
				move.getZ(serverPosition.z));
		serverYaw = move.getYaw(serverYaw);
		serverPitch = move.getPitch(serverPitch);
	}

	private void clearQueue() {
		synchronized (movementQueue) {
			movementQueue.clear();
		}
	}

	public int queuedPackets() {
		synchronized (movementQueue) {
			return movementQueue.size();
		}
	}

	// ===== Визуал последней позиции сервера =====

	public void renderWorld(WorldRenderContext context, MinecraftClient client) {
		if (!isEnabled() || !showServerPosition.get() || serverPosition == null
				|| client.player == null || client.world == null
				|| context.commandQueue() == null) {
			return;
		}

		Vec3d local = new Vec3d(client.player.getX(), client.player.getY(), client.player.getZ());
		if (serverPosition.squaredDistanceTo(local) <= 0.0004 && movementQueue.isEmpty()) {
			return;
		}

		Box localBox = client.player.getBoundingBox();
		Box serverBox = localBox.offset(
				serverPosition.x - local.x,
				serverPosition.y - local.y,
				serverPosition.z - local.z);

		Vec3d camera = client.gameRenderer.getCamera().getCameraPos();
		MatrixStack matrices = context.matrices();
		matrices.push();
		matrices.translate(-camera.x, -camera.y, -camera.z);

		int accent = color.get();
		float r = WorldRenderUtil.red(accent);
		float g = WorldRenderUtil.green(accent);
		float b = WorldRenderUtil.blue(accent);
		context.commandQueue().submitCustom(matrices, WorldRenderUtil.LINES_NO_DEPTH,
				(entry, buffer) -> drawBox(buffer, entry, serverBox, r, g, b));
		matrices.pop();
	}

	private static void drawBox(net.minecraft.client.render.VertexConsumer buffer,
			net.minecraft.client.util.math.MatrixStack.Entry entry, Box box,
			float r, float g, float b) {
		float alpha = 0.9f;
		float width = 2.5f;
		double x1 = box.minX, x2 = box.maxX;
		double y1 = box.minY, y2 = box.maxY;
		double z1 = box.minZ, z2 = box.maxZ;

		WorldRenderUtil.line(buffer, entry, x1, y1, z1, x2, y1, z1, r, g, b, alpha, width);
		WorldRenderUtil.line(buffer, entry, x2, y1, z1, x2, y1, z2, r, g, b, alpha, width);
		WorldRenderUtil.line(buffer, entry, x2, y1, z2, x1, y1, z2, r, g, b, alpha, width);
		WorldRenderUtil.line(buffer, entry, x1, y1, z2, x1, y1, z1, r, g, b, alpha, width);
		WorldRenderUtil.line(buffer, entry, x1, y2, z1, x2, y2, z1, r, g, b, alpha, width);
		WorldRenderUtil.line(buffer, entry, x2, y2, z1, x2, y2, z2, r, g, b, alpha, width);
		WorldRenderUtil.line(buffer, entry, x2, y2, z2, x1, y2, z2, r, g, b, alpha, width);
		WorldRenderUtil.line(buffer, entry, x1, y2, z2, x1, y2, z1, r, g, b, alpha, width);
		WorldRenderUtil.line(buffer, entry, x1, y1, z1, x1, y2, z1, r, g, b, alpha, width);
		WorldRenderUtil.line(buffer, entry, x2, y1, z1, x2, y2, z1, r, g, b, alpha, width);
		WorldRenderUtil.line(buffer, entry, x2, y1, z2, x2, y2, z2, r, g, b, alpha, width);
		WorldRenderUtil.line(buffer, entry, x1, y1, z2, x1, y2, z2, r, g, b, alpha, width);
	}

	public static void renderAllWorld(WorldRenderContext context) {
		NeuClient client = NeuClient.getInstance();
		if (client == null || client.getModuleManager() == null) return;
		BlinkModule blink = client.getModuleManager().get(BlinkModule.class);
		if (blink != null && blink.isEnabled()) {
			blink.renderWorld(context, MinecraftClient.getInstance());
		}
	}
}
