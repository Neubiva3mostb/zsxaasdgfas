package ru.neuclient.client;

import ru.neuclient.client.module.impl.misc.XrayModule;
import ru.neuclient.client.module.impl.player.BlinkModule;
import ru.neuclient.client.module.impl.player.HitSoundsModule;
import ru.neuclient.client.module.impl.render.ChinaHatModule;
import ru.neuclient.client.module.impl.render.JumpCirclesModule;
import ru.neuclient.client.module.impl.render.KillEffectModule;
import ru.neuclient.client.module.impl.render.ParticlesModule;
import ru.neuclient.client.module.impl.render.PredictionsModule;
import ru.neuclient.client.module.impl.render.StorageESPModule;
import ru.neuclient.client.module.impl.render.TargetEspModule;
import ru.neuclient.client.module.impl.render.TrailsModule;
import ru.neuclient.client.module.impl.render.WardenESP;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ru.neuclient.client.alt.AltManager;
import ru.neuclient.client.command.CommandManager;
import ru.neuclient.client.config.ConfigManager;
import ru.neuclient.client.config.FriendManager;
import ru.neuclient.client.config.GpsManager;
import ru.neuclient.client.hud.HudManager;
import ru.neuclient.client.module.ModuleManager;
import ru.neuclient.client.module.impl.render.InterfaceModule;
import ru.neuclient.client.util.ClientPaths;

/**
 * NeuClient — клиентский мод в стиле легендарного Nursultan.
 *
 * Точка входа (client-initializer). Здесь создаются все менеджеры,
 * загружается конфиг default.json и подписываются события Fabric:
 *  - END_CLIENT_TICK  — опрос биндов и тик модулей;
 *  - CLIENT_STOPPING  — автосохранение состояния в default.json.
 */
public class NeuClient implements ClientModInitializer {

	public static final String MOD_ID = "perfstream";
	public static final String NAME = "NeuClient";
	public static final String VERSION = "1.0.0";
	public static final Logger LOGGER = LoggerFactory.getLogger(NAME);

	private static NeuClient instance;

	private ModuleManager moduleManager;
	private InterfaceModule hudModule;
	private HudManager hudManager;
	private ConfigManager configManager;
	private FriendManager friendManager;
	private AltManager altManager;
	private CommandManager commandManager;
	private GpsManager gpsManager;

	// ===== Приветствие дворецкого (отложенное, пока поднимется звуковой движок) =====
	/** true — надо сыграть приветствие, когда движок будет готов. */
	private boolean jarvisHelloPending;
	/** Осталось попыток (каждые ~0.5 c, всего до ~10 с). */
	private int jarvisHelloAttempts;
	/** Тиков до следующей попытки. */
	private int jarvisHelloCooldown;

	/**
	 * Режим паники (команда .panic): клиент максимально притворяется ваниллой —
	 * бинды и ClickGUI мертвы, точка-команды молча проглатываются, подсказки
	 * команд не рисуются, конфиги/списки больше не пишутся на диск, звуки
	 * дворецкого отключены. Необратимо до перезапуска игры.
	 */
	private boolean panicked;

	@Override
	public void onInitializeClient() {
		// Проверка запуска из оригинального лаунчера — до любых инициализаций.
		// Без валидного launch-тикета клиент немедленно завершается.
		ru.neuclient.client.security.LaunchGuard.enforce();

		instance = this;
		long start = System.currentTimeMillis();
		LOGGER.info("[NeuClient] Client loaded");

		// 1. Папка конфигов (C:\NeuClient на Windows, ~/NeuClient на прочих ОС)
		ClientPaths.init();

		// 2. Списки друзей, альтов и GPS-меток (простые JSON, грузятся сразу)
		friendManager = new FriendManager();
		friendManager.load();
		altManager = new AltManager();
		altManager.load();
		gpsManager = new GpsManager();
		gpsManager.load();

		// 3. Фирменные звуки интерфейса (регистрация SoundEvent'ов)
		ru.neuclient.client.util.NeuSounds.init();


		ru.neuclient.client.module.impl.player.HitSoundsModule.init();

		// 3.5. SOCKS5-прокси (загрузка конфига из proxy.json)
		ru.neuclient.client.config.ProxyHandler.init();

		// 4. Модули (регистрация всех модулей клиента)
		moduleManager = new ModuleManager();
		hudModule = moduleManager.get(InterfaceModule.class);

		// 4. HUD-элементы (привязаны к настройкам InterfaceModule)
		hudManager = new HudManager();

		// 5. Конфиги: при КАЖДОМ запуске грузится default.json
		configManager = new ConfigManager();
		configManager.init();

		// 6. Команды клиента — только с префиксом "." (перехватываются
		// миксином из исходящего чата и не уходят на сервер)
		commandManager = new CommandManager();

		// 7. События Fabric: тик клиента и остановка клиента
		//
		// БОЕВЫЕ модули (AttackAura) тикают в НАЧАЛЕ тика — до того, как
		// ванильный ClientPlayerEntity#tick вызовет sendMovementPackets().
		// Иначе получалось так: аура доворачивает камеру уже ПОСЛЕ того,
		// как пакет ротации ушёл на сервер, и удар прилетает со старым
		// углом. Grim это ловит сразу тремя проверками — Hitboxes, Reach
		// и Post (interact entity). Теперь ротация успевает уйти в том же
		// пакете, что и атака.
		ClientTickEvents.START_CLIENT_TICK.register(client -> {
			ru.neuclient.client.bot.BotManager.getInstance().tickRally();
			try {
				if (!panicked) {
					moduleManager.tickCombat(client);
				}
			} catch (Throwable t) {
				LOGGER.error("[NeuClient] Ошибка в боевом тике", t);
			}
		});

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			try {
				if (panicked) {
					return;
				}
				ru.neuclient.client.util.StorageActions.tick(client);
				moduleManager.tick(client);
				// Тик виртуальных ботов
				ru.neuclient.client.bot.BotManager.getInstance().tick(client);
				// Автосохранение: если что-то поменялось — обновляем default.json
				configManager.tickSave();
				// Отложенное приветствие: пробуем, пока звуковой движок не примет звук
				tickJarvisHello();
			} catch (Throwable t) {
				LOGGER.error("[NeuClient] Ошибка в тике", t);
			}
		});

		// Рендер-панель ShulkerPreview: ванилла спрашивает у Fabric, умеет ли
		// кто-то нарисовать TooltipData — отвечаем своим компонентом-сеткой
		net.fabricmc.fabric.api.client.rendering.v1.TooltipComponentCallback.EVENT.register(data -> {
			try {
				if (panicked) return null;
				if (data instanceof ru.neuclient.client.tooltip.ShulkerPreviewData shulker) {
					return new ru.neuclient.client.tooltip.ShulkerPreviewComponent(shulker);
				}
			} catch (Throwable t) {
				LOGGER.error("[NeuClient] Ошибка компонента превью шалкера", t);
			}
			return null;
		});

		// Захват матричного состояния кадра каждый world-render (проекция
		// мировых точек на экран для NameTags, рисующегося в HUD-проходе)
		net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents.END_MAIN.register(context -> {
			try {
				if (panicked) return;
				ru.neuclient.client.render.WorldToScreen.capture(context.matrices(),
						net.minecraft.client.MinecraftClient.getInstance().gameRenderer.getCamera());
			} catch (Throwable t) {
				LOGGER.error("[NeuClient] Ошибка захвата матриц мира", t);
			}
		});

		// submitCustom должен попасть в очередь ДО RenderDispatcher.render().
		// AFTER_ENTITIES вызывается уже после обработки очереди сущностей.
		// Отдельный callback также изолирует TargetESP от ошибок соседних эффектов.
		net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents.BEFORE_ENTITIES.register(context -> {
			if (panicked) return;
			try {
				TargetEspModule.renderAllWorld(context);
			} catch (Throwable t) {
				LOGGER.error("[NeuClient] Ошибка отрисовки TargetESP", t);
			}
		});

		// Мировой 3D-рендер: траектории снарядов (толстая линия без глубины
		// + бокс падения), лучи-маяки меток .gps и контуры руд XRay
		net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents.AFTER_ENTITIES.register(context -> {
			try {
				if (panicked) return;
				ru.neuclient.client.module.impl.render.PredictionsModule.renderAllWorld(context);
				GpsManager.renderAllWorld(context);
				ru.neuclient.client.module.impl.misc.XrayModule.renderAllWorld(context);
				ru.neuclient.client.module.impl.misc.StructureFinderModule.renderAllWorld(context);
				ru.neuclient.client.module.impl.render.WardenESP.renderWardenBeams(context);
				ru.neuclient.client.module.impl.render.WardenESP.renderChestOutlines(context);
				ru.neuclient.client.module.impl.render.WardenESP.renderWardenBoxes(context);
				ru.neuclient.client.module.impl.render.StorageESPModule.renderAllWorld(context);
				ru.neuclient.client.module.impl.render.BlockOverlayModule.renderAllWorld(context);
				// Визуалы: шляпа, волны прыжка, следы и частицы темы
				ru.neuclient.client.module.impl.render.ChinaHatModule.renderAllWorld(context);
				ru.neuclient.client.module.impl.render.JumpCirclesModule.renderAllWorld(context);
				ru.neuclient.client.module.impl.render.KillEffectModule.renderAllWorld(context);
				ru.neuclient.client.module.impl.render.TrailsModule.renderAllWorld(context);
				ru.neuclient.client.module.impl.render.ParticlesModule.renderAllWorld(context);
				ru.neuclient.client.module.impl.player.BlinkModule.renderAllWorld(context);
			} catch (Throwable t) {
				LOGGER.error("[NeuClient] Ошибка мирового 3D-рендера", t);
			}
		});

		// Голос дворецкого: hello планируется на звуковой пуск (движок ещё не готов
		// в момент CLIENT_STARTED — сразу звук просто молча отбрасывается ваниллой)
		ClientLifecycleEvents.CLIENT_STARTED.register(client -> {
			// Регистрируем кастомный RenderPipeline и загружаем MSDF-атласы.
			// GL-контекст уже готов, поэтому создание текстур и UBO безопасно.
			ru.neuclient.client.font.MsdfTextPipeline.touch();
			ru.neuclient.client.render.RoundedRectPipeline.touch();
			ru.neuclient.client.render.GuiCubePipeline.touch();
			ru.neuclient.client.render.GlassPanelPipeline.touch();
			ru.neuclient.client.render.HdCapeRenderLayer.touch();
			ru.neuclient.client.render.ParticleRenderLayer.touch();
			ru.neuclient.client.render.GlassHandPipeline.touch();
			ru.neuclient.client.render.ChamsRenderLayer.touch();
			ru.neuclient.client.font.MsdfFonts.init();

			// Для ботов озвучка Джарвиса полностью отключена
			if (!ru.neuclient.client.bot.BotManager.getInstance().isChildBot()) {
				jarvisHelloPending = true;
				jarvisHelloAttempts = 20;
				jarvisHelloCooldown = 10;
			}
		});

		// При обычном выходе ВСЕГДА сохраняем именно default.json
		ClientLifecycleEvents.CLIENT_STOPPING.register(client -> {
			// Немедленно отключаем и удаляем всех ботов
			ru.neuclient.client.bot.BotManager.getInstance().disconnectAll();

			if (panicked || ru.neuclient.client.bot.BotManager.getInstance().isChildBot()) {
				// Паника или процесс бота: ни звуков, ни перезаписи
				return;
			}
			// Прощание дворецкого звучит первым (и успевает дозвучать —
			// метод держит поток, пока реплика играет)
			try {
				ru.neuclient.client.util.NeuSounds.playJarvisByeAndWait();
			} catch (Throwable t) {
				LOGGER.error("[NeuClient] Не удалось сыграть прощание", t);
			}
			LOGGER.info("[NeuClient] Сохранение конфигов перед выходом...");
			configManager.saveDefault();
			friendManager.save();
			altManager.save();
			gpsManager.save();
		});

		LOGGER.info("[NeuClient] Ready ({} ms)", System.currentTimeMillis() - start);
	}

	/**
	 * Отложенное приветствие дворецкого: SoundSystem на старте отвечает
	 * NOT_STARTED и звук теряется — поэтому повторяем попытку каждые ~0.5 с,
	 * пока движок реально не запустит реплику (максимум ~10 с ожидания).
	 */
	private void tickJarvisHello() {
		if (!jarvisHelloPending) {
			return;
		}
		if (jarvisHelloCooldown-- > 0) {
			return;
		}
		jarvisHelloCooldown = 10;
		try {
			if (ru.neuclient.client.util.NeuSounds.tryPlayJarvisHello()) {
				jarvisHelloPending = false; // приветствие прозвучало
			} else if (--jarvisHelloAttempts <= 0) {
				jarvisHelloPending = false;
				LOGGER.warn("[NeuClient] Звуковой движок так и не поднялся — приветствие пропущено");
			}
		} catch (Throwable t) {
			jarvisHelloPending = false;
			LOGGER.error("[NeuClient] Не удалось сыграть приветствие", t);
		}
	}

	public static NeuClient getInstance() {
		return instance;
	}

	/** true с момента выполнения .panic — клиент притворяется ваниллой. */
	public boolean isPanicked() {
		return panicked;
	}

	/** Включить режим паники (вызывается из PanicManager). Необратимо. */
	public void setPanicked(boolean panicked) {
		this.panicked = panicked;
		if (panicked) {
			// Останавливаем начатый сброс до закрытия GUI в PanicManager.
			ru.neuclient.client.util.InventoryResetHelper.cancel();
			jarvisHelloPending = false; // дворецкий замолкает до перезапуска
		}
	}

	public ModuleManager getModuleManager() {
		return moduleManager;
	}

	/** Модуль HUD (содержит настройки видимости элементов и тему). */
	public InterfaceModule getInterfaceModule() {
		return hudModule;
	}

	public HudManager getHudManager() {
		return hudManager;
	}

	public ConfigManager getConfigManager() {
		return configManager;
	}

	public FriendManager getFriendManager() {
		return friendManager;
	}

	public AltManager getAltManager() {
		return altManager;
	}

	public CommandManager getCommandManager() {
		return commandManager;
	}

	/** Метки .gps (лучи-маяки, хранятся в gps.json). */
	public GpsManager getGpsManager() {
		return gpsManager;
	}
}