package ru.neuclient.client.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.render.state.CameraRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.PlayerLikeEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.neuclient.client.module.impl.render.NameTagsModule;
import ru.neuclient.client.util.NameProtectUtil;

/**
 * 1) Прячет ВАНИЛЬНЫЕ ники игроков, пока включён NameTags (вместо них —
 *    наша панель). Целимся именно в OVERRIDE у PlayerEntityRenderer:
 *    базовый метод в EntityRenderer для игроков не вызывается,
 *    поэтому миксинить надо сюда.
 * 2) NameProtect: подменяет СОБСТВЕННЫЙ displayName в render-state,
 *    чтобы ник над головой (от третьего лица) показывал фейк.
 */
@Mixin(PlayerEntityRenderer.class)
public abstract class PlayerEntityRendererLabelMixin {

	@Inject(method = "renderLabelIfPresent(Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V",
			at = @At("HEAD"), cancellable = true)
	private void pc$hideVanillaPlayerLabel(PlayerEntityRenderState state, MatrixStack matrices,
			OrderedRenderCommandQueue queue, CameraRenderState cameraState, CallbackInfo ci) {
		if (NameTagsModule.hideVanillaTags()) {
			ci.cancel();
		}
	}

	/**
	 * NameProtect: на RETURN все поля state заполнены — подменяем displayName,
	 * но только у СЕБЯ (entity == client.player): чужие ники не трогаем.
	 */
	@Inject(method = "updateRenderState(Lnet/minecraft/entity/PlayerLikeEntity;Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;F)V",
			at = @At("RETURN"))
	private void pc$nameProtectLabel(PlayerLikeEntity entity, PlayerEntityRenderState state, float tickDelta,
			CallbackInfo ci) {
		if (!NameProtectUtil.active()) {
			return;
		}
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc == null || mc.player == null || entity != mc.player) {
			return;
		}
		state.displayName = NameProtectUtil.transformIfActive(state.displayName);
	}
}
