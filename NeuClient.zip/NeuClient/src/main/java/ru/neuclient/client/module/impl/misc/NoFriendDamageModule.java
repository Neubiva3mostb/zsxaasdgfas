package ru.neuclient.client.module.impl.misc;

import net.minecraft.entity.Entity;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.bot.BotManager;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;

/**
 * No Friend Damage — запрещает бить друзей из списка (.friend add) и ботов (.bot start).
 *
 * Проверка делается в Mixin на ClientPlayerInteractionManager#attackEntity:
 * если ник цели есть в списке друзей или ботов, удар молча отменяется.
 */
public class NoFriendDamageModule extends Module {

	public NoFriendDamageModule() {
		super("NoFriendDamage", "Не даёт бить друзей и ботов", Category.MISC);
	}

	/**
	 * @return true, если по цели бить можно (она не в друзьях и не бот)
	 */
	public boolean canAttack(Entity target) {
		if (target == null) {
			return false;
		}
		String name = target.getName().getString();
		if (BotManager.getInstance().isBot(name)) {
			return false;
		}
		if (!isEnabled()) {
			return true;
		}
		return !NeuClient.getInstance().getFriendManager().isFriend(name);
	}
}
