package ru.neuclient.client.module.impl.movement;

import net.minecraft.client.network.ClientPlayerEntity;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.ModeSetting;

/**
 * NoSlow — убирает замедление при использовании предмета
 * (еда, щит, лук, трезубец, зелья).
 *
 * Замедление ×0.2 ванилла накладывает в tickMovementInput по флагу
 * isUsingItem. Миксин подменяет ответ этого флага — дальше ввод
 * честно уходит на сервер со скоростью ходьбы.
 *
 * Режимы:
 *  Grim    — ноуслоу только когда используешь предмет СТОЯ на земле
 *            (в прыжке/полёте отдаём ваниль — Грим меньше дёргается);
 *  Vulcan  — только с щитом/блоком; еда и лук без спринта тоже пропускаются,
 *            остальное ванильно (Вулкан не любит спринт с предметом);
 *  Matrix  — полный ноуслоу всегда.
 */
public final class NoSlowModule extends Module {

	private final ModeSetting mode = new ModeSetting("Режим", "Grim", "Grim", "Vulcan", "Matrix");

	public NoSlowModule() {
		super("NoSlow", "Убирает замедление при взаимодействии с предметами", Category.MOVEMENT);
		addSettings(mode);
	}

	/**
	 * Вызывается из миксина tickMovementInput вместо настоящего isUsingItem().
	 * @return что вернуть в ваниллу: false = «предмет не используем» = нет замедления.
	 */
	public boolean spoofUsingItem(ClientPlayerEntity player, boolean actuallyUsing) {
		if (!actuallyUsing) {
			return false;
		}

		switch (mode.get()) {
			case "Matrix" -> {
				return false; // всегда ноуслоу
			}
			case "Vulcan" -> {
				// Щит (блок) — всегда ноуслоу; остальные предметы — только без спринта
				if (player.isBlocking() || !player.isSprinting()) {
					return false;
				}
				return true;
			}
			case "Grim" -> {
				// Только на земле
				return !player.isOnGround();
			}
			default -> {
				return actuallyUsing;
			}
		}
	}
}
