package ru.neuclient.client.module.impl.render;

import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.Vec3d;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.render.WorldRenderUtil;
import ru.neuclient.client.setting.ModeSetting;
import ru.neuclient.client.setting.NumberSetting;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * Jump Circles — расходящиеся волны в момент СВОЕГО прыжка.
 *
 * Когда игрок отрывается от земли (был на земле → в воздухе с
 * положительной вертикальной скоростью), в точке отрыва рождается волна:
 * горизонтальная окружность, которая расширяется до заданного радиуса,
 * слегка приподнимается и растворяется.
 *
 * Цвет — на выбор из палитры.
 * Настройки: «Цвет», «Радиус» и «Время жизни».
 *
 * Волны существуют только на клиенте, никаких пакетов.
 */
public final class JumpCirclesModule extends Module {

	/** Сегментов в окружности. */
	private static final int SEGMENTS = 36;
	/** Максимум одновременных волн (страховка производительности). */
	private static final int MAX_WAVES = 16;
	private static final float LINE_WIDTH = 2.5f;

	private final ru.neuclient.client.setting.ColorSetting color = new ru.neuclient.client.setting.ColorSetting("Цвет", 0xFF7A5CFF);
	private final NumberSetting radius = new NumberSetting("Радиус", 2.0, 1.0, 3.0, 1.0);
	private final NumberSetting lifetime = new NumberSetting("Время жизни", 20.0, 8.0, 40.0, 2.0);

	/** Живые волны. */
	private final List<Wave> waves = new ArrayList<>();
	/** Был ли игрок на земле на прошлом тике. */
	private boolean wasOnGround = true;

	public JumpCirclesModule() {
		super("Jump Circles", "Волны при прыжке", Category.RENDER);
		addSettings(color, radius, lifetime);
	}

	/** Одна волна: точка рождения + возраст. */
	private static final class Wave {
		final double x;
		final double y;
		final double z;
		int age;

		Wave(double x, double y, double z) {
			this.x = x;
			this.y = y;
			this.z = z;
		}
	}

	@Override
	protected void onEnable() {
		waves.clear();
		wasOnGround = true;
	}

	@Override
	protected void onDisable() {
		waves.clear();
	}

	@Override
	public void onTick(MinecraftClient client) {
		ClientPlayerEntity player = client.player;
		if (client.world == null || player == null) {
			waves.clear();
			return;
		}

		// Старение волн
		int maxAge = lifetime.get().intValue();
		Iterator<Wave> it = waves.iterator();
		while (it.hasNext()) {
			Wave wave = it.next();
			if (++wave.age >= maxAge) {
				it.remove();
			}
		}

		// Детект своего прыжка: был на земле → теперь в воздухе (независимо от высоты прыжка)
		boolean onGround = player.isOnGround();
		if (wasOnGround && !onGround && waves.size() < MAX_WAVES) {
			waves.add(new Wave(player.getX(), player.getY() + 0.02, player.getZ()));
		}
		wasOnGround = onGround;
	}

	/** Мировой рендер (AFTER_ENTITIES). */
	public void renderWorld(WorldRenderContext context, MinecraftClient client) {
		if (waves.isEmpty() || context.commandQueue() == null) {
			return;
		}
		Vec3d cam = client.gameRenderer.getCamera().getCameraPos();
		MatrixStack matrices = context.matrices();
		float tickDelta = client.getRenderTickCounter().getTickProgress(false);
		double maxRadius = radius.get();
		double maxAge = lifetime.get();

		int accent = color.get();
		float r = WorldRenderUtil.red(accent);
		float g = WorldRenderUtil.green(accent);
		float b = WorldRenderUtil.blue(accent);

		matrices.push();
		matrices.translate(-cam.x, -cam.y, -cam.z);

		context.commandQueue().submitCustom(matrices, WorldRenderUtil.LINES_NO_DEPTH, (entry, buffer) -> {
			for (Wave wave : waves) {
				// Плавный возраст 0..1 с учётом дельты кадра
				double progress = Math.min(1.0, (wave.age + tickDelta) / maxAge);
				// Радиус растёт быстро в начале и замедляется к концу
				double currentRadius = maxRadius * Math.sqrt(progress);
				// Волна слегка всплывает
				double y = wave.y + progress * 0.35;
				// И растворяется к концу жизни
				float alpha = (float) (1.0 - progress) * 0.8f;
				if (alpha <= 0.01f) {
					continue;
				}
				WorldRenderUtil.circle(buffer, entry, wave.x, y, wave.z,
						currentRadius, SEGMENTS, r, g, b, alpha, LINE_WIDTH);
			}
		});

		matrices.pop();
	}

	/** Диспетчер мирового рендера (вызывается из NeuClient). */
	public static void renderAllWorld(WorldRenderContext context) {
		var modules = ru.neuclient.client.NeuClient.getInstance().getModuleManager();
		if (modules == null) {
			return;
		}
		JumpCirclesModule self = modules.get(JumpCirclesModule.class);
		if (self != null && self.isEnabled()) {
			self.renderWorld(context, MinecraftClient.getInstance());
		}
	}
}
