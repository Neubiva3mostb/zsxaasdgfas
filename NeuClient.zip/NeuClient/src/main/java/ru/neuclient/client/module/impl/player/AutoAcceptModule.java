package ru.neuclient.client.module.impl.player;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.BooleanSetting;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Автоматически принимает входящие запросы на телепортацию. */
public final class AutoAcceptModule extends Module {

	private static final Pattern PLAYER_NAME = Pattern.compile("(?<![A-Za-z0-9_])[A-Za-z0-9_]{3,16}(?![A-Za-z0-9_])");
	private static final long ACCEPT_COOLDOWN_MS = 900L;

	/** По просьбе пользователя включено по умолчанию. */
	private final BooleanSetting onlyFriends = new BooleanSetting("Только друзей", true);
	private long lastAcceptAt;
	private String lastAcceptedName = "";

	public AutoAcceptModule() {
		super("AutoAccept", "Принимает запросы на телепортацию", Category.PLAYER);
		addSettings(onlyFriends);
	}

	/** Вызывается из ChatHudMixin для входящих сообщений сервера. */
	public void onChatMessage(String rawMessage) {
		if (!isEnabled() || rawMessage == null || rawMessage.isBlank()) {
			return;
		}
		String lower = rawMessage.toLowerCase(Locale.ROOT);
		if (!isTeleportRequest(lower)) {
			return;
		}

		String sender = findSender(rawMessage);
		if (onlyFriends.get() && !isFriend(sender)) {
			return;
		}
		if (onlyFriends.get() && sender.isEmpty()) {
			return;
		}

		long now = System.currentTimeMillis();
		if (now - lastAcceptAt < ACCEPT_COOLDOWN_MS && lastAcceptedName.equalsIgnoreCase(sender)) {
			return;
		}
		MinecraftClient client = MinecraftClient.getInstance();
		ClientPlayNetworkHandler handler = client.getNetworkHandler();
		if (client.player == null || handler == null) {
			return;
		}

		// Серверные плагины используют одну из двух распространённых команд.
		String command = lower.contains("/tpyes") ? "tpyes" : "tpaccept";
		handler.sendChatCommand(command);
		lastAcceptAt = now;
		lastAcceptedName = sender;
	}

	private boolean isTeleportRequest(String lower) {
		boolean hasCommand = lower.contains("/tpaccept") || lower.contains("/tpyes")
				|| lower.contains("tpaccept") || lower.contains("tpyes");
		boolean hasTeleportWord = lower.contains("телепорт") || lower.contains("teleport")
				|| lower.contains("tpa");
		boolean hasRequestWord = lower.contains("запрос") || lower.contains("request")
				|| lower.contains("просит") || lower.contains("хочет")
				|| lower.contains("wants") || lower.contains("запросил")
				|| lower.contains("requested");
		return hasTeleportWord && hasRequestWord || hasCommand && lower.contains("tpa");
	}

	private boolean isFriend(String name) {
		if (name.isEmpty() || NeuClient.getInstance() == null
				|| NeuClient.getInstance().getFriendManager() == null) {
			return false;
		}
		return NeuClient.getInstance().getFriendManager().isFriend(name);
	}

	/**
	 * Сначала ищем ник среди реально загруженных игроков. Это не даёт
	 * принять запрос из случайного текста чата, содержащего знакомое слово.
	 */
	private String findSender(String message) {
		MinecraftClient client = MinecraftClient.getInstance();
		if (client.world != null) {
			Matcher matcher = PLAYER_NAME.matcher(message);
			while (matcher.find()) {
				String candidate = matcher.group();
				if (client.world.getPlayers().stream().anyMatch(player ->
						player.getName().getString().equalsIgnoreCase(candidate))) {
					return candidate;
				}
			}
		}

		// При включённом ограничении друзья обычно уже входят в сообщение.
		if (NeuClient.getInstance() != null && NeuClient.getInstance().getFriendManager() != null) {
			for (String friend : NeuClient.getInstance().getFriendManager().list()) {
				if (message.toLowerCase(Locale.ROOT).contains(friend.toLowerCase(Locale.ROOT))) {
					return friend;
				}
			}
		}
		return "";
	}

	public static AutoAcceptModule active() {
		NeuClient client = NeuClient.getInstance();
		if (client == null || client.getModuleManager() == null) {
			return null;
		}
		AutoAcceptModule module = client.getModuleManager().get(AutoAcceptModule.class);
		return module != null && module.isEnabled() ? module : null;
	}

	@Override
	protected void onDisable() {
		lastAcceptAt = 0L;
		lastAcceptedName = "";
	}
}
