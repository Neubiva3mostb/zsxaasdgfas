package ru.neuclient.client.module.impl.player;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.random.Random;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.ModeSetting;
import ru.neuclient.client.setting.NumberSetting;

/**
 * HitSounds — замена ВСЕХ ванильных звуков удара на кастомные.
 *
 * Подход из референсного мода HitSound (IseyitThe):
 *   1. PlayerEntityAttackMixin хукает PlayerEntity.attack() —
 *      вызывает onPlayerAttack() при каждом ударе по живой сущности.
 *   2. Звук проигрывается через SoundManager.play(PositionedSoundInstance) —
 *      тот же способ, что NeuSounds использует для UI-звуков.
 *   3. SoundSystemMixin гасит ВСЕ entity.player.attack.* звуки —
 *      ванильный звук не прозвучит.
 *
 * SoundEvent'ы регистрируются в Registries.SOUND_EVENT при init().
 * Звук проигрывается как PositionedSoundInstance (ATTENUATION_NONE),
 * чтобы он всегда был слышен на полной громкости, как UI-звук.
 */
public final class HitSoundsModule extends Module {

	/** Идентификаторы кастомных звуков (ключи в sounds.json). */
	private static final String[] SOUND_KEYS = {
			"hitsounds_critical_hit",
			"hitsounds_apple_pay",
			"hitsounds_bone_crack",
			"hitsounds_uwu"
	};

	/** Человекочитаемые имена для ModeSetting. */
	private static final String[] SOUND_NAMES = {
			"Critical Hit",
			"Apple Pay",
			"Bone Crack",
			"UwU"
	};

	/** Зарегистрированные SoundEvent'ы (null до init()). */
	private static SoundEvent[] SOUND_EVENTS;

	/** Признак того, что SoundEvent'ы зарегистрированы. */
	private static boolean registered = false;

	/** ThreadLocal-флаг для защиты от рекурсии в SoundSystemMixin. */
	private static final ThreadLocal<Boolean> INSIDE_HITSOUNDS = ThreadLocal.withInitial(() -> false);

	private final ModeSetting sound = new ModeSetting("Звук", SOUND_NAMES[0], SOUND_NAMES);
	private final NumberSetting volume = new NumberSetting("Громкость", 100, 0, 200, 5);

	public HitSoundsModule() {
		super("HitSounds", "Заменяет звуки удара на кастомный", Category.PLAYER);
		addSettings(sound, volume);
	}

	// ===== Регистрация SoundEvent'ов =====

	/**
	 * Регистрирует кастомные SoundEvent'ы в реестре.
	 * Вызывается один раз при инициализации мода.
	 */
	public static void init() {
		if (registered) return;
		registered = true;

		SOUND_EVENTS = new SoundEvent[SOUND_KEYS.length];
		for (int i = 0; i < SOUND_KEYS.length; i++) {
			Identifier id = Identifier.of("perfstream", SOUND_KEYS[i]);
			if (!Registries.SOUND_EVENT.containsId(id)) {
				SoundEvent event = SoundEvent.of(id);
				Registry.register(Registries.SOUND_EVENT, id, event);
				SOUND_EVENTS[i] = event;
			} else {
				SOUND_EVENTS[i] = Registries.SOUND_EVENT.get(id);
			}
		}
	}

	// ===== API для миксинов =====

	/** Включён ли модуль (static-доступ из миксинов). */
	public static boolean isActive() {
		NeuClient client = NeuClient.getInstance();
		if (client == null || client.getModuleManager() == null) return false;
		HitSoundsModule module = client.getModuleManager().get(HitSoundsModule.class);
		return module != null && module.isEnabled();
	}

	/** Находимся ли внутри обработки Hitsounds (защита от рекурсии). */
	public static boolean isInsideHitsounds() {
		return INSIDE_HITSOUNDS.get();
	}

	/** Установить флаг рекурсии (вызывается из HitSoundsModule, читается из SoundSystemMixin). */
	public static void setInsideHitsounds(boolean value) {
		INSIDE_HITSOUNDS.set(value);
	}

	/** Время последнего проигрывания (для защиты от двоения звуков). */
	private static long lastPlayTime = 0L;

	/**
	 * Вызывается из PlayerEntityAttackMixin при ударе по живой сущности.
	 * Проигрывает кастомный звук через SoundManager.play().
	 */
	public static void onPlayerAttack(net.minecraft.entity.player.PlayerEntity player) {
		long now = System.currentTimeMillis();
		if (now - lastPlayTime < 60L) {
			return; // Защита от двоения звука при быстрых вызовах
		}

		NeuClient client = NeuClient.getInstance();
		if (client == null || client.getModuleManager() == null) return;
		HitSoundsModule module = client.getModuleManager().get(HitSoundsModule.class);
		if (module == null || !module.isEnabled()) return;
		if (SOUND_EVENTS == null) return;

		// Определяем, какой звук играть
		String selectedName = module.sound.get();
		SoundEvent event = SOUND_EVENTS[0]; // default
		for (int i = 0; i < SOUND_NAMES.length; i++) {
			if (SOUND_NAMES[i].equals(selectedName)) {
				event = SOUND_EVENTS[i];
				break;
			}
		}

		float vol = (float) (module.volume.get() / 100.0);

		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc == null || mc.getSoundManager() == null) return;

		lastPlayTime = now;

		// Ставим флаг рекурсии — SoundSystemMixin пропустит этот звук
		setInsideHitsounds(true);
		try {
			PositionedSoundInstance instance = new PositionedSoundInstance(
					event.id(), SoundCategory.PLAYERS,
					vol, 1.0f, Random.create(),
					false, 0, SoundInstance.AttenuationType.NONE,
					0.0, 0.0, 0.0, true);
			mc.getSoundManager().play(instance);
		} finally {
			setInsideHitsounds(false);
		}
	}
}
