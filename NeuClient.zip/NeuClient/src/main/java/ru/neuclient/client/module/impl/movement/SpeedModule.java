package ru.neuclient.client.module.impl.movement;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.BooleanSetting;
import ru.neuclient.client.setting.ModeSetting;

/** Speed — ускорение передвижения в четырёх вариантах.
 *  - Matrix      — «бхоп»: автопрыжок + ступенчатое ускорение при касании земли.
 *  - Old Matrix  — старый матрикс: после падения с высоты ≥ 0.5 при касании земли горизонтальная скорость умножается ×2.
 *  - Grim        — буст рядом с игроком (радиус GRIM_RANGE), только в воздухе; на земле не подставляем.
 *  - Vulcan      — короткий множитель на земле + лёгкий стрейф в воздухе.
 *  Все режимы крутят только клиентскую скорость (setVelocity) — как поведет себя конкретный античит, решает сервер; потолок скорости ограничен, чтобы не улетать в стратосферу флагов.
 */
public final class SpeedModule extends Module {

	/** Потолок горизонтальной скорости (блоков/тик), выше — обрезаем. */
	private static final double MAX_HORIZONTAL = 0.95;

	/** Радиус поиска игрока для Grim-режима (блоки). */
	private static final float GRIM_RANGE = 1.5f;

	/** Насколько ослаблен буст Grim: 0.7 = на 30 % слабее исходного. */
	private static final double GRIM_WEAKEN = 0.7;

	private int stage = 0;
	private boolean wasOnGround = false;
	private double prevFallDistance = 0.0;

	private final ModeSetting mode = new ModeSetting("Режим", "Matrix", "Matrix", "Grim", "Old Matrix", "Vulcan");
	private final BooleanSetting autoJump = new BooleanSetting("Автопрыжок", true);

	public SpeedModule() {
		super("Speed", "Ускорение движения", Category.MOVEMENT);
		addSettings(mode, autoJump);
	}

	@Override
	public void onTick(MinecraftClient client) {
		ClientPlayerEntity player = client.player;
		if (player == null || client.world == null) {
			reset();
			return;
		}
		if (player.isTouchingWater() || player.hasVehicle() || player.isClimbing()) {
			return; // в воде/лодке/на лестнице не подставляемся
		}

		switch (mode.get()) {
			case "Old Matrix" -> tickOldMatrix(player);
			case "Grim" -> tickGrim(client, player);
			case "Vulcan" -> tickVulcan(player);
			default -> tickMatrix(player);
		}
		capHorizontal(player);
	}

	// ===== Matrix: автопрыжок + ступенчатое ускорение =====

	private void tickMatrix(ClientPlayerEntity player) {
		if (!isMoving(player)) {
			stage = 0;
			return;
		}
		if (player.horizontalCollision) {
			stage = -1; // врезались — начинаем разгон заново
		}
		if (player.isOnGround()) {
			if (stage < 0) {
				stage = 0;
			}
			if (autoJump.get()) {
				player.jump();
			}
			setHorizontalSpeed(player, stageSpeed(stage) * 0.85 + 0.0335);
			stage++;
		}
	}

	/** Ступенчатая целевая скорость (адаптация getCurrentSpeed без эффектов). */
	private double stageSpeed(int stage) {
		if (stage <= 0) {
			return 0.64;
		}
		if (stage == 1) {
			return 0.4145;
		}
		return Math.max(0.4145 - stage / 500.0 * 1.87, 0.2873);
	}

	// ===== Old Matrix: ускорение при мягком приземлении =====

	private void tickOldMatrix(ClientPlayerEntity player) {
		if (autoJump.get() && player.isOnGround() && isMoving(player)) {
			player.jump();
		}
		boolean grounded = player.isOnGround();
		if (!wasOnGround && grounded && prevFallDistance >= 0.5 && isMoving(player)) {
			Vec3d vel = player.getVelocity();
			player.setVelocity(vel.x * 2.0, vel.y, vel.z * 2.0);
		}
		wasOnGround = grounded;
		prevFallDistance = player.fallDistance;
	}

	// ===== Grim: буст рядом с сущностями (только в воздухе) =====

	private void tickGrim(MinecraftClient client, ClientPlayerEntity player) {
		// Буста от земли нет намеренно: на земле ванильное трение 0.91
		// применяется до нас, поэтому любой наземный множитель либо ничего не
		// даёт (1/0.91 ровно гасит трение), либо тормозит игрока.
		if (player.isOnGround()) {
			return;
		}
		for (AbstractClientPlayerEntity other : client.world.getPlayers()) {
			if (other == player || player.distanceTo(other) > GRIM_RANGE) {
				continue;
			}
			// Рядом игрок — пересчитываем трение в свою пользу: исходные
			// 0.99/0.91 ≈ +8.79 %, ослаблено на 30 % → ≈ +6.15 %.
			double boost = (0.99 / 0.91 - 1.0) * GRIM_WEAKEN;
			double mult = 1.0 + boost;
			Vec3d vel = player.getVelocity();
			player.setVelocity(vel.x * mult, vel.y, vel.z * mult);
			break;
		}
	}

	// ===== Vulcan: короткий множитель + воздушный стрейф =====

	private void tickVulcan(ClientPlayerEntity player) {
		if (!isMoving(player)) {
			return;
		}
		Vec3d vel = player.getVelocity();
		if (player.isOnGround()) {
			if (autoJump.get()) {
				player.jump();
			}
			player.setVelocity(vel.x * 1.22, player.getVelocity().y, vel.z * 1.22);
		} else if (player.age % 2 == 0) {
			player.setVelocity(vel.x * 1.04, vel.y, vel.z * 1.04);
		}
	}

	// ===== Утилиты движения =====

	private boolean isMoving(ClientPlayerEntity player) {
		return ru.neuclient.client.util.MoveUtil.isMoving(player);
	}

	/** Вектор горизонтальной скорости в сторону, куда реально жмёт игрок.
	 * Считается в MoveUtil по формуле atan2(−sideways, forward) — прежняя
	 * таблица углов путала знаки на диагоналях назад (A+S / D+S).
	 */
	private static double[] motionTowardsInput(ClientPlayerEntity player, double speed) {
		return ru.neuclient.client.util.MoveUtil.motionTowardsInput(player, speed);
	}

	/** Выставить горизонтальную скорость по направлению движения, Y не трогаем. */
	private void setHorizontalSpeed(ClientPlayerEntity player, double speed) {
		double[] m = motionTowardsInput(player, speed);
		player.setVelocity(m[0], player.getVelocity().y, m[1]);
	}

	/** Страховочный потолок горизонтальной скорости. */
	private void capHorizontal(ClientPlayerEntity player) {
		Vec3d vel = player.getVelocity();
		double h = Math.hypot(vel.x, vel.z);
		if (h > MAX_HORIZONTAL) {
			double k = MAX_HORIZONTAL / h;
			player.setVelocity(vel.x * k, vel.y, vel.z * k);
		}
	}

	private void reset() {
		stage = 0;
		wasOnGround = false;
		prevFallDistance = 0.0;
	}

	@Override
	protected void onDisable() {
		reset();
	}
}
