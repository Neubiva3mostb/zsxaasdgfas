package ru.neuclient.client.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import ru.neuclient.client.util.KeyNames;

/**
 * Настройка-клавиша: GLFW-код, как у бинда модуля, но внутри настроек.
 * В ClickGUI строка показывает [KEY], ЛКМ по ней — «слушать» следующую
 * нажатую клавишу (Esc/NONE = снять клавишу).
 */
public class KeyBindSetting extends Setting<Integer> {

	/** Без клавиши (тот же код NONE, что и у биндов модулей). */
	public static final int NONE = KeyNames.NONE;

	public KeyBindSetting(String name, int defaultKey) {
		super(name, defaultKey);
	}

	public String getKeyName() {
		return KeyNames.getName(get());
	}

	@Override
	public JsonElement toJson() {
		return new JsonPrimitive(get());
	}

	@Override
	public void fromJson(JsonElement element) {
		if (element != null && element.isJsonPrimitive() && element.getAsJsonPrimitive().isNumber()) {
			set(element.getAsInt());
		}
	}
}
