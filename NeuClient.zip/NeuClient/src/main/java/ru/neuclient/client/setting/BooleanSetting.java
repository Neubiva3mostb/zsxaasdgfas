package ru.neuclient.client.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

/** Булева настройка (чекбокс). */
public class BooleanSetting extends Setting<Boolean> {

	public BooleanSetting(String name, boolean defaultValue) {
		super(name, defaultValue);
	}

	public void toggle() {
		set(!get());
	}

	@Override
	public JsonElement toJson() {
		return new JsonPrimitive(get());
	}

	@Override
	public void fromJson(JsonElement element) {
		if (element != null && element.isJsonPrimitive()) {
			set(element.getAsBoolean());
		}
	}
}
