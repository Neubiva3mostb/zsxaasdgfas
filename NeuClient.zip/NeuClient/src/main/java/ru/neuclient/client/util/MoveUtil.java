package ru.neuclient.client.util;

import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec2f;

/**
 * Математика направления движения игрока.
 *
 * ПОЧЕМУ ЭТОТ КЛАСС ПОЯВИЛСЯ. В Speed/Fly/Strafe направление считалось
 * набором if-ов с «магическими» углами (−45/45/135/−135). Для диагоналей
 * НАЗАД знаки в этой таблице были перепутаны местами: при A+S игрок ехал
 * вправо-назад вместо лево-назад, при D+S — наоборот.
 *
 * Здесь направление выводится честно из той же формулы, что использует
 * ваниль в Entity#movementInputToVelocity:
 *
 *   world_x = sideways·cos(yaw) − forward·sin(yaw)
 *   world_z = forward·cos(yaw)  + sideways·sin(yaw)
 *
 * Если записать результат как поворот на угол θ относительно взгляда, то
 * получается ровно θ = atan2(−sideways, forward). Это выражение
 * автоматически даёт правильные значения для всех восьми направлений,
 * включая диагонали назад, — таблица углов больше не нужна.
 */
public final class MoveUtil {

	private MoveUtil() {
	}

	/** Нажата ли хоть одна клавиша движения. */
	public static boolean isMoving(ClientPlayerEntity player) {
		if (player == null || player.input == null) {
			return false;
		}
		Vec2f mv = player.input.getMovementInput();
		return mv.x != 0.0f || mv.y != 0.0f;
	}

	/**
	 * Горизонтальная скорость заданной величины в ту сторону, куда реально
	 * жмёт игрок (с учётом yaw и всех диагоналей).
	 *
	 * @return массив {x, z}; {0, 0} если клавиши движения не нажаты
	 */
	public static double[] motionTowardsInput(ClientPlayerEntity player, double speed) {
		if (player == null || player.input == null) {
			return new double[]{0.0, 0.0};
		}
		Vec2f mv = player.input.getMovementInput();
		float sideways = mv.x;
		float forward = mv.y;
		if (sideways == 0.0f && forward == 0.0f) {
			return new double[]{0.0, 0.0};
		}
		// Угол направления относительно взгляда игрока
		double theta = Math.atan2(-sideways, forward);
		double rad = Math.toRadians(player.getYaw()) + theta;
		return new double[]{-Math.sin(rad) * speed, Math.cos(rad) * speed};
	}
}
