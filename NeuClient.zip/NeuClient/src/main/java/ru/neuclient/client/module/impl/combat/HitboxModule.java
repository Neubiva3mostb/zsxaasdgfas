package ru.neuclient.client.module.impl.combat;

import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.NumberSetting;

/**
 * Hitbox — расширяет хитбоксы ДРУГИХ игроков по горизонтали (X/Z),
 * высоту не трогает. Чисто клиентская правка: трассировка прицела
 * (выбор цели под курсором) цепляет игрока раньше — проще попадать
 * и проще работать TriggerBot'у. Сервер про расширение не знает,
 * реальный хитбокс на нём прежний.
 *
 * Настройка «Размер» — на сколько блоков (0.1–1.0) раздувается
 * хитбокс в каждую сторону по горизонтали.
 */
public class HitboxModule extends Module {

	private final NumberSetting expand = new NumberSetting("Размер", 0.3, 0.1, 1.0, 0.05);

	public HitboxModule() {
		super("Hitbox", "Увеличивает хитбоксы игроков", Category.COMBAT);
		addSettings(expand);
	}

	/** Величина расширения (блоки) для EntityHitboxMixin. */
	public double getExpand() {
		return expand.get();
	}
}
