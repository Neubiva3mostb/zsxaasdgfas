package ru.neuclient.client.module.impl.combat;

import com.mojang.authlib.GameProfile;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;

/**
 * AntiBot — не целиться в ботов.
 *
 * На серверах вроде FunTime рядом постоянно стоят фейковые игроки: аура
 * тратит на них кулдаун и промахи, а настоящий противник в это время бьёт
 * в ответ. Модуль отбраковывает такие сущности до выбора цели.
 *
 * Проверки применяются ТОЛЬКО к PlayerEntity — мобы не трогаются.
 * Настроек нет намеренно: работают две самые безопасные проверки,
 * которые не дают ложных срабатываний на реальных игроках.
 *
 *  • «Битый профиль» — профиль без ника или без UUID бывает только у подделок;
 *  • «Нет в таб-листе» — у настоящей сущности игрока сервер всегда присылает
 *    запись в списке игроков.
 *
 * Более агрессивные признаки (аномально большой entityId, висит в воздухе)
 * убраны: на переполненных серверах entityId у живых игроков тоже бывает
 * большим, а «не на земле» отсечёт любого прыгающего.
 *
 * ВАЖНО ПРО КАРПЕТ-БОТОВ. Боты, поставленные через carpet /player (и любые
 * другие «честные» фейк-игроки), имеют настоящий профиль и присутствуют в
 * таб-листе — эти две проверки их не ловят.
 *
 * Интеграция: AttackAura.isValidTarget и AimBot.isValidTarget вызывают
 * {@link #isBot(Entity)} до выбора цели. Чисто клиентский модуль, пакеты
 * не меняются.
 */
public final class AntiBotModule extends Module {

	public AntiBotModule() {
		super("AntiBot", "Не целиться в фейковых игроков", Category.COMBAT);
	}

	/** Активный модуль или null. */
	public static AntiBotModule active() {
		NeuClient client = NeuClient.getInstance();
		if (client == null || client.getModuleManager() == null) {
			return null;
		}
		AntiBotModule self = client.getModuleManager().get(AntiBotModule.class);
		return self != null && self.isEnabled() ? self : null;
	}

	/**
	 * Точка входа для боевых модулей: считать ли сущность ботом.
	 *
	 * Возвращает false при любой нештатной ситуации — лучше не отфильтровать
	 * бота, чем перестать видеть реального игрока.
	 */
	public static boolean isBot(Entity entity) {
		try {
			if (active() == null) {
				return false;
			}
			return check(entity);
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка AntiBot", t);
			return false;
		}
	}

	private static boolean check(Entity entity) {
		// Только игроки: мобы и прочие существа ботами не считаются.
		if (!(entity instanceof PlayerEntity other)) {
			return false;
		}
		MinecraftClient mc = MinecraftClient.getInstance();
		ClientPlayerEntity self = mc.player;
		if (self == null || other == self || other.getId() == self.getId()) {
			return false;
		}

		// 1. Битый профиль: без ника или без UUID профиль бывает у подделок.
		GameProfile profile = other.getGameProfile();
		if (profile == null
				|| profile.name() == null || profile.name().isBlank()
				|| profile.id() == null) {
			return true;
		}

		// 2. Нет в таб-листе: сервер присылает запись для каждого настоящего
		//    игрока, поэтому её отсутствие — сильный признак фейка.
		ClientPlayNetworkHandler handler = mc.getNetworkHandler();
		if (handler == null) {
			return false;
		}
		return handler.getPlayerListEntry(profile.id()) == null;
	}
}
