package ru.neuclient.client.ai;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Identifier;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.util.ClientPaths;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Профиль прицеливания, построенный по РЕАЛЬНЫМ записям боя игрока.
 *
 * ОТКУДА БЕРЁТСЯ.
 * Команда .record пишет кадры боя, затем они сводятся в один JSON:
 * кривая «скорость доворота в зависимости от ошибки», шанс и длина пауз,
 * типичная ошибка прицела в момент удара, дистанция, темп.
 *
 * ЗАЧЕМ.
 * Раньше эти числа были подобраны на глаз. Теперь они измерены: аура
 * двигает мышь по профилю конкретного человека, а не по догадкам.
 *
 * ГДЕ ЛЕЖИТ.
 * Приоритет у внешнего файла C:\NeuClient\profiles\aim_profile.json —
 * его можно заменить без пересборки мода. Если внешнего нет, берётся
 * встроенный в jar (assets/neuclient/ai/aim_profile.json).
 *
 * ВАЖНО ПРО ЧУВСТВИТЕЛЬНОСТЬ.
 * Профиль записан на конкретной сенсе, и все углы в нём — градусы.
 * Градусы от сенсы не зависят, поэтому пересчёт не нужен: меняется лишь
 * шаг сетки мыши, который считается отдельно (RotationGcd).
 */
public final class AimProfile {

	/** Одна точка кривой: диапазон ошибки → характерная скорость. */
	public record Bin(float lo, float hi, float median, float p75, float p90, float idle) {
	}

	private static AimProfile instance;

	private final List<Bin> yawCurve = new ArrayList<>();
	private final List<Bin> pitchCurve = new ArrayList<>();

	private float pauseChance = 0.25f;
	private int pauseRunP90 = 4;

	private float yawCap = 27.0f;
	private float pitchCap = 12.0f;

	private float swingErrMedian = 11.0f;
	private float swingErrP75 = 18.0f;
	private float swingErrYawMedian = 5.39f;
	private float swingErrPitchMedian = 7.34f;
	private float swingDistMedian = 2.08f;
	private float swingDistP90 = 2.95f;
	private float swingCooldownP25 = 0.88f;

	/**
	 * Доля замахов мимо цели, в процентах (измерена по записям).
	 * Полностью убирать промахи нельзя: аура со 100 % попаданий
	 * выделяется сильнее, чем аура с человеческим процентом брака.
	 */
	private double missChance = 0.0;

	private boolean loaded;
	private String source = "встроенный";

	private final Random rand = new Random();

	private AimProfile() {
	}

	public static AimProfile get() {
		if (instance == null) {
			instance = new AimProfile();
			instance.load();
		}
		return instance;
	}

	/** Перечитать профиль с диска (команда .aim reload). */
	public static void reload() {
		instance = new AimProfile();
		instance.load();
	}

	public boolean isLoaded() {
		return loaded;
	}

	public String source() {
		return source;
	}

	// ===== Загрузка =====

	private void load() {
		JsonObject root = readExternal();
		if (root != null) {
			source = "внешний файл";
		} else {
			root = readBuiltin();
			source = "встроенный";
		}
		if (root == null) {
			NeuClient.LOGGER.warn("[NeuClient] Профиль прицела не найден, работаю на дефолтах");
			return;
		}
		try {
			parse(root);
			loaded = true;
			NeuClient.LOGGER.info("[NeuClient] Профиль прицела загружен ({})", source);
		} catch (Exception e) {
			NeuClient.LOGGER.error("[NeuClient] Профиль прицела повреждён", e);
		}
	}

	/** C:\NeuClient\profiles\aim_profile.json — приоритетный источник. */
	private JsonObject readExternal() {
		try {
			if (ClientPaths.getBase() == null) {
				return null;
			}
			Path p = ClientPaths.getBase().resolve("profiles").resolve("aim_profile.json");
			if (!Files.exists(p)) {
				return null;
			}
			try (Reader r = Files.newBufferedReader(p, StandardCharsets.UTF_8)) {
				return JsonParser.parseReader(r).getAsJsonObject();
			}
		} catch (Exception e) {
			NeuClient.LOGGER.error("[NeuClient] Не удалось прочитать внешний профиль", e);
			return null;
		}
	}

	/** Профиль, вшитый в jar. */
	private JsonObject readBuiltin() {
		try {
			Identifier id = Identifier.of("perfstream", "ai/aim_profile.json");
			var resource = MinecraftClient.getInstance().getResourceManager().getResource(id);
			if (resource.isEmpty()) {
				return null;
			}
			try (InputStream in = resource.get().getInputStream();
					Reader r = new InputStreamReader(in, StandardCharsets.UTF_8)) {
				return JsonParser.parseReader(r).getAsJsonObject();
			}
		} catch (Exception e) {
			NeuClient.LOGGER.error("[NeuClient] Не удалось прочитать встроенный профиль", e);
			return null;
		}
	}

	private void parse(JsonObject root) {
		yawCurve.clear();
		pitchCurve.clear();
		readCurve(root, "yawCurve", yawCurve);
		readCurve(root, "pitchCurve", pitchCurve);

		if (root.has("pause")) {
			JsonObject p = root.getAsJsonObject("pause");
			pauseChance = p.has("chance") ? p.get("chance").getAsFloat() : pauseChance;
			pauseRunP90 = p.has("runP90") ? p.get("runP90").getAsInt() : pauseRunP90;
		}
		if (root.has("caps")) {
			JsonObject c = root.getAsJsonObject("caps");
			// Берём p95, а не p99: p99 — это единичные рывки мышью,
			// повторять их каждый доворот было бы неестественно.
			yawCap = c.has("yawP95") ? c.get("yawP95").getAsFloat() : yawCap;
			pitchCap = c.has("pitchP95") ? c.get("pitchP95").getAsFloat() : pitchCap;
		}
		if (root.has("swing")) {
			JsonObject s = root.getAsJsonObject("swing");
			swingErrMedian = getF(s, "errMedian", swingErrMedian);
			swingErrP75 = getF(s, "errP75", swingErrP75);
			swingErrYawMedian = getF(s, "errYawMedian", swingErrYawMedian);
			swingErrPitchMedian = getF(s, "errPitchMedian", swingErrPitchMedian);
			swingDistMedian = getF(s, "distMedian", swingDistMedian);
			swingDistP90 = getF(s, "distP90", swingDistP90);
			swingCooldownP25 = getF(s, "cooldownP25", swingCooldownP25);
			missChance = getF(s, "missPercent", (float) missChance);
		}
	}

	private static float getF(JsonObject o, String k, float def) {
		return o.has(k) ? o.get(k).getAsFloat() : def;
	}

	private void readCurve(JsonObject root, String key, List<Bin> out) {
		if (!root.has(key)) {
			return;
		}
		JsonArray arr = root.getAsJsonArray(key);
		for (int i = 0; i < arr.size(); i++) {
			JsonObject b = arr.get(i).getAsJsonObject();
			out.add(new Bin(
					getF(b, "lo", 0), getF(b, "hi", 0),
					getF(b, "median", 1), getF(b, "p75", 2), getF(b, "p90", 4),
					getF(b, "idle", 0.2f)));
		}
	}

	// ===== Использование =====

	/**
	 * Шаг доворота по yaw для текущей ошибки — как это делает игрок.
	 *
	 * Берём медиану из подходящего бина и добавляем разброс до p75.
	 * Копировать медиану дословно нельзя: идеально повторяемая скорость
	 * сама по себе сигнатура. Поэтому каждый тик значение случайно
	 * гуляет между медианой и p75.
	 */
	public float yawStep(float absErr) {
		return step(yawCurve, absErr, yawCap, 3.0f);
	}

	public float pitchStep(float absErr) {
		return step(pitchCurve, absErr, pitchCap, 2.0f);
	}

	private float step(List<Bin> curve, float absErr, float cap, float fallback) {
		if (curve.isEmpty()) {
			return Math.min(absErr * 0.25f, cap);
		}
		Bin bin = curve.get(curve.size() - 1);
		for (Bin b : curve) {
			if (absErr >= b.lo() && absErr < b.hi()) {
				bin = b;
				break;
			}
		}
		// Разброс ЦЕНТРИРУЕМ вокруг медианы, а не тянем вверх к p75.
		//
		// Если брать «медиана + случайное до p75», среднее получается
		// в полтора раза выше медианы игрока — аура доворачивает быстрее
		// оригинала, и весь смысл профиля теряется. Поэтому гуляем в обе
		// стороны на половину расстояния до p75: среднее совпадает с
		// медианой, но одинаковых значений не бывает.
		float base = bin.median();
		float spread = Math.max(0.0f, bin.p75() - bin.median()) * 0.5f;
		float v = base + (float) (rand.nextDouble() * 2.0 - 1.0) * spread;
		if (v < 0.05f) {
			v = 0.05f;
		}
		// Не перепрыгиваем цель и не превышаем человеческий потолок
		return Math.min(Math.min(v, absErr), cap);
	}

	/**
	 * Нужно ли «замереть» в этом тике.
	 * У живого игрока около четверти тиков мышь фактически стоит.
	 */
	public boolean shouldPause() {
		return rand.nextFloat() < pauseChance;
	}

	/** Сколько тиков держать паузу. */
	public int pauseTicks() {
		return 1 + rand.nextInt(Math.max(1, pauseRunP90));
	}

	/**
	 * Допустимая ошибка прицела для удара.
	 *
	 * Игрок не целится в математический центр: медиана его ошибки при
	 * ударе — около 11°. Требовать от ауры идеального наведения значит
	 * выдать её с головой, поэтому бьём, попадая в тот же коридор.
	 */
	public float swingTolerance() {
		return swingErrMedian + (float) rand.nextDouble() * (swingErrP75 - swingErrMedian);
	}

	public float preferredDistance() {
		return swingDistMedian;
	}

	/** Медианная ошибка прицела по yaw в момент удара, градусы. */
	public float aimErrorYaw() {
		return swingErrYawMedian;
	}

	/** Медианная ошибка прицела по pitch в момент удара, градусы. */
	public float aimErrorPitch() {
		return swingErrPitchMedian;
	}

	public float maxDistance() {
		return swingDistP90;
	}

	/**
	 * С какого кулдауна бить в ЭТОТ раз.
	 *
	 * Возвращает не константу, а случайное значение между p25 профиля и
	 * полным замахом. Фиксированный порог давал бы идеально ровные
	 * интервалы между ударами, а именно по их дисперсии и вычисляют
	 * автокликер. У живого игрока (по вашим записям) разброс интервалов
	 * около 11.6 тика при медиане 12 — то есть ритм заметно «плавает».
	 */
	public float cooldownThreshold() {
		float lo = Math.min(swingCooldownP25, 1.0f);
		return lo + (float) rand.nextDouble() * (1.0f - lo);
	}

	/**
	 * Шанс промахнуться намеренно, в процентах.
	 *
	 * По записям боя часть замахов уходит в молоко. Аура, попадающая
	 * всегда, выглядит неестественно точной — этот процент возвращает
	 * ей человеческую долю промахов.
	 */
	public double missChancePercent() {
		return missChance;
	}

	public float yawCap() {
		return yawCap;
	}
}
