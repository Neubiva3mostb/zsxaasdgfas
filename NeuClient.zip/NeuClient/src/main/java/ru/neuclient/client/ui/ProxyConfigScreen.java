package ru.neuclient.client.ui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import ru.neuclient.client.config.ProxyConfig;
import ru.neuclient.client.config.ProxyHandler;
import ru.neuclient.client.font.MsdfFontRenderer;
import ru.neuclient.client.font.MsdfFonts;
import ru.neuclient.client.util.RenderUtil;

/**
 * Экран настройки SOCKS5-прокси с нативным MSDF-шрифтом.
 */
public class ProxyConfigScreen extends Screen {

	private final Screen parent;

	private TextFieldWidget ipField;
	private TextFieldWidget portField;
	private TextFieldWidget loginField;
	private TextFieldWidget passwordField;
	private ButtonWidget enabledButton;

	private ProxyConfig config;

	public ProxyConfigScreen(Screen parent) {
		super(Text.literal("SOCKS5 Proxy"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		super.init();

		config = ProxyHandler.getConfig();

		int centerX = this.width / 2;
		int y = this.height / 2 - 95;

		this.ipField = new TextFieldWidget(this.textRenderer, centerX - 100, y + 30, 200, 20, Text.literal("IP"));
		this.ipField.setMaxLength(45);
		this.ipField.setText(config.proxyIp());
		this.ipField.setPlaceholder(Text.literal("192.168.1.1"));
		this.addSelectableChild(this.ipField);

		this.portField = new TextFieldWidget(this.textRenderer, centerX - 100, y + 70, 200, 20, Text.literal("Port"));
		this.portField.setMaxLength(5);
		this.portField.setText(String.valueOf(config.proxyPort()));
		this.portField.setPlaceholder(Text.literal("1080"));
		this.addSelectableChild(this.portField);

		this.loginField = new TextFieldWidget(this.textRenderer, centerX - 100, y + 110, 200, 20, Text.literal("Login"));
		this.loginField.setMaxLength(64);
		this.loginField.setText(config.proxyLogin());
		this.loginField.setPlaceholder(Text.literal("Логин (необязательно)"));
		this.addSelectableChild(this.loginField);

		this.passwordField = new TextFieldWidget(this.textRenderer, centerX - 100, y + 150, 200, 20, Text.literal("Password"));
		this.passwordField.setMaxLength(64);
		this.passwordField.setText(config.proxyPassword());
		this.passwordField.setPlaceholder(Text.literal("Пароль (необязательно)"));
		this.addSelectableChild(this.passwordField);

		this.enabledButton = ButtonWidget.builder(
				Text.literal("Proxy: " + (config.enabled() ? "§aON" : "§cOFF")),
				button -> {
					config = new ProxyConfig(
							ipField.getText().trim(),
							parsePort(portField.getText()),
							loginField.getText().trim(),
							passwordField.getText().trim(),
							!config.enabled()
					);
					button.setMessage(Text.literal("Proxy: " + (config.enabled() ? "§aON" : "§cOFF")));
				}
		).dimensions(centerX - 100, y + 185, 200, 20).build();
		this.addDrawableChild(this.enabledButton);

		this.addDrawableChild(ButtonWidget.builder(Text.literal("§aСохранить"), button -> {
			saveAndClose();
		}).dimensions(centerX - 100, y + 215, 95, 20).build());

		this.addDrawableChild(ButtonWidget.builder(Text.literal("§cОтмена"), button -> {
			MinecraftClient.getInstance().setScreen(parent);
		}).dimensions(centerX + 5, y + 215, 95, 20).build());
	}

	private int parsePort(String text) {
		try {
			return Integer.parseInt(text.trim());
		} catch (NumberFormatException e) {
			return 1080;
		}
	}

	private void saveAndClose() {
		String ip = ipField.getText().trim();
		int port = parsePort(portField.getText());
		String login = loginField.getText().trim();
		String password = passwordField.getText().trim();

		ProxyConfig newConfig = new ProxyConfig(ip, port, login, password, config.enabled());
		ProxyHandler.setConfig(newConfig);
		MinecraftClient.getInstance().setScreen(parent);
	}

	@Override
	public void close() {
		MinecraftClient.getInstance().setScreen(parent);
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		super.render(context, mouseX, mouseY, delta);

		int centerX = this.width / 2;
		int y = this.height / 2 - 95;

		RenderUtil.drawWaveTextCentered(context, "SOCKS5 PROXY SETTINGS", centerX, y - 24);

		if (ProxyHandler.isActive()) {
			MsdfFontRenderer.drawCenteredWithShadow(context, MsdfFonts.sfMedium(),
					"Прокси активен: " + config.proxyIp() + ":" + config.proxyPort(),
					centerX, y - 8, 0xFF55FF55, 9.0f);
		} else {
			MsdfFontRenderer.drawCenteredWithShadow(context, MsdfFonts.sfRegular(),
					"Прокси выключен", centerX, y - 8, 0xFFAAAAAA, 9.0f);
		}

		MsdfFontRenderer.drawWithShadow(context, MsdfFonts.sfRegular(), "IP адрес:", centerX - 100, y + 30 - 11, 0xFFAAAAAA, 9.0f);
		this.ipField.render(context, mouseX, mouseY, delta);

		MsdfFontRenderer.drawWithShadow(context, MsdfFonts.sfRegular(), "Порт:", centerX - 100, y + 70 - 11, 0xFFAAAAAA, 9.0f);
		this.portField.render(context, mouseX, mouseY, delta);

		MsdfFontRenderer.drawWithShadow(context, MsdfFonts.sfRegular(), "Логин:", centerX - 100, y + 110 - 11, 0xFFAAAAAA, 9.0f);
		this.loginField.render(context, mouseX, mouseY, delta);

		MsdfFontRenderer.drawWithShadow(context, MsdfFonts.sfRegular(), "Пароль:", centerX - 100, y + 150 - 11, 0xFFAAAAAA, 9.0f);
		this.passwordField.render(context, mouseX, mouseY, delta);
	}
}
