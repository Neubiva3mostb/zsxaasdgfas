package ru.neuclient.client.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.screen.slot.Slot;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.ModuleManager;
import ru.neuclient.client.module.impl.misc.ItemScrollerModule;
import ru.neuclient.client.module.impl.misc.AuctionHelperFT;
import ru.neuclient.client.util.InventoryResetHelper;
import ru.neuclient.client.util.StorageActions;

/**
 * Отдаёт ItemScroller'у слот под курсором на каждом кадре открытого
 * контейнера (render — частота кадров, плавнее тика при «проведении» мышью).
 * Никакой логики ванили не задевает: обычные шифт-клики работают как раньше.
 */
@Mixin(HandledScreen.class)
public abstract class HandledScreenMixin {

	@Shadow
	protected Slot focusedSlot;

	@Shadow
	protected int x;

	@Shadow
	protected int y;

	@Shadow
	protected int backgroundHeight;

	@Inject(method = "render", at = @At("TAIL"))
	private void pc$itemScrollerHover(DrawContext context, int mouseX, int mouseY, float delta,
			CallbackInfo ci) {
		try {
			NeuClient client = NeuClient.getInstance();
			if (client == null || client.isPanicked()) {
				return;
			}
			ModuleManager modules = client.getModuleManager();
			if (modules == null) {
				return;
			}
			
			// ItemScroller
			ItemScrollerModule scroller = modules.get(ItemScrollerModule.class);
			if (scroller != null && scroller.isEnabled()) {
				scroller.onSlotHover((HandledScreen<?>) (Object) this, focusedSlot);
			}

			// AuctionHelperFT - отрисовка подсветки поверх слотов аукциона
			AuctionHelperFT auctionHelper = modules.get(AuctionHelperFT.class);
			if (auctionHelper != null && auctionHelper.isEnabled()) {
				auctionHelper.renderSlotHighlights(context, this.x, this.y);
			}

			StorageActions.renderButtons(context, (HandledScreen<?>) (Object) this,
					this.y, this.backgroundHeight, mouseX, mouseY);

			// InventoryScreen переопределяет render(), поэтому сама кнопка
			// рисуется отдельным InventoryScreenMixin.

		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка в хуке контейнера", t);
		}
	}
	@Inject(method = "mouseClicked", at = @At("HEAD"), cancellable = true)
	private void pc$storageButtonClick(Click click, boolean doubled,
			CallbackInfoReturnable<Boolean> cir) {
		try {
			NeuClient client = NeuClient.getInstance();
			if (client == null || client.isPanicked()) {
				return;
			}
			if (StorageActions.handleButtonClick((HandledScreen<?>) (Object) this,
					click.x(), click.y(), click.button(), this.y, this.backgroundHeight)) {
				cir.setReturnValue(true);
			}
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка кнопки хранилища", t);
		}
	}

	@Inject(method = "mouseClicked", at = @At("HEAD"), cancellable = true)
	private void pc$inventoryResetClick(Click click, boolean doubled,
			CallbackInfoReturnable<Boolean> cir) {
		try {
			if (!((Object) this instanceof InventoryScreen)) {
				return;
			}
			NeuClient client = NeuClient.getInstance();
			if (client == null || client.isPanicked() || click.button() != 0) {
				return;
			}
			int buttonX = MinecraftClient.getInstance().getWindow().getScaledWidth() / 2 - 40;
			int buttonY = MinecraftClient.getInstance().getWindow().getScaledHeight() / 2 - 110;
			if (click.x() >= buttonX && click.x() < buttonX + 80
					&& click.y() >= buttonY && click.y() < buttonY + 20) {
				InventoryResetHelper.start(MinecraftClient.getInstance());
				cir.setReturnValue(true);
			}
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка кнопки сброса инвентаря", t);
		}
	}

}