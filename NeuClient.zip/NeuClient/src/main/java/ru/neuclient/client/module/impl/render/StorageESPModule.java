package ru.neuclient.client.module.impl.render;

import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.WorldChunk;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.render.WorldRenderUtil;
import ru.neuclient.client.setting.BooleanSetting;
import ru.neuclient.client.setting.NumberSetting;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * StorageESP — контур хранилищ (сундуки, шалкеры, бочки, эндер-сундуки,
 * воронки, печи, раздатчики) сквозь стены.
 *
 * Честная механика, ровно как у XRay: ни одного пакета на сервер не уходит.
 * Модуль просматривает УЖЕ полученные от сервера чанки и берёт из них
 * готовый список блок-сущностей (chunk.getBlockEntities()) — это тот самый
 * список, по которому клиент и так рендерит крышки сундуков. Значит скан
 * почти бесплатный: никакого перебора 16×16×384 блоков, как в XRay.
 *
 * Нагрузка: один чанк за тик по кругу (ближние первыми), выгруженные чанки
 * зачищаются раз в секунду. Фильтры по типам применяются на РЕНДЕРЕ, поэтому
 * галки срабатывают мгновенно, без пересканирования.
 */
public final class StorageESPModule extends Module {

	/** Сколько тиков между чистками выгруженных чанков. */
	private static final int PURGE_PERIOD = 20;
	/** Толщина и прозрачность контура. */
	private static final float LINE_WIDTH = 1.5f;
	private static final float LINE_ALPHA = 0.9f;

	// ===== Настройки =====

	/** Радиус сканирования в чанках (2 = 5×5 чанков ≈ 40 блоков). */
	private final NumberSetting radius = new NumberSetting("Радиус (чанки)", 3, 1, 8, 1);
	/** Видеть контур сквозь блоки. */
	private final BooleanSetting throughWalls = new BooleanSetting("Сквозь стены", true);

	private final BooleanSetting chests = new BooleanSetting("Сундуки", true);
	private final BooleanSetting shulkers = new BooleanSetting("Шалкеры", true);
	private final BooleanSetting barrels = new BooleanSetting("Бочки", true);
	private final BooleanSetting enderChests = new BooleanSetting("Эндер-сундуки", true);
	private final BooleanSetting hoppers = new BooleanSetting("Воронки", false);
	private final BooleanSetting furnaces = new BooleanSetting("Печи", false);
	private final BooleanSetting dispensers = new BooleanSetting("Раздатчики", false);

	/** Типы хранилищ и их цвета контура. */
	private enum StorageType {
		CHEST(0xFFFFB03A),
		SHULKER(0xFFC060FF),
		BARREL(0xFFC98A4B),
		ENDER_CHEST(0xFF2ED8C3),
		HOPPER(0xFF9AA0A6),
		FURNACE(0xFFE05656),
		DISPENSER(0xFF7FA8FF);

		final int color;

		StorageType(int color) {
			this.color = color;
		}
	}

	/** Одно найденное хранилище (целые координаты блока). */
	private record FoundStorage(int x, int y, int z, StorageType type) {
	}

	/** Найденное: ключ чанка (ChunkPos.toLong) → список хранилищ. */
	private final Map<Long, List<FoundStorage>> found = new HashMap<>();

	/** Круговая очередь чанков на сканирование (ближние первыми). */
	private final List<ChunkPos> queue = new ArrayList<>();
	/** Центр, от которого собрана очередь. */
	private ChunkPos queueCenter;
	/** Радиус, на котором собрана очередь (меняется настройкой). */
	private int queueRadius = -1;
	/** Индекс текущего чанка в очереди. */
	private int cursor;
	/** Счётчик тиков до чистки выгруженных чанков. */
	private int purgeCounter;

	public StorageESPModule() {
		super("StorageESP", "Подсвечивает хранилища сквозь блоки", Category.RENDER);
		addSettings(radius, throughWalls, chests, shulkers, barrels, enderChests, hoppers, furnaces, dispensers);
	}

	@Override
	protected void onDisable() {
		found.clear();
		queue.clear();
		queueCenter = null;
		queueRadius = -1;
	}

	// ===== Сканер (тик) =====

	@Override
	public void onTick(MinecraftClient client) {
		ClientWorld world = client.world;
		ClientPlayerEntity player = client.player;
		if (world == null || player == null) {
			found.clear();
			queue.clear();
			queueCenter = null;
			queueRadius = -1;
			return;
		}

		// Чистка выгруженных чанков — иначе контуры «замерзнут» на месте ушедших чанков
		if (++purgeCounter >= PURGE_PERIOD) {
			purgeCounter = 0;
			purgeUnloaded(world);
		}

		// Пересобираем очередь при переходе в другой чанк или смене радиуса
		ChunkPos center = player.getChunkPos();
		int r = radius.get().intValue();
		if (queue.isEmpty() || !center.equals(queueCenter) || r != queueRadius) {
			rebuildQueue(center, r);
		}
		if (queue.isEmpty()) {
			return;
		}

		// Один чанк за тик, по кругу
		if (cursor >= queue.size()) {
			cursor = 0;
		}
		ChunkPos pos = queue.get(cursor++);
		long key = pos.toLong();
		List<FoundStorage> list = scanChunk(world, pos.x, pos.z);
		if (list == null || list.isEmpty()) {
			found.remove(key);
		} else {
			found.put(key, list);
		}
	}

	/** Очередь: все чанки радиуса, ближние к игроку — первыми. */
	private void rebuildQueue(ChunkPos center, int r) {
		queue.clear();
		for (int dx = -r; dx <= r; dx++) {
			for (int dz = -r; dz <= r; dz++) {
				queue.add(new ChunkPos(center.x + dx, center.z + dz));
			}
		}
		queue.sort(Comparator.comparingInt(p ->
				(p.x - center.x) * (p.x - center.x) + (p.z - center.z) * (p.z - center.z)));
		queueCenter = center;
		queueRadius = r;
		cursor = 0;
	}

	/** Выкидываем результаты чанков, которых больше нет в памяти клиента. */
	private void purgeUnloaded(ClientWorld world) {
		Iterator<Long> it = found.keySet().iterator();
		while (it.hasNext()) {
			long key = it.next();
			// Упаковка ChunkPos.toLong: x — младшие 32 бита, z — старшие
			int cx = (int) key;
			int cz = (int) (key >> 32);
			if (!world.isChunkLoaded(cx, cz)) {
				it.remove();
			}
		}
	}

	/** Проход одного чанка по его блок-сущностям. null — чанк не загружен. */
	private List<FoundStorage> scanChunk(ClientWorld world, int cx, int cz) {
		if (!world.isChunkLoaded(cx, cz)) {
			return null;
		}
		WorldChunk chunk = world.getChunk(cx, cz);
		if (chunk == null) {
			return null;
		}
		Map<BlockPos, BlockEntity> entities = chunk.getBlockEntities();
		if (entities.isEmpty()) {
			return null;
		}
		List<FoundStorage> list = null;
		for (Map.Entry<BlockPos, BlockEntity> entry : entities.entrySet()) {
			BlockEntity be = entry.getValue();
			if (be == null) {
				continue;
			}
			StorageType type = typeOf(be.getType());
			if (type == null) {
				continue;
			}
			BlockPos pos = entry.getKey();
			if (list == null) {
				list = new ArrayList<>();
			}
			list.add(new FoundStorage(pos.getX(), pos.getY(), pos.getZ(), type));
		}
		return list;
	}

	/** Тип хранилища по типу блок-сущности. null — не хранилище. */
	private static StorageType typeOf(BlockEntityType<?> type) {
		if (type == BlockEntityType.CHEST || type == BlockEntityType.TRAPPED_CHEST) {
			return StorageType.CHEST;
		}
		if (type == BlockEntityType.SHULKER_BOX) {
			return StorageType.SHULKER;
		}
		if (type == BlockEntityType.BARREL) {
			return StorageType.BARREL;
		}
		if (type == BlockEntityType.ENDER_CHEST) {
			return StorageType.ENDER_CHEST;
		}
		if (type == BlockEntityType.HOPPER) {
			return StorageType.HOPPER;
		}
		if (type == BlockEntityType.FURNACE || type == BlockEntityType.SMOKER
				|| type == BlockEntityType.BLAST_FURNACE) {
			return StorageType.FURNACE;
		}
		if (type == BlockEntityType.DISPENSER || type == BlockEntityType.DROPPER) {
			return StorageType.DISPENSER;
		}
		return null;
	}

	/** Включена ли галка типа (фильтр — на рендере, переключение мгновенное). */
	private boolean enabled(StorageType type) {
		return switch (type) {
			case CHEST -> chests.get();
			case SHULKER -> shulkers.get();
			case BARREL -> barrels.get();
			case ENDER_CHEST -> enderChests.get();
			case HOPPER -> hoppers.get();
			case FURNACE -> furnaces.get();
			case DISPENSER -> dispensers.get();
		};
	}

	// ===== Рендер контура (AFTER_ENTITIES, из NeuClient) =====

	private void renderWorld(WorldRenderContext context, MinecraftClient client) {
		if (found.isEmpty() || context.commandQueue() == null) {
			return;
		}

		Vec3d cam = client.gameRenderer.getCamera().getCameraPos();
		MatrixStack matrices = context.matrices();
		RenderLayer layer = throughWalls.get() ? WorldRenderUtil.LINES_NO_DEPTH : WorldRenderUtil.LINES_DEPTH;

		matrices.push();
		matrices.translate(-cam.x, -cam.y, -cam.z);
		context.commandQueue().submitCustom(matrices, layer, (entry, buffer) -> {
			for (List<FoundStorage> list : found.values()) {
				for (FoundStorage s : list) {
					if (!enabled(s.type())) {
						continue;
					}
					float r = ((s.type().color >> 16) & 0xFF) / 255.0f;
					float g = ((s.type().color >> 8) & 0xFF) / 255.0f;
					float b = (s.type().color & 0xFF) / 255.0f;
					outline(entry, buffer, s.x(), s.y(), s.z(),
							s.x() + 1.0, s.y() + 1.0, s.z() + 1.0, r, g, b);
				}
			}
		});
		matrices.pop();
	}

	/** 12 рёбер куба линиями. */
	private static void outline(MatrixStack.Entry entry, VertexConsumer buffer,
			double x0, double y0, double z0, double x1, double y1, double z1,
			float r, float g, float b) {
		// Рёбра вдоль X
		WorldRenderUtil.line(buffer, entry, x0, y0, z0, x1, y0, z0, r, g, b, LINE_ALPHA, LINE_WIDTH);
		WorldRenderUtil.line(buffer, entry, x0, y1, z0, x1, y1, z0, r, g, b, LINE_ALPHA, LINE_WIDTH);
		WorldRenderUtil.line(buffer, entry, x0, y0, z1, x1, y0, z1, r, g, b, LINE_ALPHA, LINE_WIDTH);
		WorldRenderUtil.line(buffer, entry, x0, y1, z1, x1, y1, z1, r, g, b, LINE_ALPHA, LINE_WIDTH);
		// Рёбра вдоль Y
		WorldRenderUtil.line(buffer, entry, x0, y0, z0, x0, y1, z0, r, g, b, LINE_ALPHA, LINE_WIDTH);
		WorldRenderUtil.line(buffer, entry, x1, y0, z0, x1, y1, z0, r, g, b, LINE_ALPHA, LINE_WIDTH);
		WorldRenderUtil.line(buffer, entry, x0, y0, z1, x0, y1, z1, r, g, b, LINE_ALPHA, LINE_WIDTH);
		WorldRenderUtil.line(buffer, entry, x1, y0, z1, x1, y1, z1, r, g, b, LINE_ALPHA, LINE_WIDTH);
		// Рёбра вдоль Z
		WorldRenderUtil.line(buffer, entry, x0, y0, z0, x0, y0, z1, r, g, b, LINE_ALPHA, LINE_WIDTH);
		WorldRenderUtil.line(buffer, entry, x1, y0, z0, x1, y0, z1, r, g, b, LINE_ALPHA, LINE_WIDTH);
		WorldRenderUtil.line(buffer, entry, x0, y1, z0, x0, y1, z1, r, g, b, LINE_ALPHA, LINE_WIDTH);
		WorldRenderUtil.line(buffer, entry, x1, y1, z0, x1, y1, z1, r, g, b, LINE_ALPHA, LINE_WIDTH);
	}

	// ===== Диспетчер (из NeuClient) =====

	public static void renderAllWorld(WorldRenderContext context) {
		NeuClient client = NeuClient.getInstance();
		if (client == null || client.getModuleManager() == null) {
			return;
		}
		StorageESPModule self = client.getModuleManager().get(StorageESPModule.class);
		if (self != null && self.isEnabled()) {
			self.renderWorld(context, MinecraftClient.getInstance());
		}
	}
}
