package ru.neuclient.client.render;

import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.render.LayeringTransform;
import net.minecraft.client.render.OutputTarget;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderSetup;
import net.minecraft.client.render.VertexConsumer;
import org.joml.Matrix4f;
import ru.neuclient.client.mixin.RenderLayerAccessor;
import ru.neuclient.client.mixin.RenderPipelinesAccessor;

/**
 * Общие рендер-слои и примитивы для мировых визуалов NeuClient
 * (ChinaHat, Jump Circles, Trails, Particles).
 *
 * Слои собираются через RenderLayerAccessor.of() — accessor-миксин,
 * потому что в 1.21.11 RenderLayer.of() стал package-private.
 *
 * Все методы принимают координаты УЖЕ относительно камеры (то есть стек
 * матриц заранее сдвинут на -camera): так делает ванильный рендер мира.
 */
public final class WorldRenderUtil {

	/** Линии сквозь стены (трейлы, круги, контур шляпы). */
	public static final RenderLayer LINES_NO_DEPTH = RenderLayerAccessor.pc$of("neuclient_lines_nodepth",
			RenderSetup.builder(RenderPipeline.builder(new RenderPipeline.Snippet[]{RenderPipelinesAccessor.pc$getLinesSnippet()})
							.withLocation("neuclient/lines_nodepth")
							.withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
							.build())
					.layeringTransform(LayeringTransform.VIEW_OFFSET_Z_LAYERING)
					.outputTarget(OutputTarget.ITEM_ENTITY_TARGET)
					.build());

	/** Линии с обычной глубиной (прячутся за блоками — «честный» вид). */
	public static final RenderLayer LINES_DEPTH = RenderLayerAccessor.pc$of("neuclient_lines_depth",
			RenderSetup.builder(RenderPipeline.builder(new RenderPipeline.Snippet[]{RenderPipelinesAccessor.pc$getLinesSnippet()})
							.withLocation("neuclient/lines_depth")
							.build())
					.layeringTransform(LayeringTransform.VIEW_OFFSET_Z_LAYERING)
					.outputTarget(OutputTarget.ITEM_ENTITY_TARGET)
					.build());

	/**
	 * Залитые четырёхугольники (конус шляпы, частицы).
	 */
	public static final RenderLayer QUADS = RenderLayerAccessor.pc$of("neuclient_quads",
			RenderSetup.builder(RenderPipelines.DEBUG_QUADS)
					.layeringTransform(LayeringTransform.VIEW_OFFSET_Z_LAYERING)
					.outputTarget(OutputTarget.ITEM_ENTITY_TARGET)
					.build());

	private WorldRenderUtil() {
	}

	/** Отрезок линии заданной толщины (координаты относительно камеры). */
	public static void line(VertexConsumer buffer, net.minecraft.client.util.math.MatrixStack.Entry entry,
			double x1, double y1, double z1, double x2, double y2, double z2,
			float r, float g, float b, float a, float width) {
		double dx = x2 - x1;
		double dy = y2 - y1;
		double dz = z2 - z1;
		double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
		if (len < 1.0E-6) {
			return;
		}
		float nx = (float) (dx / len);
		float ny = (float) (dy / len);
		float nz = (float) (dz / len);
		buffer.vertex(entry, (float) x1, (float) y1, (float) z1)
				.color(r, g, b, a).normal(entry, nx, ny, nz).lineWidth(width);
		buffer.vertex(entry, (float) x2, (float) y2, (float) z2)
				.color(r, g, b, a).normal(entry, nx, ny, nz).lineWidth(width);
	}

	/** Горизонтальная окружность из отрезков (для Jump Circles). */
	public static void circle(VertexConsumer buffer, net.minecraft.client.util.math.MatrixStack.Entry entry,
			double cx, double cy, double cz, double radius, int segments,
			float r, float g, float b, float a, float width) {
		double step = Math.PI * 2.0 / segments;
		for (int i = 0; i < segments; i++) {
			double a1 = i * step;
			double a2 = (i + 1) * step;
			line(buffer, entry,
					cx + Math.cos(a1) * radius, cy, cz + Math.sin(a1) * radius,
					cx + Math.cos(a2) * radius, cy, cz + Math.sin(a2) * radius,
					r, g, b, a, width);
		}
	}

	/** Четырёхугольник (порядок вершин — по контуру). */
	public static void quad(VertexConsumer buffer, Matrix4f m,
			double x1, double y1, double z1, double x2, double y2, double z2,
			double x3, double y3, double z3, double x4, double y4, double z4,
			float r, float g, float b, float a) {
		buffer.vertex(m, (float) x1, (float) y1, (float) z1).color(r, g, b, a);
		buffer.vertex(m, (float) x2, (float) y2, (float) z2).color(r, g, b, a);
		buffer.vertex(m, (float) x3, (float) y3, (float) z3).color(r, g, b, a);
		buffer.vertex(m, (float) x4, (float) y4, (float) z4).color(r, g, b, a);
	}

	/** Четырёхугольник с отдельной альфой на каждую вершину (градиентный шлейф). */
	public static void quadGradient(VertexConsumer buffer, Matrix4f m,
			double x1, double y1, double z1, float a1,
			double x2, double y2, double z2, float a2,
			double x3, double y3, double z3, float a3,
			double x4, double y4, double z4, float a4,
			float r, float g, float b) {
		buffer.vertex(m, (float) x1, (float) y1, (float) z1).color(r, g, b, a1);
		buffer.vertex(m, (float) x2, (float) y2, (float) z2).color(r, g, b, a2);
		buffer.vertex(m, (float) x3, (float) y3, (float) z3).color(r, g, b, a3);
		buffer.vertex(m, (float) x4, (float) y4, (float) z4).color(r, g, b, a4);
	}

	/**
	 * Треугольник, поданный как вырожденный четырёхугольник
	 * (последняя вершина дублируется) — пайплайн ждёт QUADS.
	 */
	public static void triangle(VertexConsumer buffer, Matrix4f m,
			double x1, double y1, double z1, double x2, double y2, double z2,
			double x3, double y3, double z3,
			float r, float g, float b, float a) {
		quad(buffer, m, x1, y1, z1, x2, y2, z2, x3, y3, z3, x3, y3, z3, r, g, b, a);
	}

	/** Красный канал ARGB-цвета в 0..1. */
	public static float red(int argb) {
		return ((argb >> 16) & 0xFF) / 255.0f;
	}

	public static float green(int argb) {
		return ((argb >> 8) & 0xFF) / 255.0f;
	}

	public static float blue(int argb) {
		return (argb & 0xFF) / 255.0f;
	}
}
