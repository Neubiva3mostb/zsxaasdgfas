package ru.neuclient.client.remote;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyFactory;
import java.security.MessageDigest;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.X509EncodedKeySpec;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.module.ModuleManager;

/**
 * RemoteModuleLoader - загрузчик байткода модулей с сайта.
 *
 * КАК РАБОТАЕТ.
 *  1) GET /api/modules/manifest с заголовком X-NEU-Ticket (launch-тикет
 *     от лаунчера, тот же, что проверяет LaunchGuard). Сервер отдаёт
 *     манифест ТОЛЬКО при активной подписке и отсутствии бана.
 *  2) Проверяем Ed25519-подпись манифеста встроенным публичным ключом
 *     (MODULE_PUB_KEY). Подделать версию/хэш/ключ через MITM нельзя.
 *  3) Проверяем uid: манифест персонифицирован, пак другого юзера
 *     отбрасывается сразу.
 *  4) Если хэш совпадает с кэшем - работаем из кэша (и офлайн тоже).
 *     Иначе GET /api/modules/pack: контейнер
 *     [magic "NEUPACK1"][ver LE4][nonce 12][AES-256-GCM(jar)+tag],
 *     ключ - персональный из манифеста, AAD - "NEUPACK1|version|uid".
 *  5) Расшифровали -> сверили SHA-256 -> загрузили классы через
 *     {@link RemoteModuleClassLoader} -> все классы-наследники Module
 *     с публичным конструктором без аргументов регистрируются в
 *     ModuleManager как обычные модули (конфиг хранит их по имени).
 *
 * ОТКАЗЫ (мягкие - клиент всегда запускается):
 *  - сайт недоступен и есть кэш -> модули из кэша;
 *  - кэша нет и сайт недоступен -> клиент без удалённых модулей;
 *  - подпись/хэш/uid не сошлись -> кэш НЕ используется, модулей нет
 *    (испорченный кэш удаляется).
 */
public final class RemoteModuleLoader {

    /** База API (можно переопределить для тестов через NEU_API_URL). */
    private static String base() {
        String env = System.getenv("NEU_API_URL");
        return env != null && !env.isEmpty() ? env : "https://neuclient.ru";
    }

    /*
     * ПУБЛИЧНЫЙ КЛЮЧ ПОДПИСИ - скопируй из админки:
     * Админ-панель -> Байткод -> «Публичный ключ подписи» -> Копировать.
     * ВАЖНО: ключ обязан совпадать с серверным, иначе ни один пак не пройдёт
     * проверку подписи.
     */
    private static final String MODULE_PUB_KEY =
            "MCowBQYDK2VwAyEAUe3AUDKs6D8cmcQ/3lQLph+7IIQmeUBX3YJA3ZYVNkg=";

    private static final String MANIFEST_CACHE = "manifest.json";
    private static final String PACK_CACHE = "modules.pack";

    private RemoteModuleLoader() {}

    /** Точка входа: вызывается в конце конструктора ModuleManager. */
    public static void loadAndRegister(ModuleManager manager) {
        try {
            List<Module> remote = fetchAndLoad();
            for (Module m : remote) {
                manager.registerRemote(m);
            }
            log("загружено удалённых модулей: " + remote.size());
        } catch (Throwable t) {
            log("не удалось загрузить пак модулей: " + t.getClass().getSimpleName()
                    + (t.getMessage() != null ? ": " + t.getMessage() : ""));
        }
    }

    // ============================ основная логика ============================

    private static List<Module> fetchAndLoad() throws Exception {
        Path dir = FabricLoader.getInstance().getGameDir().resolve("neu_modules");
        Files.createDirectories(dir);
        Path manifestFile = dir.resolve(MANIFEST_CACHE);
        Path packFile = dir.resolve(PACK_CACHE);

        String ticket = System.getProperty("neu.launcher.ticket", "");
        if (ticket.isEmpty()) {
            // LaunchGuard уже отработал; без тикета онлайн-пути нет - кэш.
            return loadCached(manifestFile, packFile, null);
        }

        JsonObject manifest;
        try {
            String body = httpGet(base() + "/api/modules/manifest", ticket);
            manifest = JsonParser.parseString(body).getAsJsonObject();
            if (manifest.has("error")) {
                // banned / noSubscription - кэш не используем (доступ закрыт)
                log("сервер отказал: " + manifest.get("error").getAsString());
                return List.of();
            }
            if (!manifest.get("available").getAsBoolean()) {
                log("активного пака на сервере нет");
                return List.of();
            }
            verifyManifest(manifest);
        } catch (IOException net) {
            // Сайт недоступен (в т.ч. таймаут - HttpTimeoutException его
            // наследник) -> разрешённый офлайн-режим: работаем из кэша
            return loadCached(manifestFile, packFile, null);
        }

        String sha = manifest.get("sha256").getAsString();
        String key = manifest.get("key").getAsString();
        int version = manifest.get("version").getAsInt();

        byte[] jar = null;
        if (Files.exists(packFile) && Files.exists(manifestFile)) {
            JsonObject cachedManifest = JsonParser.parseString(
                    Files.readString(manifestFile, StandardCharsets.UTF_8)).getAsJsonObject();
            if (sha.equals(cachedManifest.get("sha256").getAsString())
                    && key.equals(cachedManifest.get("key").getAsString())) {
                jar = Files.readAllBytes(packFile);
                if (!sha256hex(jar).equals(sha)) {
                    jar = null; // кэш повреждён
                }
            }
        }

        if (jar == null) {
            byte[] container = httpGetBytes(base() + "/api/modules/pack", ticket);
            jar = decryptContainer(container, version, manifest.get("uid").getAsString(), key);
            if (!sha256hex(jar).equals(sha)) {
                throw new IllegalStateException("sha256 mismatch after decrypt");
            }
            // Кэш сохраняем ТОЛЬКО проверенный (вместе с манифестом)
            Files.write(packFile, jar);
            Files.writeString(manifestFile,
                    manifest.toString(), StandardCharsets.UTF_8);
        }

        return instantiateModules(jar);
    }

    /** Офлайн: модули из кэша, но манифест кэша тоже проверяем подписью. */
    private static List<Module> loadCached(Path manifestFile, Path packFile, Void unused) {
        try {
            if (!Files.exists(manifestFile) || !Files.exists(packFile)) {
                return List.of();
            }
            JsonObject m = JsonParser.parseString(
                    Files.readString(manifestFile, StandardCharsets.UTF_8)).getAsJsonObject();
            verifyManifest(m); // подпись + uid (бросит - значит кэш битый)
            byte[] jar = Files.readAllBytes(packFile);
            if (!sha256hex(jar).equals(m.get("sha256").getAsString())) {
                return List.of();
            }
            return instantiateModules(jar);
        } catch (Throwable t) {
            log("офлайн-кэш не прошёл проверку: " + t.getClass().getSimpleName());
            return List.of();
        }
    }

    // ============================ проверка манифеста ============================

    private static void verifyManifest(JsonObject m) throws Exception {
        // 1) uid обязан совпадать с нашим (манифест персональный)
        String ownUid = System.getenv("NEU_UID");
        String manifestUid = m.get("uid").getAsString();
        if (ownUid != null && !ownUid.isEmpty() && !ownUid.equals(manifestUid)) {
            throw new IllegalStateException("manifest uid mismatch");
        }

        // 2) Ed25519-подпись публичным ключом клиента
        String msg = "v1|" + m.get("version").getAsInt()
                + "|" + m.get("sha256").getAsString()
                + "|" + manifestUid
                + "|" + m.get("issuedAt").getAsLong()
                + "|" + m.get("key").getAsString();

        byte[] pubDer = Base64.getDecoder().decode(MODULE_PUB_KEY);
        PublicKey pub = KeyFactory.getInstance("Ed25519")
                .generatePublic(new X509EncodedKeySpec(pubDer));
        Signature sig = Signature.getInstance("Ed25519");
        sig.initVerify(pub);
        sig.update(msg.getBytes(StandardCharsets.UTF_8));
        boolean ok = sig.verify(Base64.getDecoder().decode(m.get("sig").getAsString()));
        if (!ok) {
            throw new IllegalStateException("manifest signature invalid");
        }
    }

    // ============================ контейнер ============================

    /**
     * [8Б "NEUPACK1"][4Б version LE][12Б nonce][AES-256-GCM ct][16Б tag]
     * AAD: "NEUPACK1|<version>|<uid>"
     */
    private static byte[] decryptContainer(byte[] c, int version, String uid, String keyHex)
            throws Exception {
        byte[] magic = new byte[8];
        System.arraycopy(c, 0, magic, 0, 8);
        if (!new String(magic, StandardCharsets.US_ASCII).equals("NEUPACK1")) {
            throw new IllegalStateException("bad container magic");
        }
        int containerVersion = (c[8] & 0xFF) | ((c[9] & 0xFF) << 8)
                | ((c[10] & 0xFF) << 16) | ((c[11] & 0xFF) << 24);
        if (containerVersion != version) {
            throw new IllegalStateException("container version mismatch");
        }

        byte[] nonce = new byte[12];
        System.arraycopy(c, 12, nonce, 0, 12);
        byte[] ct = new byte[c.length - 24];
        System.arraycopy(c, 24, ct, 0, ct.length);

        Cipher aes = Cipher.getInstance("AES/GCM/NoPadding");
        aes.init(Cipher.DECRYPT_MODE,
                new SecretKeySpec(hexToBytes(keyHex), "AES"),
                new GCMParameterSpec(128, nonce));
        aes.updateAAD(("NEUPACK1|" + version + "|" + uid).getBytes(StandardCharsets.UTF_8));
        return aes.doFinal(ct);
    }

    // ============================ классы и модули ============================

    private static List<Module> instantiateModules(byte[] jar) throws Exception {
        RemoteModuleClassLoader loader = new RemoteModuleClassLoader(
                RemoteModuleLoader.class.getClassLoader());
        List<Class<?>> classes = loader.defineAll(jar);

        List<Module> result = new ArrayList<>();
        for (Class<?> cls : classes) {
            if (cls.isInterface() || java.lang.reflect.Modifier.isAbstract(cls.getModifiers())) {
                continue;
            }
            if (!Module.class.isAssignableFrom(cls)) {
                continue;
            }
            try {
                Module m = (Module) cls.getDeclaredConstructor().newInstance();
                result.add(m);
            } catch (Throwable t) {
                log("модуль " + cls.getName() + " не создан: " + t);
            }
        }
        return result;
    }

    // ============================ утилиты ============================

    private static final HttpClient HTTP = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(6))
            .build();

    private static String httpGet(String url, String ticket)
            throws IOException, InterruptedException {
        HttpRequest req = HttpRequest.newBuilder(URI.create(url))
                .timeout(Duration.ofSeconds(8))
                .header("X-NEU-Ticket", ticket)
                .GET()
                .build();
        HttpResponse<String> resp = HTTP.send(req, HttpResponse.BodyHandlers.ofString());
        if (resp.statusCode() != 200 || resp.body() == null) {
            throw new IOException("HTTP " + resp.statusCode());
        }
        return resp.body();
    }

    private static byte[] httpGetBytes(String url, String ticket)
            throws IOException, InterruptedException {
        HttpRequest req = HttpRequest.newBuilder(URI.create(url))
                .timeout(Duration.ofSeconds(15))
                .header("X-NEU-Ticket", ticket)
                .GET()
                .build();
        HttpResponse<byte[]> resp = HTTP.send(req, HttpResponse.BodyHandlers.ofByteArray());
        if (resp.statusCode() != 200 || resp.body() == null) {
            throw new IOException("HTTP " + resp.statusCode());
        }
        return resp.body();
    }

    private static String sha256hex(byte[] data) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        byte[] hash = md.digest(data);
        StringBuilder sb = new StringBuilder(hash.length * 2);
        for (byte b : hash) {
            sb.append(String.format("%02x", b));
        }
        return sb.toString();
    }

    private static byte[] hexToBytes(String hex) {
        int len = hex.length() / 2;
        byte[] out = new byte[len];
        for (int i = 0; i < len; i++) {
            out[i] = (byte) Integer.parseInt(hex.substring(i * 2, i * 2 + 2), 16);
        }
        return out;
    }

    private static void log(String msg) {
        System.out.println("[NeuClient/RemoteModules] " + msg);
    }
}
