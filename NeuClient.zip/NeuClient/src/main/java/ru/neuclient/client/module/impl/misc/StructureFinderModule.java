package ru.neuclient.client.module.impl.misc;

import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockBox;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkStatus;
import net.minecraft.world.gen.structure.Structure;
import net.minecraft.structure.StructureStart;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.render.WorldRenderUtil;
import ru.neuclient.client.setting.BooleanSetting;
import ru.neuclient.client.setting.NumberSetting;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * StructureFinder — ESP-подсветка структур (как StorageESP у сундуков).
 *
 * ЧТО РИСУЕТСЯ. Реальный бокс строения (StructureStart#getBoundingBox):
 * 12 рёбер цветными линиями СКВОЗЬ СТЕНЫ (тот же слой LINES_NO_DEPTH,
 * что у StorageESP «Через стены») + вертикальный луч от крыши структуры
 * до границы мира, чтобы структуру было видно издалека (гасится настройкой).
 *
 * ОТКУДА ДАННЫЕ. В каждом чанке клиент уже хранит старты структур
 * (chunk.getStructureStarts()) — с настоящими координатами постройки в
 * мире. Модуль только читает их. ЧАНКИ НЕ ГЕНЕРИРУЕМ: getChunk с
 * ChunkStatus.STRUCTURE_STARTS и load=false.
 *
 * Раз в секунду сканируются чанки в радиусе вокруг игрока; галки выбора
 * структур применяются на рендере, поэтому переключение мгновенное.
 */
public final class StructureFinderModule extends Module {

	/** Категория структуры: как опознаётся + цвет подсветки. */
	private enum Kind {
		STRONGHOLD("Крепость (Stronghold)", 0xFFD700, "stronghold"),
		VILLAGE("Деревни", 0x4CAF50, "village"),
		DESERT_PYRAMID("Пустынная пирамида", 0xFFE066, "desert_pyramid"),
		JUNGLE_PYRAMID("Джунглевый храм", 0x66BB6A, "jungle_pyramid"),
		IGLOO("Иглу", 0xB3E5FC, "igloo"),
		MANSION("Особняк", 0x8D6E63, "mansion"),
		MONUMENT("Океанский монумент", 0x26C6DA, "monument"),
		OUTPOST("Аутпост разбойников", 0x9E9E9E, "pillager_outpost"),
		ANCIENT_CITY("Древний город", 0x7E57C2, "ancient_city"),
		TRIAL_CHAMBERS("Триал Чембер", 0xE07A3F, "trial_chambers"),
		FORTRESS("Адская крепость", 0xEF5350, "fortress"),
		BASTION("Бастион", 0xA1887F, "bastion_remnant"),
		SHIPWRECK("Кораблекрушение", 0x795548, "shipwreck");

		final String label;
		final int color;
		final String path;

		Kind(String label, int color, String path) {
			this.label = label;
			this.color = color;
			this.path = path;
		}

		/** Совпадение по пути идентификатора (деревни имеют варианты по биомам). */
		boolean matches(String idPath) {
			if (this == VILLAGE) {
				return idPath.startsWith("village");
			}
			return idPath.equals(path);
		}
	}

	/** Найденная структура: реальные границы строения в мире + категория. */
	private record Found(double minX, double minY, double minZ,
			double maxX, double maxY, double maxZ, Kind kind) {
	}

	private final NumberSetting radius = new NumberSetting("Радиус (чанки)", 6, 2, 12, 1);
	/** Вертикальный луч над структурой — видно издалека. */
	private final BooleanSetting beam = new BooleanSetting("Луч до неба", true);

	/** Стиль линий — как у StorageESP. */
	private static final float LINE_ALPHA = 0.85f;
	private static final float LINE_WIDTH = 2.0f;

	private final Map<Kind, BooleanSetting> toggles = new LinkedHashMap<>();

	/** Найденные структуры (обновляются раз в секунду сканом). */
	private List<Found> found = new ArrayList<>();
	private int scanTimer;

	public StructureFinderModule() {
		super("StructureFinder", "ESP-подсветка структур сквозь стены", Category.MISC);
		for (Kind kind : Kind.values()) {
			BooleanSetting setting = new BooleanSetting(kind.label, true);
			toggles.put(kind, setting);
			addSettings(setting);
		}
		addSettings(radius, beam);
	}

	@Override
	public void onTick(MinecraftClient client) {
		if (++scanTimer < 20) {
			return;
		}
		scanTimer = 0;
		scan();
	}

	@Override
	protected void onDisable() {
		found.clear();
	}

	private void scan() {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc == null || mc.world == null || mc.player == null) {
			return;
		}
		ClientWorld world = mc.world;
		Registry<Structure> registry;
		try {
			registry = world.getRegistryManager().getOrThrow(RegistryKeys.STRUCTURE);
		} catch (Throwable t) {
			return;
		}
		if (registry == null) {
			return;
		}

		List<Found> next = new ArrayList<>();
		ChunkPos center = mc.player.getChunkPos();
		int r = radius.get().intValue();
		for (int dx = -r; dx <= r; dx++) {
			for (int dz = -r; dz <= r; dz++) {
				// ЧАНКИ НЕ ГЕНЕРИРУЕМ: load=false — только уже сгенерённые
				// до статуса STRUCTURE_STARTS, иначе фризы на обходе.
				Chunk chunk;
				try {
					chunk = world.getChunk(center.x + dx, center.z + dz,
							ChunkStatus.STRUCTURE_STARTS, false);
				} catch (Throwable t) {
					continue;
				}
				if (chunk == null) {
					continue;
				}
				Map<Structure, StructureStart> starts;
				try {
					starts = chunk.getStructureStarts();
				} catch (Throwable t) {
					continue;
				}
				if (starts == null || starts.isEmpty()) {
					continue;
				}
				for (Map.Entry<Structure, StructureStart> e : starts.entrySet()) {
					StructureStart start = e.getValue();
					if (start == null) {
						continue;
					}
					Identifier id = registry.getId(e.getKey());
					if (id == null) {
						continue;
					}
					Kind kind = kindOf(id.getPath());
					if (kind == null) {
						continue;
					}
					Found f = toFound(start, kind);
					if (f != null) {
						next.add(f);
					}
				}
			}
		}
		found = next;
	}

	/** Границы структуры из BlockBox, при недоступности — из ChunkPos старта. */
	private static Found toFound(StructureStart start, Kind kind) {
		try {
			BlockBox bb = start.getBoundingBox();
			if (bb != null) {
				// BlockBox — int-границы включительно: max-грань на +1.
				return new Found(
						bb.getMinX(), bb.getMinY(), bb.getMinZ(),
						bb.getMaxX() + 1.0, bb.getMaxY() + 1.0, bb.getMaxZ() + 1.0,
						kind);
			}
		} catch (Throwable ignored) {
		}
		try {
			ChunkPos cp = start.getPos();
			double x0 = cp.getStartX();
			double z0 = cp.getStartZ();
			return new Found(x0, 0, z0, x0 + 16.0, 60.0, z0 + 16.0, kind);
		} catch (Throwable ignored) {
			return null;
		}
	}

	private static Kind kindOf(String path) {
		for (Kind kind : Kind.values()) {
			if (kind.matches(path)) {
				return kind;
			}
		}
		return null;
	}

	private boolean enabled(Kind kind) {
		BooleanSetting setting = toggles.get(kind);
		return setting != null && setting.get();
	}

	private void renderWorld(WorldRenderContext context, MinecraftClient client) {
		if (found.isEmpty() || context.commandQueue() == null) {
			return;
		}
		Vec3d cam = client.gameRenderer.getCamera().getCameraPos();
		MatrixStack matrices = context.matrices();
		RenderLayer layer = WorldRenderUtil.LINES_NO_DEPTH;

		matrices.push();
		matrices.translate(-cam.x, -cam.y, -cam.z);
		context.commandQueue().submitCustom(matrices, layer, (entry, buffer) -> {
			for (Found f : found) {
				if (!enabled(f.kind())) {
					continue;
				}
				float r = ((f.kind().color >> 16) & 0xFF) / 255.0f;
				float g = ((f.kind().color >> 8) & 0xFF) / 255.0f;
				float b = (f.kind().color & 0xFF) / 255.0f;

				// ESP-обводка реального бокса строения (как StorageESP).
				outline(entry, buffer, f.minX(), f.minY(), f.minZ(),
						f.maxX(), f.maxY(), f.maxZ(), r, g, b);

				// Луч от крыши структуры до границы мира — видно издалека.
				if (beam.get()) {
					double cx = (f.minX() + f.maxX()) / 2.0;
					double cz = (f.minZ() + f.maxZ()) / 2.0;
					WorldRenderUtil.line(buffer, entry,
							cx, f.maxY(), cz, cx, 320, cz, r, g, b, LINE_ALPHA, LINE_WIDTH);
				}
			}
		});
		matrices.pop();
	}

	/** 12 рёбер бокса линиями — точь-в-точь как у StorageESP. */
	private static void outline(MatrixStack.Entry entry, VertexConsumer buffer,
			double x0, double y0, double z0, double x1, double y1, double z1,
			float r, float g, float b) {
		// Рёбра вдоль X
		WorldRenderUtil.line(buffer, entry, x0, y0, z0, x1, y0, z0, r, g, b, LINE_ALPHA, LINE_WIDTH);
		WorldRenderUtil.line(buffer, entry, x0, y1, z0, x1, y1, z0, r, g, b, LINE_ALPHA, LINE_WIDTH);
		WorldRenderUtil.line(buffer, entry, x0, y0, z1, x1, y0, z1, r, g, b, LINE_ALPHA, LINE_WIDTH);
		WorldRenderUtil.line(buffer, entry, x0, y1, z1, x1, y1, z1, r, g, b, LINE_ALPHA, LINE_WIDTH);
		// Рёбра вдоль Y
		WorldRenderUtil.line(buffer, entry, x0, y0, z0, x0, y1, z0, r, g, b, LINE_ALPHA, LINE_WIDTH);
		WorldRenderUtil.line(buffer, entry, x1, y0, z0, x1, y1, z0, r, g, b, LINE_ALPHA, LINE_WIDTH);
		WorldRenderUtil.line(buffer, entry, x0, y0, z1, x0, y1, z1, r, g, b, LINE_ALPHA, LINE_WIDTH);
		WorldRenderUtil.line(buffer, entry, x1, y0, z1, x1, y1, z1, r, g, b, LINE_ALPHA, LINE_WIDTH);
		// Рёбра вдоль Z
		WorldRenderUtil.line(buffer, entry, x0, y0, z0, x0, y0, z1, r, g, b, LINE_ALPHA, LINE_WIDTH);
		WorldRenderUtil.line(buffer, entry, x1, y0, z0, x1, y0, z1, r, g, b, LINE_ALPHA, LINE_WIDTH);
		WorldRenderUtil.line(buffer, entry, x0, y1, z0, x0, y1, z1, r, g, b, LINE_ALPHA, LINE_WIDTH);
		WorldRenderUtil.line(buffer, entry, x1, y1, z0, x1, y1, z1, r, g, b, LINE_ALPHA, LINE_WIDTH);
	}

	public static void renderAllWorld(WorldRenderContext context) {
		NeuClient client = NeuClient.getInstance();
		if (client == null || client.getModuleManager() == null) {
			return;
		}
		StructureFinderModule self = client.getModuleManager().get(StructureFinderModule.class);
		if (self != null && self.isEnabled()) {
			self.renderWorld(context, MinecraftClient.getInstance());
		}
	}
}
