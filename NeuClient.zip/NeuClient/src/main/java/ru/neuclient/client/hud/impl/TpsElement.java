package ru.neuclient.client.hud.impl;

import net.minecraft.client.gui.DrawContext;
import ru.neuclient.client.hud.HudElement;
import ru.neuclient.client.util.TpsSync;

/**
 * TPS сервера — карточка [TPS │ 19.7] в общем стиле HUD.
 *
 * Значение берётся из TpsSync: скользящее среднее по последним 20
 * пакетам WorldTimeUpdate. В одиночной игре всегда 20.
 */
public class TpsElement extends HudElement {

	public TpsElement() {
		super("tps", 4, 112);
	}

	@Override
	public boolean isVisible() {
		if (ru.neuclient.client.NeuClient.getInstance().getInterfaceModule().isElementVisible("watermark")) return false;
		return super.isVisible();
	}

	@Override
	protected void drawElement(DrawContext ctx, boolean editing) {
		float tps = TpsSync.getTps();
		String value = String.format("%.1f", tps);
		this.width = valueCardWidth("TPS", value);
		this.height = CARD_H;
		drawValueCard(ctx, getX(), getY(), width, "TPS", value);
	}
}
