package ru.neuclient.client.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.impl.combat.AttackAuraModule;
import ru.neuclient.client.module.impl.misc.AutoWardenModule;
import ru.neuclient.client.module.impl.misc.TreeFarmModule;
import ru.neuclient.client.module.impl.movement.AutoSprintModule;
import ru.neuclient.client.module.impl.movement.AutoPilotModule;
import ru.neuclient.client.module.impl.movement.WallClimbModule;
import ru.neuclient.client.util.RotationSpoof;

/**
 * Временное наложение серверного yaw/pitch на ClientPlayerEntity.
 *
 * Источник угла может быть AttackAura или WallClimb. Подмена существует
 * только на время одного ClientPlayerEntity#tick: ваниль видит изменение,
 * отправляет обычный пакет движения, а затем локальные углы возвращаются.
 * Поэтому камера от первого лица не дёргается.
 */
@Mixin(ClientPlayerEntity.class)
public abstract class AuraTickSpoofMixin {

	/** Настоящие углы этого тика. */
	private float pc$yaw;
	private float pc$pitch;
	private float pc$lastYaw;
	private float pc$lastPitch;
	/**
	 * Углы «доводки руки» до тика. Их тоже сохраняем, чтобы серверная
	 * подмена не протекала в вид от первого лица.
	 */
	private float pc$renderYaw;
	private float pc$renderPitch;
	private float pc$lastRenderYaw;
	private float pc$lastRenderPitch;

	/** Нужно ли после отправки движения выполнить установку WallClimb. */
	private boolean pc$wallSpoofThisTick;

	@Inject(method = "tick", at = @At("HEAD"))
	private void pc$applySpoof(CallbackInfo ci) {
		pc$wallSpoofThisTick = false;
		try {
			ClientPlayerEntity self = (ClientPlayerEntity) (Object) this;
			if (self != MinecraftClient.getInstance().player) {
				return;
			}

			AttackAuraModule aura = AttackAuraModule.active();
			WallClimbModule wall = WallClimbModule.active();
			AutoWardenModule warden = AutoWardenModule.active();
			AutoSprintModule autoSprint = AutoSprintModule.active();
			TreeFarmModule treeFarm = TreeFarmModule.active();
			boolean auraWantsSpoof = aura != null && aura.isSpoofing();
			boolean wallWantsSpoof = wall != null && wall.shouldApplySpoof();
			// AutoWarden выше ауры: серверный угол нужен боту для открытия сундуков.
			boolean wardenWantsSpoof = warden != null && warden.isSpoofing();
			// TreeFarm ходит и ломает брёвна так же, как AutoWarden: серверный
			// угол ведёт бот, реальная камера стоит на месте.
			boolean treeFarmWantsSpoof = treeFarm != null && treeFarm.isSpoofing();
			// AutoSprint («Во все стороны») — самый низкий приоритет:
			// включается, только если угол никто не крутит.
			boolean sprintWantsSpoof = autoSprint != null && autoSprint.shouldApplySpoof()
					&& !auraWantsSpoof && !wallWantsSpoof && !wardenWantsSpoof && !treeFarmWantsSpoof;
			boolean hasSpoof = auraWantsSpoof || wallWantsSpoof || wardenWantsSpoof
					|| treeFarmWantsSpoof || sprintWantsSpoof;
			AutoPilotModule autoPilot = AutoPilotModule.active();
			if (autoPilot != null) {
				if (hasSpoof) {
					autoPilot.stopForRotationConflict();
				} else {
					// Настоящий плавный взгляд: до физики и sendMovementPackets.
					// Не RotationSpoof: после тика ничего не возвращаем назад.
					autoPilot.beforePlayerTick(self);
				}
			}
			if (!hasSpoof) {
				return;
			}

			// WallClimb имеет приоритет над боевой ротацией.
			pc$wallSpoofThisTick = wallWantsSpoof;
			pc$yaw = self.getYaw();
			pc$pitch = self.getPitch();
			pc$lastYaw = self.lastYaw;
			pc$lastPitch = self.lastPitch;
			pc$renderYaw = self.renderYaw;
			pc$renderPitch = self.renderPitch;
			pc$lastRenderYaw = self.lastRenderYaw;
			pc$lastRenderPitch = self.lastRenderPitch;

			RotationSpoof.begin(pc$yaw, pc$pitch);
			float spoofYaw = wallWantsSpoof ? wall.getSpoofYaw()
					: (wardenWantsSpoof ? warden.getSpoofYaw()
					: (treeFarmWantsSpoof ? treeFarm.getSpoofYaw()
					: (auraWantsSpoof ? aura.getSpoofYaw() : autoSprint.getSpoofYaw())));
			float spoofPitch = wallWantsSpoof ? wall.getSpoofPitch()
					: (wardenWantsSpoof ? warden.getSpoofPitch()
					: (treeFarmWantsSpoof ? treeFarm.getSpoofPitch()
					: (auraWantsSpoof ? aura.getSpoofPitch() : autoSprint.getSpoofPitch())));
			self.setYaw(spoofYaw);
			self.setPitch(spoofPitch);
			RotationSpoof.setSpoof(spoofYaw, spoofPitch);
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка наложения спуфа угла", t);
		}
	}

	@Inject(method = "tick", at = @At("TAIL"))
	private void pc$restoreSpoof(CallbackInfo ci) {
		try {
			ClientPlayerEntity self = (ClientPlayerEntity) (Object) this;
			if (self != MinecraftClient.getInstance().player) {
				return;
			}

			// Сначала запоминаем угол, который ушёл обычным пакетом движения.
			RotationSpoof.markSent(self.getYaw(), self.getPitch());

			// В этот момент сервер уже получил спуфнутый угол. Ставим блок
			// до восстановления локальной камеры, затем модуль отправляет
			// обратный LookAndOnGround с реальным углом.
			if (pc$wallSpoofThisTick) {
				WallClimbModule wall = WallClimbModule.active();
				if (wall != null) {
					try {
						wall.performPendingPlacement(MinecraftClient.getInstance(), self);
					} catch (Throwable t) {
						NeuClient.LOGGER.error("[NeuClient] Ошибка установки блока после спуфа", t);
					}
				}
			}
			if (!RotationSpoof.isApplied()) {
				return;
			}
			self.setYaw(pc$yaw);
			self.setPitch(pc$pitch);
			self.lastYaw = pc$lastYaw;
			self.lastPitch = pc$lastPitch;

			// Рука должна доводиться к настоящему взгляду, а не к спуфу.
			self.lastRenderYaw = pc$renderYaw;
			self.lastRenderPitch = pc$renderPitch;
			self.renderYaw = pc$renderYaw
					+ (pc$yaw - pc$renderYaw) * 0.5f;
			self.renderPitch = pc$renderPitch
					+ (pc$pitch - pc$renderPitch) * 0.5f;

			RotationSpoof.end();
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка возврата угла", t);
		}
	}
}
