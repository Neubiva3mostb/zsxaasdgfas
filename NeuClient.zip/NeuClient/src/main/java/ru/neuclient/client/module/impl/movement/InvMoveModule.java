package ru.neuclient.client.module.impl.movement;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.AnvilScreen;
import net.minecraft.client.gui.screen.ingame.CreativeInventoryScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.ClickSlotC2SPacket;
import net.minecraft.network.packet.c2s.play.CloseHandledScreenC2SPacket;
import ru.neuclient.client.mixin.KeyBindingAccessor;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.ui.ClickGuiScreen;
import ru.neuclient.client.util.MoveUtil;
import ru.neuclient.client.util.SwapPause;

/**
 * InvMove — движение с открытым экраном инвентаря.
 *
 * ==================== ЧТО ЭТО ДЕЛАЕТ ====================
 *
 * 1. Возвращает клавишам движения их физическое состояние: ваниль
 *    гасит их, как только открыт любой экран.
 * 2. Один раз на открытие СВОЕГО инвентаря отправляет серверу
 *    «закрытие экрана». Для сервера игрок в меню не стоит — он просто
 *    бежит, и бег с открытым рюкзаком перестаёт быть аномалией.
 * 3. Перекладывание слота стоит ровно ОДИН ТИК (50 мс) остановки —
 *    тот же самый {@link ru.neuclient.client.util.SwapPause}, что и у
 *    AutoSwap, AutoTotem, AutoArmor и остальных.
 *
 * ============= ПОЧЕМУ УБРАНА ОЧЕРЕДЬ ПАКЕТОВ =============
 *
 * Прошлая версия копила клики, пока игрок движется, и отпускала их по
 * одному, когда он ОСТАНОВИТСЯ. На практике это значило: бежишь —
 * инвентарь не работает вообще. Клик применялся локально, но на сервер
 * уходил через неопределённое время (в бою — никогда), из-за чего
 * клиент и сервер расходились в содержимом инвентаря, а при выходе из
 * мира накопленное просто терялось.
 *
 * Теперь правило ровно то же, что у всех свапперов клиента: одно
 * действие с инвентарём = один пакет стоящего игрока, 50 мс. Никаких
 * окон удержания, никаких очередей, никакой зависимости от того,
 * держит игрок что-то на курсоре или нет.
 *
 * ============= ПОЧЕМУ ЗАКРЫТИЕ ТОЛЬКО ДЛЯ СВОЕГО ИНВЕНТАРЯ =============
 *
 * Экран игрока (syncId 0) активен всегда: по нему можно кликать и без
 * открытого меню — именно так работают все свапперы. Поэтому сказать
 * серверу «я закрыл инвентарь» безопасно, клики продолжат приниматься.
 *
 * У сундука, печки и любого другого контейнера свой syncId, и закрытие
 * для сервера означает конец сессии с блоком: дальнейшие клики он
 * отклонит, а вещи останутся внутри. Поэтому чужие контейнеры модуль
 * не трогает совсем — там просто разрешается движение.
 *
 * Исключения (там WASD нужны для текста): чат, поиск в ClickGUI,
 * наковальня, креативный инвентарь, любое текстовое поле в фокусе.
 */
public final class InvMoveModule extends Module {

	/** Мы управляли клавишами на прошлом тике. */
	private boolean wasHandling;

	/**
	 * Экран своего инвентаря, для которого уже отправлено фейковое
	 * закрытие. Сравниваем по ссылке, а не флагом-счётчиком: если экран
	 * сменился или закрылся мимо нас, состояние обнулится само.
	 */
	private Screen closedFor;

	public InvMoveModule() {
		super("InvMove", "Движение с открытым инвентарём", Category.MOVEMENT);
	}

	// ===================== Ввод =====================

	@Override
	public void onTick(MinecraftClient client) {
		if (client.player == null || client.world == null || client.options == null) {
			wasHandling = false;
			closedFor = null;
			return;
		}

		Screen screen = client.currentScreen;
		boolean allowed = screen != null && isAllowed(screen);

		if (allowed || wasHandling) {
			// Возвращаем клавишам их реальное состояние: ваниль гасит их
			// при открытии экрана. Второй случай — экран только что
			// закрыли, нужно снять возможное залипание.
			//
			// Sneak сюда НЕ входит: внутри инвентаря шифт принадлежит
			// интерфейсу (быстрый перенос), иначе игрок приседал бы на
			// каждом шифт-клике.
			for (KeyBinding kb : movementKeys(client)) {
				kb.setPressed(physicallyHeld(client, kb));
			}
		}
		wasHandling = allowed;

		updateFakeClose(client, screen);
	}

	// ===================== Фейковое закрытие =====================

	/**
	 * Сказать серверу, что инвентарь закрыт, оставив его открытым локально.
	 *
	 * Строго один пакет на одно открытие: повторные закрытия того же
	 * экрана сервер счёл бы флудом.
	 */
	private void updateFakeClose(MinecraftClient client, Screen screen) {
		// Экран сменился или закрылся — состояние сбрасывается, следующее
		// открытие снова получит своё закрытие.
		if (closedFor != null && closedFor != screen) {
			closedFor = null;
		}
		if (!(screen instanceof InventoryScreen) || closedFor == screen) {
			return;
		}
		// ТОЛЬКО свой инвентарь (syncId 0). Для чужого контейнера
		// закрытие означало бы конец сессии с блоком, и вещи остались
		// бы внутри.
		if (client.player.currentScreenHandler != client.player.playerScreenHandler) {
			return;
		}
		if (client.player.networkHandler == null) {
			return;
		}
		// Отправляем прямо в канал, мимо ClientCommonNetworkHandler#sendPacket:
		// иначе пакет прошёл бы через наш же перехват.
		client.player.networkHandler.getConnection().send(
				new CloseHandledScreenC2SPacket(client.player.currentScreenHandler.syncId));
		closedFor = screen;
	}

	// ===================== Сеть =====================

	/**
	 * Нужно ли придержать этот пакет.
	 * Вызывается из ClientCommonNetworkHandlerSendMixin для всех исходящих.
	 *
	 * Держим ровно одно: повторное закрытие СВОЕГО инвентаря. Сервер уже
	 * получил его от нас заранее (см. updateFakeClose), и второй такой
	 * пакет при реальном закрытии экрана был бы лишним.
	 *
	 * Клики по слотам НЕ задерживаются никогда: их цена — один тик
	 * остановки через SwapPause, как у всех свапперов клиента.
	 */
	public boolean shouldHoldPacket(Packet<?> packet) {
		MinecraftClient client = MinecraftClient.getInstance();
		if (client == null || client.player == null) {
			return false;
		}

		// --- Клик по слоту: та же цена, что у любого сваппера ---
		if (packet instanceof ClickSlotC2SPacket) {
			return holdSlotClick(client, packet);
		}

		if (!(packet instanceof CloseHandledScreenC2SPacket) || closedFor == null) {
			return false;
		}
		// Гасим только закрытие того самого экрана, за который мы уже
		// отчитались, и только пока он ещё открыт.
		if (client.currentScreen != closedFor) {
			return false;
		}
		return client.player.currentScreenHandler == client.player.playerScreenHandler;
	}

	/**
	 * Перекладывание слота стоит один тик остановки — ровно столько же,
	 * сколько у AutoSwap, AutoTotem и остальных.
	 *
	 * Пакет отменяется здесь и уходит следующим тиком, уже после пакета
	 * стоящего игрока. Локально клик применился сразу, поэтому для
	 * игрока никакой задержки не видно.
	 *
	 * @return true — пакет перехвачен (уйдёт позже)
	 */
	private boolean holdSlotClick(MinecraftClient client, Packet<?> packet) {
		// Пакет отправляет сам планировщик — второй раз откладывать
		// нельзя, иначе клик кружил бы вечно.
		if (SwapPause.isRunning()) {
			return false;
		}
		// Только СВОЙ инвентарь: у чужого контейнера отложенный клик
		// рискует прилететь в уже закрытое сервером окно.
		if (client.player.currentScreenHandler != client.player.playerScreenHandler) {
			return false;
		}
		if (client.player.networkHandler == null) {
			return false;
		}
		// Стоящему игроку тормозить не от чего — пусть уходит сразу.
		if (!MoveUtil.isMoving(client.player)) {
			return false;
		}
		SwapPause.submit(() -> {
			if (client.player != null && client.player.networkHandler != null) {
				// Прямо в канал, мимо sendPacket: иначе снова попали бы
				// в этот же перехват.
				client.player.networkHandler.getConnection().send(packet);
			}
		});
		// Перехвачено в любом случае. При переполнении очереди submit
		// выполняет действие немедленно — пакет уже ушёл, и разрешить
		// ванили отправить его ещё раз значит продублировать клик.
		return true;
	}

	// ===================== Экраны и клавиши =====================

	/** Разрешён ли этот экран для движения. */
	private static boolean isAllowed(Screen screen) {
		// Чат — туда буквы
		if (screen instanceof ChatScreen) {
			return false;
		}
		// Наковальня и креативный инвентарь: там поля ввода и поиск
		if (screen instanceof AnvilScreen || screen instanceof CreativeInventoryScreen) {
			return false;
		}
		// Поиск / редактирование в ClickGUI
		if (screen instanceof ClickGuiScreen gui && (gui.isSearchFocused() || gui.isTextEditing())) {
			return false;
		}
		// Любое ванильное текстовое поле в фокусе (табличка, книга...)
		return !(screen.getFocused() instanceof TextFieldWidget);
	}

	/**
	 * Клавиши, которыми управляет модуль.
	 *
	 * Sneak намеренно отсутствует: внутри инвентаря Shift — это быстрый
	 * перенос стака, а не приседание.
	 */
	private static KeyBinding[] movementKeys(MinecraftClient client) {
		return new KeyBinding[] {
				client.options.forwardKey, client.options.backKey,
				client.options.leftKey, client.options.rightKey,
				client.options.jumpKey, client.options.sprintKey
		};
	}

	/** Физически держит ли рука эту клавишу (по её привязанному коду). */
	private static boolean physicallyHeld(MinecraftClient client, KeyBinding kb) {
		try {
			int code = ((KeyBindingAccessor) kb).pc$getBoundKey().getCode();
			return InputUtil.isKeyPressed(client.getWindow(), code);
		} catch (Throwable t) {
			return false;
		}
	}

	@Override
	protected void onDisable() {
		MinecraftClient client = MinecraftClient.getInstance();
		if (client != null && client.options != null) {
			for (KeyBinding kb : movementKeys(client)) {
				kb.setPressed(physicallyHeld(client, kb));
			}
		}
		closedFor = null;
		wasHandling = false;
	}
}
