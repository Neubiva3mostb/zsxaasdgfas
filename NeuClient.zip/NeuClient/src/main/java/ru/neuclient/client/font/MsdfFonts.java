package ru.neuclient.client.font;

import net.minecraft.client.MinecraftClient;
import ru.neuclient.client.NeuClient;

/**
 * Реестр MSDF-шрифтов NeuClient.
 *
 * Все гарнитуры из delta/fonts загружаются один раз при старте клиента.
 * Текстуры регистрируются в TextureManager как динамические.
 *
 * Имена совпадают с файлами атласов:
 *  - sf_regular, sf_medium, gt_regular, onest_regular, icons
 */
public final class MsdfFonts {

	private static MsdfFont sfRegular;
	private static MsdfFont sfMedium;
	private static MsdfFont gtRegular;
	private static MsdfFont onestRegular;
	private static MsdfFont icons;

	private MsdfFonts() {
	}

	/** Загрузить все шрифты (вызывается из NeuClient.onInitializeClient). */
	public static void init() {
		sfRegular    = load("sf_regular");
		sfMedium     = load("sf_medium");
		gtRegular    = load("gt_regular");
		onestRegular = load("onest_regular");
		icons        = load("icons");
	}

	private static MsdfFont load(String name) {
		try {
			MsdfFont f = new MsdfFont(NeuClient.MOD_ID, name);
			NeuClient.LOGGER.info("[NeuClient] MSDF-шрифт загружен: {}", name);
			return f;
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Не удалось загрузить MSDF-шрифт: " + name, t);
			return null;
		}
	}

	/** Освободить GPU-текстуры (при выгрузке/перезагрузке ресурсов). */
	public static void close() {
		close(sfRegular); sfRegular = null;
		close(sfMedium); sfMedium = null;
		close(gtRegular); gtRegular = null;
		close(onestRegular); onestRegular = null;
		close(icons); icons = null;
	}

	private static void close(MsdfFont f) {
		if (f != null) {
			try { f.close(); } catch (Throwable ignored) { }
		}
	}

	/** Перезагрузка при F3+T / смене ресурс-пака. */
	public static void reload() {
		MinecraftClient mc = MinecraftClient.getInstance();
		mc.execute(() -> {
			close();
			init();
		});
	}

	public static MsdfFont sfRegular()    { return sfRegular; }
	public static MsdfFont sfMedium()     { return sfMedium; }
	public static MsdfFont gtRegular()    { return gtRegular; }
	public static MsdfFont onestRegular() { return onestRegular; }
	public static MsdfFont icons()        { return icons; }
}
