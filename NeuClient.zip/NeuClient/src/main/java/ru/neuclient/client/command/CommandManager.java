package ru.neuclient.client.command;

import ru.neuclient.client.NeuClient;
import ru.neuclient.client.alt.AltManager;
import ru.neuclient.client.config.ConfigManager;
import ru.neuclient.client.config.FriendManager;
import ru.neuclient.client.util.ChatUtil;
import ru.neuclient.client.util.ClientPaths;

import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;

/**
 * Ядро команд клиента.
 *
 * Исполняется двумя способами:
 *  1) Точка-команды (".friend add x"): перехватываются миксином из
 *     ClientPlayNetworkHandler#sendChatMessage ДО отправки на сервер;
 *  2) Клиентские бригадир-команды ("/friend ...", "/cfg ..."): регистрируются
 *     CommandRegistrar'ом и делегируют сюда же.
 *
 * Команды:
 *   .friend add|rem|remove|list
 *   .cfg dir|save|load|list
 *   .help
 */
public class CommandManager {

	private static final String PREFIX = ".";

	/**
	 * Обработать сообщение из чата.
	 * @return true, если это клиентская команда (тогда её нельзя слать на сервер)
	 */
	public boolean handle(String rawMessage) {
		if (rawMessage == null || !rawMessage.startsWith(PREFIX)) {
			return false;
		}
		String body = rawMessage.substring(PREFIX.length()).trim();
		// Если после точки пусто — это не команда, пропускаем
		if (body.isEmpty()) {
			return false;
		}
		String[] args = body.split("\\s+");
		String root = args[0].toLowerCase(Locale.ROOT);
		// Проверяем, является ли это известной командой
		if (!isKnownCommand(root)) {
			return false; // Неизвестная команда — пускаем на сервер
		}
		// Режим паники: клиентские команды мертвы, пропускаем сообщение на сервер как обычный чат
		NeuClient owner = NeuClient.getInstance();
		if (owner != null && owner.isPanicked()) {
			return false;
		}
		try {
			execute(List.of(args), ChatUtil::send);
		} catch (Exception e) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка команды '{}'", rawMessage, e);
			ChatUtil.error("Ошибка команды: " + e.getMessage());
		}
		return true;
	}

	/** Проверить, является ли слово известной командой. */
	private boolean isKnownCommand(String root) {
		return switch (root) {
			case "friend", "cfg", "config", "gps", "panic", "help" -> true;
			default -> false;
		};
	}

	/**
	 * Общая логика всех команд (вызывается и из чата, и из бригадира).
	 * @param out приёмник строк ответа
	 */
	public void execute(List<String> args, Consumer<String> out) {
		if (args.isEmpty()) {
			printHelp(out);
			return;
		}
		NeuClient owner = NeuClient.getInstance();
		if (owner != null && owner.isPanicked()) {
			return; // паника: команды мертвы (страховка вторым эшелоном)
		}
		String root = args.get(0).toLowerCase(Locale.ROOT);
		switch (root) {
			case "friend" -> handleFriend(args, out);
			case "cfg", "config" -> handleCfg(args, out);
			case "gps" -> handleGps(args, out);
			case "panic" -> ru.neuclient.client.panic.PanicManager.execute();
			case "help" -> printHelp(out);
			default -> {
				out.accept("§cНеизвестная команда.");
				printHelp(out);
			}
		}
	}

	// ===== .friend =====

	private void handleFriend(List<String> args, Consumer<String> out) {
		FriendManager friends = NeuClient.getInstance().getFriendManager();
		if (args.size() < 2) {
			out.accept("§7.friend add <ник> | .friend rem <ник> | .friend list");
			return;
		}
		String sub = args.get(1).toLowerCase(Locale.ROOT);
		switch (sub) {
			case "add" -> {
				if (args.size() < 3) {
					out.accept("§7Использование: .friend add <ник>");
					return;
				}
				String name = args.get(2);
				if (friends.add(name)) {
					out.accept("§aДруг добавлен: §f" + name);
				} else {
					out.accept("§eОн уже в списке друзей.");
				}
			}
			case "rem", "remove", "del" -> {
				if (args.size() < 3) {
					out.accept("§7Использование: .friend rem <ник>");
					return;
				}
				String name = args.get(2);
				if (friends.remove(name)) {
					out.accept("§aДруг удалён: §f" + name);
				} else {
					out.accept("§cТакого друга нет в списке.");
				}
			}
			case "list" -> {
				if (friends.list().isEmpty()) {
					out.accept("§7Список друзей пуст.");
					return;
				}
				// Всегда пишем список в чат — это основное, что ждёт игрок.
				out.accept("§aДрузья (" + friends.list().size() + "): §f"
						+ String.join("§7, §f", friends.list()));
				// Дополнительно открываем экран-список с крестиками для удаления.
				net.minecraft.client.MinecraftClient mc = net.minecraft.client.MinecraftClient.getInstance();
				if (mc != null) {
					mc.setScreen(new ru.neuclient.client.ui.FriendListScreen());
				}
			}
			default -> out.accept("§7.friend add <ник> | .friend rem <ник> | .friend list");
		}
	}

	// ===== .cfg =====

	private void handleCfg(List<String> args, Consumer<String> out) {
		ConfigManager configs = NeuClient.getInstance().getConfigManager();
		if (args.size() < 2) {
			out.accept("§7.cfg save <имя> | .cfg load <имя> | .cfg dir | .cfg list");
			return;
		}
		String sub = args.get(1).toLowerCase(Locale.ROOT);
		switch (sub) {
			case "dir" -> {
				// Открываем проводник молча, без сообщений в чат
				if (!ClientPaths.openInExplorer()) {
					NeuClient.LOGGER.warn("[NeuClient] Проводник недоступен. Папка: {}",
							ClientPaths.getConfigsDir().toAbsolutePath());
				}
			}
			case "save" -> {
				if (args.size() < 3) {
					out.accept("§7Использование: .cfg save <имя>");
					return;
				}
				try {
					configs.saveNamed(args.get(2));
					out.accept("§aКонфиг сохранён: §f" + args.get(2) + ".json");
				} catch (Exception e) {
					out.accept("§cНе удалось сохранить: " + e.getMessage());
				}
			}
			case "rem", "remove", "del", "delete" -> {
				if (args.size() < 3) {
					out.accept("§7Использование: .cfg rem <имя>");
					return;
				}
				String cfgName = args.get(2);
				if (cfgName.equalsIgnoreCase("default")) {
					out.accept("§cНельзя удалить основной конфиг default.json");
					return;
				}
				if (configs.deleteNamed(cfgName)) {
					out.accept("§aКонфиг удалён: §f" + cfgName + ".json");
				} else {
					out.accept("§cКонфиг не найден: §f" + cfgName + ".json");
				}
			}
			case "load" -> {
				if (args.size() < 3) {
					out.accept("§7Использование: .cfg load <имя>");
					return;
				}
				try {
					if (!configs.exists(args.get(2))) {
						out.accept("§cКонфиг не найден: " + args.get(2) + ".json");
						return;
					}
					configs.loadNamed(args.get(2));
					out.accept("§aКонфиг применён: §f" + args.get(2) + ".json §7(автосохранение идёт в default.json)");
				} catch (Exception e) {
					out.accept("§cНе удалось загрузить: " + e.getMessage());
				}
			}
			case "list" -> {
				List<String> names = configs.listConfigs();
				if (names.isEmpty()) {
					out.accept("§7Конфигов нет.");
				} else {
					out.accept("§aКонфиги: §f" + String.join("§7, §f", names));
				}
			}
			default -> out.accept("§7.cfg save <имя> | .cfg load <имя> | .cfg rem <имя> | .cfg dir | .cfg list");
		}
	}

	// ===== .gps =====

	private void handleGps(List<String> args, Consumer<String> out) {
		ru.neuclient.client.config.GpsManager gps = NeuClient.getInstance().getGpsManager();
		if (gps == null) {
			out.accept("§cGPS-менеджер не инициализирован.");
			return;
		}
		if (args.size() == 2 && args.get(1).equalsIgnoreCase("clear")) {
			int removed = gps.clear();
			out.accept("§aМетки GPS очищены §7(удалено: §f" + removed + "§7).");
			return;
		}
		if (args.size() == 2 && args.get(1).equalsIgnoreCase("list")) {
			if (gps.markers().isEmpty()) {
				out.accept("§7Меток нет. Поставь: §f.gps <x> <z>");
			} else {
				out.accept("§aМетки GPS (" + gps.count() + "):");
				for (ru.neuclient.client.config.GpsManager.Marker m : gps.markers()) {
					out.accept(" §8- §f" + m.x() + "§7, §f" + m.z());
				}
			}
			return;
		}
		if (args.size() >= 3) {
			int x;
			int z;
			try {
				x = Integer.parseInt(args.get(1));
				z = Integer.parseInt(args.get(2));
			} catch (NumberFormatException e) {
				out.accept("§cКоординаты должны быть целыми числами. Пример: §f.gps 1500 -2300");
				return;
			}
			if (!gps.add(x, z)) {
				out.accept("§cСлишком много меток (макс. 32). Очисти: §f.gps clear");
				return;
			}
			// Метка создана молча (без спама в чат)
			return;
		}
		out.accept("§7.gps <x> <z> §8- метка по нужным координатам §7| .gps list §8- список §7| .gps clear §8- убрать все");
	}

	private void printHelp(Consumer<String> out) {
		out.accept("§aКоманды NeuClient:");
		out.accept("§7.friend add <ник> §8- добавить друга");
		out.accept("§7.friend rem <ник> §8- удалить друга");
		out.accept("§7.friend list §8- список друзей");
		out.accept("§7.cfg dir §8- открыть папку клиента");
		out.accept("§7.cfg save/load <имя> §8- сохранить/загрузить конфиг");
		out.accept("§7.cfg rem <имя> §8- удалить конфиг");
		out.accept("§7.cfg list §8- список конфигов");
		out.accept("§7.gps <x> <z> §8- метка по нужным координатам");
		out.accept("§7.panic §8- скрывает полностью клиент на проверке");
	}

	// ===== Подсказки в строке чата (рисует ChatScreenMixin) =====

	/** Корневые команды клиента. */
	private static final String[] ROOTS = { ".friend", ".cfg", ".gps", ".panic", ".help" };

	/** Подкоманды: корень → список. */
	private static final java.util.Map<String, String[]> SUBS = java.util.Map.of(
			".friend", new String[] { "add", "rem", "list" },
			".cfg", new String[] { "save", "load", "rem", "dir", "list" },
			".gps", new String[] { "list", "clear" },
			".panic", new String[] {},
			".help", new String[] {}
	);

	/**
	 * Подсказки для текущего содержимого строки чата.
	 * Возвращает готовые строки (например ".cfg save"), первый элемент — приоритетный.
	 * Пустой список = подсказывать нечего.
	 */
	public static List<String> suggest(String text) {
		if (text == null || !text.startsWith(PREFIX)) {
			return List.of();
		}
		// Паника: никаких подсказок наших команд — чат чистый, как у ваниллы
		NeuClient owner = NeuClient.getInstance();
		if (owner != null && owner.isPanicked()) {
			return List.of();
		}
		String[] tokens = text.split(" ", -1);
		List<String> result = new java.util.ArrayList<>();

		if (tokens.length == 1) {
			// Печатаем корень: ".", ".f", ".cf..."
			String typed = tokens[0].toLowerCase(Locale.ROOT);
			String[] subs = SUBS.get(typed);
			if (subs != null) {
				// Корень набран ровно → сразу показываем его подкоманды
				for (String sub : subs) {
					result.add(typed + " " + sub);
				}
			} else {
				for (String root : ROOTS) {
					if (root.startsWith(typed)) {
						result.add(root);
					}
				}
			}
			return result;
		}

		if (tokens.length == 2) {
			// Печатаем подкоманду: ".cfg s..." (prefix может быть пустым)
			String root = tokens[0].toLowerCase(Locale.ROOT);
			String prefix = tokens[1].toLowerCase(Locale.ROOT);
			String[] subs = SUBS.get(root);
			if (subs == null) {
				return List.of();
			}
			for (String sub : subs) {
				if (sub.startsWith(prefix) && !sub.equals(prefix)) {
					result.add(root + " " + sub);
				}
			}
			return result;
		}

		// Дальше идут аргументы (ники, имена конфигов) — не подсказываем
		return List.of();
	}

	/**
	 * Автодополнение по Tab: возвращает новый текст строки чата
	 * или null, если дополнять нечего.
	 */
	public static String complete(String text) {
		List<String> sugs = suggest(text);
		if (sugs.isEmpty()) {
			return null;
		}
		String best = sugs.get(0);
		// Если дополнили корень, у которого есть подкоманды, — ставим пробел,
		// чтобы следующий Tab сразу предложил подкоманды
		if (!best.contains(" ") && SUBS.containsKey(best) && SUBS.get(best).length > 0) {
			best += " ";
		}
		return best;
	}
}
