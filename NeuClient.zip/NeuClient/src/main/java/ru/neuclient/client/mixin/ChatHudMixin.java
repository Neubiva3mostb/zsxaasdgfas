package ru.neuclient.client.mixin;

import net.minecraft.client.gui.hud.ChatHud;
import net.minecraft.client.gui.hud.ChatHudLine;
import net.minecraft.client.gui.hud.MessageIndicator;
import net.minecraft.network.message.MessageSignatureData;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.neuclient.client.module.impl.misc.AntiSpamModule;
import ru.neuclient.client.module.impl.player.AutoAcceptModule;
import ru.neuclient.client.module.impl.player.AutoAuthModule;
import ru.neuclient.client.util.NameProtectUtil;

import java.util.List;

/**
 * Обработка входящих сообщений чата (обычные, смерти, килл-фид, /msg).
 *
 *  1. AutoAccept — принимает запрос телепорта по сырому тексту.
 *  2. NameProtect — подменяет ник в отображении.
 *  3. AntiSpam — схлопывает повторы: повтор не выводится новой строкой,
 *     а обновляет счётчик «[n]» у уже показанного сообщения.
 *
 * История команд и сервер не затрагиваются.
 */
@Mixin(ChatHud.class)
public abstract class ChatHudMixin {

	@Shadow
	@Final
	private List<ChatHudLine> messages;

	@Shadow
	private void refresh() {
	}

	@ModifyVariable(
			method = "addMessage(Lnet/minecraft/text/Text;Lnet/minecraft/network/message/MessageSignatureData;Lnet/minecraft/client/gui/hud/MessageIndicator;)V",
			at = @At("HEAD"), argsOnly = true)
	private Text pc$nameProtect(Text message) {
		try {
			AutoAcceptModule accept = AutoAcceptModule.active();
			if (accept != null) {
				accept.onChatMessage(message.getString());
			}
			AutoAuthModule auth = AutoAuthModule.active();
			if (auth != null) {
				auth.onChatMessage(message.getString());
			}
		} catch (Throwable t) {
			// Хуки чата не должны мешать отображению обычного чата
		}
		return NameProtectUtil.transformIfActive(message);
	}

	@Inject(
			method = "addMessage(Lnet/minecraft/text/Text;Lnet/minecraft/network/message/MessageSignatureData;Lnet/minecraft/client/gui/hud/MessageIndicator;)V",
			at = @At("HEAD"), cancellable = true)
	private void pc$antiSpam(Text message, MessageSignatureData signature,
			MessageIndicator indicator, CallbackInfo ci) {
		try {
			// Тот же текст, что уйдёт в чат через nameProtect — чтобы ключ совпал
			Text base = NameProtectUtil.transformIfActive(message);
			int count = AntiSpamModule.onMessage(base);
			if (count < 2) {
				return; // первое сообщение — показываем как обычно
			}

			String key = AntiSpamModule.keyOf(base);
			if (key.isEmpty()) {
				return;
			}

			// Ищем уже показанную строку с тем же ключом (с конца — она свежая)
			int idx = -1;
			for (int i = messages.size() - 1; i >= 0; i--) {
				if (key.equals(AntiSpamModule.keyOfLine(messages.get(i).content()))) {
					idx = i;
					break;
				}
			}
			if (idx < 0) {
				return; // исходная строка уже вытеснена — пусть повторйдёт как новый
			}

			Text newContent = base.copy().append(
					Text.literal(" [" + count + "]").formatted(Formatting.GRAY));
			ChatHudLine old = messages.get(idx);
			messages.set(idx, new ChatHudLine(
					old.creationTick(), newContent, old.signature(), old.indicator()));
			refresh();
			ci.cancel();
		} catch (Throwable t) {
			// Никогда не ломаем чат: при любой ошибке сообщение просто покажется
		}
	}
}
