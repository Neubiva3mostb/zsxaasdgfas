package ru.neuclient.client.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

import java.util.Locale;

/**
 * Числовая настройка (слайдер) с диапазоном и шагом.
 */
public class NumberSetting extends Setting<Double> {

	private final double min;
	private final double max;
	private final double step;

	public NumberSetting(String name, double defaultValue, double min, double max, double step) {
		super(name, defaultValue);
		this.min = min;
		this.max = max;
		this.step = step;
	}

	public double getMin() {
		return min;
	}

	public double getMax() {
		return max;
	}

	public double getStep() {
		return step;
	}

	/** Установка значения с округлением до шага и обрезкой по диапазону. */
	public void setClamped(double raw) {
		double stepped = Math.round(raw / step) * step;
		double clamped = Math.max(min, Math.min(max, stepped));
		// Убираем ошибки плавающей точки (0.30000000000004)
		clamped = Math.round(clamped * 1000.0) / 1000.0;
		set(clamped);
	}

	/** Относительная позиция [0..1] для отрисовки слайдера. */
	public double fraction() {
		return (get() - min) / (max - min);
	}

	/** Красивое короткое представление: 50, 2.5 и т.п. */
	public String format() {
		double v = get();
		if (v == Math.floor(v)) {
			return String.valueOf((long) v);
		}
		return String.format(Locale.ROOT, "%.3g", v);
	}

	@Override
	public JsonElement toJson() {
		return new JsonPrimitive(get());
	}

	@Override
	public void fromJson(JsonElement element) {
		if (element != null && element.isJsonPrimitive()) {
			setClamped(element.getAsDouble());
		}
	}
}
