package ru.neuclient.client.module.impl.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.BooleanSetting;

/**
 * NoRender — выключает выбранные визуальные элементы клиента.
 *
 * Всё чисто клиентское: ни один пакет не меняется, сервер ничего не заметит.
 * Конкретная резка живёт в миксинах (entites/небо/туман/частицы/оверлеи/
 * тотем/камера) — здесь только настройки + снятие тошноты по тику.
 */
public final class NoRenderModule extends Module {

	private final BooleanSetting itemFrames = new BooleanSetting("Рамки с предметами", true);
	private final BooleanSetting sky = new BooleanSetting("Небо", true);
	private final BooleanSetting armorStands = new BooleanSetting("Стойки для брони", true);
	private final BooleanSetting droppedItems = new BooleanSetting("Предметы на земле", true);
	private final BooleanSetting worldFog = new BooleanSetting("Туман мира", true);
	private final BooleanSetting particles = new BooleanSetting("Частицы", true);
	private final BooleanSetting liquidOverlay = new BooleanSetting("Оверлей воды/лавы", true);
	private final BooleanSetting pumpkinOverlay = new BooleanSetting("Оверлей тыквы", true);
	private final BooleanSetting badEffects = new BooleanSetting("Плохие эффекты", true);
	private final BooleanSetting totemPop = new BooleanSetting("Снесение тотема", true);
	private final BooleanSetting freeCamera = new BooleanSetting("Свободная камера", true);

	public NoRenderModule() {
		super("NoRender", "Отключает выбранные визуальные элементы", Category.RENDER);
		addSettings(itemFrames, sky, armorStands, droppedItems, worldFog, particles,
				liquidOverlay, pumpkinOverlay, badEffects, totemPop, freeCamera);
	}

	@Override
	public void onTick(MinecraftClient client) {
		ClientPlayerEntity player = client.player;
		// Тошнота крутится двумя полями клиентского игрока — гасим их,
		// и эффект «плывущего» экрана пропадает полностью. Слепота/тьма
		// режутся в тумане (FogRendererMixin).
		if (badEffects.get() && player != null) {
			player.nauseaIntensity = 0.0f;
			player.lastNauseaIntensity = 0.0f;
		}
	}

	// ===== Геттеры для миксинов =====

	public boolean noItemFrames() {
		return isEnabled() && itemFrames.get();
	}

	public boolean noSky() {
		return isEnabled() && sky.get();
	}

	public boolean noArmorStands() {
		return isEnabled() && armorStands.get();
	}

	public boolean noDroppedItems() {
		return isEnabled() && droppedItems.get();
	}

	public boolean noWorldFog() {
		return isEnabled() && worldFog.get();
	}

	public boolean noParticles() {
		return isEnabled() && particles.get();
	}

	public boolean noLiquidOverlay() {
		return isEnabled() && liquidOverlay.get();
	}

	public boolean noPumpkinOverlay() {
		return isEnabled() && pumpkinOverlay.get();
	}

	public boolean noBadEffects() {
		return isEnabled() && badEffects.get();
	}

	public boolean noTotemPop() {
		return isEnabled() && totemPop.get();
	}

	public boolean freeCamera() {
		return isEnabled() && freeCamera.get();
	}
}
