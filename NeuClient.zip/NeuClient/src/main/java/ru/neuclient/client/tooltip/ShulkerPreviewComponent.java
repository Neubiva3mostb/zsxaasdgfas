package ru.neuclient.client.tooltip;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.tooltip.TooltipComponent;
import net.minecraft.item.ItemStack;

import java.util.List;

/**
 * Рендер превью шалкера внутри тултипа: тёмная панель с иконками предметов
 * и их количеством (оверлей, как в слоте). Компакт — одна строка до 5 штук,
 * полный (Ctrl) — сетка 9×3 как внутри настоящего шалкера.
 */
public final class ShulkerPreviewComponent implements TooltipComponent {

	/** Шаг сетки (иконка 16px + 2px зазор). */
	private static final int CELL = 18;
	/** Колонок в полном режиме (как в интерфейсе шалкера). */
	private static final int FULL_COLS = 9;

	private final ShulkerPreviewData data;

	public ShulkerPreviewComponent(ShulkerPreviewData data) {
		this.data = data;
	}

	private int cols() {
		if (data.full()) {
			return FULL_COLS;
		}
		return Math.min(5, Math.max(1, data.stacks().size()));
	}

	private int rows() {
		if (data.full()) {
			return Math.max(1, (data.stacks().size() + FULL_COLS - 1) / FULL_COLS);
		}
		return 1;
	}

	@Override
	public int getWidth(TextRenderer textRenderer) {
		return cols() * CELL;
	}

	@Override
	public int getHeight(TextRenderer textRenderer) {
		return rows() * CELL + 2;
	}

	@Override
	public void drawItems(TextRenderer textRenderer, int x, int y, int width, int height,
			DrawContext context) {
		int w = getWidth(textRenderer);
		int h = rows() * CELL;

		// Рамка + тёмный фон панели (в стиле оригинального ShulkerBoxTooltip)
		context.fill(x - 1, y - 1, x + w + 1, y + h + 1, 0xFF1B1B29);
		context.fill(x, y, x + w, y + h, 0xF0100010);

		List<ItemStack> stacks = data.stacks();
		int cols = cols();
		for (int i = 0; i < cols * rows(); i++) {
			int gx = x + (i % cols) * CELL + 1;
			int gy = y + (i / cols) * CELL + 1;
			if (i < stacks.size()) {
				ItemStack stack = stacks.get(i);
				if (!stack.isEmpty()) {
					context.drawItem(stack, gx, gy);
					context.drawStackOverlay(textRenderer, stack, gx, gy);
				}
			} else if (data.full()) {
				// Пустая клетка сетки (только в полном режиме)
				context.fill(gx, gy, gx + 16, gy + 16, 0x30000000);
			}
		}
	}
}
