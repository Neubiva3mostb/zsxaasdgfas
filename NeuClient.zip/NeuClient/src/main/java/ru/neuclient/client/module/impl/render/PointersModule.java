package ru.neuclient.client.module.impl.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.BooleanSetting;
import ru.neuclient.client.setting.ColorSetting;
import ru.neuclient.client.setting.NumberSetting;

/**
 * Pointers — экранные стрелочки вокруг прицела, указывающие направление к игрокам
 * (аналог .gps, но на игроков и без расстояния, только стрелки).
 */
public final class PointersModule extends Module {

	private static final Identifier POINTER_TEXTURE = Identifier.of("perfstream", "textures/gui/pointer.png");
	private static final float ARROW_RADIUS = 46.0f;
	private static final float ARROW_SIZE = 16.0f;

	private final ColorSetting color = new ColorSetting("Цвет", 0xFF7A5CFF);
	private final BooleanSetting friends = new BooleanSetting("Друзья", true);
	private final NumberSetting maxDistance = new NumberSetting("Дистанция", 80.0, 16.0, 256.0, 8.0);

	public PointersModule() {
		super("Pointers", "Стрелочки к игрокам вокруг прицела", Category.RENDER);
		addSettings(color, friends, maxDistance);
	}

	public void renderHud(DrawContext ctx, MinecraftClient client) {
		ClientPlayerEntity player = client.player;
		if (client.world == null || player == null) {
			return;
		}

		float cx = ctx.getScaledWindowWidth() / 2.0f;
		float cy = ctx.getScaledWindowHeight() / 2.0f;

		double px = player.getX();
		double pz = player.getZ();
		float playerYaw = player.getYaw();

		float tickDelta = client.getRenderTickCounter().getTickProgress(false);
		int arrowHalf = Math.round(ARROW_SIZE / 2.0f);
		int arrowDim = Math.round(ARROW_SIZE);
		double maxDist = maxDistance.get();

		int normalColor = color.get();
		int friendColor = 0xFF55FF55;
		var friendManager = NeuClient.getInstance() != null ? NeuClient.getInstance().getFriendManager() : null;

		for (PlayerEntity other : client.world.getPlayers()) {
			if (other == player || !other.isAlive()) {
				continue;
			}

			Vec3d targetPos = other.getLerpedPos(tickDelta);
			double dx = targetPos.x - px;
			double dz = targetPos.z - pz;
			double dist = Math.hypot(dx, dz);
			if (dist > maxDist || dist < 0.5) {
				continue;
			}

			// Угол на цель в горизонтальной плоскости мира
			double targetAngle = Math.toDegrees(Math.atan2(dz, dx)) - 90.0;
			// Разница углов относительно направления взгляда игрока
			float diffYaw = (float) MathHelper.wrapDegrees(targetAngle - playerYaw);
			float rad = (float) Math.toRadians(diffYaw);

			// Позиция стрелочки на окружности вокруг центра экрана
			float arrowX = cx + (float) Math.sin(rad) * ARROW_RADIUS;
			float arrowY = cy - (float) Math.cos(rad) * ARROW_RADIUS;

			boolean isFriend = friends.get() && friendManager != null && friendManager.isFriend(other.getName().getString());
			int arrowColor = isFriend ? friendColor : normalColor;

			var m = ctx.getMatrices();
			m.pushMatrix();
			m.translate(arrowX, arrowY);
			m.rotate((float) Math.toRadians(diffYaw));

			ctx.drawTexture(
					RenderPipelines.GUI_TEXTURED,
					POINTER_TEXTURE,
					-arrowHalf, -arrowHalf,
					0.0f, 0.0f,
					arrowDim, arrowDim,
					628, 640,
					628, 640,
					arrowColor
			);

			m.popMatrix();
		}
	}

	public static void renderAllHud(DrawContext ctx) {
		var client = NeuClient.getInstance();
		if (client == null || client.isPanicked() || client.getModuleManager() == null) {
			return;
		}
		PointersModule module = client.getModuleManager().get(PointersModule.class);
		if (module != null && module.isEnabled()) {
			module.renderHud(ctx, MinecraftClient.getInstance());
		}
	}
}
