package ru.neuclient.client.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.font.MsdfFontRenderer;
import ru.neuclient.client.font.MsdfFonts;
import ru.neuclient.client.util.ClientPaths;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/**
 * GpsManager — метки-путеводители команды .gps.
 *
 * Вместо луча в мире рисует стильные стрелочки вокруг прицела (pointer.png)
 * с указанием точного расстояния в метрах/блоках до места назначения.
 */
public class GpsManager {

	private static final int MAX_MARKERS = 32;

	private static final Identifier POINTER_TEXTURE = Identifier.of("perfstream", "textures/gui/pointer.png");
	private static final float ARROW_SIZE = 16.0f;
	private static final float ARROW_RADIUS = 46.0f;
	private static final float TEXT_RADIUS = 60.0f;
	private static final float FONT_SIZE = 8.0f;

	/** Цвета меток по кругу. */
	private static final int[] COLORS = {
			0xFF55BFFF, // голубой
			0xFF7CFF6B, // салатовый
			0xFFFFB84D, // янтарный
			0xFFD18AFF, // сиреневый
			0xFFFF7A6B, // коралловый
			0xFFFFF36B  // лимонный
	};

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

	public record Marker(int x, int z, int color) {
	}

	private final List<Marker> markers = new ArrayList<>();
	private int colorCursor;

	public boolean add(int x, int z) {
		if (markers.size() >= MAX_MARKERS) {
			return false;
		}
		addInternal(x, z);
		save();
		return true;
	}

	public int clear() {
		int n = markers.size();
		if (n > 0) {
			markers.clear();
			save();
		}
		return n;
	}

	public List<Marker> markers() {
		return List.copyOf(markers);
	}

	public int count() {
		return markers.size();
	}

	private void addInternal(int x, int z) {
		markers.add(new Marker(x, z, COLORS[colorCursor % COLORS.length]));
		colorCursor++;
	}

	public void load() {
		Path file = ClientPaths.file("gps.json");
		if (!Files.exists(file)) {
			return;
		}
		try (Reader reader = Files.newBufferedReader(file)) {
			JsonObject root = JsonParser.parseReader(reader).getAsJsonObject();
			JsonArray array = root.getAsJsonArray("markers");
			if (array != null) {
				for (JsonElement element : array) {
					if (markers.size() >= MAX_MARKERS) {
						break;
					}
					JsonObject obj = element.getAsJsonObject();
					addInternal(obj.get("x").getAsInt(), obj.get("z").getAsInt());
				}
			}
			NeuClient.LOGGER.info("[NeuClient] GPS-меток загружено: {}", markers.size());
		} catch (Exception e) {
			NeuClient.LOGGER.error("[NeuClient] Не удалось прочитать gps.json", e);
		}
	}

	public void save() {
		NeuClient client = NeuClient.getInstance();
		if (client != null && client.isPanicked()) {
			return;
		}
		JsonObject root = new JsonObject();
		JsonArray array = new JsonArray();
		for (Marker marker : markers) {
			JsonObject obj = new JsonObject();
			obj.addProperty("x", marker.x());
			obj.addProperty("z", marker.z());
			array.add(obj);
		}
		root.add("markers", array);
		try (Writer writer = Files.newBufferedWriter(ClientPaths.file("gps.json"))) {
			GSON.toJson(root, writer);
		} catch (Exception e) {
			NeuClient.LOGGER.error("[NeuClient] Не удалось записать gps.json", e);
		}
	}

	// ===== Отрисовка стрелочек вокруг прицела (HUD-проход) =====

	private void renderHud(DrawContext ctx, MinecraftClient client) {
		ClientPlayerEntity player = client.player;
		if (markers.isEmpty() || client.world == null || player == null) {
			return;
		}

		float cx = ctx.getScaledWindowWidth() / 2.0f;
		float cy = ctx.getScaledWindowHeight() / 2.0f;

		double px = player.getX();
		double pz = player.getZ();
		float playerYaw = player.getYaw();

		for (Marker marker : List.copyOf(markers)) {
			double dx = marker.x() + 0.5 - px;
			double dz = marker.z() + 0.5 - pz;
			long dist = Math.round(Math.hypot(dx, dz));

			// Угол на цель в плоскости мира
			double targetAngle = Math.toDegrees(Math.atan2(dz, dx)) - 90.0;
			// Угол относительно текущей камеры игрока (0 = строго в прицеле, 90 = справа, 180 = сзади, -90 = слева)
			float diffYaw = (float) MathHelper.wrapDegrees(targetAngle - playerYaw);
			float rad = (float) Math.toRadians(diffYaw);

			// Позиция стрелочки вокруг центра экрана
			float arrowX = cx + (float) Math.sin(rad) * ARROW_RADIUS;
			float arrowY = cy - (float) Math.cos(rad) * ARROW_RADIUS;

			// 1. Отрисовка повёрнутой стрелочки
			var m = ctx.getMatrices();
			m.pushMatrix();
			m.translate(arrowX, arrowY);
			m.rotate((float) Math.toRadians(diffYaw));

			int arrowHalf = Math.round(ARROW_SIZE / 2.0f);
			int arrowDim = Math.round(ARROW_SIZE);
			ctx.drawTexture(
					RenderPipelines.GUI_TEXTURED,
					POINTER_TEXTURE,
					-arrowHalf, -arrowHalf,
					0.0f, 0.0f,
					arrowDim, arrowDim,
					628, 640,
					628, 640,
					marker.color()
			);

			m.popMatrix();

			// 2. Отрисовка расстояния рядом со стрелочкой (MSDF SF Pro)
			float textX = cx + (float) Math.sin(rad) * TEXT_RADIUS;
			float textY = cy - (float) Math.cos(rad) * TEXT_RADIUS;
			String distStr = dist + "м";
			MsdfFontRenderer.drawCenteredWithShadow(ctx, MsdfFonts.sfMedium(), distStr,
					textX, textY - 4.0f, marker.color(), FONT_SIZE);
		}
	}

	// ===== Диспетчеры =====

	private static GpsManager active() {
		NeuClient client = NeuClient.getInstance();
		if (client == null || client.getGpsManager() == null || client.isPanicked()) {
			return null;
		}
		GpsManager manager = client.getGpsManager();
		return manager.count() > 0 ? manager : null;
	}

	public static void renderAllWorld(WorldRenderContext context) {
		// Мировой луч отключён в пользу чистых экранных стрелочек у прицела
	}

	public static void renderAllHud(DrawContext ctx) {
		GpsManager manager = active();
		if (manager != null) {
			manager.renderHud(ctx, MinecraftClient.getInstance());
		}
	}
}
