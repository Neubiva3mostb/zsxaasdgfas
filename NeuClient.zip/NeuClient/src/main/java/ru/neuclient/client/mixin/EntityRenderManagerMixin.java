package ru.neuclient.client.mixin;

import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.entity.EntityRenderManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.decoration.ItemFrameEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.impl.render.NoRenderModule;

/**
 * NoRender: скрывает рамки с предметами (включая светящиеся), стойки
 * для брони и лежащие на земле предметы. Чисто клиентский рендер —
 * сущности на сервере никуда не деваются.
 */
@Mixin(EntityRenderManager.class)
public abstract class EntityRenderManagerMixin {

	@Inject(method = "shouldRender", at = @At("HEAD"), cancellable = true)
	private void pc$hideEntities(Entity entity, Frustum frustum, double x, double y, double z,
			CallbackInfoReturnable<Boolean> cir) {
		NoRenderModule module = pc$noRender();
		if (module == null) {
			return;
		}
		if (module.noItemFrames()
				&& entity instanceof ItemFrameEntity frame
				&& !frame.getHeldItemStack().isEmpty()) {
			cir.setReturnValue(false);
			return;
		}
		if (module.noArmorStands() && entity instanceof ArmorStandEntity) {
			cir.setReturnValue(false);
			return;
		}
		if (module.noDroppedItems() && entity instanceof ItemEntity) {
			cir.setReturnValue(false);
		}
	}

	private static NoRenderModule pc$noRender() {
		NeuClient client = NeuClient.getInstance();
		if (client == null || client.getModuleManager() == null) {
			return null;
		}
		NoRenderModule module = client.getModuleManager().get(NoRenderModule.class);
		return module != null && module.isEnabled() ? module : null;
	}
}
