package ru.neuclient.client.module.impl.combat;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;

/**
 * Criticals — каждый удар при полном кулдауне становится критом,
 * БЕЗ прыжка и БЕЗ фейковых пакетов. Логика как у классического
 * клиентского крит-модуля (motionY = 0.1), адаптированная под 1.21.11.
 *
 * Механика: сервер САМ считает fallDistance игрока по пакетам движения,
 * а крит засчитывает, когда fallDistance > 0, игрок не на земле и не в
 * спринте. Подменённых пакетов («телепорт вверх-вниз») современные
 * античиты игнорируют или ловят — поэтому вместо них даём РЕАЛЬНЫЙ
 * микро-импульс: скорость по Y ставится = 0.1 (высота подъёма ~0.05 блока,
 * на экране незаметно). Дальше клиент честно «падает» пару тиков, сервер
 * видит fallDistance > 0 — и удар, который модуль исполняет сам на спаде,
 * засчитывается критом ×1.5.
 *
 * Пока летим — спринт выключен (в спринте крит сервером не засчитывается),
 * после удара спринт возвращается. Если импульс «съеден» (потолок) —
 * клик не теряется: удар всё равно исполняется. Без настроек.
 */
public final class CriticalsModule extends Module {

	/** Реальный микро-импульс вверх (как motionY=0.1 у классики). */
	private static final double MICRO_BOOST = 0.1;

	/** Цель отложенного крит-удара (null = нет отложенного). */
	private Entity pending;
	/** Тиков с момента импульса (защита от зависания). */
	private int waitTicks;
	/** Был ли игрок в спринте до связки (вернуть после удара). */
	private boolean restoreSprint;
	/** true = attackEntity вызван нами самими (защита от рекурсии). */
	private boolean processing;

	public CriticalsModule() {
		super("Criticals", "Криты без прыжка", Category.COMBAT);
	}

	/** Свой отложенный удар сейчас исполняется (для других модулей). */
	public boolean isProcessing() {
		return processing;
	}

	/**
	 * HEAD миксина атаки.
	 * @param player     атакующий
	 * @param target     цель
	 * @param shieldBusy ShieldBreaker в этот момент исполняет свой удар
	 * @return true — ванильный удар отменить (мы нанесём крит сами на спаде).
	 */
	public boolean onAttackStart(PlayerEntity player, Entity target, boolean shieldBusy) {
		if (processing || shieldBusy) {
			return false; // наш (или ShieldBreaker-а) удар — не трогаем
		}
		if (pending != null) {
			return true; // уже летим за критом — спам-удары гасим
		}
		if (!(target instanceof LivingEntity)) {
			return false; // криты работают только по живым
		}

		// Условия, где крит возможен: стоим на земле, не карабкаемся,
		// не в воде/лаве, не в транспорте. В воздухе не лезем — ванилла сама.
		if (!player.isOnGround()
				|| player.hasVehicle()
				|| player.isClimbing()
				|| player.isTouchingWater()
				|| player.isInLava()) {
			return false;
		}
		// Неполный кулдаун — крита всё равно не будет, не дёргаемся
		if (player.getAttackCooldownProgress(0.5f) < 0.9f) {
			return false;
		}

		// 1) Сразу гасим спринт: сервер крит в спринте НЕ засчитывает,
		//    а STOP_SPRINT успеет дойти до сервера раньше удара
		restoreSprint = player.isSprinting();
		player.setSprinting(false);

		// 2) Реальный микро-импульс вверх (motionY = 0.1) — движение честное,
		//    сервер сам посчитает fallDistance по обычным пакетам позиции
		player.setVelocity(player.getVelocity().x, MICRO_BOOST, player.getVelocity().z);

		// 3) Удар исполним сами, когда начнём падать (fallDistance > 0)
		pending = target;
		waitTicks = 0;
		return true;
	}

	@Override
	public void onTick(MinecraftClient client) {
		if (pending == null) {
			return;
		}
		if (client.player == null || client.interactionManager == null) {
			clearAndRestoreSprint(client);
			return;
		}
		if (!pending.isAlive()) {
			clearAndRestoreSprint(client);
			return;
		}
		waitTicks++;
		if (waitTicks > 10) {
			// Импульс «съели» (потолок/странный тик) — клик не теряем,
			// бьём как есть (пусть обычным, чем никак)
			performAttack(client);
			return;
		}

		// Всё ожидание держим спринт выключенным (AutoSprint не вернёт его)
		client.player.setSprinting(false);

		if (client.player.fallDistance > 0.0f && !client.player.isOnGround()) {
			// Началось падение: fallDistance > 0, не на земле, не в спринте —
			// все три условия крита выполнены
			performAttack(client);
			return;
		}
	}

	/** Исполнить отложенный удар (с махом руки, как у живого клика). */
	private void performAttack(MinecraftClient client) {
		Entity target = pending;
		pending = null;
		waitTicks = 0;
		processing = true;
		try {
			client.player.setSprinting(false); // страховка прямо перед ударом
			client.player.swingHand(Hand.MAIN_HAND);
			client.interactionManager.attackEntity(client.player, target);
		} finally {
			processing = false;
		}
		// Возвращаем спринт, если он был до связки
		if (restoreSprint) {
			restoreSprint = false;
			client.player.setSprinting(true);
		}
	}

	/** Сброс состояния + возврат спринта при аварийной отмене связки. */
	private void clearAndRestoreSprint(MinecraftClient client) {
		pending = null;
		waitTicks = 0;
		if (restoreSprint && client.player != null) {
			restoreSprint = false;
			client.player.setSprinting(true);
		}
	}

	@Override
	protected void onDisable() {
		pending = null;
		waitTicks = 0;
		restoreSprint = false;
		processing = false;
	}
}
