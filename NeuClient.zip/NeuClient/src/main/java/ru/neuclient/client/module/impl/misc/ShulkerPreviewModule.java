package ru.neuclient.client.module.impl.misc;

import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ContainerComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.lwjgl.glfw.GLFW;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.tooltip.ShulkerPreviewData;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * ShulkerPreview — визуальное превью шалкера в тултипе, в стиле мода
 * ShulkerBoxTooltip: тёмная панель с иконками предметов внутри тултипа.
 *
 *  - простое наведение: одна строка до 5 иконок (одинаковые предметы
 *    склеиваются, суммарное количество рисуется оверлеем);
 *  - зажатый Ctrl:      вся сетка 9×3, как окно настоящего шалкера;
 *  - подсказка «Ctrl — показать всё» висит строкой под тултипом.
 *
 * Рендер панели живёт в ShulkerPreviewComponent и вклинивается в ванильные
 * тултипы через TooltipComponentCallback (зарегистрирован в NeuClient).
 */
public final class ShulkerPreviewModule extends Module {

	/** Лимит иконок в компактной строке. */
	private static final int SHORT_LIMIT = 5;

	public ShulkerPreviewModule() {
		super("ShulkerPreview", "Показывает содержимое шалкера", Category.MISC);
	}

	/**
	 * Данные для визуальной панели (вызывается из миксина getTooltipData).
	 * @return ShulkerPreviewData или null, если не шалкер/пусто.
	 */
	public ShulkerPreviewData buildData(ItemStack stack) {
		ContainerComponent container = containerOf(stack);
		if (container == null) {
			return null;
		}

		if (isCtrlDown()) {
			// Полная сетка 9×3 — как есть, без склейки
			List<ItemStack> all = new ArrayList<>();
			container.iterateNonEmpty().forEach(all::add);
			if (all.isEmpty()) {
				return null;
			}
			return new ShulkerPreviewData(all, true);
		}

		// Компактная строка: склеиваем одинаковые предметы, берём до 5 штук
		Map<String, Integer> grouped = new LinkedHashMap<>();
		Map<String, ItemStack> sample = new LinkedHashMap<>();
		container.iterateNonEmpty().forEach(s -> {
			String key = s.getName().getString();
			grouped.merge(key, s.getCount(), Integer::sum);
			sample.putIfAbsent(key, s);
		});
		if (grouped.isEmpty()) {
			return null;
		}

		List<ItemStack> compact = new ArrayList<>();
		int shown = 0;
		for (Map.Entry<String, Integer> e : grouped.entrySet()) {
			if (shown >= SHORT_LIMIT) {
				break;
			}
			ItemStack icon = sample.get(e.getKey()).copy();
			icon.setCount(Math.min(e.getValue(), 99)); // оверлей до двух цифр читаемо
			compact.add(icon);
			shown++;
		}
		return compact.isEmpty() ? null : new ShulkerPreviewData(compact, false);
	}

	/**
	 * Строка-подсказка в конец текстового тултипа (миксин getTooltip).
	 * @return 0 или 1 строка.
	 */
	public List<Text> buildExtraLines(ItemStack stack, TooltipType type) {
		List<Text> out = new ArrayList<>();
		if (containerOf(stack) == null) {
			return out;
		}
		if (!isCtrlDown()) {
			out.add(Text.literal("Ctrl — показать всё").formatted(Formatting.DARK_GRAY));
		}
		return out;
	}

	/** Контейнер шалкера (или null, если не шалкер/пустой компонент). */
	private ContainerComponent containerOf(ItemStack stack) {
		if (!stack.isIn(ItemTags.SHULKER_BOXES)) {
			return null;
		}
		return stack.get(DataComponentTypes.CONTAINER);
	}

	/** Зажат ли Ctrl (любой) прямо сейчас, по состоянию окна. */
	private boolean isCtrlDown() {
		long handle = mc.getWindow() != null ? mc.getWindow().getHandle() : 0L;
		if (handle == 0L) {
			return false;
		}
		return GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_LEFT_CONTROL) == GLFW.GLFW_PRESS
				|| GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_RIGHT_CONTROL) == GLFW.GLFW_PRESS;
	}
}
