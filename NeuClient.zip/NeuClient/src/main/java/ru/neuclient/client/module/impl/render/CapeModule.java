package ru.neuclient.client.module.impl.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.model.PlayerCapeModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.mixin.BipedEntityModelAccessor;
import ru.neuclient.client.mixin.PlayerCapeModelAccessor;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.render.HdCapeRenderLayer;

import java.util.concurrent.ThreadLocalRandom;

/** Локальный декоративный HD-плащ NeuClient. */
public final class CapeModule extends Module {

	/** Fallback asset id стандартной cape-текстуры. */
	public static final Identifier CAPE_TEXTURE = Identifier.of(
			NeuClient.MOD_ID, "cape/hd");
	/** Полноразмерная текстура с соотношением 5:8. */
	public static final Identifier HD_TEXTURE = Identifier.of(
			NeuClient.MOD_ID, "textures/cape/hd.png");

	/** Vanilla-модель нужна только для точных pivot/rotation плеч и плаща. */
	private static final PlayerCapeModel MODEL = new PlayerCapeModel(
			PlayerCapeModel.getTexturedModelData().createModel());

	// Состояние редкого порыва ветра во время полного простоя.
	private static long lastActivityMs;
	private static long nextWindMs;
	private static long windStartMs;
	private static long windDurationMs;
	private static boolean windArmed;
	private static boolean windActive;
	private static float lastYaw;
	private static float lastPitch;

	public CapeModule() {
		super("Cape", "Плащ NeuClient", Category.RENDER);
		// Плащ включён из коробки, как Interface.
		setEnabled(true);
	}

	@Override
	protected void onEnable() {
		resetWindState();
	}

	@Override
	protected void onDisable() {
		resetWindState();
	}

	private static void resetWindState() {
		lastActivityMs = System.currentTimeMillis();
		nextWindMs = 0L;
		windStartMs = 0L;
		windDurationMs = 0L;
		windArmed = false;
		windActive = false;
		lastYaw = Float.NaN;
		lastPitch = Float.NaN;
	}

	public static CapeModule active() {
		NeuClient client = NeuClient.getInstance();
		if (client == null || client.getModuleManager() == null) return null;
		CapeModule cape = client.getModuleManager().get(CapeModule.class);
		return cape != null && cape.isEnabled() ? cape : null;
	}

	/** HD-текстура на vanilla-pivot с сегментной cloth-физикой. */
	public static void renderHd(MatrixStack matrices, OrderedRenderCommandQueue queue,
			int light, PlayerEntityRenderState state) {
		if (active() == null || queue == null) return;

		MODEL.setAngles(state);
		ModelPart body = ((BipedEntityModelAccessor) MODEL).pc$getBody();
		ModelPart cape = ((PlayerCapeModelAccessor) MODEL).pc$getCape();

		// Применяем ровно те же parent transforms, что и vanilla:
		// body pivot → cape pivot → cape rotation. Это исключает смещение
		// к ногам и зависимость положения от камеры.
		matrices.push();
		body.applyTransform(matrices);
		cape.applyTransform(matrices);

		MinecraftClient client = MinecraftClient.getInstance();
		float speed = client.player == null
				? 0.0f : (float) client.player.getVelocity().horizontalLength();
		float vertical = client.player == null
				? 0.0f : (float) client.player.getVelocity().y;
		long now = System.currentTimeMillis();
		updateIdleWind(client, now, speed);
		float time = (now % 100000L) / 1000.0f;
		float lift = currentWindLift(now);
		queue.submitCustom(matrices, HdCapeRenderLayer.LAYER,
				(entry, buffer) -> drawCloth(buffer, entry, time, speed, vertical, lift));
		matrices.pop();
	}

	/**
	 * Плащ 10x16 model-pixels, разбитый на 12 полос. Верх закреплён,
	 * низ отстаёт при беге, а боковой swing зависит от скорости и времени.
	 * Координаты делятся на 16 так же, как vanilla ModelPart.
	 */
	private static void drawCloth(VertexConsumer buffer, MatrixStack.Entry entry,
			float time, float speed, float vertical, float lift) {
		final int segments = 12;
		final float width = 10.0f / 16.0f;
		final float height = 16.0f / 16.0f;
		final float bodyClearance = -0.045f;
		float motion = Math.min(1.0f, speed * 4.0f);
		float trail = motion * 0.22f + Math.max(0.0f, -vertical) * 0.08f;

		for (int i = 0; i < segments; i++) {
			float v0 = i / (float) segments;
			float v1 = (i + 1) / (float) segments;
			// Верх остаётся закреплённым, а низ немного поднимается
			// плавной дугой во время порыва ветра.
			float y0 = v0 * height - lift * v0 * v0;
			float y1 = v1 * height - lift * v1 * v1;

			float wave0 = (float) Math.sin(time * (5.0f + motion * 3.0f) + v0 * 5.0f)
					* (0.008f + v0 * 0.025f) * (0.35f + motion);
			float wave1 = (float) Math.sin(time * (5.0f + motion * 3.0f) + v1 * 5.0f)
					* (0.008f + v1 * 0.025f) * (0.35f + motion);
			float z0 = bodyClearance + v0 * v0 * trail + wave0;
			float z1 = bodyClearance + v1 * v1 * trail + wave1;
			float x0 = (float) Math.sin(time * 2.2f + v0 * 3.0f) * 0.012f * v0 * motion;
			float x1 = (float) Math.sin(time * 2.2f + v1 * 3.0f) * 0.012f * v1 * motion;

			emitQuad(buffer, entry, -width / 2.0f + x0, y0, z0,
					-width / 2.0f + x1, y1, z1,
					width / 2.0f + x1, y1, z1,
					width / 2.0f + x0, y0, z0,
					0.0f, v0, 1.0f, v1);
			// Вторая сторона нужна для прозрачных/полупрозрачных материалов
			// и сохраняет рисунок при развороте камеры.
			emitQuad(buffer, entry, width / 2.0f + x0, y0, z0 + 0.001f,
					width / 2.0f + x1, y1, z1 + 0.001f,
					-width / 2.0f + x1, y1, z1 + 0.001f,
					-width / 2.0f + x0, y0, z0 + 0.001f,
					0.0f, v0, 1.0f, v1);
		}
	}

	/**
	 * После 10 секунд полного покоя вооружаем случайный порыв через 3–10 с.
	 * Любое движение или заметный поворот головы отменяет ожидание.
	 */
	private static void updateIdleWind(MinecraftClient client, long now, float speed) {
		if (client.player == null) {
			windActive = false;
			windArmed = false;
			return;
		}

		float yaw = client.player.getYaw();
		float pitch = client.player.getPitch();
		if (Float.isNaN(lastYaw) || Float.isNaN(lastPitch)) {
			lastYaw = yaw;
			lastPitch = pitch;
			lastActivityMs = now;
		}

		boolean headMoved = Math.abs(MathHelper.wrapDegrees(yaw - lastYaw)) > 0.15f
				|| Math.abs(pitch - lastPitch) > 0.15f;
		lastYaw = yaw;
		lastPitch = pitch;

		if (speed > 0.008f || headMoved) {
			lastActivityMs = now;
			windArmed = false;
			windActive = false;
			return;
		}

		if (!windArmed && now - lastActivityMs >= 10_000L) {
			windArmed = true;
			nextWindMs = now + ThreadLocalRandom.current().nextLong(3_000L, 10_001L);
		}

		if (windArmed && !windActive && now >= nextWindMs) {
			windActive = true;
			windStartMs = now;
			windDurationMs = ThreadLocalRandom.current().nextLong(1_000L, 2_001L);
		}

		if (windActive && now >= windStartMs + windDurationMs) {
			windActive = false;
			windArmed = false;
			lastActivityMs = now;
		}
	}

	/** Плавный подъём нижней части плаща на время порыва. */
	private static float currentWindLift(long now) {
		if (!windActive || windDurationMs <= 0L) return 0.0f;
		float progress = Math.max(0.0f, Math.min(1.0f,
				(now - windStartMs) / (float) windDurationMs));
		return (float) Math.sin(progress * Math.PI) * 0.10f;
	}

	private static void emitQuad(VertexConsumer buffer, MatrixStack.Entry entry,
			float x0, float y0, float z0, float x1, float y1, float z1,
			float x2, float y2, float z2, float x3, float y3, float z3,
			float u0, float v0, float u1, float v1) {
		buffer.vertex(entry, x0, y0, z0).texture(u0, v0).color(0xFFFFFFFF);
		buffer.vertex(entry, x1, y1, z1).texture(u0, v1).color(0xFFFFFFFF);
		buffer.vertex(entry, x2, y2, z2).texture(u1, v1).color(0xFFFFFFFF);
		buffer.vertex(entry, x3, y3, z3).texture(u1, v0).color(0xFFFFFFFF);
	}
}
