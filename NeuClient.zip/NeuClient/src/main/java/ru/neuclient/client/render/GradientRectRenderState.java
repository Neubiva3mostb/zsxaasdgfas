package ru.neuclient.client.render;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.minecraft.client.gui.ScreenRect;
import net.minecraft.client.gui.render.state.SimpleGuiElementRenderState;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.texture.TextureSetup;
import org.joml.Matrix3x2f;

/**
 * 4-точечный градиентный прямоугольник со скруглением для палитры цветов.
 */
public record GradientRectRenderState(
		Matrix3x2f pose,
		float x,
		float y,
		float width,
		float height,
		int cTopLeft,
		int cBottomLeft,
		int cBottomRight,
		int cTopRight,
		ScreenRect scissorArea,
		ScreenRect bounds
) implements SimpleGuiElementRenderState {

	@Override
	public void setupVertices(VertexConsumer buffer) {
		buffer.vertex(pose, x, y).texture(0.0f, 0.0f).color(cTopLeft);
		buffer.vertex(pose, x, y + height).texture(0.0f, 1.0f).color(cBottomLeft);
		buffer.vertex(pose, x + width, y + height).texture(1.0f, 1.0f).color(cBottomRight);
		buffer.vertex(pose, x + width, y).texture(1.0f, 0.0f).color(cTopRight);
	}

	@Override
	public RenderPipeline pipeline() {
		return RoundedRectPipeline.PIPELINE;
	}

	@Override
	public TextureSetup textureSetup() {
		return TextureSetup.empty();
	}
}
