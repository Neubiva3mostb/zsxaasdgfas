package ru.neuclient.client.mixin;

import net.minecraft.client.network.ServerInfo;
import net.minecraft.client.option.ServerList;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

/**
 * Автоматически добавляет сервера FunTime, HollyWorld и ReallyWorld
 * в список серверов при загрузке.
 */
@Mixin(ServerList.class)
public abstract class ServerListMixin {

	@Shadow
	@Final
	private List<ServerInfo> servers;

	@Shadow
	public abstract void saveFile();

	@Inject(method = "loadFile", at = @At("TAIL"))
	private void pc$addDefaultServers(CallbackInfo ci) {
		boolean modified = false;
		if (ensureServer("FunTime", "neo.funtime.sh")) {
			modified = true;
		}
		if (ensureServer("HollyWorld", "hub.holyworld.ru")) {
			modified = true;
		}
		if (ensureServer("ReallyWorld", "mc.reallyworld.me")) {
			modified = true;
		}

		if (modified) {
			saveFile();
		}
	}

	/**
	 * Гарантирует сервер с точным именем и адресом: добавляет, если нет,
	 * и обновляет адрес, если сервер с таким именем уже сохранён со старым IP
	 * (миграция: ReallyWorld mc.reallyworld.ru → mc.reallyworld.me).
	 */
	private boolean ensureServer(String name, String address) {
		for (ServerInfo server : this.servers) {
			if (server != null && name.equalsIgnoreCase(server.name)) {
				if (server.address == null || !address.trim().equalsIgnoreCase(server.address.trim())) {
					server.address = address;
					return true;
				}
				return false;
			}
		}
		this.servers.add(new ServerInfo(name, address, ServerInfo.ServerType.OTHER));
		return true;
	}
}
