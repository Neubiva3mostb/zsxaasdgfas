package ru.neuclient.client.render;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.LayeringTransform;
import net.minecraft.client.render.OutputTarget;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderSetup;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;
import ru.neuclient.client.mixin.RenderLayerAccessor;
import ru.neuclient.client.module.impl.render.CapeModule;

/** Текстурный слой HD-текстуры для физической геометрии плаща. */
public final class HdCapeRenderLayer {

	private static final RenderPipeline PIPELINE = RenderPipelines.register(
			RenderPipeline.builder()
					.withLocation(Identifier.of("perfstream", "pipeline/hd_cape"))
					.withVertexShader(Identifier.of("perfstream", "core/hd_cape"))
					.withFragmentShader(Identifier.of("perfstream", "core/hd_cape"))
					.withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR, VertexFormat.DrawMode.QUADS)
					.withSampler("Sampler0")
					.withUniform("DynamicTransforms", UniformType.UNIFORM_BUFFER)
					.withUniform("Projection", UniformType.UNIFORM_BUFFER)
					.withBlend(BlendFunction.TRANSLUCENT)
					.withDepthTestFunction(DepthTestFunction.LEQUAL_DEPTH_TEST)
					.withCull(false)
					.withColorWrite(true, true)
					.build()
	);

	public static final RenderLayer LAYER = RenderLayerAccessor.pc$of(
			"hd_cape",
			RenderSetup.builder(PIPELINE)
					.texture("Sampler0", CapeModule.HD_TEXTURE)
					.layeringTransform(LayeringTransform.VIEW_OFFSET_Z_LAYERING)
					.outputTarget(OutputTarget.ITEM_ENTITY_TARGET)
					.build());

	public static void touch() {
	}

	private HdCapeRenderLayer() {
	}
}
