package ru.neuclient.client.module.impl.misc.autowarden;

import java.util.List;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class Walker {
   private static final double NODE_REACH = 0.45;
   private static final int STUCK_TICKS = 50;
   private final MinecraftClient mc;
   private List<BlockPos> path;
   private int index;
   private BlockPos goal;
   private double goalReach;
   private Vec3d lastPos = Vec3d.ZERO;
   private int stuckTicks;
   private int recomputeCooldown;
   private boolean stuck;
   private boolean sprint = true;
   private static final float MAX_TURN = 14.0F;
   private static final float JITTER = 3.0F;
   private final java.util.Random rnd = new java.util.Random();
   private float jitterYaw;
   private float jitterPitch;
   private float jitterTargetYaw;
   private float jitterTargetPitch;
   private int jitterTicks;
   private float turnVel;
   private int lastIndex = -1;
   private int noProgressTicks;
   /** Спуф-углы: их видит сервер и F5; реальная камера (F1) не крутится. */
   private float spoofYaw;
   private float spoofPitch;

   public Walker(MinecraftClient mc) {
      this.mc = mc;
   }

   public void setSprint(boolean sprint) {
      this.sprint = sprint;
   }

   public void setPath(List<BlockPos> path, BlockPos goal, double reach) {
      this.path = path;
      this.index = 0;
      this.goal = goal;
      this.goalReach = reach;
      this.stuck = false;
      this.stuckTicks = 0;
      this.recomputeCooldown = 0;
      this.lastIndex = -1;
      this.noProgressTicks = 0;
      this.turnVel = 0.0F;
      ClientPlayerEntity p0 = this.mc.player;
      if (p0 != null) {
         this.spoofYaw = p0.getYaw();
         this.spoofPitch = p0.getPitch();
      }
   }

   public boolean hasPath() {
      return this.path != null && this.index < this.path.size();
   }

   public boolean isStuck() {
      return this.stuck;
   }

   public BlockPos getGoal() {
      return this.goal;
   }

   /** Спуф активен: бот идёт по пути — сервер видит этот угол, F5 его показывает. */
   public boolean isSpoofing() {
      return this.path != null;
   }

   public float getSpoofYaw() {
      return this.spoofYaw;
   }

   public float getSpoofPitch() {
      return this.spoofPitch;
   }

   public boolean reachedGoal() {
      ClientPlayerEntity p = this.mc.player;
      if (p != null && this.goal != null) {
         double dx = (double)this.goal.getX() + 0.5 - p.getX();
         double dz = (double)this.goal.getZ() + 0.5 - p.getZ();
         return Math.hypot(dx, dz) <= this.goalReach && Math.abs((double)this.goal.getY() - p.getY()) <= 2.5;
      } else {
         return false;
      }
   }

   public void stop() {
      this.path = null;
      this.goal = null;
      this.releaseKeys();
   }

   public void releaseKeys() {
      if (this.mc.options != null) {
         this.mc.options.forwardKey.setPressed(false);
         this.mc.options.jumpKey.setPressed(false);
         this.mc.options.sprintKey.setPressed(false);
         this.mc.options.sneakKey.setPressed(false);
      }
   }

   public boolean tick() {
      ClientPlayerEntity p = this.mc.player;
      if (p != null && this.path != null) {
         int lookahead = Math.min(this.path.size(), this.index + 6);

         for (int i = this.index; i < lookahead; i++) {
            if (distToNode(p, this.path.get(i)) < 0.75) {
               this.index = i + 1;
            }
         }

         if (this.index != this.lastIndex) {
            this.lastIndex = this.index;
            this.noProgressTicks = 0;
         } else if (++this.noProgressTicks > 80) {
            this.stuck = true;
            this.noProgressTicks = 0;
         }

         if (this.index >= this.path.size()) {
            this.releaseKeys();
            return false;
         } else {
            BlockPos target = this.path.get(this.index);
            if (this.index + 1 < this.path.size()) {
               BlockPos nxt = this.path.get(this.index + 1);
               if (nxt.getY() == target.getY() && distToNode(p, nxt) < 1.6 && !p.horizontalCollision) {
                  target = nxt;
               }
            }

            double tx = (double)target.getX() + 0.5;
            double tz = (double)target.getZ() + 0.5;
            double dx = tx - p.getX();
            double dz = tz - p.getZ();
            float yaw = (float)(Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
            this.updateJitter();
            float wantYaw = yaw + this.jitterYaw;
            float cur = this.spoofYaw;
            float diff = MathHelper.wrapDegrees(wantYaw - cur);
            // Плавный доворот: пропорционально углу (быстрее на больших), но не более MAX_TURN за тик,
            // с небольшой инерцией (turnVel), чтобы не было рывков.
            float desired = MathHelper.clamp(diff * 0.28F, -MAX_TURN, MAX_TURN);
            this.turnVel = MathHelper.lerp(0.45F, this.turnVel, desired);
            if (Math.abs(this.turnVel) > Math.abs(diff)) {
               this.turnVel = diff;
            }

            this.spoofYaw = MathHelper.wrapDegrees(cur + this.turnVel);
            float wantPitch = 8.0F + this.jitterPitch;
            this.spoofPitch = MathHelper.lerp(0.08F, this.spoofPitch, wantPitch);
            float remaining = Math.abs(MathHelper.wrapDegrees(yaw - this.spoofYaw));
            boolean facing = remaining < 30.0F;
            boolean sharpTurn = Math.abs(diff) > 60.0F;
            double distTarget = distToNode(p, target);
            this.mc.options.forwardKey.setPressed(facing);
            this.mc.options.sprintKey.setPressed(facing && this.sprint && !sharpTurn && distTarget > 1.5 && !p.isTouchingWater());
            // Прыжок нужен ТОЛЬКО чтобы подняться по пути (ступенька/подъём).
            // Раньше прыжок включался на любое столкновение — бот постоянно скакал.
            int feetY = p.getBlockPos().getY();
            boolean stepUp = target.getY() > feetY && distTarget < 1.5;
            boolean climbAhead = this.pathNeedsClimb(p, feetY);
            boolean needJump = stepUp
               || climbAhead && p.horizontalCollision && p.isOnGround()
               || p.isTouchingWater();
            this.mc.options.jumpKey.setPressed(needJump);
            Vec3d now = p.getEntityPos();
            if (now.squaredDistanceTo(this.lastPos) < 0.0025) {
               this.stuckTicks++;
            } else {
               this.stuckTicks = 0;
            }

            this.lastPos = now;
            if (this.recomputeCooldown > 0) {
               this.recomputeCooldown--;
            }

            if (this.stuckTicks > 50) {
               this.stuck = true;
               this.stuckTicks = 0;
            }

            return true;
         }
      } else {
         return false;
      }
   }

   /**
    * Есть ли впереди по пути подъём выше текущих ног. Если нет — прыгать
    * бессмысленно (упираемся в настоящую стену), и бот не скачет зря.
    */
   private boolean pathNeedsClimb(ClientPlayerEntity p, int feetY) {
      if (this.path == null) {
         return false;
      }

      int end = Math.min(this.path.size(), this.index + 4);
      for (int i = this.index; i < end; i++) {
         BlockPos n = this.path.get(i);
         if (n.getY() > feetY) {
            // Подъём должен быть рядом — иначе это просто точка пути выше по рельефу.
            return distToNode(p, n) < 2.5;
         }
      }

      return false;
   }

   /** Джиттер ±3°: цель меняется раз в 6–18 тиков, текущее значение плавно к ней ползёт. */
   private void updateJitter() {
      if (--this.jitterTicks <= 0) {
         this.jitterTicks = 6 + this.rnd.nextInt(13);
         this.jitterTargetYaw = (this.rnd.nextFloat() * 2.0F - 1.0F) * JITTER;
         this.jitterTargetPitch = (this.rnd.nextFloat() * 2.0F - 1.0F) * JITTER;
      }

      this.jitterYaw = MathHelper.lerp(0.15F, this.jitterYaw, this.jitterTargetYaw);
      this.jitterPitch = MathHelper.lerp(0.15F, this.jitterPitch, this.jitterTargetPitch);
   }

   private static double distToNode(ClientPlayerEntity p, BlockPos n) {
      return Math.hypot((double)n.getX() + 0.5 - p.getX(), (double)n.getZ() + 0.5 - p.getZ())
         + (Math.abs((double)n.getY() - p.getY()) > 1.2 ? 1.0 : 0.0);
   }
}
