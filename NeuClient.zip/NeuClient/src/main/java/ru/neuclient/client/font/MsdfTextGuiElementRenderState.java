package ru.neuclient.client.font;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.minecraft.client.gui.ScreenRect;
import net.minecraft.client.gui.render.state.SimpleGuiElementRenderState;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.texture.TextureSetup;
import org.joml.Matrix3x2f;

/**
 * Элемент отрисовки строки целиком для GuiRenderer.
 *
 * Все глифы строки (и тень) генерируются напрямую в единый VertexConsumer
 * без создания объектов на каждый символ, что устраняет просадки FPS.
 * Субпиксельные float-координаты предотвращают "съезжание" и дрожание букв.
 */
public record MsdfTextGuiElementRenderState(
		MsdfFont font,
		String text,
		Matrix3x2f pose,
		float x,
		float y,
		float size,
		int argb,
		boolean shadow,
		int shadowColor,
		ScreenRect scissorArea,
		ScreenRect bounds
) implements SimpleGuiElementRenderState {

	@Override
	public void setupVertices(VertexConsumer buffer) {
		if (font == null || text == null || text.isEmpty()) return;

		float atlasW = font.atlasWidth();
		float atlasH = font.atlasHeight();
		boolean yOriginBottom = font.isYOriginBottom();
		float baseline = y + font.ascender() * size;

		if (shadow && ((shadowColor >>> 24) > 0)) {
			emitString(buffer, x + 0.6f, baseline + 0.6f, shadowColor, atlasW, atlasH, yOriginBottom);
		}
		emitString(buffer, x, baseline, argb, atlasW, atlasH, yOriginBottom);
	}

	private void emitString(VertexConsumer buffer, float startX, float baseline, int color,
							float atlasW, float atlasH, boolean yOriginBottom) {
		float pen = startX;
		int currentColor = color;
		int initialAlpha = (color >>> 24);
		int prev = -1;

		for (int i = 0; i < text.length(); i++) {
			char c = text.charAt(i);
			if (c == '§' && i + 1 < text.length()) {
				char code = Character.toLowerCase(text.charAt(i + 1));
				int colorIndex = "0123456789abcdef".indexOf(code);
				if (colorIndex >= 0) {
					int rgb = MsdfFontRenderer.COLOR_CODES[colorIndex];
					currentColor = (initialAlpha << 24) | rgb;
				} else if (code == 'r') {
					currentColor = color;
				}
				i++;
				continue;
			}

			int cp = text.codePointAt(i);
			if (Character.isSupplementaryCodePoint(cp)) i++;

			if (prev >= 0) {
				pen += font.kerning(prev, cp) * size;
			}

			MsdfFont.Glyph glyph = font.glyph(cp);
			if (glyph != null && glyph.hasBounds) {
				float x0 = pen + glyph.planeLeft * size;
				float x1 = pen + glyph.planeRight * size;
				float y0 = baseline - glyph.planeTop * size;
				float y1 = baseline - glyph.planeBottom * size;

				float u0 = glyph.atlasLeft / atlasW;
				float u1 = glyph.atlasRight / atlasW;
				float v0 = yOriginBottom ? (atlasH - glyph.atlasTop) / atlasH : glyph.atlasTop / atlasH;
				float v1 = yOriginBottom ? (atlasH - glyph.atlasBottom) / atlasH : glyph.atlasBottom / atlasH;

				buffer.vertex(pose, x0, y0).texture(u0, v0).color(currentColor);
				buffer.vertex(pose, x0, y1).texture(u0, v1).color(currentColor);
				buffer.vertex(pose, x1, y1).texture(u1, v1).color(currentColor);
				buffer.vertex(pose, x1, y0).texture(u1, v0).color(currentColor);
			}

			if (glyph != null) {
				pen += glyph.advance * size;
			}
			prev = cp;
		}
	}

	@Override
	public RenderPipeline pipeline() {
		return MsdfTextPipeline.PIPELINE;
	}

	@Override
	public TextureSetup textureSetup() {
		return font.textureSetup();
	}
}
