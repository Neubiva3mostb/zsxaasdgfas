package ru.neuclient.client.hud;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.font.MsdfFontRenderer;
import ru.neuclient.client.font.MsdfFonts;
import ru.neuclient.client.module.impl.render.InterfaceModule;
import ru.neuclient.client.util.RenderUtil;

/**
 * Базовый HUD-элемент.
 *
 * Отрисовка всех текстов и карточек выполняется через нативные MSDF-шрифты (SF Pro Medium).
 */
public abstract class HudElement {

	protected final MinecraftClient mc = MinecraftClient.getInstance();

	protected Text bold(String text) {
		return Text.literal(text);
	}

	protected int boldWidth(String text) {
		return (int) Math.ceil(MsdfFontRenderer.getWidth(MsdfFonts.sfMedium(), text, 9.0f));
	}

	protected int boldHeight() {
		return 9;
	}

	protected void drawBold(DrawContext ctx, String text, int x, int y, int color) {
		MsdfFontRenderer.drawWithShadow(ctx, MsdfFonts.sfMedium(), text, x, y, color, 9.0f);
	}

	protected void drawBold(DrawContext ctx, String text, int x, int y, int color, boolean shadow) {
		MsdfFontRenderer.draw(ctx, MsdfFonts.sfMedium(), text, x, y, color, 9.0f, shadow);
	}

	private final String id;
	private final int defaultX;
	private final int defaultY;

	private int customX;
	private int customY;
	private boolean customPosition;

	/** Актуальные размеры (пересчитываются при отрисовке). */
	protected int width;
	protected int height;

	/** Смещение захвата при перетаскивании. */
	private int dragOffX;
	private int dragOffY;

	/** Доступные масштабы элемента. */
	public static final float[] SCALES = {1.0f, 0.8f, 0.6f, 0.4f, 0.2f};

	/** Текущий масштаб отрисовки (1.0 = 100%). */
	private float scale = 1.0f;

	protected HudElement(String id, int defaultX, int defaultY) {
		this.id = id;
		this.defaultX = defaultX;
		this.defaultY = defaultY;
	}

	public String getId() {
		return id;
	}

	/** Мастер-выключатель модуля HUD + настройка видимости элемента. */
	public boolean isVisible() {
		InterfaceModule hud = NeuClient.getInstance().getInterfaceModule();
		return hud.isEnabled() && hud.isElementVisible(id);
	}

	public int getX() {
		return customPosition ? customX : getDefaultX();
	}

	public int getY() {
		return customPosition ? customY : getDefaultY();
	}

	protected int getDefaultX() {
		return defaultX;
	}

	protected int getDefaultY() {
		return defaultY;
	}

	public int getWidth() {
		return width;
	}

	public int getHeight() {
		return height;
	}

	public boolean hasCustomPosition() {
		return customPosition;
	}

	public void setPosition(int x, int y) {
		this.customX = x;
		this.customY = y;
		this.customPosition = true;
		ru.neuclient.client.module.Module.markConfigDirty();
	}

	public void resetPosition() {
		this.customPosition = false;
	}

	// ===== Масштаб =====

	public float getScale() {
		return scale;
	}

	public void setScale(float value) {
		this.scale = Math.max(0.2f, Math.min(1.0f, value));
		ru.neuclient.client.module.Module.markConfigDirty();
	}

	public void cycleScale() {
		int index = 0;
		for (int i = 0; i < SCALES.length; i++) {
			if (Math.abs(SCALES[i] - scale) < 0.01f) {
				index = i;
				break;
			}
		}
		setScale(SCALES[(index + 1) % SCALES.length]);
	}

	public int getScalePercent() {
		return Math.round(scale * 100.0f);
	}

	// ===== Рендер =====

	public final void render(DrawContext ctx, boolean editing) {
		float s = scale;
		boolean scaled = Math.abs(s - 1.0f) > 0.001f;

		if (scaled) {
			var m = ctx.getMatrices();
			m.pushMatrix();
			m.translate(getX(), getY());
			m.scale(s, s);
			m.translate(-getX(), -getY());
		}

		drawElement(ctx, editing);

		if (scaled) {
			ctx.getMatrices().popMatrix();
		}

		if (editing && width > 0 && height > 0) {
			RenderUtil.border(ctx, getX() - 1, getY() - 1,
					scaledWidth() + 2, scaledHeight() + 2, RenderUtil.accentDim());
		}
	}

	public int scaledWidth() {
		return Math.round(width * scale);
	}

	public int scaledHeight() {
		return Math.round(height * scale);
	}

	protected abstract void drawElement(DrawContext ctx, boolean editing);

	// ===== Единый стиль карточек (как HUD-виджеты Delta) =====

	protected static final int CARD_RADIUS = 4;
	protected static final int CARD_PAD = 5;
	protected static final int CARD_H = 15;

	/**
	 * Фон HUD-карточки.
	 *
	 * В Delta виджеты — тёмная плашка с лёгкой примесью акцентного цвета
	 * ({@code BACKGROUND_HUD} = тёмный, смешанный с primary). Здесь тот же
	 * принцип: почти чёрный фон с акцентным оттенком поверх — карточка не
	 * сливается с миром и не «выжигает» глаза ярким цветом.
	 */
	public static int cardBg() {
		// Тёмный фон + примесь акцента ~14% (как mixer у Delta).
		int a = 0xF0;
		int r = (int) (((RenderUtil.accent() >> 16) & 0xFF) * 0.14f);
		int g = (int) (((RenderUtil.accent() >> 8) & 0xFF) * 0.14f);
		int b = (int) ((RenderUtil.accent() & 0xFF) * 0.14f);
		return (a << 24) | (r << 16) | (g << 8) | b;
	}

	protected static int cardInner() {
		return 0xFF000000 | (shade(RenderUtil.accent(), 0.20f) & 0x00FFFFFF);
	}

	public static int withAlpha(int color, int a) {
		return ((a & 0xFF) << 24) | (color & 0x00FFFFFF);
	}

	public static int withAlpha(int color, float a) {
		int alpha = Math.max(0, Math.min(255, Math.round(a * 255.0f)));
		return (alpha << 24) | (color & 0x00FFFFFF);
	}

	protected static int shade(int color, float k) {
		int r = (int) (((color >> 16) & 0xFF) * k);
		int g = (int) (((color >> 8) & 0xFF) * k);
		int b = (int) ((color & 0xFF) * k);
		return (r << 16) | (g << 8) | b;
	}

	protected void drawPanel(DrawContext ctx) {
		// Подложка + «стекло» поверх (тот же шейдер, что у модуля Hands).
		RenderUtil.roundRect(ctx, getX(), getY(), width, height, CARD_RADIUS, cardBg());
		RenderUtil.glass(ctx, getX(), getY(), width, height, RenderUtil.accent(), 1.0f);
		// Тонкая акцентная рамка — как OUTLINE у карточек Delta.
		RenderUtil.roundBorderEdge(ctx, getX(), getY(), width, height, CARD_RADIUS,
				withAlpha(RenderUtil.accent(), 0x33));
	}

	protected int drawHeaderCard(DrawContext ctx, int x, int y, int w,
			String icon, String title) {
		RenderUtil.roundRect(ctx, x, y, w, CARD_H, CARD_RADIUS, cardBg());
		RenderUtil.glass(ctx, x, y, w, CARD_H, RenderUtil.accent(), 1.0f);
		RenderUtil.roundBorderEdge(ctx, x, y, w, CARD_H, CARD_RADIUS,
				withAlpha(RenderUtil.accent(), 0x33));
		int ty = y + (CARD_H - boldHeight()) / 2 + 1;
		int cx = x + CARD_PAD;
		drawBold(ctx, icon, cx, ty, RenderUtil.accent(), false);
		cx += boldWidth(icon) + 6;
		ctx.fill(cx, y + 4, cx + 1, y + CARD_H - 4, withAlpha(RenderUtil.accent(), 0x66));
		cx += 7;
		drawBold(ctx, title, cx, ty, 0xFFFFFFFF, false);
		return CARD_H;
	}

	protected int drawHeaderCardIcon(DrawContext ctx, int x, int y, int w,
			int iconW, IconDrawer icon, String title) {
		RenderUtil.roundRect(ctx, x, y, w, CARD_H, CARD_RADIUS, cardBg());
		RenderUtil.glass(ctx, x, y, w, CARD_H, RenderUtil.accent(), 1.0f);
		RenderUtil.roundBorderEdge(ctx, x, y, w, CARD_H, CARD_RADIUS,
				withAlpha(RenderUtil.accent(), 0x33));
		int cx = x + CARD_PAD;
		icon.draw(ctx, cx, y);
		cx += iconW + 6;
		ctx.fill(cx, y + 4, cx + 1, y + CARD_H - 4, withAlpha(RenderUtil.accent(), 0x66));
		cx += 7;
		drawBold(ctx, title, cx, y + (CARD_H - boldHeight()) / 2 + 1,
				0xFFFFFFFF, false);
		return CARD_H;
	}

	protected int headerCardWidthIcon(int iconW, String title) {
		return CARD_PAD + iconW + 6 + 1 + 6 + boldWidth(title) + CARD_PAD;
	}

	@FunctionalInterface
	protected interface IconDrawer {
		void draw(DrawContext ctx, int x, int y);
	}

	protected static void drawKeyboardIcon(DrawContext ctx, int x, int y) {
		int c = RenderUtil.accent();
		int dim = withAlpha(c, 0xAA);
		int top = y + (CARD_H - 8) / 2;

		ctx.fill(x, top, x + 11, top + 1, c);
		ctx.fill(x, top + 7, x + 11, top + 8, c);
		ctx.fill(x, top, x + 1, top + 8, c);
		ctx.fill(x + 10, top, x + 11, top + 8, c);

		ctx.fill(x + 2, top + 2, x + 3, top + 3, dim);
		ctx.fill(x + 4, top + 2, x + 5, top + 3, dim);
		ctx.fill(x + 6, top + 2, x + 7, top + 3, dim);
		ctx.fill(x + 8, top + 2, x + 9, top + 3, dim);
		ctx.fill(x + 2, top + 4, x + 3, top + 5, dim);
		ctx.fill(x + 4, top + 4, x + 5, top + 5, dim);
		ctx.fill(x + 6, top + 4, x + 7, top + 5, dim);
		ctx.fill(x + 8, top + 4, x + 9, top + 5, dim);
		ctx.fill(x + 3, top + 6, x + 8, top + 7, dim);
	}

	protected static final int KEYBOARD_ICON_W = 11;

	protected int headerCardWidth(String icon, String title) {
		return CARD_PAD + boldWidth(icon) + 6 + 1 + 6 + boldWidth(title) + CARD_PAD;
	}

	protected void drawValueCard(DrawContext ctx, int x, int y, int w,
			String label, String value) {
		RenderUtil.roundRect(ctx, x, y, w, CARD_H, CARD_RADIUS, cardBg());
		RenderUtil.glass(ctx, x, y, w, CARD_H, RenderUtil.accent(), 1.0f);
		RenderUtil.roundBorderEdge(ctx, x, y, w, CARD_H, CARD_RADIUS,
				withAlpha(RenderUtil.accent(), 0x33));
		int ty = y + (CARD_H - boldHeight()) / 2 + 1;
		drawBold(ctx, label, x + CARD_PAD, ty, 0xFFFFFFFF, false);
		int vw = boldWidth(value);
		int vx = x + w - CARD_PAD - vw;
		ctx.fill(vx - 7, y + 4, vx - 6, y + CARD_H - 4, withAlpha(RenderUtil.accent(), 0x66));
		drawBold(ctx, value, vx, ty, RenderUtil.accent(), false);
	}

	protected int valueCardWidth(String label, String value) {
		return CARD_PAD + boldWidth(label) + 12 + 1 + boldWidth(value) + CARD_PAD;
	}

	// ===== Перетаскивание =====

	public boolean contains(double mx, double my) {
		return width > 0 && height > 0
				&& mx >= getX() && mx <= getX() + scaledWidth()
				&& my >= getY() && my <= getY() + scaledHeight();
	}

	public void startDrag(double mx, double my) {
		dragOffX = (int) (mx - getX());
		dragOffY = (int) (my - getY());
	}

	public void dragTo(double mx, double my, int screenW, int screenH) {
		int nx = (int) mx - dragOffX;
		int ny = (int) my - dragOffY;
		nx = Math.max(0, Math.min(nx, Math.max(0, screenW - scaledWidth())));
		ny = Math.max(0, Math.min(ny, Math.max(0, screenH - scaledHeight())));
		setPosition(nx, ny);
	}
}
