package ru.neuclient.client.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.client.sound.SoundInstance;
import net.minecraft.sound.SoundCategory;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.random.Random;

/**
 * Фирменные звуки NeuClient (НЕ ванильные): короткие синтезированные
 * «бипы» в assets/perfstream/sounds/*.ogg.
 *
 *  toggle_on / toggle_off — включение/выключение модуля или тумблера;
 *  settings — открытие/закрытие настроек, переключение режимов;
 *  tab — переключение вкладок категорий, обычные клики по кнопкам;
 *  bind — назначен/снят бинд клавиши.
 *
 * Отдельно регистрировать SoundEvent в реестре НЕ нужно: звуки
 * клиентские, резолвятся прямо по идентификатору через sounds.json.
 */
public final class NeuSounds {

	public static final Identifier TOGGLE_ON = id("toggle_on");
	public static final Identifier TOGGLE_OFF = id("toggle_off");
	public static final Identifier SETTINGS = id("settings");
	public static final Identifier TAB = id("tab");
	public static final Identifier BIND = id("bind");

	/** Голосовые приветствия/прощания «дворецкого» (Джарвис-стиль). */
	public static final Identifier JARVIS_HELLO_1 = id("jarvis_hello_1");
	public static final Identifier JARVIS_HELLO_2 = id("jarvis_hello_2");
	public static final Identifier JARVIS_BYE_1 = id("jarvis_bye_1");
	public static final Identifier JARVIS_BYE_2 = id("jarvis_bye_2");

	private NeuSounds() {
	}

	private static Identifier id(String name) {
		return Identifier.of("perfstream", name);
	}

	/** Оставлено для единообразия инициализации (звукам она не нужна). */
	public static void init() {
	}

	// ===== Воспроизведение =====

	/** Проиграть звук интерфейса с заданным тоном (1.0 = как в файле). */
	public static void play(Identifier sound, float pitch) {
		MinecraftClient client = MinecraftClient.getInstance();
		if (client == null) {
			return;
		}
		PositionedSoundInstance instance = new PositionedSoundInstance(
				sound, SoundCategory.UI,
				0.65f, pitch, Random.create(),
				false, 0, SoundInstance.AttenuationType.NONE,
				0.0, 0.0, 0.0, true);
		client.getSoundManager().play(instance);
	}

	public static void play(Identifier sound) {
		play(sound, 1.0f);
	}

	/** Звук переключения: on = восходящий бип, off = нисходящий. */
	public static void toggle(boolean enabled) {
		play(enabled ? TOGGLE_ON : TOGGLE_OFF);
	}

	// ===== Голос «дворецкого» при входе/выходе =====

	/** Самая длинная прощальная реплика (сек) + запас на буфер движка. */
	private static final long JARVIS_BYE_WAIT_MS = 2450;

	/** Голосовое воспроизведение (категория Voice, громче UI-бипов). */
	private static void playVoice(Identifier sound) {
		MinecraftClient client = MinecraftClient.getInstance();
		if (client == null) {
			return;
		}
		PositionedSoundInstance instance = new PositionedSoundInstance(
				sound, SoundCategory.VOICE,
				1.0f, 1.0f, Random.create(),
				false, 0, SoundInstance.AttenuationType.NONE,
				0.0, 0.0, 0.0, true);
		client.getSoundManager().play(instance);
	}

	/**
	 * Голосовое воспроизведение с проверкой результата.
	 * @return true, если звук РЕАЛЬНО запустился (движок уже поднят).
	 */
	private static boolean playVoiceWithResult(Identifier sound) {
		MinecraftClient client = MinecraftClient.getInstance();
		if (client == null) {
			return false;
		}
		PositionedSoundInstance instance = new PositionedSoundInstance(
				sound, SoundCategory.VOICE,
				1.0f, 1.0f, Random.create(),
				false, 0, SoundInstance.AttenuationType.NONE,
				0.0, 0.0, 0.0, true);
		// В самом начале запуска SoundSystem ещё отдыхает и тихо отвечает
		// NOT_STARTED — по флагу понимаем, что надо попробовать позже
		return client.getSoundManager().play(instance)
				!= net.minecraft.client.sound.SoundSystem.PlayResult.NOT_STARTED;
	}

	/**
	 * При входе в игру: случайное приветствие —
	 * «Добрый день, сэр!» или «Готов к работе, сэр!».
	 * @return true, если реплика удалось запустить (иначе стоит повторить позже)
	 */
	public static boolean tryPlayJarvisHello() {
		return playVoiceWithResult(java.util.concurrent.ThreadLocalRandom.current().nextBoolean()
				? JARVIS_HELLO_1 : JARVIS_HELLO_2);
	}

	/**
	 * При выходе: случайное прощание — «До свидания, сэр!» или «Хорошего дня, сэр!».
	 * ВНИМАНИЕ: метод ДЕРЖИТ главный поток ~2.5 с — звуковой движок играет
	 * на своих потоках, поэтому реплика успевает прозвучать целиком до того,
	 * как ванилла доберётся до закрытия SoundManager'а.
	 */
	public static void playJarvisByeAndWait() {
		try {
			playVoice(java.util.concurrent.ThreadLocalRandom.current().nextBoolean()
					? JARVIS_BYE_1 : JARVIS_BYE_2);
			Thread.sleep(JARVIS_BYE_WAIT_MS);
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		} catch (Throwable ignored) {
			// выход не должен падать из-за звука
		}
	}
}
