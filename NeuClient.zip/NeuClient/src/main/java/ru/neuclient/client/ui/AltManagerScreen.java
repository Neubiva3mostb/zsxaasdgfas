package ru.neuclient.client.ui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.alt.AltEntry;
import ru.neuclient.client.alt.AltManager;
import ru.neuclient.client.font.MsdfFontRenderer;
import ru.neuclient.client.font.MsdfFonts;
import ru.neuclient.client.util.RenderUtil;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Экран Alt Manager'а с нативным MSDF-шрифтом.
 */
public class AltManagerScreen extends Screen {

	private final Screen parent;

	private TextFieldWidget loginField;

	private NeonButton addButton;
	private NeonButton generateButton;
	private NeonButton deleteButton;
	private NeonButton backButton;

	private NeonButton modalAddButton;
	private NeonButton modalCancelButton;

	private boolean modalOpen;
	private int selectedIndex = -1;

	private String status = "";
	private boolean statusError = false;

	public AltManagerScreen(Screen parent) {
		super(Text.literal("Alt Manager"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		int cx = width / 2;

		addButton = new NeonButton(cx - 116, 44, 66, 16, Text.literal("Добавить"), b -> setModalOpen(true));
		generateButton = new NeonButton(cx - 42, 44, 84, 16, Text.literal("Сгенерировать"), b -> generateAlt());
		deleteButton = new NeonButton(cx + 50, 44, 66, 16, Text.literal("Удалить"), b -> removeSelected());
		backButton = new NeonButton(cx - 50, height - 30, 100, 16, Text.literal("Назад"), b -> close());

		addButton.active = !modalOpen;
		generateButton.active = !modalOpen;
		deleteButton.active = !modalOpen;
		backButton.active = !modalOpen;
		addButton.visible = !modalOpen;
		generateButton.visible = !modalOpen;
		deleteButton.visible = !modalOpen;
		backButton.visible = !modalOpen;

		addDrawableChild(addButton);
		addDrawableChild(generateButton);
		addDrawableChild(deleteButton);
		addDrawableChild(backButton);

		int px = modalX();
		int py = modalY();
		loginField = new TextFieldWidget(textRenderer, px + 12, py + 18, MODAL_W - 24, 16, Text.literal("Логин"));
		loginField.setMaxLength(16);
		loginField.visible = modalOpen;
		addDrawableChild(loginField);

		modalAddButton = new NeonButton(px + 12, py + 46, 88, 16, Text.literal("Добавить"), b -> confirmAdd());
		modalCancelButton = new NeonButton(px + MODAL_W - 100, py + 46, 88, 16, Text.literal("Отмена"), b -> setModalOpen(false));
		modalAddButton.visible = modalOpen;
		modalCancelButton.visible = modalOpen;
		addDrawableChild(modalAddButton);
		addDrawableChild(modalCancelButton);

		if (modalOpen) {
			loginField.setText("");
			setFocused(loginField);
		}
	}

	private static final int MODAL_W = 212;
	private static final int MODAL_H = 72;

	private int modalX() {
		return (width - MODAL_W) / 2;
	}

	private int modalY() {
		return Math.max(20, height * 4 / 10 - MODAL_H / 2);
	}

	private void setModalOpen(boolean open) {
		modalOpen = open;
		clearAndInit();
	}

	@Override
	public void close() {
		MinecraftClient.getInstance().setScreen(parent);
	}

	@Override
	public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
		super.renderBackground(ctx, mouseX, mouseY, delta);
		ctx.fill(0, 0, width, height, 0x5506090F);
	}

	@Override
	public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
		super.render(ctx, mouseX, mouseY, delta);

		int cx = width / 2;

		RenderUtil.drawWaveTextCentered(ctx, "NEUCLIENT ALT MANAGER", cx, 12);

		if (!status.isEmpty()) {
			RenderUtil.textCentered(ctx, status, cx, 68, statusError ? RenderUtil.DANGER : RenderUtil.accent());
		}

		String current = "Текущий ник: " + NeuClient.getInstance().getAltManager().currentName();
		float currentW = MsdfFontRenderer.getWidth(MsdfFonts.sfRegular(), current, 9.0f);
		MsdfFontRenderer.drawWithShadow(ctx, MsdfFonts.sfRegular(), current, width - 8f - currentW, height - 14f, RenderUtil.textDim(), 9.0f);

		if (!modalOpen) {
			renderAltList(ctx, mouseX, mouseY, cx);
		}

		if (modalOpen) {
			ctx.fill(0, 0, width, height, 0x99060A12);
			int px = modalX();
			int py = modalY();
			RenderUtil.glow(ctx, px, py, MODAL_W, MODAL_H, 8);
			RenderUtil.roundBorderRect(ctx, px, py, MODAL_W, MODAL_H, 8, RenderUtil.accent(), RenderUtil.bg());
			loginField.render(ctx, mouseX, mouseY, delta);
			modalAddButton.render(ctx, mouseX, mouseY, delta);
			modalCancelButton.render(ctx, mouseX, mouseY, delta);
		}
	}

	private void renderAltList(DrawContext ctx, int mouseX, int mouseY, int cx) {
		List<AltEntry> alts = NeuClient.getInstance().getAltManager().getAlts();
		int listX = cx - 110;
		int listY = 88;
		int rowH = 15;
		int listW = 220;
		int maxRows = Math.max(1, (height - 44 - listY) / rowH);
		int visible = Math.min(alts.size(), maxRows);
		int listH = Math.max(visible, 1) * rowH + 2;

		RenderUtil.roundBorderRect(ctx, listX, listY, listW, listH, 4, RenderUtil.BORDER, RenderUtil.bg());

		if (alts.isEmpty()) {
			RenderUtil.textCentered(ctx, "Список пуст", cx, listY + 4, RenderUtil.textDim());
			return;
		}

		int ry = listY + 2;
		for (int i = 0; i < visible; i++) {
			AltEntry alt = alts.get(i);
			boolean hovered = mouseX >= listX && mouseX < listX + listW && mouseY >= ry && mouseY < ry + rowH;
			if (i == selectedIndex) {
				RenderUtil.fill(ctx, listX + 1, ry, listW - 2, rowH, RenderUtil.accentDim());
			} else if (hovered) {
				RenderUtil.fill(ctx, listX + 1, ry, listW - 2, rowH, 0x223FB4FF);
			}
			if (i == selectedIndex) {
				RenderUtil.fill(ctx, listX + 1, ry, 2, rowH, RenderUtil.accent());
			}
			MsdfFontRenderer.drawWithShadow(ctx, MsdfFonts.sfRegular(), alt.getUsername(),
					listX + 6, ry + 3f, i == selectedIndex ? RenderUtil.accent() : RenderUtil.TEXT, 9.0f);
			ry += rowH;
		}
	}

	@Override
	public boolean mouseClicked(Click click, boolean doubled) {
		if (modalOpen) {
			if (loginField.mouseClicked(click, doubled)) {
				setFocused(loginField);
				return true;
			}
			if (modalAddButton.mouseClicked(click, doubled)) {
				return true;
			}
			if (modalCancelButton.mouseClicked(click, doubled)) {
				return true;
			}
			setFocused(loginField);
			return true;
		}

		int cx = width / 2;
		int listX = cx - 110;
		int listY = 88;
		int rowH = 15;
		int listW = 220;

		List<AltEntry> alts = NeuClient.getInstance().getAltManager().getAlts();
		int maxRows = Math.max(1, (height - 44 - listY) / rowH);
		int visible = Math.min(alts.size(), maxRows);

		double mx = click.x();
		double my = click.y();
		if (mx >= listX && mx < listX + listW && my >= listY && my < listY + visible * rowH + 2) {
			int index = (int) ((my - listY - 2) / rowH);
			if (index >= 0 && index < visible) {
				selectedIndex = index;
				ClickGuiScreen.playClick();
				loginSelected();
				return true;
			}
		}
		return super.mouseClicked(click, doubled);
	}

	@Override
	public boolean keyPressed(KeyInput input) {
		if (modalOpen) {
			int code = input.key();
			if (code == GLFW.GLFW_KEY_ESCAPE) {
				setModalOpen(false);
				return true;
			}
			if (code == GLFW.GLFW_KEY_ENTER || code == GLFW.GLFW_KEY_KP_ENTER) {
				confirmAdd();
				return true;
			}
			loginField.keyPressed(input);
			return true;
		}
		return super.keyPressed(input);
	}

	@Override
	public boolean charTyped(CharInput input) {
		if (modalOpen) {
			loginField.charTyped(input);
			return true;
		}
		return super.charTyped(input);
	}

	private void confirmAdd() {
		AltManager manager = NeuClient.getInstance().getAltManager();
		String err = manager.add(loginField.getText(), "");
		if (err == null) {
			setStatus("Альт добавлен: " + loginField.getText().trim(), false);
			setModalOpen(false);
		} else {
			setStatus(err, true);
		}
	}

	private void generateAlt() {
		AltManager manager = NeuClient.getInstance().getAltManager();
		ThreadLocalRandom random = ThreadLocalRandom.current();

		for (int attempt = 0; attempt < 25; attempt++) {
			String name = generateHumanNickname(random);
			if (manager.add(name, "") == null) {
				List<AltEntry> alts = manager.getAlts();
				for (int i = 0; i < alts.size(); i++) {
					if (alts.get(i).getUsername().equalsIgnoreCase(name)) {
						selectedIndex = i;
						break;
					}
				}
				String err = manager.login(alts.get(selectedIndex));
				setStatus(err == null ? "Вошли как: " + name : err, err != null);
				return;
			}
		}
		setStatus("Не удалось придумать ник — попробуйте ещё раз", true);
	}

	/* ---------- «человеческие» ники вместо анаграмм ---------- */

	private static final String[] WORDS = {
		"Dark", "Shadow", "Ghost", "Wolf", "Dragon", "King", "Queen",
		"Night", "Light", "Fire", "Ice", "Storm", "Blood", "Soul"
	};
	private static final String[] PREFIXES = { "pro", "ultra", "mega", "super", "hyper", "neo" };
	private static final String[] ROLES = { "player", "gamer", "hunter", "killer", "master" };
	private static final String[] NAMES = { "Alex", "John", "Mike", "Kate", "Anna", "Lisa", "Max", "Tom" };
	private static final String[] ADJECTIVES = { "Crazy", "Silent", "Lucky", "Angry", "Happy", "Fast", "Smart" };
	private static final String[] ANIMALS = { "Cat", "Dog", "Fox", "Bear", "Eagle", "Tiger" };
	private static final String[] DEMONS = { "demon", "angel", "warrior", "ninja", "sniper" };
	private static final String[] REPEAT = { "III", "XXX", "OOO", "ZZZ", "666", "777", "888" };
	private static final String[] KILLWORDS = { "kill", "dead", "live", "born", "end" };
	private static final String[] ARTICLES = { "the", "my", "your", "our" };
	private static final String[] ABSTRACTS = { "darkness", "light", "future", "past" };
	private static final String[] TITLES = { "lord", "king", "queen", "god" };

	private static String pick(ThreadLocalRandom r, String[] arr) {
		return arr[r.nextInt(arr.length)];
	}

	/**
	 * Ник «как у людей»: осмысленный шаблон, иногда с заменой букв
	 * на похожие цифры (leet: I→1, Z→3, A→4, E→3, O→0, S→5, T→7, L→1...).
	 */
	private static String generateHumanNickname(ThreadLocalRandom r) {
		for (int guard = 0; guard < 12; guard++) {
			String out;
			switch (r.nextInt(8)) {
				case 0 -> out = pick(r, WORDS) + r.nextInt(1, 1000);
				case 1 -> out = pick(r, PREFIXES) + "_" + pick(r, ROLES);
				case 2 -> out = pick(r, NAMES) + r.nextInt(1980, 2027);
				case 3 -> out = pick(r, ADJECTIVES) + pick(r, ANIMALS);
				case 4 -> out = (r.nextBoolean() ? "xX_" : "") + pick(r, DEMONS)
						+ (r.nextBoolean() ? "_Xx" : "");
				case 5 -> {
					int len = 2 + r.nextInt(3);
					StringBuilder sb = new StringBuilder(len);
					String pool = "abcdefghijklmnopqrstuvwxyz_";
					for (int i = 0; i < len; i++) sb.append(pool.charAt(r.nextInt(pool.length())));
					out = sb.toString();
				}
				case 6 -> out = pick(r, REPEAT) + pick(r, KILLWORDS);
				default -> out = pick(r, ARTICLES) + "_" + pick(r, ABSTRACTS) + "_" + pick(r, TITLES);
			}
			if (r.nextInt(100) < 35) out = leetify(out, r);
			if (out.length() >= 3 && out.length() <= 16) return out;
		}
		// запасной вариант, если шаблоны всё время получались длинноваты
		return pick(r, WORDS).substring(0, 4) + r.nextInt(10, 99);
	}

	/** Заменяет часть букв похожими цифрами (не более 3-х на ник). */
	private static String leetify(String nick, ThreadLocalRandom r) {
		StringBuilder sb = new StringBuilder(nick.length());
		int done = 0;
		for (int i = 0; i < nick.length(); i++) {
			char c = nick.charAt(i);
			String sub = leetOf(Character.toLowerCase(c));
			if (sub != null && done < 3 && r.nextInt(100) < 50) {
				sb.append(sub);
				done++;
			} else {
				sb.append(c);
			}
		}
		return sb.toString();
	}

	private static String leetOf(char c) {
		return switch (c) {
			case 'a' -> "4";
			case 'e', 'z' -> "3";
			case 'i', 'l' -> "1";
			case 'o' -> "0";
			case 's' -> "5";
			case 't' -> "7";
			case 'b' -> "8";
			case 'g' -> "9";
			default -> null;
		};
	}

	private void loginSelected() {
		List<AltEntry> alts = NeuClient.getInstance().getAltManager().getAlts();
		if (selectedIndex < 0 || selectedIndex >= alts.size()) {
			return;
		}
		String err = NeuClient.getInstance().getAltManager().login(alts.get(selectedIndex));
		if (err == null) {
			setStatus("Вошли как: " + alts.get(selectedIndex).getUsername(), false);
		} else {
			setStatus(err, true);
		}
	}

	private void removeSelected() {
		List<AltEntry> alts = NeuClient.getInstance().getAltManager().getAlts();
		if (selectedIndex < 0 || selectedIndex >= alts.size()) {
			setStatus("Сначала выберите альта в списке", true);
			return;
		}
		String name = alts.get(selectedIndex).getUsername();
		NeuClient.getInstance().getAltManager().remove(alts.get(selectedIndex));
		selectedIndex = -1;
		setStatus("Альт удалён: " + name, false);
	}

	private void setStatus(String message, boolean error) {
		this.status = message;
		this.statusError = error;
	}
}
