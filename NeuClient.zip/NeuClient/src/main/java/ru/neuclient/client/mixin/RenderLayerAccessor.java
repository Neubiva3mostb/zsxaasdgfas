package ru.neuclient.client.mixin;

import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderSetup;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

/**
 * Расширяет доступ к package-private методу RenderLayer.of().
 *
 * В Minecraft 1.21.11 RenderLayer.of(String, RenderSetup) стал
 * package-private — моды не могут создавать свои RenderLayer
 * без accessor'а. Через @Invoker открываем доступ.
 */
@Mixin(RenderLayer.class)
public interface RenderLayerAccessor {

	@Invoker(value = "of")
	static RenderLayer pc$of(String name, RenderSetup renderSetup) {
		throw new AssertionError();
	}
}
