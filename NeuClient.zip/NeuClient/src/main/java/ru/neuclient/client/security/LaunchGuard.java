package ru.neuclient.client.security;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.FileTime;
import java.time.Duration;
import java.util.Locale;
import java.util.Optional;

/**
 * LaunchGuard — проверка, что клиент запущен ОРИГИНАЛЬНЫМ лаунчером
 * NeuClient, а не голым javaw/чужим лаунчером/тлаунчером.
 *
 * Цепочка доверия:
 *  1) лаунчер передаёт игре launch-тикет дважды: через -Dneu.launcher.ticket
 *     и через переменную окружения NEU_TICKET — значения обязаны совпасть;
 *  2) тикет проверяется на сервере (POST /api/launcher/verify-ticket) —
 *     он подписан сервером и живёт 10 минут, подделать нельзя;
 *  3) если сайт недоступен (нет сети) — офлайн-запасной вариант:
 *     файл-тикет во временной папке должен совпадать с тикетом и быть
 *     свежим, а родительский процесс — похож на лаунчер.
 *
 * Любой провал — мгновенный краш (halt), клиент не запускается.
 */
public final class LaunchGuard {

    private static final String VERIFY_URL = "https://neuclient.ru/api/launcher/verify-ticket";
    private static final long TICKET_FILE_MAX_AGE_MS = 12 * 60 * 1000L;

    private LaunchGuard() {}

    public static void enforce() {
        String propTicket = System.getProperty("neu.launcher.ticket", "");
        String envTicket = getenvSafe("NEU_TICKET");
        String envUid = getenvSafe("NEU_UID");
        String envHwid = getenvSafe("NEU_HWID");

        // 1) Лаунчер обязан передать тикет двумя каналами и они должны совпасть.
        if (propTicket.isEmpty() || envTicket.isEmpty() || !propTicket.equals(envTicket)) {
            crash("missing or mismatched launch ticket");
            return;
        }
        if (envUid.isEmpty() || envHwid.isEmpty()) {
            crash("missing launch identity");
            return;
        }

        // 2) Онлайн-проверка тикета (главный путь).
        switch (verifyOnline(propTicket)) {
            case VALID -> { return; }
            case INVALID -> crash("launch ticket rejected by server");
            case UNREACHABLE -> {
                // 3) Сайт недоступен → офлайн-запасной путь.
                if (!offlineFallbackOk(propTicket)) {
                    crash("offline launch check failed");
                }
            }
        }
    }

    private enum VerifyResult { VALID, INVALID, UNREACHABLE }

    private static VerifyResult verifyOnline(String ticket) {
        String verifyUrl = getenvSafe("NEU_VERIFY_URL");
        if (verifyUrl.isEmpty()) verifyUrl = VERIFY_URL;
        try {
            HttpClient client = HttpClient.newBuilder()
                    .connectTimeout(Duration.ofSeconds(6))
                    .build();
            String body = "{\"ticket\":\"" + ticket + "\"}";
            HttpRequest req = HttpRequest.newBuilder()
                    .uri(URI.create(verifyUrl))
                    .timeout(Duration.ofSeconds(8))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(body))
                    .build();
            HttpResponse<String> resp = client.send(req, HttpResponse.BodyHandlers.ofString());
            if (resp.statusCode() == 200 && resp.body() != null
                    && resp.body().contains("\"valid\":true")) {
                return VerifyResult.VALID;
            }
            return VerifyResult.INVALID;
        } catch (IOException e) {
            return VerifyResult.UNREACHABLE;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return VerifyResult.UNREACHABLE;
        } catch (IllegalArgumentException e) {
            return VerifyResult.UNREACHABLE;
        }
    }

    /** Офлайн-проверка, когда сайт не отвечает: файл-тикет + родительский процесс. */
    private static boolean offlineFallbackOk(String ticket) {
        // файл-тикет, который лаунчер пишет во временную папку
        String ticketPath = getenvSafe("NEU_TICKET_FILE");
        if (ticketPath.isEmpty()) return false;
        try {
            Path p = Path.of(ticketPath);
            if (!Files.isRegularFile(p)) return false;
            String content = Files.readString(p).trim();
            if (!ticket.equals(content)) return false;
            FileTime mtime = Files.getLastModifiedTime(p);
            if (System.currentTimeMillis() - mtime.toMillis() > TICKET_FILE_MAX_AGE_MS) return false;
        } catch (IOException | RuntimeException e) {
            return false;
        }
        // родительский процесс должен быть нашим лаунчером
        Optional<ProcessHandle> parent = ProcessHandle.current().parent();
        if (parent.isEmpty()) return false;
        String cmd = parent.get().info().command().orElse("").toLowerCase(Locale.ROOT);
        return cmd.contains("launcher") || cmd.contains("neuclient");
    }

    private static String getenvSafe(String name) {
        try {
            String v = System.getenv(name);
            return v == null ? "" : v.trim();
        } catch (SecurityException e) {
            return "";
        }
    }

    /** Мгновенная остановка процесса без штатного завершения игры. */
    private static void crash(String reason) {
        System.err.println("[NeuClient] This client must be started from the official launcher (" + reason + ").");
        Runtime.getRuntime().halt(0x5EED);
    }
}
