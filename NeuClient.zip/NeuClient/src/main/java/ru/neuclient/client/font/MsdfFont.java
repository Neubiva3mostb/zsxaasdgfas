package ru.neuclient.client.font;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.TextureSetup;
import net.minecraft.util.Identifier;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

/**
 * Одна MSDF/MTSDF-гарнитура: метрики глифов (из msdf-atlas-gen JSON)
 * и атлас-текстура.
 *
 * Оптимизирована для нулевого GC и прямого O(1) доступа к глифам.
 */
public final class MsdfFont {

	/** Описание одного глифа. */
	public static final class Glyph {
		public final float advance;
		public final float planeLeft, planeBottom, planeRight, planeTop;
		public final float atlasLeft, atlasBottom, atlasRight, atlasTop;
		public final boolean hasBounds;

		Glyph(float advance, float pl, float pb, float pr, float pt,
			  float al, float ab, float ar, float at, boolean hasBounds) {
			this.advance = advance;
			this.planeLeft = pl; this.planeBottom = pb; this.planeRight = pr; this.planeTop = pt;
			this.atlasLeft = al; this.atlasBottom = ab; this.atlasRight = ar; this.atlasTop = at;
			this.hasBounds = hasBounds;
		}

		public float planeWidth()  { return planeRight - planeLeft; }
		public float planeHeight() { return planeTop - planeBottom; }
	}

	private final Identifier id;
	private final Identifier textureId;
	private final MsdfTexture texture;
	private final TextureSetup textureSetup;

	private final float distanceRange;
	private final float atlasWidth;
	private final float atlasHeight;
	private final float emSize;
	private final float lineHeight;
	private final float ascender;
	private final float descender;
	private final boolean yOriginBottom;

	// Быстрый массив для символов ASCII и кириллицы (O(1) без boxing/хеширования)
	private final Glyph[] fastGlyphs = new Glyph[2048];
	private final Map<Integer, Glyph> glyphs = new HashMap<>();
	private final Map<Long, Float> kerning = new HashMap<>();
	private final boolean hasKerning;

	/**
	 * Загружает шрифт из ресурсов мода.
	 *
	 * @param namespace неймспейс ("perfstream")
	 * @param name      имя файла без расширения ("sf_regular")
	 */
	public MsdfFont(String namespace, String name) throws Exception {
		this.id = Identifier.of(namespace, "fonts/" + name);
		this.textureId = Identifier.of(namespace, "textures/font/msdf_" + name + ".png");

		// 1. JSON метрик
		JsonObject root;
		try (InputStream in = openResource("/assets/" + namespace + "/fonts/" + name + ".json")) {
			if (in == null) {
				throw new IllegalStateException("Не найден JSON шрифта: " + name);
			}
			root = JsonParser.parseReader(new InputStreamReader(in, StandardCharsets.UTF_8)).getAsJsonObject();
		}

		JsonObject atlas = root.getAsJsonObject("atlas");
		this.distanceRange = atlas.has("distanceRange") ? atlas.get("distanceRange").getAsFloat() : 12.0f;
		this.atlasWidth = atlas.get("width").getAsFloat();
		this.atlasHeight = atlas.get("height").getAsFloat();
		this.yOriginBottom = !atlas.has("yOrigin") || "bottom".equalsIgnoreCase(atlas.get("yOrigin").getAsString());

		JsonObject metrics = root.getAsJsonObject("metrics");
		this.emSize = metrics.has("emSize") ? metrics.get("emSize").getAsFloat() : 1.0f;
		this.lineHeight = metrics.has("lineHeight") ? metrics.get("lineHeight").getAsFloat() : 1.19f;
		this.ascender = metrics.has("ascender") ? metrics.get("ascender").getAsFloat() : 0.95f;
		this.descender = metrics.has("descender") ? metrics.get("descender").getAsFloat() : -0.24f;

		JsonArray gl = root.getAsJsonArray("glyphs");
		for (int i = 0; i < gl.size(); i++) {
			JsonObject g = gl.get(i).getAsJsonObject();
			int unicode = g.get("unicode").getAsInt();
			float advance = g.has("advance") ? g.get("advance").getAsFloat() : 0f;
			float pl = 0, pb = 0, pr = 0, pt = 0;
			float al = 0, ab = 0, ar = 0, at = 0;
			boolean hasBounds = g.has("planeBounds") && g.has("atlasBounds");
			if (hasBounds) {
				JsonObject pb2 = g.getAsJsonObject("planeBounds");
				pl = pb2.get("left").getAsFloat();
				pb = pb2.get("bottom").getAsFloat();
				pr = pb2.get("right").getAsFloat();
				pt = pb2.get("top").getAsFloat();
				JsonObject ab2 = g.getAsJsonObject("atlasBounds");
				al = ab2.get("left").getAsFloat();
				ab = ab2.get("bottom").getAsFloat();
				ar = ab2.get("right").getAsFloat();
				at = ab2.get("top").getAsFloat();
			}
			Glyph glyph = new Glyph(advance, pl, pb, pr, pt, al, ab, ar, at, hasBounds);
			glyphs.put(unicode, glyph);
			if (unicode >= 0 && unicode < fastGlyphs.length) {
				fastGlyphs[unicode] = glyph;
			}
		}

		if (root.has("kerning")) {
			JsonArray kn = root.getAsJsonArray("kerning");
			for (int i = 0; i < kn.size(); i++) {
				JsonObject k = kn.get(i).getAsJsonObject();
				int u1 = k.get("unicode1").getAsInt();
				int u2 = k.get("unicode2").getAsInt();
				float adv = k.get("advance").getAsFloat();
				kerning.put(((long) u1 << 32) | (u2 & 0xFFFFFFFFL), adv);
			}
		}
		this.hasKerning = !this.kerning.isEmpty();

		// 2. Атлас-текстура
		try (InputStream in = openResource("/assets/" + namespace + "/fonts/" + name + ".png")) {
			if (in == null) {
				throw new IllegalStateException("Не найден PNG атлас шрифта: " + name);
			}
			NativeImage image = NativeImage.read(in);
			this.texture = new MsdfTexture(() -> "msdf_" + name, image);
			MinecraftClient.getInstance().getTextureManager()
					.registerTexture(textureId, this.texture);
		}

		this.textureSetup = TextureSetup.of(this.texture.getGlTextureView(), this.texture.getSampler());
	}

	private static InputStream openResource(String path) {
		return MsdfFont.class.getResourceAsStream(path);
	}

	public Identifier id() { return id; }
	public Identifier textureId() { return textureId; }
	public TextureSetup textureSetup() { return textureSetup; }
	public float distanceRange() { return distanceRange; }
	public float atlasWidth() { return atlasWidth; }
	public float atlasHeight() { return atlasHeight; }
	public float lineHeight() { return lineHeight; }
	public float ascender() { return ascender; }
	public float descender() { return descender; }
	public boolean isYOriginBottom() { return yOriginBottom; }

	public Glyph glyph(int codepoint) {
		if (codepoint >= 0 && codepoint < fastGlyphs.length) {
			Glyph g = fastGlyphs[codepoint];
			if (g != null) return g;
		}
		Glyph g = glyphs.get(codepoint);
		if (g != null) return g;
		return fastGlyphs[0x20];
	}

	public boolean hasGlyph(int codepoint) {
		if (codepoint >= 0 && codepoint < fastGlyphs.length) {
			return fastGlyphs[codepoint] != null;
		}
		return glyphs.containsKey(codepoint);
	}

	/** Кернинг между двумя кодпоинтами в EM (0 если нет). */
	public float kerning(int left, int right) {
		if (!hasKerning) return 0f;
		Float v = kerning.get(((long) left << 32) | (right & 0xFFFFFFFFL));
		return v == null ? 0f : v;
	}

	public void close() {
		if (texture != null) {
			texture.close();
		}
	}
}
