package ru.neuclient.client.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.util.ClientPaths;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Collection;
import java.util.Collections;
import java.util.Set;
import java.util.TreeSet;

/**
 * Список друзей (для модуля NoFriendDamage).
 * Хранится в friends.json в папке конфигов, сравнение ников — без учёта регистра.
 * Сохраняется сразу при каждом изменении + на выходе из игры.
 */
public class FriendManager {

	private final Gson gson = new GsonBuilder().setPrettyPrinting().create();
	private final Set<String> friends = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);

	private Path file() {
		return ClientPaths.file("friends.json");
	}

	public void load() {
		Path file = file();
		if (!Files.exists(file)) {
			return;
		}
		try (Reader reader = Files.newBufferedReader(file)) {
			JsonArray array = JsonParser.parseReader(reader).getAsJsonArray();
			for (JsonElement el : array) {
				friends.add(el.getAsString());
			}
			NeuClient.LOGGER.info("[NeuClient] Друзей загружено: {}", friends.size());
		} catch (Exception e) {
			NeuClient.LOGGER.error("[NeuClient] Не удалось прочитать friends.json", e);
		}
	}

	public void save() {
		try (Writer writer = Files.newBufferedWriter(file())) {
			JsonArray array = new JsonArray();
			for (String f : friends) {
				array.add(f);
			}
			gson.toJson(array, writer);
		} catch (IOException e) {
			NeuClient.LOGGER.error("[NeuClient] Не удалось сохранить friends.json", e);
		}
	}

	/** Добавить друга. @return true, если это новый ник. */
	public boolean add(String name) {
		boolean added = friends.add(name);
		if (added) {
			save();
		}
		return added;
	}

	/** Удалить друга. @return true, если ник был в списке. */
	public boolean remove(String name) {
		boolean removed = friends.remove(name);
		if (removed) {
			save();
		}
		return removed;
	}

	public boolean isFriend(String name) {
		if (name == null) return false;
		if (friends.contains(name)) return true;
		try {
			if (ru.neuclient.client.bot.BotManager.getInstance().isBot(name)) return true;
		} catch (Throwable ignored) {}
		return false;
	}

	/** Неменяемое представление списка (алфавитный порядок). */
	public Collection<String> list() {
		return Collections.unmodifiableSet(friends);
	}
}
