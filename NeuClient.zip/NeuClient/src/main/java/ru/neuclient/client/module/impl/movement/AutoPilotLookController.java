package ru.neuclient.client.module.impl.movement;

/** Плавные реальные углы, общие для камеры, физики элитр и пакетов движения. */
final class AutoPilotLookController {
    private float yawSpeed;
    private float pitchSpeed;
    private int flightTicks;

    void reset() {
        yawSpeed = pitchSpeed = 0.0f;
        flightTicks = 0;
    }

    AutoPilotFlightController.Steering step(float yaw, float pitch, float targetYaw,
                                           float targetPitch, boolean gliding) {
        if (gliding) flightTicks++;
        else flightTicks = 0;
        // Маленькое покачивание, а не случайные рывки каждый тик. Оно
        // добавляется к реальному направлению, а не только к модели головы.
        double fade = Math.min(1.0, flightTicks / 40.0);
        float swayYaw = (float) (fade * (1.4 * Math.sin(flightTicks * 0.055)
                + 0.35 * Math.sin(flightTicks * 0.021)));
        float swayPitch = (float) (fade * (0.45 * Math.sin(flightTicks * 0.071)
                + 0.15 * Math.sin(flightTicks * 0.033)));
        float yawError = wrap(targetYaw + swayYaw - yaw);
        float pitchError = clamp(targetPitch + swayPitch, -89.0f, 89.0f) - pitch;
        yawSpeed = approach(yawSpeed, clamp(yawError * 0.22f, -3.0f, 3.0f), 0.45f);
        pitchSpeed = approach(pitchSpeed, clamp(pitchError * 0.28f, -3.0f, 3.0f), 0.50f);
        // Не пролетать через целевой угол, особенно на границе ±180°.
        if (Math.abs(yawSpeed) > Math.abs(yawError)) yawSpeed = yawError;
        if (Math.abs(pitchSpeed) > Math.abs(pitchError)) pitchSpeed = pitchError;
        return new AutoPilotFlightController.Steering(yaw + yawSpeed,
                clamp(pitch + pitchSpeed, -89.0f, 89.0f));
    }

    private static float approach(float value, float target, float step) {
        return value + clamp(target - value, -step, step);
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }

    private static float wrap(float value) {
        value %= 360.0f;
        if (value >= 180.0f) value -= 360.0f;
        if (value < -180.0f) value += 360.0f;
        return value;
    }
}
