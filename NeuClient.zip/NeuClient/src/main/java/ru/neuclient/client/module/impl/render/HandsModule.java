package ru.neuclient.client.module.impl.render;

import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.textures.TextureFormat;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.Window;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.render.GlassHandPipeline;
import ru.neuclient.client.setting.ModeSetting;
import ru.neuclient.client.util.RenderUtil;

/**
 * Hands — «стеклянные» руки от первого лица.
 *
 * Референс: GlassHand/HandChams из старых клиентов, перенесённый на рендер
 * 1.21.11 без единого GL11-вызова. Режимы:
 *
 *  • «Стекло»  — размытие, по которому плывут бегущие волны,
 *                гребни подсвечиваются цветом акцента (режим по умолчанию);
 *  • «Обводка» — контур акцентом (толщина 4) + резкая рука сверху.
 *
 * Цвет всегда берётся из акцента темы (панель «Цвета» в ClickGUI),
 * интенсивность зафиксирована на максимуме.
 *
 * КАК РАБОТАЕТ.
 * 1. GameRendererMixin включает захват ровно на время renderItem внутри
 *    renderHand: вывод перенаправляется через
 *    RenderSystem.outputColorTextureOverride/outputDepthTextureOverride
 *    (официальный механизм 1.21.11, им же пользуется ванилла). Рука
 *    рисуется в наши текстуры, а не в главный фреймбуфер.
 * 2. На выходе из renderHand модуль возвращает цель ванилле и композитит
 *    кадр руки обратно одним фуллскрин-квадом (GlassHandPipeline).
 *
 * Ни один пакет на сервер не уходит: эффект целиком клиентский.
 */
public final class HandsModule extends Module {

	// ===== Настройки =====

	/** Режим эффекта. */
	private final ModeSetting type = new ModeSetting("Тип", "Стекло", "Стекло", "Обводка");
	private final ru.neuclient.client.setting.ColorSetting color = new ru.neuclient.client.setting.ColorSetting("Цвет", 0xFF7A5CFF);

	// ===== Зафиксированные параметры =====

	/** Радиус размытия в режиме «Стекло». */
	private static final float BLUR_RADIUS = 8.0f;
	/** Толщина обводки («Обводка»). */
	private static final float OUTLINE_WIDTH = 4.0f;
	/** Интенсивность эффекта. */
	private static final float INTENSITY = 1.0f;
	/** Период цикла волн в режиме «Стекло». */
	private static final long WAVE_PERIOD_MS = 4000L;

	// ===== Ресурсы захвата =====

	private static GpuTexture colorTex;
	private static GpuTextureView colorView;
	private static GpuTexture depthTex;
	private static GpuTextureView depthView;
	private static int texWidth = -1;
	private static int texHeight = -1;
	/** true — захват активен (между beginCapture и endCaptureAndComposite). */
	private static boolean capturing;

	public HandsModule() {
		super("Hands", "Стеклянные руки от первого лица", Category.RENDER);
		addSettings(type, color);
	}

	@Override
	protected void onDisable() {
		resetCapture();
		freeTextures();
	}

	public static HandsModule active() {
		NeuClient client = NeuClient.getInstance();
		if (client == null || client.getModuleManager() == null) {
			return null;
		}
		HandsModule self = client.getModuleManager().get(HandsModule.class);
		return self != null && self.isEnabled() ? self : null;
	}

	// ===== Захват (вызывается из GameRendererMixin) =====

	/** До renderItem: готовим текстуры и переключаем вывод на них. */
	public static void beginCapture() {
		HandsModule self = active();
		if (self == null) {
			return;
		}

		MinecraftClient mc = MinecraftClient.getInstance();
		Window window = mc.getWindow();
		int w = Math.max(1, window.getFramebufferWidth());
		int h = Math.max(1, window.getFramebufferHeight());

		if (w != texWidth || h != texHeight) {
			freeTextures();
			colorTex = RenderSystem.getDevice().createTexture(
					() -> "neuclient hands color", GpuTexture.USAGE_TEXTURE_BINDING | GpuTexture.USAGE_RENDER_ATTACHMENT,
					TextureFormat.RGBA8, w, h, 1, 1);
			depthTex = RenderSystem.getDevice().createTexture(
					() -> "neuclient hands depth", GpuTexture.USAGE_RENDER_ATTACHMENT,
					TextureFormat.DEPTH32, w, h, 1, 1);
			colorView = RenderSystem.getDevice().createTextureView(colorTex);
			depthView = RenderSystem.getDevice().createTextureView(depthTex);
			texWidth = w;
			texHeight = h;
		}

		CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
		encoder.clearColorAndDepthTextures(colorTex, 0, depthTex, 1.0);

		RenderSystem.outputColorTextureOverride = colorView;
		RenderSystem.outputDepthTextureOverride = depthView;
		capturing = true;
	}

	public static boolean isCapturing() {
		return capturing;
	}

	/** После renderHand: возвращаем вывод и рисуем эффект поверх кадра. */
	public static void endCaptureAndComposite() {
		if (!capturing) {
			return;
		}
		capturing = false;

		// Сначала обязательно возвращаем цель ванилле — эффект рисуем уже на главный кадр
		RenderSystem.outputColorTextureOverride = null;
		RenderSystem.outputDepthTextureOverride = null;

		HandsModule self = active();
		if (self == null || colorView == null) {
			return;
		}

		// Цвет эффекта
		int accent = self.color.get();
		float ar = ((accent >> 16) & 0xFF) / 255.0f;
		float ag = ((accent >> 8) & 0xFF) / 255.0f;
		float ab = (accent & 0xFF) / 255.0f;

		switch (self.type.get()) {
			case "Обводка" -> {
				GlassHandPipeline.drawFullscreen(GlassHandPipeline.OUTLINE, colorView,
						OUTLINE_WIDTH, ar, ag, ab, INTENSITY);
				// Резкая рука поверх обводки
				GlassHandPipeline.drawFullscreen(GlassHandPipeline.BLUR, colorView, 0.0f,
						1.0f, 1.0f, 1.0f, 1.0f);
			}
			default -> {
				// Фаза волн 0..1 прячется в дробной части Param (радиус — в целой)
				float phase = (System.currentTimeMillis() % WAVE_PERIOD_MS)
						/ (float) WAVE_PERIOD_MS;
				GlassHandPipeline.drawFullscreen(GlassHandPipeline.GLASS, colorView,
						BLUR_RADIUS + phase, ar, ag, ab, INTENSITY);
			}
		}
	}

	/** Аварийный сброс (ошибка в миксине / выключение модуля). */
	public static void resetCapture() {
		capturing = false;
		RenderSystem.outputColorTextureOverride = null;
		RenderSystem.outputDepthTextureOverride = null;
	}

	private static void freeTextures() {
		if (colorView != null) {
			colorView.close();
			colorView = null;
		}
		if (depthView != null) {
			depthView.close();
			depthView = null;
		}
		if (colorTex != null) {
			colorTex.close();
			colorTex = null;
		}
		if (depthTex != null) {
			depthTex.close();
			depthTex = null;
		}
		texWidth = -1;
		texHeight = -1;
	}
}
