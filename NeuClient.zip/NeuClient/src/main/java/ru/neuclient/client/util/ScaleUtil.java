package ru.neuclient.client.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * Утилита адаптивного масштабирования интерфейса:
 * Нормализует масштаб менюшек (ClickGUI, панели, диалоги),
 * чтобы они выглядели одинаково на любом размере интерфейса (GUI Scale)
 * и любом разрешении экрана.
 */
public final class ScaleUtil {

	private ScaleUtil() {}

	/**
	 * Вычисляет коэффициент масштабирования DrawContext,
	 * приводящий любой установленный в настройках GUI Scale (1, 2, 3, 4, Auto)
	 * к единому физическому размеру на экране.
	 */
	public static float getRenderScale() {
		var mc = MinecraftClient.getInstance();
		if (mc == null || mc.getWindow() == null) return 1.0f;
		int guiScale = mc.getWindow().getScaleFactor();
		if (guiScale <= 0) guiScale = 1;

		int fbWidth = mc.getWindow().getFramebufferWidth();
		// На 1920x1080 физический множитель равен 2.0 (стандарт GUI Scale 2)
		// На экранах меньше 1600px плавно поджимаем, чтобы 790px гарантированно помещались
		float physicalScale = Math.min(2.0f, Math.max(0.5f, (fbWidth * 0.94f) / 790.0f));

		return physicalScale / (float) guiScale;
	}

	public static int getVirtualWidth() {
		var mc = MinecraftClient.getInstance();
		if (mc == null || mc.getWindow() == null) return 960;
		float renderScale = getRenderScale();
		return (int) Math.ceil(mc.getWindow().getScaledWidth() / renderScale);
	}

	public static int getVirtualHeight() {
		var mc = MinecraftClient.getInstance();
		if (mc == null || mc.getWindow() == null) return 540;
		float renderScale = getRenderScale();
		return (int) Math.ceil(mc.getWindow().getScaledHeight() / renderScale);
	}

	public static double toVirtualX(double x) {
		float s = getRenderScale();
		return s <= 0.001f ? x : x / s;
	}

	public static double toVirtualY(double y) {
		float s = getRenderScale();
		return s <= 0.001f ? y : y / s;
	}

	public static void begin(DrawContext ctx) {
		float s = getRenderScale();
		ctx.getMatrices().pushMatrix();
		ctx.getMatrices().scale(s, s);
	}

	public static void end(DrawContext ctx) {
		ctx.getMatrices().popMatrix();
	}
}
