package ru.neuclient.client.module.impl.combat;

import ru.neuclient.client.module.impl.combat.aura.LegitRotation;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.MaceItem;
import net.minecraft.item.TridentItem;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.client.util.InputUtil;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.mixin.KeyBindingAccessor;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.BooleanSetting;
import ru.neuclient.client.setting.ModeSetting;
import ru.neuclient.client.setting.NumberSetting;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

/**
 * AttackAura — легитный одиночный помощник для ближнего боя.
 *
 * Модуль не подменяет move-пакеты, не меняет серверную ротацию отдельно от
 * камеры и не использует снапы. Поворот выполняется через обычные yaw/pitch
 * игрока небольшими шагами, поэтому его видно на экране как движение мыши.
 * Атака отправляется только ванильным ClientPlayerInteractionManager и только
 * после проверки кулдауна, дистанции, raytrace и фильтров цели.
 *
 * В проекте уже есть ClientPlayerInteractionManagerMixin с @Mixin и @Inject
 * на attackEntity: он обслуживает NoFriendDamage, WTap, Criticals и TargetHud.
 * AttackAura намеренно не добавляет отдельный сетевой миксин.
 */
public final class AttackAuraModule extends Module {

	// ===== Режим ротации (самая первая настройка) =====
	/**
	 * Legit        — плавный доворот РЕАЛЬНОЙ камеры по ползункам ниже;
	 * SpookyTime   — ротация по ЗАПИСИ РЕАЛЬНОГО БОЯ: скорость доворота
	 *                и разброс прицела взяты из профиля, угол крутится
	 *                только для сервера (камера игрока стоит на месте);
	 */
	private final ModeSetting rotationMode = new ModeSetting("Режим", "Legit",
			"Legit", "SpookyTime");

	// ===== Настройки Legit =====
	private final NumberSetting legitYawSpeed = new NumberSetting("Скорость yaw", 0.4, 0.1, 0.9, 0.05);
	private final NumberSetting legitYawLimit = new NumberSetting("Ограничение yaw", 25.0, 10.0, 40.0, 1.0);
	private final NumberSetting legitRandom = new NumberSetting("Сила рандома", 1.0, 0.0, 3.0, 0.1);
	private final NumberSetting legitPitchSpeed = new NumberSetting("Скорость pitch", 0.08, 0.01, 0.2, 0.01);
	private final NumberSetting legitPitchLimit = new NumberSetting("Ограничение pitch", 4.0, 1.0, 10.0, 0.5);

	// ===== Настройки SpookyTime =====
	/**
	 * Коррекция движения под спуф.
	 *
	 * Профильные режимы ВСЕГДА крутят угол только для сервера (камера
	 * игрока не двигается), поэтому коррекция ввода нужна всегда: иначе
	 * ваниль посчитала бы направление движения от спуфнутого угла и игрок
	 * бежал бы не туда, куда жмёт.
	 */
	private final ModeSetting spookyCorrection = new ModeSetting("Коррекция движения", "Свободная",
			"Свободная", "Сфокусированная");

	/** Реализация Legit и SpookyTime. */
	private final LegitRotation legit = new LegitRotation();
	private final BooleanSetting sprintReset = new BooleanSetting("Сброс спринта", true);

	// ===== Обязательные настройки =====
		/**
	 * Дальность атаки.
	 *
	 * Ванильный сервер принимает удар при расстоянии от глаз до ближайшей
	 * точки хитбокса ≤ 3.0, и Grim штрафует за превышение (флаг Reach).
	 * Ползунок всё же поднят до 6.0 по запросу: значения выше 3.0 — это
	 * осознанный ризек, на серверах с античитом их лучше не трогать.
	 */
	private final NumberSetting range = new NumberSetting("Дальность атаки", 2.9, 1.0, 6.0, 0.05);
	private final NumberSetting missChance = new NumberSetting("Шанс промаха", 15.0, 0.0, 20.0, 1.0);
	private final ModeSetting priority = new ModeSetting("Приоритет", "Дистанция",
			"Дистанция", "Здоровье", "Броня");
	private final BooleanSetting attackWhileEating = new BooleanSetting("Бить во время еды", false);
	private final BooleanSetting throughWalls = new BooleanSetting("Бить сквозь стены", false);
	private final BooleanSetting onlyWeapon = new BooleanSetting("Только с оружием в руке", true);
	private final BooleanSetting onlyCrits = new BooleanSetting("Только криты", false);
	/**
	 * Адаптивный режим удара.
	 *
	 * true: может критануть (падаем, спринт снят) — бьём критом;
	 * стоим на земле — бьём обычным ударом (с земли крита не бывает,
	 * и терять темп ради него глупо); в воздухе без возможности крита
	 * (набираем высоту после прыжка) — ждём: обычный удар из воздуха
	 * слабее крита и как паттерн «палится» сильнее.
	 *
	 * false: удар каждый тик готовности, без разбора — крит или нет.
	 */
	private final BooleanSetting adaptive = new BooleanSetting("Адаптивная", true);
	private final BooleanSetting hitNaked = new BooleanSetting("Бить голых игроков", true);
	private final BooleanSetting hitArmored = new BooleanSetting("Бить игроков в броне", true);
	private final BooleanSetting hitInvisible = new BooleanSetting("Бить невидимых игроков", false);
	private final BooleanSetting hitPeacefulMobs = new BooleanSetting("Бить мирных мобов", false);
	private final BooleanSetting hitHostileMobs = new BooleanSetting("Бить агрессивных мобов", false);



	/**
	 * Насколько радиус ВЫБОРА цели больше радиуса АТАКИ, в блоках.
	 *
	 * Цель должна захватываться заранее: пока противник только подходит,
	 * TargetStrafe уже бежит к нему, а ротация успевает довернуть голову. Если
	 * захватывать ровно в дистанции удара, погоня начиналась бы в тот же
	 * момент, когда пора бить, — модуль всегда опаздывал бы.
	 */
	private static final double TARGET_SEARCH_BONUS = 2.0;

	/**
	 * Гистерезис переключения цели при приоритете «Дистанция», в блоках.
	 *
	 * Переключаемся на нового кандидата, только если он ближе текущей цели
	 * БОЛЬШЕ чем на эту величину. Меньше — это «сосед на полблока ближе»,
	 * из-за которого не стоит дёргать прицел и терять уже набранный доворот.
	 * Больше — цель реально ближе, и приоритет «Дистанция» должен работать.
	 */
	private static final double SWITCH_MARGIN = 0.75;

	/** Текущая выбранная цель. */
	private LivingEntity target;
	/** Всегда один дополнительный тик после попытки удара. */
	private int attackDelayTicks;
	// Сброс спринта
	private final SprintControl sprintControl = new SprintControl();
	/** Минимальный интервал между атаками (тики) — для руки как у меча. */
	private int ticksSinceLastAttack = 0;
	/**
	 * Интервал между ударами, тики.
	 *
	 * Ровно 12 тиков (600 мс) — это ЗАМЕРЕННАЯ величина из записи боя:
	 * 117 интервалов из 123 в точности такие, медиана 600 мс, p10 598,
	 * p90 601. Совпадение с кулдауном меча тут случайное: в записи
	 * период задаёт прыжок (джамп-криты — касание земли приходится
	 * строго на один и тот же тик цикла), поэтому джиттера нет и
	 * добавлять его нельзя. Значение берётся из ротации, чтобы часы
	 * гейта и часы снапа не могли разъехаться.
	 */
	private static final int MIN_ATTACK_INTERVAL_TICKS = 12;
	public AttackAuraModule() {
		super("AttackAura", "Автоматическая атака", Category.COMBAT);
		legitYawSpeed.visibleWhen(this::isLegit);
		legitYawLimit.visibleWhen(this::isLegit);
		legitRandom.visibleWhen(() -> false);
		legitPitchSpeed.visibleWhen(this::isLegit);
		legitPitchLimit.visibleWhen(this::isLegit);
		missChance.visibleWhen(() -> false);
		spookyCorrection.visibleWhen(() -> false);
		addSettings(rotationMode,
				legitYawSpeed, legitYawLimit, legitRandom, legitPitchSpeed, legitPitchLimit,
				spookyCorrection, sprintReset, range, missChance, priority,
				attackWhileEating, throughWalls, onlyWeapon, onlyCrits, adaptive,
				hitNaked, hitArmored, hitInvisible, hitPeacefulMobs, hitHostileMobs);
	}

	@Override
	protected void onEnable() {
		target = null;
		attackDelayTicks = ticksSinceLastAttack = 0;
		rollCooldownGate();
		legit.reset();
		sprintControl.reset();
	}

	@Override
	protected void onDisable() {
		target = null;
		attackDelayTicks = ticksSinceLastAttack = 0;
		legit.reset();
		sprintControl.reset();
	}

	@Override
	public void onTick(MinecraftClient client) {
		sprintControl.onTick(client);
		ClientPlayerEntity player = client.player;
		if (player == null || client.world == null || client.interactionManager == null) return;
		if (attackDelayTicks > 0) attackDelayTicks--;
		if (ticksSinceLastAttack > 0) ticksSinceLastAttack--;
		if (!hasUsableItem(player) || (!attackWhileEating.get() && isEating(player))) {
			target = null;
			return;
		}

		target = findTarget(client);
		if (target == null) {
			if (isProfileMode()) {
				legit.updateFromProfile(null, 1.0f, false, true);
			} else {
				legit.update(null, legitYawSpeed.get().floatValue(), legitYawLimit.get().floatValue(),
						legitPitchSpeed.get().floatValue(), legitPitchLimit.get().floatValue(),
						legitRandom.get().floatValue());
			}
			return;
		}
		if (needsSprintOffForCrit() && player.isSprinting()) player.setSprinting(false);
		boolean readyToHit = attackDelayTicks <= 0 && ticksSinceLastAttack <= 0
				&& insideAttackReach(player, target)
				&& AttackTiming.allowsAttack(onlyCrits.get(), adaptive.get(), player.isOnGround(), canCrit(player))
				&& readyForAttack(player);

		if (isProfileMode()) {
			legit.updateFromProfile(target, 1.0f, false, true);
		} else {
			legit.update(target, legitYawSpeed.get().floatValue(), legitYawLimit.get().floatValue(),
					legitPitchSpeed.get().floatValue(), legitPitchLimit.get().floatValue(),
					legitRandom.get().floatValue());
		}
		if (!readyToHit || !rayHitsTarget(player, target)) return;

		// Сохраняем прежние кулдаун, случайный промах и темп оставшихся режимов.
		if (ThreadLocalRandom.current().nextDouble(100.0) < missChance.get()) {
			player.swingHand(Hand.MAIN_HAND);
			attackDelayTicks = 1 + ThreadLocalRandom.current().nextInt(3);
			ticksSinceLastAttack = MIN_ATTACK_INTERVAL_TICKS;
			rollCooldownGate();
			return;
		}
		client.interactionManager.attackEntity(player, target);
		player.swingHand(Hand.MAIN_HAND);
		if (sprintReset.get()) sprintControl.resetSprint();
		attackDelayTicks = 1 + ThreadLocalRandom.current().nextInt(3);
		ticksSinceLastAttack = MIN_ATTACK_INTERVAL_TICKS;
		rollCooldownGate();
	}

	/** Активен ли режим Legit (ползунки, реальная камера). */
	public boolean isLegit() {
		return "Legit".equals(rotationMode.get());
	}

	/** Активен ли режим SpookyTime (профиль из записи, спуф угла). */
	public boolean isSpooky() {
		return "SpookyTime".equals(rotationMode.get());
	}

	/** Режим по профилю реального боя (SpookyTime). */
	public boolean isProfileMode() {
		return isSpooky();
	}

	/** Приоритет целей — по расстоянию (переключение на более близкого). */
	private boolean isDistancePriority() {
		return "Дистанция".equals(priority.get());
	}

	/**
	 * Двигаем ли РЕАЛЬНУЮ камеру.
	 *
	 * Только Legit: он доворачивает настоящий взгляд игрока.
	 * SpookyTime крутит угол исключительно для сервера —
	 * камера остаётся там, куда смотрит мышь.
	 */
	public boolean usesRealCamera() {
		return isLegit();
	}

	/** Спуф активен: серверу уходит не настоящий угол взгляда. */
	public boolean isSpoofing() {
		if (!isEnabled()) {
			return false;
		}
		if (isProfileMode()) {
			return legit.isSpoofActive();
		}
		// Legit крутит настоящую камеру — спуфа нет.
		return false;
	}

	public float getSpoofYaw() {
		if (isProfileMode()) {
			return legit.spoofYaw();
		}
		// Спуфа нет: серверу уходит настоящий угол игрока.
		var p = MinecraftClient.getInstance().player;
		return p == null ? 0.0f : p.getYaw();
	}

	public float getSpoofPitch() {
		if (isProfileMode()) {
			return legit.spoofPitch();
		}
		var p = MinecraftClient.getInstance().player;
		return p == null ? 0.0f : p.getPitch();
	}

	/** Коррекция ввода движения под спуфнутый угол. */
	public float[] correctMovement(float forward, float strafe) {
		if (isProfileMode()) {
			return legit.correctInput(forward, strafe, isFocusedCorrectionActive());
		}
		// Legit: спуфа нет, ввод не трогаем.
		return new float[] { forward, strafe };
	}

	/** Угол, который увидит сервер (для коррекции ввода в миксине). */
	public boolean isFocusedCorrectionActive() {
		if (isSpooky()) {
			return "Сфокусированная".equals(spookyCorrection.get());
		}
		return false;
	}

	/**
	 * Активно окно легитного сброса спринта: ClientPlayerEntitySprintMixin
	 * по нему запрещает canSprint и останавливает текущий спринт.
	 */
	public boolean shouldPreventSprinting() {
		return false;
	}

	public SprintControl getSprintControl() {
		return sprintControl;
	}

	/** Клавиша реально зажата рукой (не модулем). */
	private boolean physicallyHeld(KeyBinding key) {
		try {
			int code = ((KeyBindingAccessor) key).pc$getBoundKey().getCode();
			return InputUtil.isKeyPressed(mc.getWindow(), code);
		} catch (Throwable t) {
			return false;
		}
	}

	/** Нужно ли снять спринт, чтобы сервер не увидел бег спиной. */
	public boolean shouldStopSprint() {
		if (!isSpoofing()) {
			return false;
		}
		if (isProfileMode()) {
			return legit.shouldStopSprint(isFocusedCorrectionActive());
		}
		return false;
	}

	/** Активный экземпляр модуля для миксинов (null — выключен). */
	public static AttackAuraModule active() {
		var c = NeuClient.getInstance();
		if (c == null || c.getModuleManager() == null) {
			return null;
		}
		AttackAuraModule m = c.getModuleManager().get(AttackAuraModule.class);
		return m != null && m.isEnabled() ? m : null;
	}

	/**
	 * Текущая цель ауры (null — цели нет).
	 * Нужен модулю TargetESP, который рисует метку вокруг того, на кого
	 * аура реально навелась.
	 */
	public LivingEntity getTarget() {
		return target;
	}

	/** Оружие ближнего боя: WEAPON-компонент, топор, булава или трезубец. */
	private boolean hasUsableItem(ClientPlayerEntity player) {
		return !onlyWeapon.get() || isWeapon(player.getMainHandStack());
	}

	private static boolean isWeapon(ItemStack stack) {
		return stack.contains(DataComponentTypes.WEAPON)
				|| stack.getItem() instanceof AxeItem
				|| stack.getItem() instanceof MaceItem
				|| stack.getItem() instanceof TridentItem;
	}

	/** Цель должна быть жива, не быть другом и проходить выбранные фильтры. */
	private boolean isValidTarget(MinecraftClient client, LivingEntity entity) {
		if (entity == null || entity == client.player || entity.getId() == client.player.getId()
				|| !entity.isAlive() || entity.isRemoved()) {
			return false;
		}
		if (ru.neuclient.client.bot.BotManager.getInstance().isBot(entity.getName().getString())) {
			return false;
		}
		if (entity instanceof PlayerEntity player) {
			if (player.isSpectator() || isFriend(player)) {
				return false;
			}
			// AntiBot: фейковые игроки не должны забирать кулдаун и промахи
			if (ru.neuclient.client.module.impl.combat.AntiBotModule.isBot(player)) {
				return false;
			}
			if (player.isInvisible() && !hitInvisible.get()) {
				return false;
			}
			return player.getArmor() == 0 ? hitNaked.get() : hitArmored.get();
		}
		if (entity instanceof HostileEntity) {
			return hitHostileMobs.get();
		}
		// Остальные LivingEntity считаются мирными существами: животные,
		// жители и прочие нейтральные существа попадают в этот отдельный фильтр.
		return hitPeacefulMobs.get();
	}

	private boolean isFriend(Entity entity) {
		NeuClient client = NeuClient.getInstance();
		return client != null && client.getFriendManager() != null
				&& client.getFriendManager().isFriend(entity.getName().getString());
	}

	/** Выбор цели с липкостью: сначала ближайшая подходящая к текущему прицелу. */
	private LivingEntity findTarget(MinecraftClient client) {
		ClientPlayerEntity player = client.player;
		double searchDistance = effectiveRange() + TARGET_SEARCH_BONUS + 1.0;
		Box searchBox = player.getBoundingBox().expand(searchDistance);
		List<LivingEntity> candidates = new ArrayList<>();

		for (LivingEntity entity : client.world.getEntitiesByClass(LivingEntity.class, searchBox, e -> true)) {
			// Захват — по расширенному радиусу: цель берём заранее, ещё на
			// подходе. Сам удар всё равно проверяется по insideAttackReach.
			if (!isValidTarget(client, entity) || !insideSearchReach(player, entity)) {
				continue;
			}
			if (!throughWalls.get() && !player.canSee(entity)) {
				continue;
			}
			candidates.add(entity);
		}

		if (candidates.isEmpty()) {
			return null;
		}

		// ЛИПКОСТЬ — с умом под приоритет.
		//
		// Полная слепота к соседям («держимся за текущую цель, пока она
		// валидна») ломает приоритет «Дистанция»: цель убежала на край
		// радиуса, рядом встал противник в упор — аура продолжала бы
		// долбить далёкого. Но и полный отказ от липкости дёргал бы
		// прицел между двумя целями равной дальности каждый тик.
		//
		// «Дистанция»: держим текущую цель, только пока она остаётся
		// лучшей (самой близкой) — или новая не настолько ближе, чтобы её
		// сменить. Переключение идёт с гистерезисом SWITCH_MARGIN (не
		// прыгаем на доли блока), плюс всегда переключаемся, если текущая
		// цель вышла из радиуса удара, а новая — ещё внутри.
		//
		// «Здоровье»/«Броня»: прежняя липкость — цель должна выпасть из
		// списка кандидатов, иначе аура скакала бы между противниками
		// из-за того, что у соседа на полхвостика меньше здоровья/брони.
		if (target != null && candidates.contains(target)) {
			if (isDistancePriority()) {
				LivingEntity best = candidates.stream()
						.min(Comparator.comparingDouble(player::squaredDistanceTo))
						.orElse(target);
				if (best != target) {
					boolean targetOutOfReach = reachTo(player, target) > effectiveRange();
					boolean bestInReach = reachTo(player, best) <= effectiveRange();
					boolean notablyCloser = reachTo(player, best)
							<= reachTo(player, target) - SWITCH_MARGIN;
					if ((targetOutOfReach && bestInReach) || notablyCloser) {
						return best;
					}
				}
				return target;
			}
			return target;
		}

		Comparator<LivingEntity> comparator = switch (priority.get()) {
			case "Здоровье" -> Comparator.comparingDouble(LivingEntity::getHealth)
					.thenComparingDouble(player::squaredDistanceTo);
			case "Броня" -> Comparator.comparingInt(LivingEntity::getArmor)
					.thenComparingDouble(player::squaredDistanceTo);
			default -> Comparator.comparingDouble(player::squaredDistanceTo);
		};
		return candidates.stream().min(comparator).orElse(null);
	}

	private boolean insideAttackReach(ClientPlayerEntity player, LivingEntity entity) {
		return reachTo(player, entity.getBoundingBox()) <= effectiveRange();
	}

	/**
	 * Рабочая дальность удара.
	 *
	 * Профиль знает, с какой дистанции игрок реально бьёт (p90 его
	 * ударов). Это честнее ползунка: значение измерено, а не выставлено
	 * на глаз, и заведомо не выходит за реальный человеческий разброс.
	 * Ползунок используется, только если он СТРОЖЕ профиля — чтобы
	 * пользователь мог сознательно ужаться, но не мог задрать реач.
	 */
	private double effectiveRange() {
		return range.get();
	}

	/** Цель попадает в радиус ЗАХВАТА (дальность атаки + запас на подход). */
	private boolean insideSearchReach(ClientPlayerEntity player, LivingEntity entity) {
		return reachTo(player, entity.getBoundingBox()) <= effectiveRange() + TARGET_SEARCH_BONUS;
	}

	/** Расстояние от глаз до ближайшей точки хитбокса цели. */
	private static double reachTo(ClientPlayerEntity player, LivingEntity entity) {
		return reachTo(player, entity.getBoundingBox());
	}

	/** Расстояние от глаз до ближайшей точки указанного бокса. */
	private static double reachTo(ClientPlayerEntity player, Box box) {
		Vec3d eye = player.getEyePos();
		double dx = Math.max(box.minX - eye.x, Math.max(0.0, eye.x - box.maxX));
		double dy = Math.max(box.minY - eye.y, Math.max(0.0, eye.y - box.maxY));
		double dz = Math.max(box.minZ - eye.z, Math.max(0.0, eye.z - box.maxZ));
		return Math.sqrt(dx * dx + dy * dy + dz * dz);
	}

	/**
	 * Рейтрейс от глаз по фактической камере. При выключенном throughWalls
	 * дополнительно требуется ванильная видимость; при включённом настройка
	 * позволяет выбрать цель за блоком, но сервер всё равно принимает только
	 * валидный для него ванильный attackEntity.
	 */
	private boolean rayHitsTarget(ClientPlayerEntity player, LivingEntity entity) {
		Vec3d eye = player.getEyePos();
		// Луч считаем по углу, который сервер УЖЕ ПОЛУЧИЛ.
		//
		// Боевые модули тикают в START_CLIENT_TICK, то есть пакет атаки
		// уходит РАНЬШЕ, чем пакет движения этого тика. Сервер обрабатывает
		// взмах, имея ротацию из ПРЕДЫДУЩЕГО пакета. Если проверять по
		// свежему углу (спуфнутому или камере), клиент считает попадание,
		// а сервер — промах: это и есть флаги Hitboxes. Актуальное
		// отправленное значение пишет AuraTickSpoofMixin на конце тика.
		float rayYaw = ru.neuclient.client.util.RotationSpoof.hasSent()
				? ru.neuclient.client.util.RotationSpoof.sentYaw() : player.getYaw();
		float rayPitch = ru.neuclient.client.util.RotationSpoof.hasSent()
				? ru.neuclient.client.util.RotationSpoof.sentPitch() : player.getPitch();
		Vec3d look = Vec3d.fromPolar(rayPitch, rayYaw);
		Vec3d end = eye.add(look.multiply(effectiveRange()));
		// Небольшой допуск хитбокса — как было раньше: без него удар
		// срывался, когда прицел стоял у самого края модели.
		Box currentBox = entity.getBoundingBox().expand(0.12);
		boolean hitBox = currentBox.raycast(eye, end).isPresent();
		return hitBox && (throughWalls.get() || player.canSee(entity));
	}

	/**
	 * Готов ли удар по кулдауну.
	 *
	 * Порог НЕ фиксированный: каждый удар он заново разыгрывается в
	 * диапазоне 0.88–0.95. Это касается ВСЕХ режимов ауры.
	 *
	 * Зачем. Аура, бьющая ровно в 1.000, даёт идеально ровные интервалы
	 * между ударами, а дисперсия интервалов — первое, что считают
	 * проверки на автокликер. Живой игрок так не может: по записям боя
	 * его удары ложатся около 0.88–0.96 с заметным разбросом.
	 *
	 * Порог перевыбирается ПОСЛЕ КАЖДОГО удара (см. rollCooldownGate),
	 * иначе он был бы случайным лишь единожды за сессию.
	 */
	private boolean readyForAttack(ClientPlayerEntity player) {
		if (!(attackWhileEating.get() || !isEating(player))) {
			return false;
		}
		float progress = player.getAttackCooldownProgress(1.0f);
		return progress >= cooldownGate;
	}

	/** Нижняя граница разброса порога кулдауна. */
	private static final float COOLDOWN_GATE_MIN = 0.85f;
	/** Верхняя граница разброса порога кулдауна. */
	private static final float COOLDOWN_GATE_MAX = 0.95f;

	/** Текущий порог кулдауна — свой на каждый удар. */
	private float cooldownGate = COOLDOWN_GATE_MIN;

	/** Разыграть новый порог на следующий удар. */
	private void rollCooldownGate() {
		cooldownGate = COOLDOWN_GATE_MIN + (float) ThreadLocalRandom.current()
				.nextDouble(COOLDOWN_GATE_MAX - COOLDOWN_GATE_MIN);
	}

	private static boolean isEating(ClientPlayerEntity player) {
		return player.isUsingItem()
				&& player.getActiveItem().get(DataComponentTypes.FOOD) != null;
	}

	/**
	 * Точная копия ванильного PlayerEntity#isCriticalHit.
	 *
	 * Прежняя версия проверяла не всё: не хватало !isSprinting() и
	 * !hasBlindnessEffect(). Спринт — главная причина «не критует»: в
	 * спринте ваниль крит НЕ засчитывает вообще, а TargetStrafe держит
	 * спринт постоянно. Аура считала момент подходящим, била — и получала
	 * обычный удар вместо крита.
	 *
	 * Сверено по байткоду PlayerEntity#isCriticalHit (1.21.11):
	 * fallDistance > 0 && !onGround && !climbing && !touchingWater
	 * && !blindness && !hasVehicle && target instanceof LivingEntity
	 * && !sprinting.
	 */
	private static boolean canCrit(ClientPlayerEntity player) {
		return player.fallDistance > 0.0
				&& !player.isOnGround()
				&& !player.isClimbing()
				&& !player.isTouchingWater()
				&& !player.hasBlindnessEffect()
				&& !player.hasVehicle()
				&& !player.isSprinting();
	}

	/**
	 * Аура ждёт крит прямо сейчас: включены «Только криты», цель есть и
	 * удар готов, но мешает только спринт.
	 *
	 * По этому признаку KeyboardInputMixin временно снимает спринт —
	 * иначе при активном TargetStrafe (он спринтует всегда) условие крита
	 * не выполнится никогда и аура просто не будет бить.
	 */
	public boolean needsSprintOffForCrit() {
		ClientPlayerEntity player = mc.player;
		if (!isEnabled() || player == null || target == null) {
			return false;
		}
		// «Адаптивная»: в воздухе мы всё равно ждём крита, а спринт его
		// блокирует — гасим заранее, чтобы к началу спада он был снят.
		if (!onlyCrits.get() && !(adaptive.get() && !player.isOnGround())) {
			return false;
		}
		// ВАЖНО: условие НЕ включает fallDistance > 0.
		//
		// Прошлая версия требовала, чтобы игрок уже падал. Но снятие
		// спринта действует не мгновенно: ваниль решает вопрос спринта
		// внутри тика движения, и пока флаг дойдёт, момент спада уже
		// упущен — крит срывался, отсюда «очень редко критует».
		//
		// Спринт надо гасить на ВСЁ время в воздухе, тогда к началу
		// спада (fallDistance > 0) он уже снят и крит проходит.
		return !player.isOnGround()
				&& !player.isClimbing()
				&& !player.isTouchingWater()
				&& !player.hasBlindnessEffect()
				&& !player.hasVehicle();
	}

}
