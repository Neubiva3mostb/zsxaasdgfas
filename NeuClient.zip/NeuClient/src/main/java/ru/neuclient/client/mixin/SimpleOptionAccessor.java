package ru.neuclient.client.mixin;

import net.minecraft.client.option.SimpleOption;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Доступ к приватному полю {@code value} у SimpleOption<T>.
 * SimpleOption — final generic-класс, поэтому каст у нас только через
 * Object, а сеттер принимает Object (стирание дженерика).
 * Нужен FullBright'у: записать гамму +100 напрямую, минуя клэмп
 * ползунка настроек (который ограничивает значение диапазоном 0..1).
 */
@Mixin(SimpleOption.class)
public interface SimpleOptionAccessor {

	@Accessor("value")
	void pc$setValue(Object value);
}
