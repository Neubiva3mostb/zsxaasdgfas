package ru.neuclient.client.module.impl.misc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.util.InputUtil;
import net.minecraft.item.ItemStack;
import net.minecraft.item.LingeringPotionItem;
import net.minecraft.item.SplashPotionItem;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.KeyBindSetting;
import ru.neuclient.client.ui.PotionWheelScreen;
import ru.neuclient.client.util.InventoryUtil;
import ru.neuclient.client.util.KeyNames;
import ru.neuclient.client.util.SwapPause;
import ru.neuclient.client.util.SwapUtil;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Potion Thrower — быстрое метание зелий через колесо выбора.
 *
 * КАК РАБОТАЕТ. У модуля одна настройка — «Кнопка колеса» (по умолчанию
 * СКМ, само колесо мыши). Нажал её — открылось круговое меню со ВСЕМИ
 * метательными зельями из инвентаря: по кругу разложены иконки с общим
 * количеством, название наведённого сектора показывается в центре.
 * Кликнул по сектору — зелье брошено по взгляду, колесо закрылось.
 *
 * ГРУППИРОВКА. Зелья собираются со всех слотов инвентаря (хотбар 0–8 +
 * рюкзак 9–35) и группируются по предмету и имени: одинаковые зелья из
 * разных стаканов — один сектор на колесе с суммарным количеством.
 *
 * БРОСОК. Если зелье в хотбаре — берём в руку и жмём ПКМ, как обычный
 * игрок. Если в рюкзаке — честный свап в текущий слот хотбара (тот же
 * механизм, что у AutoPot/AutoSwap), бросок следующим тиком, потом слоты
 * раскладываются обратно. Пока идёт чужая операция с инвентарём
 * (SwapPause занят) — бросок откладывается, чтобы не разъехаться слотами.
 *
 * ТОЛЬКО МЕТАТЕЛЬНЫЕ. Splash и lingering зелья. Питьевые по ПКМ
 * выпиваются, а не бросаются — на колесе им делать нечего.
 *
 * КНОПКА МЫШИ В БИНДЕ. Коды 1–7 трактуются как кнопки мыши и опрашиваются
 * через glfwGetMouseButton, остальные — как клавиши (InputUtil). Имена
 * кнопок показывает KeyNames («СКМ», «МС4»...). Назначить кнопку мыши
 * через слушатель ClickGUI нельзя (он слушает только клавиатуру), но
 * колёсико по умолчанию уже назначено — СКМ.
 */
public final class PotionThrowerModule extends Module {

	/** Клавиша/кнопка открытия колеса. По умолчанию — само колесо мыши. */
	private final KeyBindSetting wheelButton =
			new KeyBindSetting("Кнопка колеса", GLFW.GLFW_MOUSE_BUTTON_MIDDLE);

	/** Предыдущее состояние кнопки колеса (детект фронта нажатия). */
	private boolean prevWheel;

	/** Хотбар-слот отложенного броска после свапа (-1 = броска нет). */
	private int pendingHotbarSlot = -1;
	/** Рюкзачный слот для обратного раскладывания (-1 = не свапали). */
	private int pendingInventorySlot = -1;
	/** Тиков до броска (клик свапа доходит на тик позже вызова). */
	private int pendingDelayTicks;

	public PotionThrowerModule() {
		super("Potion Thrower", "Быстрое метание зелий через колесо выбора", Category.MISC);
		addSettings(wheelButton);
	}

	/** Код кнопки колеса (для колеса: повторное нажатие закрывает его). */
	public int wheelButtonKey() {
		return wheelButton.get();
	}

	@Override
	protected void onDisable() {
		pendingHotbarSlot = -1;
		pendingInventorySlot = -1;
		pendingDelayTicks = 0;
		prevWheel = false;
	}

	@Override
	public void onTick(MinecraftClient client) {
		ClientPlayerEntity player = client.player;
		if (player == null || client.world == null || client.interactionManager == null) {
			return;
		}

		// 1) Доводим отложенный бросок. Экран колеса к этому моменту уже
		// закрыт, но даже если игрок успел открыть что-то другое — бросок
		// доводим до конца, иначе слоты останутся перекрученными.
		if (pendingHotbarSlot >= 0) {
			if (SwapPause.isBusy()) {
				return;
			}
			if (pendingDelayTicks > 0) {
				pendingDelayTicks--;
				return;
			}
			// pause=false: свап-пакет уходит СРАЗУ, до броска (иначе ПКМ
			// уходит со старым слотом, а свап — после броска).
			InventoryUtil.selectSlot(player, pendingHotbarSlot, client.interactionManager, false);
			client.interactionManager.interactItem(player, Hand.MAIN_HAND);
			if (pendingInventorySlot >= 0) {
				SwapUtil.restoreSwap(client, player, pendingInventorySlot, pendingHotbarSlot);
			}
			pendingHotbarSlot = -1;
			pendingInventorySlot = -1;
			return;
		}

		// 2) В экранах кнопку колеса не опрашиваем: там свой ввод, а само
		// колесо закрывается по этой же кнопке (см. PotionWheelScreen).
		if (client.currentScreen != null || player.isDead()) {
			prevWheel = false;
			return;
		}

		int key = wheelButton.get();
		if (key == KeyBindSetting.NONE) {
			prevWheel = false;
			return;
		}
		boolean now = pressed(client, key);
		boolean was = prevWheel;
		prevWheel = now;
		if (now && !was) {
			client.setScreen(new PotionWheelScreen(client.currentScreen, this));
		}
	}

	/** Опрос бинда: коды 1–7 — кнопки мыши, остальные — клавиши. */
	private static boolean pressed(MinecraftClient client, int code) {
		if (KeyNames.isMouse(code)) {
			return GLFW.glfwGetMouseButton(client.getWindow().getHandle(), code)
					== GLFW.GLFW_PRESS;
		}
		return InputUtil.isKeyPressed(client.getWindow(), code);
	}

	// ===== Колесо выбора: сбор и бросок =====

	/**
	 * Группа одинаковых зелий — один сектор на колесе. Имя берём с самого
	 * предмета, {@code total} — суммарное количество по всем стаканам.
	 */
	public static final class PotionGroup {
		/** Отображаемое имя (как его пишет сервер, без цветовых кодов). */
		public final String name;
		/** Образец для иконки и сопоставления при броске. */
		public final ItemStack sample;
		/** Сколько всего таких зелий в инвентаре. */
		public int total;

		PotionGroup(String name, ItemStack sample) {
			this.name = name;
			this.sample = sample;
		}
	}

	/**
	 * Собрать все метательные зелья инвентаря и сгруппировать по предмету
	 * и имени. Порядок — по слотам (хотбар первым).
	 */
	public List<PotionGroup> collectGroups() {
		ClientPlayerEntity player = mc.player;
		if (player == null) {
			return List.of();
		}
		Map<String, PotionGroup> out = new LinkedHashMap<>();
		for (int i = 0; i < 36; i++) {
			ItemStack stack = player.getInventory().getStack(i);
			if (stack.isEmpty() || !isThrowablePotion(stack)) {
				continue;
			}
			String name = displayName(stack);
			String key = stack.getItem() + "|" + name.toLowerCase(Locale.ROOT);
			PotionGroup group = out.get(key);
			if (group == null) {
				group = new PotionGroup(name, stack.copy());
				out.put(key, group);
			}
			group.total += stack.getCount();
		}
		return new ArrayList<>(out.values());
	}

	/**
	 * Бросить зелье из группы (вызывается из колеса по клику). Сначала
	 * хотбар, потом рюкзак через свап с отложенным броском.
	 */
	public void throwGroup(PotionGroup group, MinecraftClient client) {
		ClientPlayerEntity player = client.player;
		if (player == null || client.interactionManager == null
				|| group == null || SwapPause.isBusy()) {
			return;
		}

		// Зелье уже в хотбаре — берём в руку и бросаем сразу.
		for (int i = 0; i < 9; i++) {
			if (matches(player.getInventory().getStack(i), group)) {
				// pause=false: порядок пакетов UpdateSelectedSlot → UseItem.
				InventoryUtil.selectSlot(player, i, client.interactionManager, false);
				client.interactionManager.interactItem(player, Hand.MAIN_HAND);
				return;
			}
		}

		// Зелье в рюкзаке — свапаем в текущий слот хотбара, бросаем тиком
		// позже (клик свапа применяется с задержкой), затем раскладываем
		// слоты обратно.
		for (int i = 9; i < 36; i++) {
			if (matches(player.getInventory().getStack(i), group)) {
				int target = player.getInventory().getSelectedSlot();
				if (SwapUtil.swapToHotbar(client, player, i, target)) {
					pendingHotbarSlot = target;
					pendingInventorySlot = i;
					pendingDelayTicks = 2;
				}
				return;
			}
		}
	}

	/** Тот же предмет и то же имя, что у образца группы. */
	private boolean matches(ItemStack stack, PotionGroup group) {
		return !stack.isEmpty()
				&& stack.getItem() == group.sample.getItem()
				&& displayName(stack).toLowerCase(Locale.ROOT)
						.equals(displayName(group.sample).toLowerCase(Locale.ROOT));
	}

	/** Метательное зелье: splash или lingering (питьевые не бросаются). */
	private static boolean isThrowablePotion(ItemStack stack) {
		return stack.getItem() instanceof SplashPotionItem
				|| stack.getItem() instanceof LingeringPotionItem;
	}

	/** Имя предмета без цветовых кодов §x. */
	private static String displayName(ItemStack stack) {
		return stack.getName().getString().replaceAll("§.", "").trim();
	}
}
