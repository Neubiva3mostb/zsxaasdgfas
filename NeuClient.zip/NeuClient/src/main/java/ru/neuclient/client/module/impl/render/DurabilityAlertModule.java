package ru.neuclient.client.module.impl.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.font.MsdfFontRenderer;
import ru.neuclient.client.font.MsdfFonts;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.NumberSetting;

/**
 * DurabilityAlert — большое предупреждение по центру экрана с нативным MSDF-шрифтом.
 */
public final class DurabilityAlertModule extends Module {

	private final NumberSetting threshold = new NumberSetting("Прочность", 10.0, 1.0, 100.0, 1.0);

	public DurabilityAlertModule() {
		super("DurabilityAlert", "Предупреждение о почти сломанном предмете", Category.RENDER);
		addSettings(threshold);
	}

	public double getThreshold() {
		return threshold.get();
	}

	public static void renderAlert(DrawContext context) {
		NeuClient client = NeuClient.getInstance();
		if (client == null || client.getModuleManager() == null) {
			return;
		}
		DurabilityAlertModule module = client.getModuleManager().get(DurabilityAlertModule.class);
		if (module == null || !module.isEnabled()) {
			return;
		}
		MinecraftClient mc = MinecraftClient.getInstance();
		ClientPlayerEntity player = mc.player;
		if (player == null) {
			return;
		}
		if (!module.hasLowDurability(player)) {
			return;
		}
		long t = System.currentTimeMillis() % 720L;
		if (t > 500L) {
			return;
		}
		String text = "Предмет скоро будет сломан!";
		int x = context.getScaledWindowWidth() / 2;
		int y = context.getScaledWindowHeight() / 2 - 18;
		MsdfFontRenderer.drawCenteredWithShadow(context, MsdfFonts.sfMedium(), text, x, y, 0xFFFF3333, 11.0f);
	}

	private boolean hasLowDurability(ClientPlayerEntity player) {
		double limit = threshold.get() / 100.0;
		for (EquipmentSlot slot : new EquipmentSlot[]{
				EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS,
				EquipmentSlot.FEET, EquipmentSlot.MAINHAND, EquipmentSlot.OFFHAND}) {
			ItemStack stack = player.getEquippedStack(slot);
			if (stack.isEmpty() || !stack.isDamageable()) {
				continue;
			}
			double remaining = (double) (stack.getMaxDamage() - stack.getDamage()) / stack.getMaxDamage();
			if (remaining <= limit) {
				return true;
			}
		}
		return false;
	}
}
