package ru.neuclient.client.module.impl.combat;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.ModeSetting;

/**
 * Velocity — снижение отдачи (нокбэка) от ударов по игроку.
 *
 * Режимы:
 *  Grim      — пакет отдачи глушится полностью, но в тот же момент делается
 *              прыжок (если стояли на земле). Со стороны выглядит как jump reset,
 *              горизонтальная отдача пропадает целиком. Агрессивный вариант.
 *  Vulcan    — пакет глушится, на следующий тик применяется ослабленная скорость
 *              (40% по горизонтали, 100% по вертикали — приземление быстрое).
 *  Matrix    — полная отмена всех пакетов отдачи (сильно палится на строгих античитах).
 *  JumpReset — отдача применяется на 100%, но идеальный прыжок происходит в тот же
 *              момент: вертикаль нокбэка перезаписывается прыжком, а раннее
 *              приземление гасит горизонталь трением. Один в один легит-приём.
 *
 * Модуль только управляет собственной скоростью движения — никаких лишних
 * пакетов на сервер не отправляется.
 */
public final class VelocityModule extends Module {

    // Порог горизонтальной скорости — ниже него это течения воды и прочий мусор
    private static final double THRESHOLD = 0.2;

    private final ModeSetting mode = new ModeSetting("Режим", "Grim", "Grim", "Vulcan", "Matrix", "JumpReset");

    // Отложенное применение ослабленной скорости (режим Vulcan)
    private boolean vulcanPending;
    private double vX, vY, vZ;

    public VelocityModule() {
        super("Velocity", "Снижает отдачу от ударов по тебе", Category.COMBAT);
        addSettings(mode);
    }

    /** Вызывается из миксина в начале обработчика пакета скорости. */
    public void onVelocity(EntityVelocityUpdateS2CPacket packet, CallbackInfo ci) {
        if (mc.player == null || mc.world == null) return;
        if (packet.getEntityId() != mc.player.getId()) return;

        double x = packet.getVelocity().x;
        double y = packet.getVelocity().y;
        double z = packet.getVelocity().z;
        if (Math.hypot(x, z) < THRESHOLD) return;

        switch (mode.get()) {
            case "Grim" -> {
                // Полностью глушим нокбэк и мгновенно прыгаем — со стороны это
                // выглядит как обычный jump reset без горизонтальной отдачи
                ci.cancel();
                if (canJumpReset()) mc.player.jump();
            }
            case "Vulcan" -> {
                ci.cancel();
                vX = x; vY = y; vZ = z;
                vulcanPending = true;
            }
            case "Matrix" -> ci.cancel();
            case "JumpReset" -> {
                // Пакет НЕ отменяем: прыжок нужен ПОСЛЕ того, как ваниль
                // применит скорость, — см. onVelocityApplied (хвост хендлера)
            }
            default -> { }
        }
    }

    /** Вызывается из миксина в ХВОСТЕ обработчика — скорость уже применена. */
    public void onVelocityApplied(EntityVelocityUpdateS2CPacket packet) {
        if (!"JumpReset".equals(mode.get())) return;
        if (mc.player == null) return;
        if (packet.getEntityId() != mc.player.getId()) return;

        double x = packet.getVelocity().x;
        double z = packet.getVelocity().z;
        if (Math.hypot(x, z) < THRESHOLD) return;

        // Прыжок тем же моментом: вертикаль нокбэка перезаписывается прыжковой,
        // горизонталь гасится трением при быстром приземлении
        if (canJumpReset()) mc.player.jump();
    }

    /** Прыгать имеет смысл только с земли и вне воды/лавы/транспорта. */
    private boolean canJumpReset() {
        ClientPlayerEntity p = mc.player;
        return p != null
                && p.isOnGround()
                && !p.isTouchingWater()
                && !p.isInLava()
                && !p.hasVehicle();
    }

    /** Тик клиента — дожимаем отложенную ослабленную скорость (Vulcan). */
    @Override
    public void onTick(MinecraftClient client) {
        if (!vulcanPending) return;
        vulcanPending = false;

        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) return;
        if (!"Vulcan".equals(mode.get())) return;

        Vec3d cur = p.getVelocity();
        // Горизонталь — 40% от нокбэка, вертикаль — полная (быстрое приземление)
        p.setVelocity(cur.x + (vX - cur.x) * 0.4,
                vY,
                cur.z + (vZ - cur.z) * 0.4);
    }

    @Override
    protected void onDisable() {
        vulcanPending = false;
    }
}
