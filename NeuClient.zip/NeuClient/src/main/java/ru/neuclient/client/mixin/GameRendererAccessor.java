package ru.neuclient.client.mixin;

import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Доступ к приватным полям множителя FOV у GameRenderer.
 * WorldToScreen лерпует их (last → current по frameDelta), чтобы
 * экранная проекция совпадала с реальным FOV кадра даже при
 * спринте и эффектах скорости (FOV «дышит»).
 */
@Mixin(GameRenderer.class)
public interface GameRendererAccessor {

	@Accessor("fovMultiplier")
	float pc$getFovMultiplier();

	@Accessor("lastFovMultiplier")
	float pc$getLastFovMultiplier();
}
