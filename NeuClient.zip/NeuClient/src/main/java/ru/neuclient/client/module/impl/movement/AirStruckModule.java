package ru.neuclient.client.module.impl.movement;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInputC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.PlayerInput;
import net.minecraft.util.math.Vec3d;
import ru.neuclient.client.mixin.EntityInvoker;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.ModeSetting;

/**
 * Air Stuck — игрок «зависает» в воздухе там, где включил модуль.
 *
 * ДВА РЕЖИМА.
 *
 * «ОБЫЧНЫЙ». Мягкая заморозка: каждый тик обнуляем скорость, гасим ввод
 * и возвращаем игрока в зафиксированную точку. Серверу продолжают уходить
 * пакеты движения, но все — с одной и той же координатой, поэтому для него
 * игрок просто стоит на месте. Плюс режима в том, что клиент живёт обычной
 * жизнью. Минус — античит видит «игрока, стоящего в воздухе», и любые
 * обходы это его проблема, не наша.
 *
 * «УДАЛЯЮЩИЙ ИГРОКА». Жёсткий вариант: сущность игрока удаляется из
 * клиентского мира (setRemoved/DISCARDED — только локально, сервер о
 * выходе ничего не знает). Мир не тикает удалённую сущность, поэтому
 * клиент вообще перестаёт генерировать пакеты движения — а мы ещё и гасим
 * их на отправке (см. {@link #shouldHoldPacket}). Чтобы игрок при этом не
 * «замер окончательно», вручную крутим {@code baseTick()} — он держит
 * огонь/утопание/прочую базовую логику без физики передвижения. При
 * выключении сущность возвращается в мир ({@code unsetRemoved} +
 * {@code addEntity}) ровно в захваченную точку.
 *
 * ПАКЕТЫ. В обоих режимах на уровне сетевого обработчика гасятся
 * исходящие PlayerMoveC2SPacket, PlayerInputC2SPacket и
 * PlayerActionC2SPacket: позиция/ввод не нужны серверу в принципе
 * (игрок «не здесь»), а action-пакеты (копание, дроп) в зависе только
 * ломают синхронизацию.
 *
 * СМЕНА ИГРОКА. После респауна/смены мира приходит новый экземпляр
 * ClientPlayerEntity — точку перезахватываем, в «Удаляющем» режиме сразу
 * удаляем нового игрока из мира.
 */
public final class AirStruckModule extends Module {

	/** Режим зависания: мягкая заморозка или удаление сущности из мира. */
	private final ModeSetting mode = new ModeSetting("Режим зависания", "Обычный",
			"Обычный", "Удаляющий игрока");

	/** Точка, в которой игрок включил модуль. */
	private Vec3d lockedPos;
	/** Игрок, для которого захвачена точка (для детекта респауна). */
	private ClientPlayerEntity lockedPlayer;

	public AirStruckModule() {
		super("Air Struck", "Позволяет зависнуть в воздухе на месте", Category.MOVEMENT);
		addSettings(mode);
	}

	@Override
	protected void onEnable() {
		capture(mc.player);
		if (mc.player != null && isRemovingMode()) {
			mc.player.setRemoved(Entity.RemovalReason.DISCARDED);
		}
	}

	@Override
	protected void onDisable() {
		ClientPlayerEntity player = mc.player;
		if (player != null && player.isRemoved()) {
			// Возвращаем сущность в мир ровно в захваченную точку.
			// unsetRemoved() protected — зовём через инвокер.
			((EntityInvoker) (Object) player).pc$invokeUnsetRemoved();
			if (mc.world != null) {
				mc.world.addEntity(player);
			}
			if (lockedPos != null) {
				player.refreshPositionAfterTeleport(lockedPos);
			}
		}
		lockedPos = null;
		lockedPlayer = null;
	}

	@Override
	public void onTick(MinecraftClient client) {
		ClientPlayerEntity player = client.player;
		if (player == null || client.world == null) {
			return;
		}

		// Респаун/смена мира: игрок другой — перезахватываем состояние.
		if (player != lockedPlayer) {
			capture(player);
			if (isRemovingMode() && !player.isRemoved()) {
				player.setRemoved(Entity.RemovalReason.DISCARDED);
			}
		}
		if (lockedPos == null) {
			return;
		}

		if (player.isRemoved()) {
			// «Удаляющий игрока»: мир не тикает удалённую сущность,
			// поэтому базовый тик крутим вручную — без него встанут
			// огонь, воздух под водой и прочая базовая логика.
			player.baseTick();
			return;
		}

		// В лодке/на лошади не вмешиваемся — там своя физика.
		if (player.hasVehicle()) {
			return;
		}

		// Полная заморозка: скорость в ноль, ввод погашен, позиция на точке.
		player.setVelocity(0.0, 0.0, 0.0);
		player.input.playerInput = PlayerInput.DEFAULT;
		player.setPosition(lockedPos.x, lockedPos.y, lockedPos.z);

		// Никакого урона от падения после выключения.
		player.fallDistance = 0.0;
		player.setOnGround(false);
	}

	/**
	 * Хук из ClientCommonNetworkHandlerSendMixin: пока модуль включён,
	 * гасим исходящие пакеты движения/ввода/действий. В «Обычном» режиме
	 * они и так шляются с одной координатой, но гашение делает завис
	 * полностью невидимым для сервера; в «Удаляющем» движение и так
	 * перестаёт генерироваться, а этот фильтр — страховка от остаточных
	 * пакетов (телепорты, прыжки в первый тик и т.п.).
	 */
	public boolean shouldHoldPacket(Packet<?> packet) {
		if (!isEnabled()) {
			return false;
		}
		return packet instanceof PlayerMoveC2SPacket
				|| packet instanceof PlayerInputC2SPacket
				|| packet instanceof PlayerActionC2SPacket;
	}

	/** Захват точки под конкретного игрока. */
	private void capture(ClientPlayerEntity player) {
		lockedPlayer = player;
		lockedPos = player == null ? null : player.getEntityPos();
	}

	private boolean isRemovingMode() {
		return "Удаляющий игрока".equals(mode.get());
	}
}
