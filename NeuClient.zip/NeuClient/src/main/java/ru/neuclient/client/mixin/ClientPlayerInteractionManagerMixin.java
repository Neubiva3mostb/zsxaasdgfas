package ru.neuclient.client.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.bot.BotManager;
import ru.neuclient.client.module.ModuleManager;
import ru.neuclient.client.module.impl.player.AutoToolModule;
import ru.neuclient.client.module.impl.player.BlinkModule;
import ru.neuclient.client.module.impl.player.FastBreakModule;
import ru.neuclient.client.module.impl.combat.CriticalsModule;
import ru.neuclient.client.module.impl.render.KillEffectModule;
import ru.neuclient.client.module.impl.misc.NoFriendDamageModule;
import ru.neuclient.client.module.impl.combat.ShieldBreakerModule;
import ru.neuclient.client.module.impl.combat.WTapModule;

/**
 * Перехват атаки клиентом.
 * Срабатывает ровно в момент "успешного" удара ЛКМ по сущности
 * (до отправки пакетов на сервер):
 *  - Защита: атака по себе (Cannot interact with self) или по своим ботам отменяется;
 *  - NoFriendDamage: цель в друзьях → атака отменяется;
 *  - ShieldBreaker: цель блокирует щитом → топор берётся в руку сейчас;
 *  - иначе W-Tap: запускает окно отжатия W.
 */
@Mixin(ClientPlayerInteractionManager.class)
public abstract class ClientPlayerInteractionManagerMixin {

	@Inject(method = "attackBlock", at = @At("HEAD"))
	private void pc$autoToolStart(net.minecraft.util.math.BlockPos pos,
			net.minecraft.util.math.Direction direction, CallbackInfoReturnable<Boolean> cir) {
		pc$callAutoTool(pos);
	}

	@Inject(method = "updateBlockBreakingProgress", at = @At("HEAD"))
	private void pc$autoToolProgress(net.minecraft.util.math.BlockPos pos,
			net.minecraft.util.math.Direction direction, CallbackInfoReturnable<Boolean> cir) {
		pc$callAutoTool(pos);
	}

	/** Общий вход AutoTool: блок начали ломать (или продолжаем) — взять лучший инструмент. */
	private void pc$callAutoTool(net.minecraft.util.math.BlockPos pos) {
		try {
			AutoToolModule autoTool = NeuClient.getInstance().getModuleManager().get(AutoToolModule.class);
			if (autoTool != null && autoTool.isEnabled()) {
				autoTool.onBreakStart(pos);
			}
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка AutoTool", t);
		}
	}

	@Inject(method = "attackEntity", at = @At("HEAD"), cancellable = true)
	private void pc$onAttackEntity(PlayerEntity player, Entity target, CallbackInfo ci) {
		try {
			if (target == null || player == null) {
				ci.cancel();
				return;
			}

			// Полная защита от атаки по себе или по сущности под камерой
			if (player == target || target.getId() == player.getId()) {
				ci.cancel();
				return;
			}

			// Защита от атаки по ботам клиента
			if (BotManager.getInstance().isBot(target.getName().getString())) {
				ci.cancel();
				return;
			}

			ModuleManager modules = NeuClient.getInstance().getModuleManager();

			BlinkModule blink = modules.get(BlinkModule.class);
			if (blink != null && blink.isEnabled()) {
				blink.flushForAttack();
			}

			// Друзей не бьём
			NoFriendDamageModule nfd = modules.get(NoFriendDamageModule.class);
			if (nfd != null && nfd.isEnabled() && !nfd.canAttack(target)) {
				ci.cancel();
				return;
			}

			// Цель в блоке щитом → топор в руку, удар откладываем на следующий тик
			ShieldBreakerModule sb = modules.get(ShieldBreakerModule.class);
			if (sb != null && sb.isEnabled() && sb.onAttackStart(player, target)) {
				ci.cancel();
				return;
			}

			// Criticals: стоим на земле → микро-импульс, крит нанесём сами на спаде
			CriticalsModule crit = modules.get(CriticalsModule.class);
			if (crit != null && crit.isEnabled()
					&& crit.onAttackStart(player, target, sb != null && sb.isBusy())) {
				ci.cancel();
				return;
			}

			// Запуск W-Tap окна
			WTapModule wtap = modules.get(WTapModule.class);
			if (wtap != null && wtap.isEnabled()) {
				wtap.onAttack(target);
			}

			// Таргет худ: всплывает на 1.5 с после удара
			ru.neuclient.client.hud.impl.TargetHudElement.onHit(target);
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка в хуке атаки", t);
		}
	}

	/** Стоит ли прямо сейчас докрутка прогресса от FastBreak (защита от повторного входа). */
	private static boolean pc$fastBreakBusy;

	/**
	 * FastBreak: после обычного обновления прогресса докручиваем его ещё
	 * несколько раз за этот же тик — блок ломается быстрее.
	 *
	 * Встаём в TAIL, а не в HEAD: так мы знаем результат первого вызова и не
	 * трогаем уже сломанный блок. Флаг pc$fastBreakBusy не даёт хуку
	 * сработать повторно на наших же вызовах.
	 */
	@Inject(method = "updateBlockBreakingProgress", at = @At("RETURN"))
	private void pc$fastBreak(net.minecraft.util.math.BlockPos pos,
			net.minecraft.util.math.Direction direction, CallbackInfoReturnable<Boolean> cir) {
		if (pc$fastBreakBusy) {
			return;
		}
		// Блок уже сломан первым вызовом — докручивать нечего
		if (cir.getReturnValue() != null && !cir.getReturnValue()) {
			return;
		}
		try {
			FastBreakModule fastBreak = NeuClient.getInstance().getModuleManager().get(FastBreakModule.class);
			if (fastBreak == null || !fastBreak.isEnabled()) {
				return;
			}
			ClientPlayerInteractionManager self = (ClientPlayerInteractionManager) (Object) this;
			pc$fastBreakBusy = true;
			try {
				int extra = fastBreak.extraBreakingCalls();
				for (int i = 0; i < extra && self.isBreakingBlock(); i++) {
					if (!self.updateBlockBreakingProgress(pos, direction)) {
						break;
					}
				}
			} finally {
				pc$fastBreakBusy = false;
			}
		} catch (Throwable t) {
			pc$fastBreakBusy = false;
			NeuClient.LOGGER.error("[NeuClient] Ошибка FastBreak", t);
		}
	}

	/**
	 * Сразу после отправки attack-пакета, до локального PlayerEntity.attack.
	 * Не зависит от KillEffect/TargetHUD и не срабатывает на отменённых HEAD-хуком атаках.
	 */
	@Inject(method = "attackEntity", at = @At(value = "INVOKE",
			target = "Lnet/minecraft/client/network/ClientPlayNetworkHandler;sendPacket(Lnet/minecraft/network/packet/Packet;)V",
			shift = At.Shift.AFTER), require = 1)
	private void pc$trackTargetEsp(PlayerEntity player, Entity target, CallbackInfo ci) {
		if (player != MinecraftClient.getInstance().player || player.isSpectator()) return;
		try {
			BotManager.getInstance().onAttackPacket(target);
			ru.neuclient.client.module.impl.render.TargetEspModule.onAttack(target);
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка регистрации цели TargetESP", t);
		}
	}

	/** Отслеживаем только фактическую атаку после того, как HEAD-хуки её не отменили. */
	@Inject(method = "attackEntity", at = @At("RETURN"))
	private void pc$trackKillEffect(PlayerEntity player, Entity target, CallbackInfo ci) {
		if (player == MinecraftClient.getInstance().player && target != null) {
			KillEffectModule.onAttack(target);
		}
	}
}
