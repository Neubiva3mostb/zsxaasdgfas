package ru.neuclient.client.module.impl.movement;

import ru.neuclient.client.module.impl.combat.AttackAuraModule;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.MathHelper;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.BooleanSetting;
import ru.neuclient.client.setting.NumberSetting;

/**
 * TargetStrafe — облёт цели по кругу.
 *
 * ПОЧЕМУ ПЕРЕПИСАН (важно, чтобы не вернуться к старой ошибке).
 * Первая версия каждый тик вызывала setVelocity() с посчитанным вектором.
 * Сервер такое движение воспроизвести не может в принципе: он симулирует
 * игрока по НАЖАТЫМ КЛАВИШАМ и ОТПРАВЛЕННОМУ УГЛУ, а не по вектору. Любое
 * прямое присваивание скорости = мгновенный Simulation (0,16…0,44 в логе
 * — это уже целые доли блока расхождения).
 *
 * Правильная схема (из присланного референса) не трогает скорость вообще:
 *  • ввод подменяется на БУЛЕВЫ клавиши: forward = ±1, strafe = ±1;
 *  • подменяется YAW, от которого ваниль считает направление движения;
 *  • этот же yaw уходит серверу.
 * Дальше физику считает сама ваниль. Сервер, получив тот же yaw и те же
 * клавиши, повторит расчёт бит в бит — расхождения нет по построению.
 *
 * КАК СЧИТАЕТСЯ YAW (setRotation в референсе):
 *  1. Берём угол на цель.
 *  2. Прибавляем небольшое смещение (10° × направление) — «обходим» её.
 *  3. От цели по этому углу откладываем точку на расстоянии радиуса.
 *  4. Пересчитываем yaw уже НА ЭТУ ТОЧКУ. Игрок бежит вперёд (W), но
 *     повёрнут по касательной — получается движение по окружности.
 *
 * СКОРОСТЬ НЕ МЕНЯЕТСЯ. Никакого boost/friction: модуль только
 * поворачивает и жмёт клавиши, разгон остаётся ванильным. Спринт при этом
 * снимается — иначе при движении вбок сервер увидел бы спринт без
 * движения вперёд.
 */
public final class TargetStrafeModule extends Module {

	/**
	 * Дистанция, ближе которой начинаем кружить (референс: 2 блока).
	 * Дальше неё модуль не бездействует, а БЕЖИТ к цели — см. chasing.
	 */
	private static final double ENGAGE_DISTANCE = 2.0;

	private final NumberSetting radius = new NumberSetting("Радиус", 1.5, 1.0, 2.0, 0.05);
	private final NumberSetting angleOffset = new NumberSetting("Смещение угла", 10.0, 0.0, 45.0, 1.0);
	private final BooleanSetting autoJump = new BooleanSetting("Автопрыжок", true);

	/** Направление облёта: true — влево, false — вправо. */
	private boolean left = true;
	/** Был ли контакт со стеной на прошлом тике (антидребезг разворота). */
	private boolean colliding;

	/** Цель облёта и рассчитанный для неё yaw. */
	private LivingEntity target;
	private float strafeYaw;
	/** Модуль реально управляет движением прямо сейчас. */
	private boolean strafing;
	/** Игрок пересекается с целью — надо отходить назад. */
	private boolean intersecting;
	/**
	 * Режим погони: цель дальше ENGAGE_DISTANCE, бежим прямо на неё.
	 * Отличается от облёта только смещением угла (0° вместо касательной)
	 * и тем, что автопрыжок не нужен — по земле догонять быстрее.
	 */
	private boolean chasing;
	/** Модуль хочет прыгнуть в этом тике (исполняется через клавишу). */
	private boolean wantJump;

	public TargetStrafeModule() {
		super("TargetStrafe", "Сам бегает вокруг цели при AttackAura", Category.MOVEMENT);
		addSettings(radius, angleOffset, autoJump);
	}

	@Override
	protected void onEnable() {
		left = true;
		colliding = false;
		strafing = false;
		target = null;
	}

	@Override
	protected void onDisable() {
		strafing = false;
		wantJump = false;
		target = null;
	}

	@Override
	public void onTick(MinecraftClient client) {
		ClientPlayerEntity player = client.player;
		strafing = false;
		wantJump = false;
		if (player == null || client.world == null) {
			target = null;
			return;
		}
		// С открытым экраном работаем, только если InvMove включён
		if (client.currentScreen != null) {
			ru.neuclient.client.module.impl.movement.InvMoveModule invMove =
					ru.neuclient.client.NeuClient.getInstance().getModuleManager().get(ru.neuclient.client.module.impl.movement.InvMoveModule.class);
			if (invMove == null || !invMove.isEnabled()) {
				target = null;
				return;
			}
		}
		// В воде и при плавании не вмешиваемся: там своя физика
		if (player.hasVehicle() || player.isTouchingWater() || player.isInLava()
				|| player.isSwimming() || player.isClimbing() || player.isGliding()) {
			target = null;
			return;
		}

		// Цель берём только у ауры: кружить надо вокруг того, кого бьём.
		// Аура захватывает цель на 2 блока раньше дистанции удара, поэтому
		// погоня успевает начаться до того, как пора бить.
		AttackAuraModule aura = AttackAuraModule.active();
		target = aura != null ? aura.getTarget() : null;
		if (target == null) {
			return;
		}
		// Далеко — догоняем, вплотную — кружим
		chasing = !allowStrafe(player);

		// Ручное управление стрейфом имеет приоритет: жмёшь A — идём влево
		if (client.options.leftKey.isPressed()) {
			left = true;
		}
		if (client.options.rightKey.isPressed()) {
			left = false;
		}
		// Уперлись в стену или впереди обрыв — разворачиваемся.
		// Флаг colliding нужен, чтобы не дёргаться каждый тик у стены.
		if (player.horizontalCollision) {
			if (!colliding) {
				left = !left;
			}
			colliding = true;
		} else {
			colliding = false;
		}

		intersecting = player.getBoundingBox().intersects(target.getBoundingBox());
		strafeYaw = computeYaw(player);
		strafing = true;

		// Прыжок НЕ выполняется здесь напрямую.
		//
		// Прежняя версия звала player.jump() из onTick. Это добавляло
		// вертикальную скорость в обход ввода: серверу в PlayerInputC2SPacket
		// уходил jump=false, он прыжка не ждал и получал расхождение по Y —
		// ровно тот Simulation, что появлялся при сближении (0,04…0,09).
		// Хуже того, jump() применяет спринт-рывок вперёд по ТЕКУЩЕМУ yaw,
		// а у сервера в этот момент угол от спуфа ауры — расхождение и по XZ.
		//
		// Теперь модуль лишь поднимает флаг, а сам прыжок делает ваниль по
		// клавише (см. KeyboardInputMixin): сервер видит jump=true и
		// повторяет расчёт сам.
		wantJump = autoJump.get() && player.isOnGround();
	}

	/**
	 * Yaw для движения по касательной.
	 *
	 * Логика из референса: угол на цель + смещение, затем точка на
	 * окружности радиуса вокруг цели, и yaw уже на неё.
	 */
	private float computeYaw(ClientPlayerEntity player) {
		double tx = target.getX();
		double tz = target.getZ();

		// Угол от игрока на цель
		float base = (float) Math.toDegrees(
				Math.atan2(tz - player.getZ(), tx - player.getX())) - 90.0f;

		// В погоне бежим ПРЯМО на цель: смещения по касательной нет,
		// иначе игрок нарезал бы круги, так и не сблизившись.
		if (chasing) {
			float real = player.getYaw();
			return real + MathHelper.wrapDegrees(base - real);
		}

		// Смещение в сторону облёта
		int mul = left ? 1 : -1;
		float shifted = base + angleOffset.get().floatValue() * mul;

		// Точка на окружности вокруг цели по смещённому углу
		double r = radius.get();
		double px = -MathHelper.sin((float) Math.toRadians(shifted)) * r + tx;
		double pz = MathHelper.cos((float) Math.toRadians(shifted)) * r + tz;

		// Итоговый yaw — на эту точку. Сохраняем «обороты» игрока, чтобы
		// не ловить AimModulo360 (ванильный yaw не нормализуется).
		float raw = (float) Math.toDegrees(
				Math.atan2(pz - player.getZ(), px - player.getX())) - 90.0f;
		float real = player.getYaw();
		return real + MathHelper.wrapDegrees(raw - real);
	}

	/** Кружим только вплотную, как в референсе: ≤ 2 блоков. */
	private boolean allowStrafe(ClientPlayerEntity player) {
		return player.getBoundingBox().expand(1.5).intersects(target.getBoundingBox())
				&& player.distanceTo(target) <= ENGAGE_DISTANCE;
	}

	// ===== Доступ для миксинов =====

	/** Модуль управляет движением прямо сейчас. */
	public boolean isStrafing() {
		return isEnabled() && strafing;
	}

	/**
	 * Идёт погоня (цель дальше дистанции облёта).
	 * В этом режиме спринт нужен — иначе цель не догнать; при облёте он
	 * наоборот снимается, чтобы сервер не увидел спринт без forward.
	 */
	public boolean isChasing() {
		return chasing;
	}

	/**
	 * Нужно ли жать пробел в этом тике.
	 *
	 * Прыжки идут и в погоне, и при облёте: бег «шагом» медленнее, чем
	 * прыжками, — в воздухе нет трения, и спринт-прыжок сохраняет скорость.
	 */
	public boolean wantsJump() {
		return wantJump;
	}

	/**
	 * НАПРАВЛЕНИЕ ДВИЖЕНИЯ В МИРОВЫХ КООРДИНАТАХ, в градусах.
	 *
	 * Модуль намеренно НЕ подменяет yaw, уходящий серверу: за угол уже
	 * отвечает аура, и два спуфа подрались бы. Вместо
	 * этого отдаём желаемое мировое направление, а клавиши под него
	 * подбираются в KeyboardInputMixin относительно того угла, который
	 * реально уйдёт серверу. Тогда сервер, симулируя по клавишам и своему
	 * yaw, получит ровно тот же вектор — расхождения нет.
	 *
	 * Формула ванили: мировое направление = yaw + atan2(−strafe, forward).
	 */
	public float getDesiredWorldAngle() {
		double local = Math.toDegrees(Math.atan2(-getStrafeInput(), getForwardInput()));
		return (float) (strafeYaw + local);
	}

	/**
	 * Ввод «вперёд»: обычно 1, но если влезли внутрь хитбокса цели —
	 * отходим назад, чтобы не толкаться в неё.
	 */
	public float getForwardInput() {
		return (!chasing && intersecting) ? -1.0f : 1.0f;
	}

	/** Ввод вбок: сторона облёта. В погоне вбок не уводим. */
	public float getStrafeInput() {
		if (chasing) {
			return 0.0f;
		}
		return left ? 1.0f : -1.0f;
	}

	/** Активный экземпляр модуля для миксинов (null — выключен/не работает). */
	public static TargetStrafeModule active() {
		var c = ru.neuclient.client.NeuClient.getInstance();
		if (c == null || c.getModuleManager() == null) {
			return null;
		}
		TargetStrafeModule m = c.getModuleManager().get(TargetStrafeModule.class);
		return m != null && m.isStrafing() ? m : null;
	}
}
