package ru.neuclient.client.module.impl.render;

import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LightningEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.render.WorldRenderUtil;
import ru.neuclient.client.setting.ModeSetting;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;

/** Визуальные эффекты после убийства игрока локальным игроком. */
public final class KillEffectModule extends Module {

	private static final String CUBES = "Кубы";
	private static final String PYRAMIDS = "Пирамиды";
	private static final String FOUNTAIN = "Фонтан";
	private static final String LIGHTNING = "Молния";

	private static final long WATCH_MS = 2_500L;
	private static final long EFFECT_MS = 1_800L;

	private final ModeSetting effect = new ModeSetting("Эффект", CUBES,
			CUBES, PYRAMIDS, FOUNTAIN, LIGHTNING);
	private final ru.neuclient.client.setting.ColorSetting color = new ru.neuclient.client.setting.ColorSetting("Цвет", 0xFF7A5CFF);
	private final Random random = new Random();

	private final Map<Integer, WatchedTarget> watched = new HashMap<>();
	private final List<ActiveEffect> activeEffects = new ArrayList<>();

	private static final class WatchedTarget {
		final Entity entity;
		final long expiresAt;

		WatchedTarget(Entity entity, long expiresAt) {
			this.entity = entity;
			this.expiresAt = expiresAt;
		}
	}

	/** Одна геометрическая частица для режимов «Кубы», «Пирамиды» и «Фонтан». */
	private static final class Shard {
		double x;
		double y;
		double z;
		double velocityX;
		double velocityY;
		double velocityZ;
		double gravity;
		float yaw;
		float pitch;
		float roll;
		float spinYaw;
		float spinPitch;
		float spinRoll;
		float size;
		int kind;

		Shard(double x, double y, double z, double velocityX, double velocityY, double velocityZ,
				double gravity, float size, int kind, Random random) {
			this.x = x;
			this.y = y;
			this.z = z;
			this.velocityX = velocityX;
			this.velocityY = velocityY;
			this.velocityZ = velocityZ;
			this.gravity = gravity;
			this.size = size;
			this.kind = kind;
			this.yaw = random.nextFloat() * (float) (Math.PI * 2.0);
			this.pitch = random.nextFloat() * (float) (Math.PI * 2.0);
			this.roll = random.nextFloat() * (float) (Math.PI * 2.0);
			this.spinYaw = (random.nextFloat() - 0.5f) * 0.22f;
			this.spinPitch = (random.nextFloat() - 0.5f) * 0.18f;
			this.spinRoll = (random.nextFloat() - 0.5f) * 0.24f;
		}
	}

	private static final class ActiveEffect {
		final Entity entity;
		final int entityId;
		final Vec3d position;
		final long startedAt;
		final String mode;
		final List<Shard> shards = new ArrayList<>();

		ActiveEffect(Entity entity, Vec3d position, long startedAt, String mode) {
			this.entity = entity;
			this.entityId = entity.getId();
			this.position = position;
			this.startedAt = startedAt;
			this.mode = mode;
		}
	}

	public KillEffectModule() {
		super("KillEffect", "Эффект после убийства игрока", Category.RENDER);
		addSettings(effect, color);
	}

	@Override
	protected void onEnable() {
		watched.clear();
		activeEffects.clear();
	}

	@Override
	protected void onDisable() {
		watched.clear();
		activeEffects.clear();
	}

	/** Вызывается после реальной отправки атаки локального игрока. */
	public void trackAttack(Entity target) {
		if (!isEnabled() || !(target instanceof PlayerEntity) || target == mc.player) {
			return;
		}
		long now = System.currentTimeMillis();
		watched.put(target.getId(), new WatchedTarget(target, now + WATCH_MS));
	}

	@Override
	public void onTick(MinecraftClient client) {
		long now = System.currentTimeMillis();

		Iterator<Map.Entry<Integer, WatchedTarget>> watchIt = watched.entrySet().iterator();
		while (watchIt.hasNext()) {
			WatchedTarget watch = watchIt.next().getValue();
			Entity entity = watch.entity;
			if (entity instanceof LivingEntity living
					&& (!living.isAlive() || living.getHealth() <= 0.0f || entity.isRemoved())) {
				startEffect(entity, now);
				watchIt.remove();
			} else if (now >= watch.expiresAt) {
				watchIt.remove();
			}
		}

		for (ActiveEffect active : activeEffects) {
			updateShards(active);
		}

		Iterator<ActiveEffect> effectIt = activeEffects.iterator();
		while (effectIt.hasNext()) {
			ActiveEffect active = effectIt.next();
			if (now - active.startedAt > EFFECT_MS) {
				effectIt.remove();
				if (client.world != null) {
					client.world.removeEntity(active.entityId, Entity.RemovalReason.DISCARDED);
				}
			}
		}
	}

	private void startEffect(Entity entity, long now) {
		for (ActiveEffect active : activeEffects) {
			if (active.entityId == entity.getId()) {
				return;
			}
		}

		String mode = effect.get();
		Vec3d position = new Vec3d(entity.getX(), entity.getY(), entity.getZ());
		ActiveEffect active = new ActiveEffect(entity, position, now, mode);
		if (isShardMode(mode)) {
			createShards(active);
		}
		activeEffects.add(active);

		if (LIGHTNING.equals(mode)) {
			spawnVanillaLightning(position);
		}
	}

	private boolean isShardMode(String mode) {
		return CUBES.equals(mode) || PYRAMIDS.equals(mode) || FOUNTAIN.equals(mode);
	}

	private void createShards(ActiveEffect active) {
		int count = 20;
		boolean fountain = FOUNTAIN.equals(active.mode);
		for (int i = 0; i < count; i++) {
			double angle = random.nextDouble() * Math.PI * 2.0;
			double radial = fountain
					? 0.015 + random.nextDouble() * 0.08
					: 0.05 + random.nextDouble() * 0.16;
			double height = fountain
					? 0.16 + random.nextDouble() * 0.12
					: 0.06 + random.nextDouble() * 0.13;
			double startY = active.position.y + 0.75 + random.nextDouble() * 1.15;
			int kind;
			if (CUBES.equals(active.mode)) {
				kind = 0;
			} else if (PYRAMIDS.equals(active.mode)) {
				kind = 1;
			} else {
				kind = random.nextBoolean() ? 0 : 1;
			}
			active.shards.add(new Shard(
					active.position.x + (random.nextDouble() - 0.5) * 0.35,
					startY,
					active.position.z + (random.nextDouble() - 0.5) * 0.35,
					Math.cos(angle) * radial,
					height,
					Math.sin(angle) * radial,
					fountain ? 0.008 : 0.010,
					(float) (0.10 + random.nextDouble() * 0.12), kind, random));
		}
	}

	private void updateShards(ActiveEffect active) {
		for (Shard shard : active.shards) {
			shard.x += shard.velocityX;
			shard.y += shard.velocityY;
			shard.z += shard.velocityZ;
			shard.velocityY -= shard.gravity;
			shard.yaw += shard.spinYaw;
			shard.pitch += shard.spinPitch;
			shard.roll += shard.spinRoll;
		}
	}

	/** Клиентская косметическая молния: серверу и миру урон/огонь не уходят. */
	private void spawnVanillaLightning(Vec3d position) {
		MinecraftClient client = MinecraftClient.getInstance();
		if (client.world == null) return;
		LightningEntity lightning = new LightningEntity(EntityType.LIGHTNING_BOLT, client.world);
		lightning.setPosition(position.x, position.y, position.z);
		lightning.setCosmetic(true);
		client.world.addEntity(lightning);
	}

	/**
	 * Сервер иногда удаляет игрока сразу после смерти. Запускаем эффект
	 * прямо из removeEntity, пока объект ещё доступен, и удерживаем его
	 * локально до окончания анимации.
	 */
	public boolean onEntityRemoved(int entityId) {
		if (!isEnabled()) return false;
		for (ActiveEffect active : activeEffects) {
			if (active.entityId == entityId) return true;
		}
		WatchedTarget watch = watched.remove(entityId);
		if (watch == null) return false;
		startEffect(watch.entity, System.currentTimeMillis());
		return true;
	}

	/** Разрешить появление нового экземпляра игрока после respawn. */
	public void onEntityAdded(Entity replacement) {
		if (!isEnabled() || replacement == null) return;
		ActiveEffect matched = null;
		for (ActiveEffect active : activeEffects) {
			if (active.entityId == replacement.getId() && active.entity != replacement) {
				matched = active;
				break;
			}
		}
		if (matched == null) return;

		activeEffects.remove(matched);
		watched.remove(matched.entityId);
		MinecraftClient client = MinecraftClient.getInstance();
		if (client.world != null) {
			client.world.removeEntity(matched.entityId, Entity.RemovalReason.DISCARDED);
		}
	}

	/** Удержать старый объект в ClientWorld на время визуальной анимации. */
	public boolean shouldKeepEntity(int entityId) {
		if (!isEnabled()) return false;
		for (ActiveEffect active : activeEffects) {
			if (active.entityId == entityId
					&& System.currentTimeMillis() - active.startedAt <= EFFECT_MS) {
				return true;
			}
		}
		return watched.containsKey(entityId);
	}

	/** Во время любого KillEffect обычная модель убитого игрока не рисуется. */
	public boolean shouldHideBody(int entityId) {
		if (!isEnabled()) return false;
		for (ActiveEffect active : activeEffects) {
			if (active.entityId == entityId) {
				return true;
			}
		}
		return false;
	}

	/** Рендер геометрических режимов «Кубы», «Пирамиды» и «Фонтан». */
	public void renderWorld(WorldRenderContext context, MinecraftClient client) {
		if (!isEnabled() || activeEffects.isEmpty() || context.commandQueue() == null) return;

		Vec3d camera = client.gameRenderer.getCamera().getCameraPos();
		long now = System.currentTimeMillis();
		int accent = color.get();
		float red = WorldRenderUtil.red(accent);
		float green = WorldRenderUtil.green(accent);
		float blue = WorldRenderUtil.blue(accent);

		context.matrices().push();
		context.matrices().translate(-camera.x, -camera.y, -camera.z);
		context.commandQueue().submitCustom(context.matrices(), WorldRenderUtil.QUADS, (entry, buffer) -> {
			Matrix4f matrix = entry.getPositionMatrix();
			for (ActiveEffect active : activeEffects) {
				if (!isShardMode(active.mode)) continue;
				float progress = Math.max(0.0f, Math.min(1.0f,
						(now - active.startedAt) / (float) EFFECT_MS));
				float alpha = (1.0f - progress) * (1.0f - progress) * 0.9f;
				for (Shard shard : active.shards) {
					if (shard.y < active.position.y - 2.0 || shard.y > active.position.y + 8.0) continue;
					if (shard.kind == 1) {
						drawPyramid(buffer, matrix, shard, red, green, blue, alpha);
					} else {
						drawCube(buffer, matrix, shard, red, green, blue, alpha);
					}
				}
			}
		});
		context.matrices().pop();
	}

	private static Vec3d point(Shard shard, double localX, double localY, double localZ) {
		double cosYaw = Math.cos(shard.yaw);
		double sinYaw = Math.sin(shard.yaw);
		double x = localX * cosYaw - localZ * sinYaw;
		double z = localX * sinYaw + localZ * cosYaw;

		double cosPitch = Math.cos(shard.pitch);
		double sinPitch = Math.sin(shard.pitch);
		double y = localY * cosPitch - z * sinPitch;
		z = localY * sinPitch + z * cosPitch;

		double cosRoll = Math.cos(shard.roll);
		double sinRoll = Math.sin(shard.roll);
		double rotatedX = x * cosRoll - y * sinRoll;
		double rotatedY = x * sinRoll + y * cosRoll;
		return new Vec3d(shard.x + rotatedX, shard.y + rotatedY, shard.z + z);
	}

	private static void drawCube(VertexConsumer buffer, Matrix4f matrix, Shard shard,
			float red, float green, float blue, float alpha) {
		double h = shard.size * 0.5;
		Vec3d p000 = point(shard, -h, -h, -h);
		Vec3d p100 = point(shard, h, -h, -h);
		Vec3d p110 = point(shard, h, h, -h);
		Vec3d p010 = point(shard, -h, h, -h);
		Vec3d p001 = point(shard, -h, -h, h);
		Vec3d p101 = point(shard, h, -h, h);
		Vec3d p111 = point(shard, h, h, h);
		Vec3d p011 = point(shard, -h, h, h);
		WorldRenderUtil.quad(buffer, matrix, p000.x, p000.y, p000.z, p100.x, p100.y, p100.z,
				p110.x, p110.y, p110.z, p010.x, p010.y, p010.z, red, green, blue, alpha);
		WorldRenderUtil.quad(buffer, matrix, p001.x, p001.y, p001.z, p011.x, p011.y, p011.z,
				p111.x, p111.y, p111.z, p101.x, p101.y, p101.z, red, green, blue, alpha);
		WorldRenderUtil.quad(buffer, matrix, p000.x, p000.y, p000.z, p001.x, p001.y, p001.z,
				p101.x, p101.y, p101.z, p100.x, p100.y, p100.z, red, green, blue, alpha);
		WorldRenderUtil.quad(buffer, matrix, p010.x, p010.y, p010.z, p110.x, p110.y, p110.z,
				p111.x, p111.y, p111.z, p011.x, p011.y, p011.z, red, green, blue, alpha);
		WorldRenderUtil.quad(buffer, matrix, p000.x, p000.y, p000.z, p010.x, p010.y, p010.z,
				p011.x, p011.y, p011.z, p001.x, p001.y, p001.z, red, green, blue, alpha);
		WorldRenderUtil.quad(buffer, matrix, p100.x, p100.y, p100.z, p101.x, p101.y, p101.z,
				p111.x, p111.y, p111.z, p110.x, p110.y, p110.z, red, green, blue, alpha);
	}

	private static void drawPyramid(VertexConsumer buffer, Matrix4f matrix, Shard shard,
			float red, float green, float blue, float alpha) {
		double h = shard.size * 0.55;
		double height = shard.size * 1.45;
		Vec3d b0 = point(shard, -h, -h, -h);
		Vec3d b1 = point(shard, h, -h, -h);
		Vec3d b2 = point(shard, h, -h, h);
		Vec3d b3 = point(shard, -h, -h, h);
		Vec3d top = point(shard, 0.0, height, 0.0);
		WorldRenderUtil.triangle(buffer, matrix, b0.x, b0.y, b0.z, b1.x, b1.y, b1.z,
				 top.x, top.y, top.z, red, green, blue, alpha);
		WorldRenderUtil.triangle(buffer, matrix, b1.x, b1.y, b1.z, b2.x, b2.y, b2.z,
				top.x, top.y, top.z, red, green, blue, alpha);
		WorldRenderUtil.triangle(buffer, matrix, b2.x, b2.y, b2.z, b3.x, b3.y, b3.z,
				top.x, top.y, top.z, red, green, blue, alpha);
		WorldRenderUtil.triangle(buffer, matrix, b3.x, b3.y, b3.z, b0.x, b0.y, b0.z,
				top.x, top.y, top.z, red, green, blue, alpha);
		WorldRenderUtil.quad(buffer, matrix, b0.x, b0.y, b0.z, b3.x, b3.y, b3.z,
				b2.x, b2.y, b2.z, b1.x, b1.y, b1.z, red, green, blue, alpha * 0.75f);
	}

	public static KillEffectModule active() {
		NeuClient client = NeuClient.getInstance();
		if (client == null || client.getModuleManager() == null) return null;
		KillEffectModule module = client.getModuleManager().get(KillEffectModule.class);
		return module != null && module.isEnabled() ? module : null;
	}

	public static void onAttack(Entity target) {
		KillEffectModule module = active();
		if (module != null) module.trackAttack(target);
	}

	/** Совместимость со старым вызовом из NeuClient. */
	public static void renderAllWorld(WorldRenderContext context) {
		KillEffectModule module = active();
		if (module != null) module.renderWorld(context, MinecraftClient.getInstance());
	}
}
