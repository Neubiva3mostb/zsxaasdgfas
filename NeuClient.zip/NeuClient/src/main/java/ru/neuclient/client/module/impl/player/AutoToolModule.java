package ru.neuclient.client.module.impl.player;

import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.util.InventoryUtil;
import ru.neuclient.client.util.SwapUtil;

/**
 * AutoTool — при начале ломания блока легитно берёт лучший инструмент
 * в руку (как ShieldBreaker берёт топор), а когда ломание закончилось —
 * возвращает слот/предметы как было.
 *
 * Поиск: сначала хотбар (переключение слота с мгновенной синкой серверу),
 * потом основной инвентарь (честный свап инвентарь↔хотбар клавишей-цифрой).
 * Если инструмент, который уже в руке, не хуже найденного — не дёргаемся.
 */
public final class AutoToolModule extends Module {

	/** Изначально выбранный слот хотбара (-1 = не меняли). */
	private int restoreSlot = -1;
	/** Слот инвентаря, с которым делали свап (-1 = свапа не было). */
	private int restoreInvSlot = -1;
	/**
	 * Ячейка хотбара, В КОТОРУЮ клали инструмент.
	 *
	 * Хранится отдельно, потому что вернуть предмет надо именно в ту
	 * ячейку, из которой его брали. Раньше возврат шёл в «текущий
	 * выбранный слот»: стоило игроку крутнуть колесо во время ломания,
	 * и SWAP уносил инструмент в чужую ячейку, перемешивая хотбар.
	 */
	private int restoreHotbarSlot = -1;
	/** true = ждём завершения ломания, чтобы вернуть всё обратно. */
	private boolean restorePending;

	public AutoToolModule() {
		super("AutoTool", "Берёт лучший инструмент при ломании блока", Category.PLAYER);
	}

	/** Вызывается из хуков attackBlock / updateBlockBreakingProgress. */
	public void onBreakStart(BlockPos pos) {
		ClientPlayerEntity player = mc.player;
		if (player == null || mc.world == null || mc.interactionManager == null) {
			return;
		}
		BlockState state = mc.world.getBlockState(pos);
		if (state.isAir()) {
			return;
		}

		PlayerInventory inv = player.getInventory();
		int current = inv.getSelectedSlot();
		float currentSpeed = inv.getStack(current).getMiningSpeedMultiplier(state);

		// Лучший инструмент по скорости добычи этого блока (хотбар + инвентарь)
		int bestSlot = -1;
		float bestSpeed = currentSpeed;
		for (int i = 0; i <= 35; i++) {
			if (i == current) {
				continue;
			}
			ItemStack stack = inv.getStack(i);
			if (stack.isEmpty()) {
				continue;
			}
			float speed = stack.getMiningSpeedMultiplier(state);
			if (speed > bestSpeed) {
				bestSpeed = speed;
				bestSlot = i;
			}
		}
		if (bestSlot < 0) {
			return; // в руке уже не хуже лучшего — не дёргаемся
		}

		if (bestSlot < 9) {
			// Хотбар: легитное переключение слота с мгновенной синкой серверу
			InventoryUtil.selectSlot(player, bestSlot, mc.interactionManager);
			if (restoreSlot < 0) {
				restoreSlot = current;
			}
		} else {
			// Инвентарь: честный свап в текущий слот хотбара
			if (SwapUtil.swapToHotbar(mc, player, bestSlot, current) && restoreInvSlot < 0) {
				restoreInvSlot = bestSlot;
				restoreHotbarSlot = current;
			}
		}
		restorePending = true;
	}

	@Override
	public void onTick(MinecraftClient client) {
		// Отложенный свап ещё в очереди (уходит на тик позже вызова —
		// см. SwapPause): возвращать слоты сейчас значит откатить
		// инструмент раньше, чем он вообще доехал в руку.
		if (ru.neuclient.client.util.SwapPause.isBusy()) {
			return;
		}
		// Ломание закончилось (блок добыт / отпустили ЛКМ) — возвращаем всё как было
		if (restorePending && (client.interactionManager == null
				|| !client.interactionManager.isBreakingBlock())) {
			restorePending = false;
			restore(client.player);
		}
	}

	/**
	 * Возврат слотов на исходные места.
	 *
	 * Порядок важен: сначала предметы, потом выбранная ячейка. Иначе
	 * SWAP успел бы сработать уже относительно возвращённого слота.
	 */
	private void restore(ClientPlayerEntity player) {
		if (player == null || mc.interactionManager == null) {
			restoreSlot = -1;
			restoreInvSlot = -1;
			restoreHotbarSlot = -1;
			return;
		}
		// Инструмент уезжает ровно туда, откуда пришёл: тот же обмен
		// повторно (SWAP симметричен) и та же ячейка хотбара.
		if (restoreInvSlot >= 0 && restoreHotbarSlot >= 0) {
			SwapUtil.restoreSwap(mc, player, restoreInvSlot, restoreHotbarSlot);
		}
		restoreInvSlot = -1;
		restoreHotbarSlot = -1;

		if (restoreSlot >= 0) {
			InventoryUtil.selectSlot(player, restoreSlot, mc.interactionManager);
			restoreSlot = -1;
		}
	}

	@Override
	protected void onDisable() {
		restorePending = false;
		restore(mc.player);
	}
}
