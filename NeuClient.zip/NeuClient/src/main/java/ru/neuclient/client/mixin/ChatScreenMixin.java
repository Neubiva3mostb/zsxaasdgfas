package ru.neuclient.client.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.input.KeyInput;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.command.CommandHints;

/**
 * Миксин на экран чата:
 *
 *  1) Подсказки точка-команд (".", ".cfg" → save/load/...) поверх строки ввода
 *     и их дополнение по Tab (перехват keyPressed);
 *  2) ПЕРЕТАСКИВАНИЕ HUD-КАЖДЫЙ-КАДР: опрос мыши идёт из render() —
 *     60+ раз в секунду, а не 20 раз в секунду из тика, поэтому драг
 *     плавный и не дёргается.
 */
@Mixin(ChatScreen.class)
public abstract class ChatScreenMixin {

	@Shadow
	protected TextFieldWidget chatField;

	@Inject(method = "render", at = @At("TAIL"))
	private void pc$renderNeuStuff(DrawContext ctx, int mouseX, int mouseY, float delta, CallbackInfo ci) {
		try {
			NeuClient client = NeuClient.getInstance();
			if (client != null && client.isPanicked()) {
				return;
			}
			// Плавный драг HUD — обновляем позицию каждый кадр
			if (client != null && client.getModuleManager() != null) {
				client.getModuleManager().frameChatHudDrag(MinecraftClient.getInstance());
			}
			// Подсказки команд над строкой ввода
			CommandHints.render(ctx, this.chatField);
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка оверлея чата", t);
		}
	}

	@Inject(method = "keyPressed", at = @At("HEAD"), cancellable = true)
	private void pc$tabComplete(KeyInput input, CallbackInfoReturnable<Boolean> cir) {
		try {
			NeuClient client = NeuClient.getInstance();
			if (client != null && client.isPanicked()) {
				return;
			}
			if (input.key() == GLFW.GLFW_KEY_TAB) {
				String text = this.chatField.getText();
				if (text.startsWith(".") && CommandHints.complete(this.chatField)) {
					cir.setReturnValue(true);
				}
			}
		} catch (Throwable ignored) {
		}
	}
}
