package ru.neuclient.client.hud.impl;

import net.minecraft.client.gui.DrawContext;
import ru.neuclient.client.hud.HudElement;

import java.util.Locale;

/**
 * Координаты игрока — карточка [XYZ │ 128.5 71.0 -340.2] в общем стиле HUD.
 */
public class CoordsElement extends HudElement {

	public CoordsElement() {
		super("coordinates", 4, 40);
	}

	@Override
	public boolean isVisible() {
		if (ru.neuclient.client.NeuClient.getInstance().getInterfaceModule().isElementVisible("watermark")) return false;
		return super.isVisible();
	}

	@Override
	protected void drawElement(DrawContext ctx, boolean editing) {
		String value = "--";
		if (mc.player != null) {
			value = String.format(Locale.ROOT, "%.1f  %.1f  %.1f",
					mc.player.getX(), mc.player.getY(), mc.player.getZ());
		}
		this.width = valueCardWidth("XYZ", value);
		this.height = CARD_H;
		drawValueCard(ctx, getX(), getY(), width, "XYZ", value);
	}
}
