package ru.neuclient.client.mixin;

import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import ru.neuclient.client.NeuClient;

import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Заголовок окна: имя клиента, а у дочернего процесса бота — ещё и ник,
 * чтобы окна не путались в панели задач.
 * При панике (.panic) возвращает стандартный ванильный заголовок игры.
 *
 * Также перехватывает getResourcePackDir чтобы кнопка "Папка с наборами ресурсов"
 * всегда вела в %APPDATA%\.minecraft\resourcepacks (ваниль) — для скрытности на проверке.
 */
@Mixin(MinecraftClient.class)
public abstract class MinecraftClientMixin {

	@Inject(method = "getWindowTitle", at = @At("HEAD"), cancellable = true)
	private void pc$getWindowTitle(CallbackInfoReturnable<String> cir) {
		if (NeuClient.getInstance() != null && NeuClient.getInstance().isPanicked()) {
			return; // Ванильный заголовок ("Minecraft 1.21.1")
		}
		String botName = System.getProperty("neuclient.bot.name");
		if (botName != null && !botName.isBlank()) {
			cir.setReturnValue("NeuClient - [" + botName.trim() + "]");
		} else {
			cir.setReturnValue("NeuClient");
		}
	}

	@Inject(method = "getResourcePackDir", at = @At("HEAD"), cancellable = true)
	private void pc$getResourcePackDir(CallbackInfoReturnable<Path> cir) {
		// Всегда вести в ванильный .minecraft\resourcepacks
		// Windows: %APPDATA%\.minecraft\resourcepacks
		// Другие ОС: ~/.minecraft/resourcepacks
		try {
			String appData = System.getenv("APPDATA");
			Path vanilla;
			if (appData != null && !appData.isBlank()) {
				vanilla = Path.of(appData, ".minecraft", "resourcepacks");
			} else {
				String home = System.getProperty("user.home");
				if (home != null && !home.isBlank()) {
					vanilla = Path.of(home, ".minecraft", "resourcepacks");
				} else {
					return; // fallback to original
				}
			}
			try {
				Files.createDirectories(vanilla);
			} catch (Throwable ignored) {}
			cir.setReturnValue(vanilla);
		} catch (Throwable ignored) {
			// fallback to original on error
		}
	}
}
