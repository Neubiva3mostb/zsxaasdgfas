package ru.neuclient.client.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.InventoryS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket;
import net.minecraft.network.packet.s2c.play.ScreenHandlerSlotUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.UpdateSelectedSlotS2CPacket;
import net.minecraft.network.packet.s2c.play.WorldTimeUpdateS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.ModuleManager;
import ru.neuclient.client.module.impl.player.BlinkModule;
import ru.neuclient.client.module.impl.player.NoRotateModule;
import ru.neuclient.client.module.impl.combat.NoSlotChangeModule;
import ru.neuclient.client.module.impl.combat.VelocityModule;

/**
 * Перехват сетевых пакетов:
 *  - исходящий чат: сообщения с "." — клиентские команды (на сервер не уходят);
 *  - входящая скорость по нашему игроку: Velocity (отдача от ударов).
 *    HEAD — модуль может погасить пакет; TAIL — прыжок ПОСЛЕ применения
 *    скорости (режим JumpReset), пока движение тика ещё не отыгралось;
 *  - принудительная смена слота и подмена инвентаря сервером: NoSlotChange
 *    просто не даёт таким пакетам примениться.
 */
@Mixin(ClientPlayNetworkHandler.class)
public abstract class ClientPlayNetworkHandlerMixin {

	@Inject(method = "sendChatMessage", at = @At("HEAD"), cancellable = true)
	private void pc$interceptDotCommands(String message, CallbackInfo ci) {
		try {
			NeuClient client = NeuClient.getInstance();
			if (client != null && client.getCommandManager() != null
					&& client.getCommandManager().handle(message)) {
				ci.cancel(); // команда съедена — на сервер не уходит
			}
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка перехвата команды", t);
		}
	}

	@Inject(method = "onEntityVelocityUpdate", at = @At("HEAD"), cancellable = true)
	private void pc$velocity(EntityVelocityUpdateS2CPacket packet, CallbackInfo ci) {
		try {
			ModuleManager modules = NeuClient.getInstance().getModuleManager();
			BlinkModule blink = modules.get(BlinkModule.class);
			if (blink != null && blink.isEnabled()) {
				blink.onIncomingVelocity(packet.getEntityId());
			}
			VelocityModule velocity = modules.get(VelocityModule.class);
			if (velocity != null && velocity.isEnabled()) {
				velocity.onVelocity(packet, ci); // модуль сам решает, гасить ли пакет
			}
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка в хуке скорости", t);
		}
	}

	@Inject(method = "onEntityVelocityUpdate", at = @At("TAIL"))
	private void pc$afterVelocity(EntityVelocityUpdateS2CPacket packet, CallbackInfo ci) {
		try {
			ModuleManager modules = NeuClient.getInstance().getModuleManager();
			VelocityModule velocity = modules.get(VelocityModule.class);
			if (velocity != null && velocity.isEnabled()) {
				velocity.onVelocityApplied(packet); // скорость уже применена — момент для прыжка
			}
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка в пост-хуке скорости", t);
		}
	}

	// ===== NoSlotChange: сервер не должен трогать наши слоты =====
	// Работает как в aethereal: при получении UpdateSelectedSlotS2CPacket
	// пакет отменяется, а серверу отправляется наш реальный слот.

	@Inject(method = "onUpdateSelectedSlot", at = @At("HEAD"), cancellable = true)
	private void pc$noSelectedSlotChange(UpdateSelectedSlotS2CPacket packet, CallbackInfo ci) {
		try {
			NoSlotChangeModule module = NeuClient.getInstance().getModuleManager().get(NoSlotChangeModule.class);
			if (module == null || !module.isEnabled()) return;

			MinecraftClient mc = MinecraftClient.getInstance();
			ClientPlayerEntity player = mc.player;
			if (player == null) return;

			// Отменяем серверный пакет — слот НЕ меняется локально
			ci.cancel();

			// Отправляем серверу наш реальный слот
			player.networkHandler.sendPacket(
					new net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket(
							player.getInventory().getSelectedSlot()));
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка NoSlotChange (слот руки)", t);
		}
	}

	@Inject(method = "onScreenHandlerSlotUpdate", at = @At("HEAD"), cancellable = true)
	private void pc$noSlotUpdate(ScreenHandlerSlotUpdateS2CPacket packet, CallbackInfo ci) {
		try {
			NoSlotChangeModule module = NeuClient.getInstance().getModuleManager()
					.get(NoSlotChangeModule.class);
			if (module != null && module.blockSlotUpdate(packet.getSyncId())) {
				ci.cancel();
			}
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка NoSlotChange (слот инвентаря)", t);
		}
	}

	@Inject(method = "onInventory", at = @At("HEAD"), cancellable = true)
	private void pc$noInventorySync(InventoryS2CPacket packet, CallbackInfo ci) {
		try {
			NoSlotChangeModule module = NeuClient.getInstance().getModuleManager()
					.get(NoSlotChangeModule.class);
			if (module != null && module.blockFullInventory(packet.syncId())) {
				ci.cancel();
			}
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка NoSlotChange (инвентарь)", t);
		}
	}

	// ===== NoRotate: игнорируем принудительный поворот от сервера =====

	@Inject(method = "onPlayerPositionLook", at = @At("HEAD"))
	private void pc$noRotate(PlayerPositionLookS2CPacket packet, CallbackInfo ci) {
		try {
			NeuClient client = NeuClient.getInstance();
			if (client == null || client.getModuleManager() == null) return;
			NoRotateModule module = client.getModuleManager().get(NoRotateModule.class);
			if (module == null || !module.isEnabled()) return;

			MinecraftClient mc = MinecraftClient.getInstance();
			ClientPlayerEntity player = mc.player;
			if (player == null) return;

			module.saveRotation(player.getYaw(), player.getPitch());
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка NoRotate", t);
		}
	}

	@Inject(method = "onPlayerPositionLook", at = @At("RETURN"))
	private void pc$afterNoRotate(PlayerPositionLookS2CPacket packet, CallbackInfo ci) {
		try {
			NeuClient client = NeuClient.getInstance();
			if (client == null || client.getModuleManager() == null) return;
			NoRotateModule module = client.getModuleManager().get(NoRotateModule.class);
			if (module == null || !module.isEnabled()) return;

			MinecraftClient mc = MinecraftClient.getInstance();
			ClientPlayerEntity player = mc.player;
			if (player == null) return;

			module.restoreRotation(player);
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка NoRotate", t);
		}
	}

	// ===== Синхронизация TPS с сервером =====

	@Inject(method = "onWorldTimeUpdate", at = @At("HEAD"))
	private void pc$onWorldTimeUpdate(WorldTimeUpdateS2CPacket packet, CallbackInfo ci) {
		try {
			ru.neuclient.client.util.TpsSync.onTimeUpdate();
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка TpsSync", t);
		}
	}
}
