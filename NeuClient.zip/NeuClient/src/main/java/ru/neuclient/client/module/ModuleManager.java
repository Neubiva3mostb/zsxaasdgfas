package ru.neuclient.client.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.util.SwapPause;
import ru.neuclient.client.hud.HudManager;
import ru.neuclient.client.module.impl.combat.AimBotModule;
import ru.neuclient.client.module.impl.combat.AntiBotModule;
import ru.neuclient.client.module.impl.misc.AntiSpamModule;
import ru.neuclient.client.module.impl.render.DamageIndicatorModule;
import ru.neuclient.client.module.impl.movement.AirStruckModule;
import ru.neuclient.client.module.impl.render.BlockOverlayModule;
import ru.neuclient.client.module.impl.render.ChamsModule;
import ru.neuclient.client.module.impl.render.HandsModule;
import ru.neuclient.client.module.impl.misc.AutoReconnectModule;
import ru.neuclient.client.module.impl.movement.AutoSprintModule;
import ru.neuclient.client.module.impl.movement.AutoPilotModule;
import ru.neuclient.client.module.impl.player.AutoToolModule;
import ru.neuclient.client.module.impl.player.BlinkModule;
import ru.neuclient.client.module.impl.player.FastBreakModule;
import ru.neuclient.client.module.impl.render.AspectRatioModule;
import ru.neuclient.client.module.impl.render.AttackAnimationsModule;
import ru.neuclient.client.module.impl.combat.AttackAuraModule;
import ru.neuclient.client.module.impl.combat.BowAimBotModule;
import ru.neuclient.client.module.impl.render.CapeModule;
import ru.neuclient.client.module.impl.render.ChinaHatModule;
import ru.neuclient.client.module.impl.combat.CriticalsModule;
import ru.neuclient.client.module.impl.render.CrosshairModule;
import ru.neuclient.client.module.impl.render.DurabilityAlertModule;
import ru.neuclient.client.module.impl.render.WardenESP;
import ru.neuclient.client.module.impl.misc.AutoWardenModule;
import ru.neuclient.client.module.impl.player.FreeCamModule;
import ru.neuclient.client.module.impl.combat.HitboxModule;
import ru.neuclient.client.module.impl.player.HitSoundsModule;
import ru.neuclient.client.module.impl.render.InterfaceModule;
import ru.neuclient.client.module.impl.movement.InvMoveModule;
import ru.neuclient.client.module.impl.render.JumpCirclesModule;
import ru.neuclient.client.module.impl.render.KillEffectModule;
import ru.neuclient.client.module.impl.misc.PotionThrowerModule;
import ru.neuclient.client.module.impl.misc.ItemScrollerModule;
import ru.neuclient.client.module.impl.misc.MiddleClickPearlModule;
import ru.neuclient.client.module.impl.render.NameProtectModule;
import ru.neuclient.client.module.impl.render.NameTagsModule;
import ru.neuclient.client.module.impl.misc.NoFriendDamageModule;
import ru.neuclient.client.module.impl.render.NoRenderModule;
import ru.neuclient.client.module.impl.movement.NoPushModule;
import ru.neuclient.client.module.impl.combat.NoSlotChangeModule;
import ru.neuclient.client.module.impl.movement.NoSlowModule;
import ru.neuclient.client.module.impl.movement.NoWebModule;
import ru.neuclient.client.module.impl.render.ParticlesModule;
import ru.neuclient.client.module.impl.render.PointersModule;
import ru.neuclient.client.module.impl.render.PredictionsModule;
import ru.neuclient.client.module.impl.combat.ShieldBreakerModule;
import ru.neuclient.client.module.impl.render.SeeInvisiblesModule;
import ru.neuclient.client.module.impl.render.SpinnerModule;
import ru.neuclient.client.module.impl.misc.ShulkerPreviewModule;
import ru.neuclient.client.module.impl.movement.SpeedModule;
import ru.neuclient.client.module.impl.movement.StrafeModule;
import ru.neuclient.client.module.impl.movement.TargetStrafeModule;
import ru.neuclient.client.module.impl.render.TargetEspModule;
import ru.neuclient.client.module.impl.misc.TreeFarmModule;
import ru.neuclient.client.module.impl.movement.TimerModule;
import ru.neuclient.client.module.impl.render.TrailsModule;
import ru.neuclient.client.module.impl.combat.TriggerBotModule;
import ru.neuclient.client.module.impl.combat.VelocityModule;
import ru.neuclient.client.module.impl.movement.WallClimbModule;
import ru.neuclient.client.module.impl.render.ViewModelModule;
import ru.neuclient.client.module.impl.combat.WTapModule;
import ru.neuclient.client.module.impl.misc.XrayModule;
import ru.neuclient.client.module.impl.render.ZoomModule;
import ru.neuclient.client.module.impl.render.BigHeadModule;
import ru.neuclient.client.module.impl.misc.StructureFinderModule;
import ru.neuclient.client.module.impl.misc.AuctionHelperFT;
import ru.neuclient.client.module.impl.player.AutoAcceptModule;
import ru.neuclient.client.module.impl.player.AutoAuthModule;
import ru.neuclient.client.module.impl.render.CustomFogModule;

import ru.neuclient.client.module.impl.player.NoRotateModule;
import ru.neuclient.client.module.impl.render.StorageESPModule;
import ru.neuclient.client.module.impl.combat.ShiftTAPModule;
import ru.neuclient.client.ui.ClickGuiScreen;
import ru.neuclient.client.util.KeyNames;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Центральный реестр модулей клиента.
 */
public class ModuleManager {

	private final List<Module> modules = new ArrayList<>();

	/** Клавиша открытия ClickGUI (из конфига, по умолчанию RShift=344). */
	private int guiKey = GLFW.GLFW_KEY_RIGHT_SHIFT;

	/** Предыдущее состояние клавиш (для детекта фронта нажатия). */
	private final Map<Module, Boolean> prevModuleKey = new HashMap<>();
	private boolean prevGuiKey = false;

	/** Состояние ЛКМ в чате на прошлом тике (для захвата HUD-элементов). */
	private boolean prevChatMouseDown = false;
	/** Состояние ПКМ в чате на прошлом тике (меню масштаба HUD). */
	private boolean prevChatRmbDown = false;

	public ModuleManager() {
		// Регистрация всех модулей клиента
		register(new AimBotModule());
		register(new AntiBotModule());
		register(new AirStruckModule());
		register(new AutoReconnectModule());
		register(new AutoSprintModule());
		register(new AutoPilotModule());
		register(new AutoToolModule());
		register(new BlinkModule());
		register(new FastBreakModule());
		register(new AspectRatioModule());
		register(new AttackAnimationsModule());
		register(new AttackAuraModule());
		register(new BlockOverlayModule());
		register(new BowAimBotModule());
		register(new CapeModule());
		register(new ChinaHatModule());
		register(new CriticalsModule());
		register(new CrosshairModule());
		register(new DurabilityAlertModule());
		register(new WardenESP());
		register(new AutoWardenModule());
		register(new FreeCamModule());
		register(new HandsModule());
		register(new HitboxModule());
		register(new HitSoundsModule());
		register(new ItemScrollerModule());
		register(new InvMoveModule());
		register(new JumpCirclesModule());
		register(new KillEffectModule());
		register(new MiddleClickPearlModule());
		register(new NameProtectModule());
		register(new NameTagsModule());
		register(new NoRenderModule());
		register(new NoPushModule());
		register(new NoSlotChangeModule());
		register(new NoSlowModule());
		register(new NoWebModule());
		register(new ViewModelModule());
		register(new WTapModule());
		register(new NoFriendDamageModule());
		register(new ParticlesModule());
		register(new PointersModule());
		register(new PredictionsModule());
		register(new ShieldBreakerModule());
		register(new SeeInvisiblesModule());
		register(new ChamsModule());
		register(new SpinnerModule());
		register(new ShulkerPreviewModule());
		register(new SpeedModule());
		register(new StrafeModule());
		register(new TargetEspModule());
		register(new TargetStrafeModule());
		register(new TreeFarmModule());
		register(new ru.neuclient.client.module.impl.render.MusicModule());
		register(new TimerModule());
		register(new TrailsModule());
		register(new TriggerBotModule());
		register(new AntiSpamModule());
		register(new DamageIndicatorModule());
		register(new VelocityModule());
		register(new WallClimbModule());
		register(new ZoomModule());
		register(new BigHeadModule());
		register(new StructureFinderModule());
		register(new XrayModule());
		register(new InterfaceModule());
		register(new AuctionHelperFT());
		register(new AutoAcceptModule());
		register(new CustomFogModule());

		register(new NoRotateModule());
		register(new StorageESPModule());
		register(new ShiftTAPModule());
		register(new PotionThrowerModule());
		register(new AutoAuthModule());

		// Модули с сайта (байткод) - последними, поверх встроенных.
		// Мягкий отказ: без сети/кэша клиент просто работает без них.
		ru.neuclient.client.remote.RemoteModuleLoader.loadAndRegister(this);
	}

	/**
	 * Регистрация модуля, загруженного удалённо (байткод с сайта).
	 * Работает как обычный register, вызывается только RemoteModuleLoader.
	 */
	public void registerRemote(Module module) {
		register(module);
	}

	private void register(Module module) {
		modules.add(module);
	}

	// ===== Поиск =====

	public List<Module> getModules() {
		return modules;
	}

	/**
	 * Модули категории — всегда в АЛФАВИТНОМ порядке (для ClickGUI).
	 * Скрытые модули (например NeuAI) сюда не попадают: ими управляют
	 * командой, в меню их быть не должно.
	 */
	public List<Module> getByCategory(Category category) {
		List<Module> result = new ArrayList<>();
		for (Module m : modules) {
			if (m.getCategory() == category && !m.isHidden()) {
				result.add(m);
			}
		}
		result.sort(java.util.Comparator.comparing(m -> m.getName().toLowerCase(java.util.Locale.ROOT)));
		return result;
	}

	@SuppressWarnings("unchecked")
	public <T extends Module> T get(Class<T> clazz) {
		for (Module m : modules) {
			if (clazz.isInstance(m)) {
				return (T) m;
			}
		}
		return null;
	}

	public Module getByName(String name) {
		for (Module m : modules) {
			if (m.getName().equalsIgnoreCase(name)) {
				return m;
			}
		}
		return null;
	}

	// ===== Клавиша GUI (меняется в конфиге) =====

	public int getGuiKey() {
		return guiKey;
	}

	public void setGuiKey(int guiKey) {
		this.guiKey = guiKey;
		Module.markConfigDirty();
	}

	public String getGuiKeyName() {
		return KeyNames.getName(guiKey);
	}

	// ===== Главный тик (вызывается из END_CLIENT_TICK) =====

	public void tick(MinecraftClient client) {
		Screen screen = client.currentScreen;

		// Отложенные операции с инвентарём — ПЕРВЫМ делом.
		//
		// Мы в конце клиентского тика: пакет движения уже улетел, и если
		// в этом тике ввод был обнулён, то улетел он от СТОЯЩЕГО игрока.
		// Значит сейчас — единственный правильный момент для клика по
		// слоту. Делаем это до тика модулей, чтобы они в этом же тике
		// увидели уже переложенный предмет.
		SwapPause.tick();

		// Режим паники (.panic): клиент должен вести себя как чистая ванилла —
		// ни ClickGUI, ни биндов модулей, тики модулей бессмысленны (все выключены)
		NeuClient self = NeuClient.getInstance();
		if (self != null && self.isPanicked()) {
			prevGuiKey = false;
			prevModuleKey.replaceAll((m, v) -> false);
			return;
		}

		// --- Открытие ClickGUI по клавише (только когда других экранов нет) ---
		boolean guiNow = InputUtil.isKeyPressed(client.getWindow(), guiKey);
		if (guiNow && !prevGuiKey && screen == null) {
			client.setScreen(new ClickGuiScreen());
		}
		prevGuiKey = guiNow;

		// --- Бинды модулей ---
		if (screen == null) {
			// Экранов нет: опрашиваем клавиши модулей
			for (Module m : modules) {
				int bind = m.getKeyBind();
				if (bind == KeyNames.NONE) {
					prevModuleKey.put(m, false);
					continue;
				}
				boolean now = InputUtil.isKeyPressed(client.getWindow(), bind);
				boolean was = prevModuleKey.getOrDefault(m, false);
				if (now && !was) {
					m.toggle();
					// Фирменный звук переключения (вкл — восходящий, выкл — нисходящий)
					ru.neuclient.client.util.NeuSounds.toggle(m.isEnabled());
				}
				prevModuleKey.put(m, now);
			}
		} else {
			// Любой экран открыт: сбрасываем фронт, чтобы не было "залипания"
			prevModuleKey.replaceAll((m, v) -> false);
		}

		// --- Страховка от «залипшего» драга: само перетаскивание идёт
		// КАЖДЫЙ КАДР из ChatScreenMixin#render (плавно, 60+ fps),
		// а из тика только отпускаем элемент, если чат уже закрыт ---
		HudManager hud = NeuClient.getInstance().getHudManager();
		if (hud != null && hud.isDragging() && !(client.currentScreen instanceof ChatScreen)) {
			hud.endDrag();
		}

		// --- Тик включённых модулей ---
		// Боевые модули здесь пропускаем: они тикают в START_CLIENT_TICK,
		// до отправки ванильных пакетов движения (см. tickCombat).
		for (Module m : modules) {
			if (m.isEnabled() && !isCombatTicked(m)) {
				try {
					m.onTick(client);
				} catch (Throwable t) {
					NeuClient.LOGGER.error("[NeuClient] onTick упал у {}", m.getName(), t);
				}
			}
		}
	}

	/**
	 * Тик боевых модулей — вызывается в НАЧАЛЕ клиентского тика.
	 * AttackAura тикает даже при открытом GUI (если включён InvMove).
	 */
	public void tickCombat(MinecraftClient client) {
		// AttackAura работает даже при открытом ClickGUI/инвентаре
		AttackAuraModule aura = get(AttackAuraModule.class);
		if (aura != null && aura.isEnabled()) {
			try {
				aura.onTick(client);
			} catch (Throwable t) {
				NeuClient.LOGGER.error("[NeuClient] боевой onTick упал у {}", aura.getName(), t);
			}
		}
		// Остальные боевые модули пропускаем при открытом экране
		if (client.currentScreen != null) {
			return;
		}
		for (Module m : modules) {
			if (m.isEnabled() && isCombatTicked(m)) {
				try {
					m.onTick(client);
				} catch (Throwable t) {
					NeuClient.LOGGER.error("[NeuClient] боевой onTick упал у {}", m.getName(), t);
				}
			}
		}
	}

	/** Модули, которым нужен ранний тик (до пакетов движения). */
	private boolean isCombatTicked(Module m) {
		return m instanceof ru.neuclient.client.module.impl.combat.AttackAuraModule
				|| m instanceof ru.neuclient.client.module.impl.combat.AimBotModule
				|| m instanceof ru.neuclient.client.module.impl.combat.TriggerBotModule
				|| m instanceof ru.neuclient.client.module.impl.combat.ShiftTAPModule;
	}

	/**
	 * Перетаскивание HUD-элементов в открытом чате.
	 */
	public void frameChatHudDrag(MinecraftClient client) {
		boolean chatOpen = client.currentScreen instanceof ChatScreen;
		long handle = client.getWindow().getHandle();
		boolean lmbDown = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_LEFT)
				== GLFW.GLFW_PRESS;
		boolean rmbDown = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_RIGHT)
				== GLFW.GLFW_PRESS;
		HudManager hud = NeuClient.getInstance().getHudManager();

		// mouse.getX/getY отдают ФИЗИЧЕСКИЕ пиксели окна — переводим
		// в масштабированные GUI-координаты, в которых живёт HUD
		double sx = client.getWindow().getScaledWidth() / (double) client.getWindow().getWidth();
		double sy = client.getWindow().getScaledHeight() / (double) client.getWindow().getHeight();
		double mx = ru.neuclient.client.util.ScaleUtil.toVirtualX(client.mouse.getX() * sx);
		double my = ru.neuclient.client.util.ScaleUtil.toVirtualY(client.mouse.getY() * sy);

		// --- ПКМ: меню выбора масштаба у элемента под курсором ---
		if (chatOpen && rmbDown && !prevChatRmbDown) {
			hud.openScaleMenu(mx, my);
		}
		prevChatRmbDown = chatOpen && rmbDown;

		if (chatOpen && lmbDown) {
			if (!prevChatMouseDown) {
				// Фронт клика: сначала отдаём его открытому меню масштаба,
				// и только если меню не съело клик — начинаем перетаскивание
				if (!hud.clickScaleMenu(mx, my)) {
					hud.beginDrag(mx, my);
				}
			}
			if (hud.isDragging()) {
				hud.dragTo(mx, my);
			}
		} else if (hud.isDragging()) {
			hud.endDrag(); // ЛКМ отпущена или чат закрыт
		}
		prevChatMouseDown = chatOpen && lmbDown;
	}

	/** Карта "категория → модули" для построения панелей ClickGUI. */
	public Map<Category, List<Module>> groupByCategory() {
		Map<Category, List<Module>> map = new EnumMap<>(Category.class);
		for (Category c : Category.values()) {
			map.put(c, getByCategory(c));
		}
		return map;
	}
}
