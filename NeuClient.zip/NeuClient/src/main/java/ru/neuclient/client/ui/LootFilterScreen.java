package ru.neuclient.client.ui;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import ru.neuclient.client.font.MsdfFontRenderer;
import ru.neuclient.client.font.MsdfFonts;
import ru.neuclient.client.module.impl.misc.autowarden.LootFilter;
import ru.neuclient.client.module.impl.misc.autowarden.LootFilter.Entry;
import ru.neuclient.client.util.NeuSounds;
import ru.neuclient.client.util.RenderUtil;

import java.util.List;

/** «Что лутать» — фильтр лута AutoWarden (две колонки переключателей). */
public class LootFilterScreen extends Screen {

	private static final int W = 400;
	private static final int H = 250;
	private static final int PAD = 10;
	private static final int ROW_H = 22;
	private static final int ROW_GAP = 4;
	private static final int HEADER_H = 26;
	private static final int BANNER_H = 16;
	private static final int FOOTER_H = 22;
	private static final int SEARCH_W = 110;
	private static final float F = 7.5f;
	private static final float FS = 6.5f;

	private final Screen parent;
	private String search = "";
	private boolean searchFocused;
	private int scroll;
	private float alpha;
	private boolean closing;
	private long lastMs = System.currentTimeMillis();

	public LootFilterScreen(Screen parent) {
		super(Text.literal("Что лутать"));
		this.parent = parent;
		LootFilter.load();
	}

	private int x0() { return (width - W) / 2; }
	private int y0() { return (height - H) / 2; }
	private int listTop() { return y0() + HEADER_H + BANNER_H + 8; }
	private int listBottom() { return y0() + H - FOOTER_H - 6; }
	private int colW() { return (W - PAD * 2 - 8) / 2; }
	private int visibleRows() { return Math.max(1, (listBottom() - listTop() + ROW_GAP) / (ROW_H + ROW_GAP)); }

	private static boolean in(double mx, double my, int x, int y, int w, int h) {
		return mx >= x && mx < x + w && my >= y && my < y + h;
	}

	private int a(int color) {
		int base = color >>> 24;
		if (base == 0) base = 255;
		return (Math.max(0, Math.min(255, (int) (base * alpha))) << 24) | (color & 0xFFFFFF);
	}

	private void txt(DrawContext ctx, String s, float x, float y, int color, float size) {
		MsdfFontRenderer.drawWithShadow(ctx, MsdfFonts.sfRegular(), s, x, y, a(color), size);
	}

	private float tw(String s, float size) {
		return MsdfFontRenderer.getWidth(MsdfFonts.sfRegular(), s, size);
	}

	private void txtC(DrawContext ctx, String s, float cx, float y, int color, float size) {
		txt(ctx, s, cx - tw(s, size) / 2f, y, color, size);
	}

	@Override
	public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
		if (client.world != null) ctx.applyBlur();
		ctx.fill(0, 0, width, height, a(0x90000000));
	}

	@Override
	public void render(DrawContext ctx, int mx, int my, float delta) {
		super.render(ctx, mx, my, delta);
		long now = System.currentTimeMillis();
		float dt = Math.min((now - lastMs) / 1000f, 0.1f);
		lastMs = now;
		if (closing) {
			alpha = Math.max(0f, alpha - dt * 6f);
			if (alpha <= 0f) { client.setScreen(parent); return; }
		} else {
			alpha = Math.min(1f, alpha + dt * 6f);
		}

		int accent = RenderUtil.accent();
		int x = x0(), y = y0();
		RenderUtil.roundRect(ctx, x - 4, y - 4, W + 8, H + 8, 8, a(0xF0121218));
		RenderUtil.roundRect(ctx, x, y, W, H, 6, a(0xFF1A1A22));

		// Заголовок
		RenderUtil.circle(ctx, x + PAD + 3, y + PAD + 3, 2.5f, a(accent));
		txt(ctx, "Что лутать", x + PAD + 10, y + PAD - 1, RenderUtil.TEXT, F + 1);

		// Поиск
		int sx = x + W - PAD - SEARCH_W - 16, sy = y + 6;
		RenderUtil.roundBorderRect(ctx, sx, sy, SEARCH_W, 14, 3, a(searchFocused ? accent : 0xFF2A2A34), a(0xFF15151C));
		String sv = search.isEmpty() && !searchFocused ? "поиск" : search + (searchFocused && (now / 500) % 2 == 0 ? "_" : "");
		txt(ctx, sv, sx + 4, sy + (14 - FS) / 2f - 0.5f, search.isEmpty() ? RenderUtil.textDim() : RenderUtil.TEXT, FS);
		// Закрыть
		boolean hc = in(mx, my, x + W - PAD - 10, y + 5, 12, 12);
		txt(ctx, "✕", x + W - PAD - 8, y + 5, hc ? RenderUtil.TEXT : RenderUtil.textDim(), F);

		// Баннер
		int by = y + HEADER_H;
		RenderUtil.roundBorderRect(ctx, x + PAD, by, W - PAD * 2, BANNER_H, 4, a(RenderUtil.shade(accent, 0.5f)), a(0xFF231C2E));
		txtC(ctx, "Сферы, талисманы, отмычки и топовые зелья лутаются всегда", x + W / 2f, by + (BANNER_H - FS) / 2f - 0.5f, RenderUtil.TEXT, FS);

		// Список
		List<Entry> list = LootFilter.search(search);
		int rows = visibleRows();
		int totalRows = (list.size() + 1) / 2;
		scroll = Math.max(0, Math.min(scroll, Math.max(0, totalRows - rows)));
		ctx.enableScissor(x, listTop(), x + W, listBottom());
		for (int i = scroll * 2; i < list.size() && i < (scroll + rows) * 2; i++) {
			Entry e = list.get(i);
			int col = i % 2, row = i / 2 - scroll;
			int rx = x + PAD + col * (colW() + 8);
			int ry = listTop() + row * (ROW_H + ROW_GAP);
			boolean on = LootFilter.isEnabled(e);
			boolean hover = in(mx, my, rx, ry, colW(), ROW_H);
			if (on) {
				RenderUtil.roundBorderRect(ctx, rx, ry, colW(), ROW_H, 4, a(RenderUtil.shade(accent, 0.8f)), a(0xFF262030));
			} else {
				RenderUtil.roundRect(ctx, rx, ry, colW(), ROW_H, 4, a(hover ? 0xFF24242D : 0xFF20202A));
			}
			// иконка
			ctx.getMatrices().pushMatrix();
			ctx.getMatrices().translate(rx + 4, ry + (ROW_H - 16) / 2f);
			ctx.drawItem(new ItemStack(e.icon()), 0, 0);
			ctx.getMatrices().popMatrix();
			txt(ctx, e.label(), rx + 24, ry + (ROW_H - FS) / 2f - 0.5f, on ? RenderUtil.TEXT : RenderUtil.textDim(), FS);
			// тумблер
			int tw = 22, th = 10;
			int tx = rx + colW() - tw - 6, ty = ry + (ROW_H - th) / 2;
			RenderUtil.roundRect(ctx, tx, ty, tw, th, th / 2, a(on ? accent : 0xFF3A3A44));
			int kr = th / 2 - 1;
			RenderUtil.circle(ctx, tx + 1 + kr + (on ? tw - th : 0), ty + th / 2, kr, a(0xFFFFFFFF));
		}
		ctx.disableScissor();

		// Футер
		int fy = y + H - FOOTER_H;
		int bw = 80;
		footerBtn(ctx, x + W - PAD - bw * 3 - 8, fy, bw, "Всё", mx, my);
		footerBtn(ctx, x + W - PAD - bw * 2 - 4, fy, bw, "Ничего", mx, my);
		footerBtn(ctx, x + W - PAD - bw, fy, bw, "По умолчанию", mx, my);
	}

	private void footerBtn(DrawContext ctx, int bx, int by, int bw, String label, int mx, int my) {
		boolean hover = in(mx, my, bx, by, bw, 16);
		RenderUtil.roundRect(ctx, bx, by, bw, 16, 3, a(hover ? 0xFF34343E : 0xFF2A2A34));
		txtC(ctx, label, bx + bw / 2f, by + (16 - FS) / 2f - 0.5f, RenderUtil.TEXT, FS);
	}

	@Override
	public boolean mouseClicked(Click click, boolean doubled) {
		if (alpha < 0.9f) return true;
		double mx = click.x(), my = click.y();
		if (click.button() != 0) return super.mouseClicked(click, doubled);
		int x = x0(), y = y0();
		if (in(mx, my, x + W - PAD - 10, y + 5, 12, 12)) { close(); return true; }
		int sx = x + W - PAD - SEARCH_W - 16;
		searchFocused = in(mx, my, sx, y + 6, SEARCH_W, 14);

		int fy = y + H - FOOTER_H, bw = 80;
		if (in(mx, my, x + W - PAD - bw * 3 - 8, fy, bw, 16)) { LootFilter.setAll(true); NeuSounds.play(NeuSounds.SETTINGS); return true; }
		if (in(mx, my, x + W - PAD - bw * 2 - 4, fy, bw, 16)) { LootFilter.setAll(false); NeuSounds.play(NeuSounds.SETTINGS); return true; }
		if (in(mx, my, x + W - PAD - bw, fy, bw, 16)) { LootFilter.resetDefaults(); NeuSounds.play(NeuSounds.SETTINGS); return true; }

		if (my >= listTop() && my < listBottom()) {
			List<Entry> list = LootFilter.search(search);
			int rows = visibleRows();
			for (int i = scroll * 2; i < list.size() && i < (scroll + rows) * 2; i++) {
				int col = i % 2, row = i / 2 - scroll;
				int rx = x + PAD + col * (colW() + 8);
				int ry = listTop() + row * (ROW_H + ROW_GAP);
				if (in(mx, my, rx, ry, colW(), ROW_H)) {
					Entry e = list.get(i);
					boolean on = !LootFilter.isEnabled(e);
					LootFilter.set(e, on);
					NeuSounds.toggle(on);
					return true;
				}
			}
		}
		return true;
	}

	@Override
	public boolean mouseScrolled(double mx, double my, double h, double v) {
		scroll -= (int) Math.signum(v);
		return true;
	}

	@Override
	public boolean keyPressed(KeyInput input) {
		int code = input.key();
		if (code == GLFW.GLFW_KEY_ESCAPE) { close(); return true; }
		if (searchFocused) {
			if (code == GLFW.GLFW_KEY_BACKSPACE && !search.isEmpty()) { search = search.substring(0, search.length() - 1); scroll = 0; return true; }
			if (code == GLFW.GLFW_KEY_ENTER) { searchFocused = false; return true; }
			return true;
		}
		return super.keyPressed(input);
	}

	@Override
	public boolean charTyped(CharInput input) {
		if (searchFocused && input.isValidChar()) {
			if (search.length() < 32) { search += input.asString(); scroll = 0; }
			return true;
		}
		return super.charTyped(input);
	}

	@Override
	public boolean shouldPause() { return false; }

	@Override
	public void close() { closing = true; }
}
