package ru.neuclient.client.mixin;

import net.minecraft.scoreboard.ScoreboardEntry;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.neuclient.client.util.NameProtectUtil;

/**
 * NameProtect в скорборде: сервер может задавать записи сайдбара кастомным
 * текстом (ScoreboardEntry.display) — если ник там, подменяем и тут.
 * require=0: метода вдруг нет — тихо пропускаем.
 */
@Mixin(ScoreboardEntry.class)
public abstract class ScoreboardEntryNameMixin {

	@Inject(method = "display()Lnet/minecraft/text/Text;",
			at = @At("RETURN"), cancellable = true, require = 0)
	private void pc$nameProtectEntry(CallbackInfoReturnable<Text> cir) {
		Text value = cir.getReturnValue();
		if (value != null && NameProtectUtil.active()) {
			cir.setReturnValue(NameProtectUtil.transformIfActive(value));
		}
	}
}
