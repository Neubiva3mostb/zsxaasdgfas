package ru.neuclient.client.alt;

/**
 * Запись об альте в Alt Manager'е.
 * Пароль хранится только локально в alts.json и никуда не отправляется —
 * авторизация по ТЗ лишь имитируется (оффлайн-смена ника).
 */
public class AltEntry {

	private String username;
	private String password;

	// Пустой конструктор нужен Gson'у
	public AltEntry() {
	}

	public AltEntry(String username, String password) {
		this.username = username;
		this.password = password;
	}

	public String getUsername() {
		return username;
	}

	public String getPassword() {
		return password;
	}

	/** Маскированный пароль для отображения в списке. */
	public String getMaskedPassword() {
		if (password == null || password.isEmpty()) {
			return "(без пароля)";
		}
		return "*".repeat(Math.min(10, password.length()));
	}
}
