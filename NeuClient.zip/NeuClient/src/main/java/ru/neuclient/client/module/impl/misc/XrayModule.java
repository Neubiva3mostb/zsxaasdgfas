package ru.neuclient.client.module.impl.misc;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.render.LayeringTransform;
import net.minecraft.client.render.OutputTarget;
import net.minecraft.client.render.RenderSetup;
import ru.neuclient.client.mixin.RenderLayerAccessor;
import ru.neuclient.client.mixin.RenderPipelinesAccessor;

import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.BooleanSetting;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * XRay — обводка руд КОНТУРОМ сквозь блоки (BlockESP).
 *
 * Честная механика, без обходов: сервер сам присылает клиенту все блоки
 * вокруг игрока — модуль лишь просматривает загруженные чанки и рисует
 * контур там, где лежит руда. НИ ОДНОГО лишнего пакета на сервер не
 * уходит (для античита нас вообще не существует). Обратная сторона
 * честности: то, чего сервер НЕ прислал (плагин anti-xray на сервере
 * подменяет руды мусором), — увидеть невозможно, контур рисуется только
 * по реальным данным.
 *
 * Сканер: радиус 3 чанка (49 чанков вокруг), один чанк за тик по кругу
 * (ближние первыми) — полное обновление примерно раз в 2.5 секунды,
 * процессор почти не замечает. Выгруженные чанки зачищаются.
 *
 * Каждая руда — своя галка и свой цвет; учитываются и обычная,
 * и глубинная (deepslate) разновидность. Незерит = Ancient Debris.
 */
public class XrayModule extends Module {

	/** Радиус сканирования в чанках (3 = квадрат 7×7 чанков ≈ 48–64 блока). */
	private static final int SCAN_RADIUS = 3;
	/** Сколько тиков между чистками выгруженных чанков. */
	private static final int PURGE_PERIOD = 20;
	/** Толщина и прозрачность контура. */
	private static final float LINE_WIDTH = 1.5f;
	private static final float LINE_ALPHA = 0.9f;

	// ===== Типы руд (галки + цвета) =====

	private final BooleanSetting coal = new BooleanSetting("Уголь", true);
	private final BooleanSetting iron = new BooleanSetting("Железо", true);
	private final BooleanSetting gold = new BooleanSetting("Золото", true);
	private final BooleanSetting lapis = new BooleanSetting("Лазурит", true);
	private final BooleanSetting redstone = new BooleanSetting("Редстоун", true);
	private final BooleanSetting diamond = new BooleanSetting("Алмазы", true);
	private final BooleanSetting netherite = new BooleanSetting("Незерит", true);
	private final BooleanSetting emerald = new BooleanSetting("Изумруды", true);

	private enum OreType {
		COAL(0xFF8A8A8A),
		IRON(0xFFD8AF93),
		GOLD(0xFFFBE04B),
		LAPIS(0xFF3F66D4),
		REDSTONE(0xFFFF3B30),
		DIAMOND(0xFF3FD8E8),
		NETHERITE(0xFFCF7B3C),
		EMERALD(0xFF2EFF70);

		final int color;

		OreType(int color) {
			this.color = color;
		}
	}

	/** Один найденный блок руды (целые координаты). */
	private record FoundOre(int x, int y, int z, OreType type) {
	}

	/** Линии без глубины (контур виден сквозь блоки). */
	private static final RenderLayer LINES_LAYER = RenderLayerAccessor.pc$of("neuclient_xray_lines",
			RenderSetup.builder(RenderPipeline.builder(new RenderPipeline.Snippet[]{RenderPipelinesAccessor.pc$getLinesSnippet()})
							.withLocation("neuclient/xray_lines")
							.withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
							.build())
					.layeringTransform(LayeringTransform.VIEW_OFFSET_Z_LAYERING)
					.outputTarget(OutputTarget.ITEM_ENTITY_TARGET)
					.build());

	/** Найденные руды: ключ чанка (ChunkPos.toLong) → список блоков. */
	private final Map<Long, List<FoundOre>> found = new HashMap<>();

	/** Круговая очередь чанков на сканирование (ближние первыми). */
	private final List<ChunkPos> queue = new ArrayList<>();
	/** Центр, от которого собрана очередь. */
	private ChunkPos queueCenter;
	/** Индекс текущего чанка в очереди. */
	private int cursor;
	/** Счётчик тиков до чистки выгруженных чанков. */
	private int purgeCounter;

	public XrayModule() {
		super("XRay", "Подсвечивает руды сквозь блоки", Category.MISC);
		addSettings(coal, iron, gold, lapis, redstone, diamond, netherite, emerald);
	}

	@Override
	protected void onDisable() {
		found.clear();
		queue.clear();
		queueCenter = null;
	}

	// ===== Сканер (тик) =====

	@Override
	public void onTick(MinecraftClient client) {
		ClientWorld world = client.world;
		ClientPlayerEntity player = client.player;
		if (world == null || player == null) {
			found.clear();
			queue.clear();
			queueCenter = null;
			return;
		}

		// Чистка выгруженных чанков — иначе контуры «замерзнут» на месте ушедших чанков
		if (++purgeCounter >= PURGE_PERIOD) {
			purgeCounter = 0;
			purgeUnloaded(world);
		}

		// Пересобираем очередь, когда игрок переходит в другой чанк (или очередь пуста)
		ChunkPos center = player.getChunkPos();
		if (queue.isEmpty() || !center.equals(queueCenter)) {
			rebuildQueue(center);
		}
		if (queue.isEmpty()) {
			return;
		}

		// Один чанк за тик, по кругу — нагрузка на кадр почти нулевая
		if (cursor >= queue.size()) {
			cursor = 0;
		}
		ChunkPos pos = queue.get(cursor++);
		long key = pos.toLong();
		List<FoundOre> ores = scanChunk(world, pos.x, pos.z);
		if (ores == null || ores.isEmpty()) {
			found.remove(key);
		} else {
			found.put(key, ores);
		}
	}

	/** Очередь: все чанки радиуса, ближние к игроку — первыми. */
	private void rebuildQueue(ChunkPos center) {
		queue.clear();
		for (int dx = -SCAN_RADIUS; dx <= SCAN_RADIUS; dx++) {
			for (int dz = -SCAN_RADIUS; dz <= SCAN_RADIUS; dz++) {
				queue.add(new ChunkPos(center.x + dx, center.z + dz));
			}
		}
		queue.sort(Comparator.comparingInt(p ->
				(p.x - center.x) * (p.x - center.x) + (p.z - center.z) * (p.z - center.z)));
		queueCenter = center;
		cursor = 0;
	}

	/** Выкидываем результаты чанков, которых больше нет в памяти клиента. */
	private void purgeUnloaded(ClientWorld world) {
		Iterator<Long> it = found.keySet().iterator();
		while (it.hasNext()) {
			long key = it.next();
			// Упаковка ChunkPos.toLong: x — младшие 32 бита, z — старшие
			int cx = (int) key;
			int cz = (int) (key >> 32);
			if (!world.isChunkLoaded(cx, cz)) {
				it.remove();
			}
		}
	}

	/** Полный проход одного чанка. null — чанк не загружен. */
	private List<FoundOre> scanChunk(ClientWorld world, int cx, int cz) {
		if (!world.isChunkLoaded(cx, cz)) {
			return null;
		}
		WorldChunk chunk = world.getChunk(cx, cz);
		if (chunk == null) {
			return null;
		}
		ChunkSection[] sections = chunk.getSectionArray();
		int bottomY = world.getBottomY();
		List<FoundOre> ores = null;

		for (int s = 0; s < sections.length; s++) {
			ChunkSection section = sections[s];
			if (section == null || section.isEmpty()) {
				continue; // секция однородного воздуха — пропуск бесплатный
			}
			int sectionBaseY = bottomY + (s << 4);
			for (int y = 0; y < 16; y++) {
				for (int z = 0; z < 16; z++) {
					for (int x = 0; x < 16; x++) {
						BlockState state = section.getBlockState(x, y, z);
						if (state.isAir()) {
							continue;
						}
						OreType type = typeOf(state.getBlock());
						if (type != null) {
							if (ores == null) {
								ores = new ArrayList<>();
							}
							ores.add(new FoundOre((cx << 4) + x, sectionBaseY + y, (cz << 4) + z, type));
						}
					}
				}
			}
		}
		return ores;
	}

	/** Тип руды по блоку (обычная + глубинная разновидность). null — не руда. */
	private static OreType typeOf(Block block) {
		if (block == Blocks.COAL_ORE || block == Blocks.DEEPSLATE_COAL_ORE) {
			return OreType.COAL;
		}
		if (block == Blocks.IRON_ORE || block == Blocks.DEEPSLATE_IRON_ORE) {
			return OreType.IRON;
		}
		// Золото: обычное + глубинное + адское (nether gold ore)
		if (block == Blocks.GOLD_ORE || block == Blocks.DEEPSLATE_GOLD_ORE
				|| block == Blocks.NETHER_GOLD_ORE) {
			return OreType.GOLD;
		}
		if (block == Blocks.LAPIS_ORE || block == Blocks.DEEPSLATE_LAPIS_ORE) {
			return OreType.LAPIS;
		}
		if (block == Blocks.REDSTONE_ORE || block == Blocks.DEEPSLATE_REDSTONE_ORE) {
			return OreType.REDSTONE;
		}
		if (block == Blocks.DIAMOND_ORE || block == Blocks.DEEPSLATE_DIAMOND_ORE) {
			return OreType.DIAMOND;
		}
		if (block == Blocks.ANCIENT_DEBRIS) {
			return OreType.NETHERITE;
		}
		if (block == Blocks.EMERALD_ORE || block == Blocks.DEEPSLATE_EMERALD_ORE) {
			return OreType.EMERALD;
		}
		return null;
	}

	/** Включена ли галка типа (фильтр применяем при РЕНДЕРЕ — переключение мгновенное). */
	private boolean enabled(OreType type) {
		return switch (type) {
			case COAL -> coal.get();
			case IRON -> iron.get();
			case GOLD -> gold.get();
			case LAPIS -> lapis.get();
			case REDSTONE -> redstone.get();
			case DIAMOND -> diamond.get();
			case NETHERITE -> netherite.get();
			case EMERALD -> emerald.get();
		};
	}

	// ===== Рендер контура (AFTER_ENTITIES, из NeuClient) =====

	public void renderWorld(WorldRenderContext context, MinecraftClient client) {
		if (found.isEmpty() || context.commandQueue() == null) {
			return;
		}

		Vec3d cam = client.gameRenderer.getCamera().getCameraPos();
		MatrixStack matrices = context.matrices();

		matrices.push();
		matrices.translate(-cam.x, -cam.y, -cam.z);
		context.commandQueue().submitCustom(matrices, LINES_LAYER, (entry, buffer) -> {
			for (List<FoundOre> ores : found.values()) {
				for (FoundOre ore : ores) {
					if (!enabled(ore.type())) {
						continue;
					}
					float r = ((ore.type().color >> 16) & 0xFF) / 255.0f;
					float g = ((ore.type().color >> 8) & 0xFF) / 255.0f;
					float b = (ore.type().color & 0xFF) / 255.0f;
					outline(entry, buffer, ore.x(), ore.y(), ore.z(),
							ore.x() + 1.0, ore.y() + 1.0, ore.z() + 1.0, r, g, b);
				}
			}
		});
		matrices.pop();
	}

	/** 12 рёбер куба линиями. */
	private static void outline(MatrixStack.Entry entry, VertexConsumer buffer,
			double x0, double y0, double z0, double x1, double y1, double z1,
			float r, float g, float b) {
		// Рёбра вдоль X
		edge(entry, buffer, x0, y0, z0, x1, y0, z0, r, g, b);
		edge(entry, buffer, x0, y1, z0, x1, y1, z0, r, g, b);
		edge(entry, buffer, x0, y0, z1, x1, y0, z1, r, g, b);
		edge(entry, buffer, x0, y1, z1, x1, y1, z1, r, g, b);
		// Рёбра вдоль Y
		edge(entry, buffer, x0, y0, z0, x0, y1, z0, r, g, b);
		edge(entry, buffer, x1, y0, z0, x1, y1, z0, r, g, b);
		edge(entry, buffer, x0, y0, z1, x0, y1, z1, r, g, b);
		edge(entry, buffer, x1, y0, z1, x1, y1, z1, r, g, b);
		// Рёбра вдоль Z
		edge(entry, buffer, x0, y0, z0, x0, y0, z1, r, g, b);
		edge(entry, buffer, x1, y0, z0, x1, y0, z1, r, g, b);
		edge(entry, buffer, x0, y1, z0, x0, y1, z1, r, g, b);
		edge(entry, buffer, x1, y1, z0, x1, y1, z1, r, g, b);
	}

	private static void edge(MatrixStack.Entry entry, VertexConsumer buffer,
			double ax, double ay, double az, double bx, double by, double bz,
			float r, float g, float b) {
		float dx = (float) (bx - ax);
		float dy = (float) (by - ay);
		float dz = (float) (bz - az);
		float len = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
		if (len < 1.0E-5f) {
			return;
		}
		dx /= len;
		dy /= len;
		dz /= len;
		buffer.vertex(entry, (float) ax, (float) ay, (float) az)
				.color(r, g, b, LINE_ALPHA)
				.normal(entry, dx, dy, dz)
				.lineWidth(LINE_WIDTH);
		buffer.vertex(entry, (float) bx, (float) by, (float) bz)
				.color(r, g, b, LINE_ALPHA)
				.normal(entry, dx, dy, dz)
				.lineWidth(LINE_WIDTH);
	}

	// ===== Диспетчер (из NeuClient) =====

	public static void renderAllWorld(WorldRenderContext context) {
		NeuClient client = NeuClient.getInstance();
		if (client == null || client.getModuleManager() == null) {
			return;
		}
		XrayModule self = client.getModuleManager().get(XrayModule.class);
		if (self != null && self.isEnabled()) {
			self.renderWorld(context, MinecraftClient.getInstance());
		}
	}
}
