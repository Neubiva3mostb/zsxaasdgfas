package ru.neuclient.client.module.impl.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.font.MsdfFontRenderer;
import ru.neuclient.client.font.MsdfFonts;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.render.WorldToScreen;
import ru.neuclient.client.setting.BooleanSetting;
import ru.neuclient.client.util.SkinUtil;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

/**
 * NameTags — панель над головой игрока с нативным MSDF-шрифтом.
 */
public class NameTagsModule extends Module {

	private final BooleanSetting naked = new BooleanSetting("Голых", false);
	private final BooleanSetting players = new BooleanSetting("Игроков", true);
	private final BooleanSetting invisiblePlayers = new BooleanSetting("Невидимых игроков", true);
	private final BooleanSetting mobs = new BooleanSetting("Мобы", false);
	private final BooleanSetting items = new BooleanSetting("Предметы", true);
	private final BooleanSetting armor = new BooleanSetting("Броню", true);
	private final BooleanSetting effects = new BooleanSetting("Эффекты", false);
	private final BooleanSetting head = new BooleanSetting("Голова", true);
	private final BooleanSetting friendTag = new BooleanSetting("Тег друга", true);

	private static final double MAX_RANGE_SQ = 100.0 * 100.0;
	private static final double ITEM_RANGE_SQ = 48.0 * 48.0;
	private static final int MAX_ITEM_TAGS = 40;

	private static final float TAG_FONT_SIZE = 8.0f;
	private static final float ITEM_SCALE = 0.5f;
	private static final int PANEL_BG = 0x90000000;

	private final Set<ItemEntity> glowingItems = new HashSet<>();

	public NameTagsModule() {
		super("NameTags", "Подсвечивает ники игроков/предметов", Category.RENDER);
		addSettings(naked, players, invisiblePlayers, mobs, items, armor, effects, head, friendTag);
	}

	@Override
	protected void onDisable() {
		clearGlow();
	}

	@Override
	public void onTick(MinecraftClient client) {
		if (!items.get() || client.world == null || client.player == null) {
			clearGlow();
			return;
		}

		List<ItemEntity> drops = collectDrops(client.player);
		Set<ItemEntity> keep = new HashSet<>(
				drops.subList(0, Math.min(MAX_ITEM_TAGS, drops.size())));

		Iterator<ItemEntity> it = glowingItems.iterator();
		while (it.hasNext()) {
			ItemEntity e = it.next();
			if (e.isRemoved() || !keep.contains(e)) {
				e.setGlowing(false);
				it.remove();
			}
		}
		for (ItemEntity e : keep) {
			if (glowingItems.add(e)) {
				e.setGlowing(true);
			}
		}
	}

	private void clearGlow() {
		for (ItemEntity e : glowingItems) {
			e.setGlowing(false);
		}
		glowingItems.clear();
	}

	private List<PlayerEntity> targets(ClientPlayerEntity self) {
		List<PlayerEntity> out = new ArrayList<>();
		net.minecraft.client.world.ClientWorld world = MinecraftClient.getInstance().world;
		if (world == null) {
			return out;
		}
		for (PlayerEntity other : world.getPlayers()) {
			if (other == self || !other.isAlive() || other.isSpectator()) {
				continue;
			}
			Text custom = other.getCustomName();
			if (custom != null && custom.getString().startsWith("Ghost_")) {
				continue;
			}
			if (other.isInvisible() && !invisiblePlayers.get()) {
				continue;
			}
			if (self.squaredDistanceTo(other) > MAX_RANGE_SQ) {
				continue;
			}
			boolean armored = !isNaked(other);
			if (armored && !players.get()) {
				continue;
			}
			if (!armored && !naked.get()) {
				continue;
			}
			out.add(other);
		}
		return out;
	}

	private List<ItemEntity> collectDrops(ClientPlayerEntity self) {
		List<ItemEntity> drops = new ArrayList<>();
		net.minecraft.client.world.ClientWorld world = MinecraftClient.getInstance().world;
		if (world == null) {
			return drops;
		}
		for (Entity entity : world.getEntities()) {
			if (entity instanceof ItemEntity item && item.isAlive()
					&& self.squaredDistanceTo(item) <= ITEM_RANGE_SQ) {
				drops.add(item);
			}
		}
		drops.sort((a, b) -> Double.compare(self.squaredDistanceTo(a), self.squaredDistanceTo(b)));
		return drops;
	}

	public void renderNameTags(DrawContext ctx, MinecraftClient client) {
		ClientPlayerEntity self = client.player;
		if (self == null || client.world == null) {
			return;
		}
		float tickDelta = WorldToScreen.frameDelta;

		if (items.get()) {
			List<ItemEntity> drops = collectDrops(self);
			int shown = 0;
			for (ItemEntity item : drops) {
				if (shown >= MAX_ITEM_TAGS) {
					break;
				}
				double[] s = WorldToScreen.project(
						item.getLerpedPos(tickDelta).add(0.0, 0.85, 0.0), client);
				if (s == null) {
					continue;
				}
				drawDropTag(ctx, item.getStack(), (float) s[0], (float) s[1]);
				shown++;
			}
		}

		for (PlayerEntity other : targets(self)) {
			Vec3d cameraPos = client.gameRenderer.getCamera().getCameraPos();
			Vec3d lerped = other.getLerpedPos(tickDelta);
			if (cameraPos.distanceTo(lerped.add(0.0, other.getHeight() * 0.5, 0.0)) < 0.5) {
				continue;
			}
			double[] s = WorldToScreen.project(lerped.add(0.0, other.getHeight() + 0.35, 0.0), client);
			if (s == null) {
				continue;
			}
			drawTag(ctx, other, (float) s[0], (float) s[1]);
		}

		// Мобы
		if (mobs.get()) {
			for (net.minecraft.entity.Entity entity : client.world.getEntities()) {
				if (entity instanceof MobEntity mob && (Object) mob != self && mob.isAlive()
						&& self.squaredDistanceTo(mob) <= MAX_RANGE_SQ) {
					Vec3d lerped = mob.getLerpedPos(tickDelta);
					double[] s = WorldToScreen.project(lerped.add(0.0, mob.getHeight() + 0.35, 0.0), client);
					if (s == null) continue;
					drawMobTag(ctx, mob, (float) s[0], (float) s[1]);
				}
			}
		}
	}

	private void drawTag(DrawContext ctx, PlayerEntity other, float centerX, float anchorY) {
		boolean friend = NeuClient.getInstance().getFriendManager().isFriend(other.getName().getString());

		float headW = head.get() ? 6.0f + 2.0f : 0.0f;
		String fSeg = friend && friendTag.get() ? "F " : "";
		String nameText = nameWithPrefix(other).getString();
		String hpSeg = buildHp(other);

		float fW = segW(fSeg);
		float nameW = segW(nameText);
		float hpW = segW(hpSeg);
		float totalW = headW + fW + nameW + hpW;

		float cursor = anchorY - 2.0f;

		if (armor.get()) {
			List<ItemStack> icons = new ArrayList<>();
			ItemStack handStack = other.getMainHandStack();
			if (!handStack.isEmpty()) {
				icons.add(handStack);
			}
			for (EquipmentSlot slot : new EquipmentSlot[] {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
				ItemStack piece = other.getEquippedStack(slot);
				if (!piece.isEmpty()) {
					icons.add(piece);
				}
			}
			if (!icons.isEmpty()) {
				float rowW = icons.size() * 9.0f - 1.0f;
				float rowX = centerX - rowW / 2.0f;
				float rowTop = cursor - 10.0f;
				ctx.fill(Math.round(rowX - 2), Math.round(rowTop - 1),
						Math.round(rowX + rowW + 2), Math.round(rowTop + 10), PANEL_BG);
				float ix = rowX;
				for (ItemStack stack : icons) {
					var m = ctx.getMatrices();
					m.pushMatrix();
					m.translate(ix, rowTop);
					m.scale(ITEM_SCALE, ITEM_SCALE);
					ctx.drawItem(stack, 0, 0);
					m.popMatrix();
					ix += 9.0f;
				}
				cursor = rowTop - 1.0f;
			}
		}

		float panelTop = cursor - 10.0f;
		float panelX = centerX - totalW / 2.0f;
		ctx.fill(Math.round(panelX - 4), Math.round(panelTop),
				Math.round(panelX + totalW + 4), Math.round(panelTop + 11), PANEL_BG);

		float dx = panelX;
		float textY = panelTop + 1.5f;
		if (head.get()) {
			SkinUtil.drawHead(ctx, other, dx, textY - 0.3f, 6.0f);
			dx += headW;
		}
		if (fW > 0) {
			drawSeg(ctx, fSeg, dx, textY, 0xFF55FF55);
			dx += fW;
		}
		drawSeg(ctx, nameText, dx, textY, 0xFFFFFFFF);
		dx += nameW;
		if (hpW > 0) {
			drawSeg(ctx, hpSeg, dx, textY, 0xFFFFFFFF);
		}

		if (effects.get() && !other.getStatusEffects().isEmpty()) {
			drawEffectIcons(ctx, other.getStatusEffects(), centerX, anchorY + 2.0f);
		}
	}

	private void drawEffectIcons(DrawContext ctx, java.util.Collection<StatusEffectInstance> effects,
			float centerX, float ey) {
		List<StatusEffectInstance> list = new ArrayList<>(effects);
		float cell = 10.0f;
		float totalW = list.size() * cell - 1.0f;
		float x0 = centerX - totalW / 2.0f;

		ctx.fill(Math.round(x0 - 2), Math.round(ey - 1),
				Math.round(x0 + totalW + 2), Math.round(ey + 10), PANEL_BG);

		float ix = x0;
		for (StatusEffectInstance e : list) {
			boolean good = e.getEffectType().value().isBeneficial();
			if (!good) {
				ctx.fill(Math.round(ix), Math.round(ey), Math.round(ix + 9), Math.round(ey + 9), 0x80401212);
			}
			Identifier icon = net.minecraft.client.gui.hud.InGameHud.getEffectTexture(e.getEffectType());
			ctx.drawGuiTexture(RenderPipelines.GUI_TEXTURED, icon,
					Math.round(ix), Math.round(ey), 9, 9);

			int amp = e.getAmplifier() + 1;
			if (amp > 1) {
				MsdfFontRenderer.drawWithShadow(ctx, MsdfFonts.sfMedium(), String.valueOf(amp),
						ix + 5.0f, ey + 4.0f, 0xFFFFFFFF, 6.0f);
			}
			ix += cell;
		}
	}

	private static Text nameWithPrefix(PlayerEntity other) {
		var nh = MinecraftClient.getInstance().getNetworkHandler();
		if (nh != null) {
			net.minecraft.client.network.PlayerListEntry entry = nh.getPlayerListEntry(other.getUuid());
			if (entry != null && entry.getDisplayName() != null) {
				return entry.getDisplayName();
			}
		}
		Text display = other.getDisplayName();
		return display != null ? display : other.getName();
	}

	private static String buildHp(PlayerEntity player) {
		int hp = Math.round(Math.max(0.0f, player.getHealth()));
		int abs = Math.round(player.getAbsorptionAmount());
		return abs > 0 ? " [" + hp + "," + abs + "]" : " [" + hp + "]";
	}

	private void drawMobTag(DrawContext ctx, MobEntity mob, float centerX, float anchorY) {
		String nameText = mob.getName().getString();
		int hp = Math.round(Math.max(0.0f, mob.getHealth()));
		String hpSeg = " [" + hp + "]";
		float nameW = segW(nameText);
		float hpW = segW(hpSeg);
		float totalW = nameW + hpW;

		float panelTop = anchorY - 10.0f;
		float panelX = centerX - totalW / 2.0f;
		ctx.fill(Math.round(panelX - 4), Math.round(panelTop),
				Math.round(panelX + totalW + 4), Math.round(panelTop + 11), PANEL_BG);
		float textY = panelTop + 1.5f;
		drawSeg(ctx, nameText, panelX, textY, 0xFFFFFFFF);
		drawSeg(ctx, hpSeg, panelX + nameW, textY, 0xFFFFFFFF);
	}

	private void drawDropTag(DrawContext ctx, ItemStack stack, float centerX, float anchorY) {
		String name = stack.getName().getString();
		String count = stack.getCount() > 1 ? " x" + stack.getCount() : "";
		float nameW = segW(name);
		float countW = segW(count);
		float totalW = nameW + countW;

		float panelTop = anchorY - 9.0f;
		float panelX = centerX - totalW / 2.0f;
		ctx.fill(Math.round(panelX - 3), Math.round(panelTop),
				Math.round(panelX + totalW + 3), Math.round(panelTop + 10), PANEL_BG);
		drawSeg(ctx, name, panelX, panelTop + 1.0f, 0xFFFFFFFF);
		if (!count.isEmpty()) {
			drawSeg(ctx, count, panelX + nameW, panelTop + 1.0f, 0xFFFFAA00);
		}
	}

	private static float segW(String s) {
		return MsdfFontRenderer.getWidth(MsdfFonts.sfMedium(), s, TAG_FONT_SIZE);
	}

	private static void drawSeg(DrawContext ctx, String s, float x, float y, int color) {
		MsdfFontRenderer.drawWithShadow(ctx, MsdfFonts.sfMedium(), s, x, y, color, TAG_FONT_SIZE);
	}

	private static boolean isNaked(PlayerEntity player) {
		for (EquipmentSlot slot : new EquipmentSlot[] {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET}) {
			if (!player.getEquippedStack(slot).isEmpty()) {
				return false;
			}
		}
		return true;
	}

	private static NameTagsModule active() {
		NeuClient c = NeuClient.getInstance();
		if (c == null || c.getModuleManager() == null) {
			return null;
		}
		NameTagsModule self = c.getModuleManager().get(NameTagsModule.class);
		return self != null && self.isEnabled() ? self : null;
	}

	public static void renderAllHud(DrawContext ctx) {
		NameTagsModule self = active();
		if (self != null) {
			self.renderNameTags(ctx, MinecraftClient.getInstance());
		}
	}

	public static boolean hideVanillaTags() {
		return active() != null;
	}
}
