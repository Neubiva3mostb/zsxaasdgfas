package ru.neuclient.client.mixin;

import net.minecraft.client.network.ClientPlayerInteractionManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

/**
 * Доступ к приватному ClientPlayerInteractionManager#syncSelectedSlot():
 * при его вызове серверу МГНОВЕННО улетает UpdateSelectedSlotC2SPacket
 * (если выбранный слот реально поменялся). Нужен легитным макросам,
 * чтобы сервер видел предмет в руке ДО броска/удара, а не «когда-нибудь».
 */
@Mixin(ClientPlayerInteractionManager.class)
public interface ClientPlayerInteractionManagerInvoker {

	@Invoker("syncSelectedSlot")
	void pc$syncSelectedSlot();

	/**
	 * Доступ к приватному полю lastSelectedSlot.
	 *
	 * ЗАЧЕМ. syncSelectedSlot() шлёт UpdateSelectedSlotC2SPacket ТОЛЬКО
	 * когда текущий слот инвентаря отличается от lastSelectedSlot
	 * (проверено по байткоду: getSelectedSlot vs lastSelectedSlot,
	 * if_icmpeq → выход без отправки).
	 *
	 * Из-за этого NoSlotChange и не работал. Сервер шлёт «переключись на
	 * слот 3», мы возвращаем инвентарю слот 0 — но lastSelectedSlot всё
	 * ещё 0, расхождения нет, и ваниль НИКОГДА не отправит серверу наш
	 * настоящий слот. Сервер остаётся при своём мнении.
	 *
	 * Ставя сюда заведомо другое значение, мы заставляем ванильный
	 * sync в следующем же тике отправить корректирующий пакет — тем же
	 * путём, каким его шлёт обычное переключение колесом.
	 */
	@Accessor("lastSelectedSlot")
	void pc$setLastSelectedSlot(int slot);

	@Accessor("lastSelectedSlot")
	int pc$getLastSelectedSlot();
}
