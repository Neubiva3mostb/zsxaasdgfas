package ru.neuclient.client.module.impl.combat;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Getter @Setter
public class SprintControl {

    private MinecraftClient client = MinecraftClient.getInstance();
    private boolean serverSprint;
    private int sprintResetTicks;
    private boolean lastSprint;

    @Getter(AccessLevel.NONE) @Setter(AccessLevel.NONE)
    private boolean hasReset;

    @Retention(RetentionPolicy.RUNTIME)
    @Target(ElementType.METHOD)
    public @interface EventHandler {}

    public record PacketEvent(Packet<?> packet) {
        public Packet<?> getPacket() {
            return packet;
        }
    }

    public static class TickEvent {}

    @EventHandler
    public void onPacket(PacketEvent e) {
        if (e == null || e.getPacket() == null) return;
        switch (e.getPacket()) {
            case ClientCommandC2SPacket command -> serverSprint = switch (command.getMode()) {
                case START_SPRINTING -> true;
                case STOP_SPRINTING -> false;
                default -> serverSprint;
            };

            default -> {}
        }
    }

    public void onPacket(Packet<?> packet) {
        if (packet == null) return;
        switch (packet) {
            case ClientCommandC2SPacket command -> serverSprint = switch (command.getMode()) {
                case START_SPRINTING -> true;
                case STOP_SPRINTING -> false;
                default -> serverSprint;
            };

            default -> {}
        }
    }

    @EventHandler
    public void onTick(TickEvent ignored) {
        onTick();
    }

    public void onTick() {
        if (client == null) {
            client = MinecraftClient.getInstance();
        }
        if (client.player == null) {
            sprintResetTicks = 0;
            hasReset = false;
            return;
        }

        if (sprintResetTicks > 0) {
            if (!hasReset) {
                hasReset = true;
            }
            client.player.setSprinting(false);
            sprintResetTicks--;
        } else if (hasReset) {
            if (client.options != null && client.options.sprintKey != null) {
                client.options.sprintKey.setPressed(true);
            }
            client.player.setSprinting(true);
            hasReset = false;
        }
    }

    public void onTick(MinecraftClient client) {
        if (client != null) {
            this.client = client;
        }
        onTick();
    }

    public void resetSprint(int ticks) {
        if (client == null) {
            client = MinecraftClient.getInstance();
        }
        if (client.player == null) {
            return;
        }
        lastSprint = client.player.isSprinting();
        this.sprintResetTicks = Math.max(1, ticks);
    }

    public void resetSprint() {
        resetSprint(1);
    }

    public void reset() {
        this.sprintResetTicks = 0;
        if (this.hasReset) {
            if (client != null && client.options != null && client.options.sprintKey != null) {
                client.options.sprintKey.setPressed(true);
            }
            if (client != null && client.player != null) {
                client.player.setSprinting(true);
            }
            this.hasReset = false;
        }
    }

    public MinecraftClient getClient() {
        return client;
    }

    public void setClient(MinecraftClient client) {
        this.client = client;
    }

    public boolean isServerSprint() {
        return serverSprint;
    }

    public void setServerSprint(boolean serverSprint) {
        this.serverSprint = serverSprint;
    }

    public int getSprintResetTicks() {
        return sprintResetTicks;
    }

    public void setSprintResetTicks(int sprintResetTicks) {
        this.sprintResetTicks = sprintResetTicks;
    }

    public boolean isLastSprint() {
        return lastSprint;
    }

    public void setLastSprint(boolean lastSprint) {
        this.lastSprint = lastSprint;
    }
}
