package ru.neuclient.client.mixin;

import ru.neuclient.client.module.impl.render.ViewModelModule;

import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import net.minecraft.util.math.RotationAxis;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.impl.render.AttackAnimationsModule;

/**
 * Рендер руки от первого лица. Здесь живут два модуля:
 *
 *  • ViewModel — смещение X/Y/Z и наклон предмета;
 *  • Attack Animations — полная замена ванильной анимации удара.
 *
 * Схема Attack Animations повторяет рабочий референс Swing Animation Plus
 * для 1.21.11 (github.com/sskyness/Swing-Animation, CC0):
 *
 *  1. @Redirect по swingArm с ordinal = 2 — это вызов в ветке обычного
 *     предмета в руке (всего вызовов три: ordinal 0, 1, 2). Если модуль
 *     сам отрисовал анимацию, ванильную раскачку не зовём.
 *  2. @Redirect по applyEquipOffset с ordinal = 4 — последний из пяти
 *     вызовов, он относится к той же ветке. Его тоже глушим, потому что
 *     базовое смещение руки модуль ставит сам.
 *
 * Раньше redirect висел без ordinal и цеплял первый попавшийся вызов —
 * из-за этого «Никакой» не работал, а режимы выглядели одинаково.
 */
@Mixin(HeldItemRenderer.class)
public abstract class HeldItemRendererMixin {

	/** true — между HEAD и RETURN: мы сделали push и обязаны сделать pop. */
	@Unique
	private boolean pc$viewModelPushed;

	@Inject(method = "renderFirstPersonItem(Lnet/minecraft/client/network/AbstractClientPlayerEntity;FFLnet/minecraft/util/Hand;FLnet/minecraft/item/ItemStack;FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;I)V",
			at = @At("HEAD"))
	private void pc$viewModelApply(AbstractClientPlayerEntity player, float tickDelta, float pitch,
			Hand hand, float swingProgress, ItemStack stack, float equipProgress, MatrixStack matrices,
			OrderedRenderCommandQueue queue, int light, CallbackInfo ci) {
		pc$viewModelPushed = false;

		ru.neuclient.client.module.impl.render.ViewModelModule viewModel =
				ru.neuclient.client.module.impl.render.ViewModelModule.activeModule();
		if (viewModel == null) {
			return;
		}
		pc$viewModelPushed = true;
		matrices.push();
		matrices.translate(viewModel.getOffsetX(hand), viewModel.getOffsetY(hand), viewModel.getOffsetZ(hand));
		matrices.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(viewModel.getTiltZ(hand)));
	}

	@Inject(method = "renderFirstPersonItem(Lnet/minecraft/client/network/AbstractClientPlayerEntity;FFLnet/minecraft/util/Hand;FLnet/minecraft/item/ItemStack;FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;I)V",
			at = @At("RETURN"))
	private void pc$viewModelRestore(AbstractClientPlayerEntity player, float tickDelta, float pitch,
			Hand hand, float swingProgress, ItemStack stack, float equipProgress, MatrixStack matrices,
			OrderedRenderCommandQueue queue, int light, CallbackInfo ci) {
		if (pc$viewModelPushed) {
			matrices.pop();
			pc$viewModelPushed = false;
		}
	}

	/**
	 * Attack Animations: своя анимация вместо ванильной раскачки.
	 * ordinal = 2 — вызов swingArm в ветке обычного предмета в руке.
	 */
	@Redirect(method = "renderFirstPersonItem(Lnet/minecraft/client/network/AbstractClientPlayerEntity;FFLnet/minecraft/util/Hand;FLnet/minecraft/item/ItemStack;FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;I)V",
			at = @At(value = "INVOKE",
					target = "Lnet/minecraft/client/render/item/HeldItemRenderer;swingArm(FLnet/minecraft/client/util/math/MatrixStack;ILnet/minecraft/util/Arm;)V",
					ordinal = 2))
	private void pc$replaceSwingArm(HeldItemRenderer self, float swingProgress,
			MatrixStack matrices, int light, Arm arm) {
		try {
			AttackAnimationsModule animations = AttackAnimationsModule.active();
			if (animations != null && animations.apply(matrices, arm, swingProgress)) {
				return; // модуль отрисовал сам — ваниль не нужна
			}
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка Attack Animations (свинг)", t);
		}
		((HeldItemRendererInvoker) self).pc$swingArm(swingProgress, matrices, light, arm);
	}

	/**
	 * Attack Animations: базовое смещение руки модуль ставит сам,
	 * поэтому ванильный applyEquipOffset (ordinal = 4, та же ветка)
	 * пропускаем, иначе смещение применилось бы дважды.
	 */
	@Redirect(method = "renderFirstPersonItem(Lnet/minecraft/client/network/AbstractClientPlayerEntity;FFLnet/minecraft/util/Hand;FLnet/minecraft/item/ItemStack;FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;I)V",
			at = @At(value = "INVOKE",
					target = "Lnet/minecraft/client/render/item/HeldItemRenderer;applyEquipOffset(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/util/Arm;F)V",
					ordinal = 4))
	private void pc$skipEquipOffset(HeldItemRenderer self, MatrixStack matrices,
			Arm arm, float equipProgress) {
		try {
			AttackAnimationsModule animations = AttackAnimationsModule.active();
			if (animations != null && animations.shouldAnimate(arm)) {
				return; // смещение поставит сам модуль
			}
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка Attack Animations (offset)", t);
		}
		((HeldItemRendererInvoker) self).pc$applyEquipOffset(matrices, arm, equipProgress);
	}
}
