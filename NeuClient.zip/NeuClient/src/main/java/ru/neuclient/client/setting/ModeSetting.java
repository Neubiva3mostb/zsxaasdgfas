package ru.neuclient.client.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

import java.util.Arrays;
import java.util.List;

/**
 * Настройка-перечисление: перебирает значения из фиксированного списка
 * (ЛКМ — вперёд, ПКМ — назад в GUI).
 */
public class ModeSetting extends Setting<String> {

	private final List<String> modes;

	public ModeSetting(String name, String defaultValue, String... modes) {
		super(name, defaultValue);
		this.modes = Arrays.asList(modes);
	}

	public List<String> getModes() {
		return modes;
	}

	/** Следующий режим (циклически). */
	public void next() {
		set(modes.get((modes.indexOf(get()) + 1) % modes.size()));
	}

	/** Предыдущий режим (циклически). */
	public void prev() {
		int i = modes.indexOf(get()) - 1;
		if (i < 0) {
			i = modes.size() - 1;
		}
		set(modes.get(i));
	}

	@Override
	public JsonElement toJson() {
		return new JsonPrimitive(get());
	}

	@Override
	public void fromJson(JsonElement element) {
		if (element != null && element.isJsonPrimitive() && modes.contains(element.getAsString())) {
			set(element.getAsString());
		}
	}
}
