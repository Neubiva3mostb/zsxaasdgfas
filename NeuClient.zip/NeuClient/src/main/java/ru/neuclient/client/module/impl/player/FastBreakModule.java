package ru.neuclient.client.module.impl.player;

import net.minecraft.client.MinecraftClient;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.NumberSetting;

/**
 * FastBreak — ускоренная добыча блоков.
 *
 * Как работает: каждый тик клиент вызывает
 * ClientPlayerInteractionManager.updateBlockBreakingProgress ровно один раз,
 * и прогресс растёт со скоростью, которую сервер считает из твёрдости блока
 * и твоего инструмента. Миксин вызывает этот метод ещё (скорость − 1) раз
 * за тик — сервер получает больше «настоящих» обновлений прогресса, и блок
 * ломается быстрее.
 *
 * Ползунок «Скорость» — множитель: 2.0 ломает вдвое быстрее, 1.0 = ванилла.
 *
 * ОГРАНИЧЕНИЕ. Это только клиентская сторона: античит видит, что прогресс
 * растёт быстрее, чем положено твоему инструменту. На серверах с проверкой
 * скорости копания высокие значения будут заметны.
 */
public class FastBreakModule extends Module {

	private final NumberSetting speed = new NumberSetting("Скорость", 2.0, 1.0, 10.0, 0.5);

	/** Остаток дробной части множителя между тиками. */
	private double fract;

	/** Защита от повторного входа, пока миксин докручивает прогресс. */
	private boolean applying;

	public FastBreakModule() {
		super("FastBreak", "Ломает блоки быстрее", Category.PLAYER);
		addSettings(speed);
	}

	/** Множитель скорости (≥ 1.0). */
	public double speed() {
		return Math.max(1.0, speed.get());
	}

	/**
	 * Сколько ДОПОЛНИТЕЛЬНЫХ вызовов копания сделать в этот тик.
	 *
	 * Вызывается из миксина. Ноль — если модуль выключен или множитель ≤ 1.
	 * Дробная часть накапливается между тиками, чтобы 1.5x работало ровно.
	 */
	public int extraBreakingCalls() {
		if (!isEnabled()) {
			fract = 0.0;
			return 0;
		}
		// Целевое число вызовов за тик = множитель. Ванильный вызов уже будет,
		// поэтому возвращаем только добавку сверх него. Дробная часть копится
		// между тиками: при 1.5 тики чередуются 1/2, в среднем ровно 1.5x.
		double target = speed() + fract;
		int total = (int) Math.floor(target);
		fract = target - total;
		return Math.max(0, total - 1);
	}

	/** Миксин сообщает, что докручивает прогресс — не заходить повторно. */
	public boolean isApplying() {
		return applying;
	}

	public void setApplying(boolean applying) {
		this.applying = applying;
	}

	@Override
	public void onTick(MinecraftClient client) {
		// Пусто: вся работа в миксине ClientPlayerInteractionManagerMixin
	}
}
