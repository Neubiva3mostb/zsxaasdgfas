package ru.neuclient.client.util;

/**
 * Общее состояние подмены угла взгляда.
 *
 * ЗАЧЕМ ЭТО НУЖНО.
 * Раньше спуф делался подменой аргументов в конструкторе PlayerMoveC2SPacket.
 * Это не работало: ваниль решает, СЛАТЬ ли пакет поворота, сравнивая
 * настоящие yaw/pitch с последними отправленными (lastYawClient). Раз
 * настоящий угол не менялся (мышь стоит), пакет вообще не создавался — и
 * подменять было нечего. Голова «поворачивалась» только когда игрок сам
 * двигался/крутил мышь, потому что тогда пакет отправлялся по другой
 * причине.
 *
 * Теперь угол подменяется НА САМОЙ СУЩНОСТИ на время тика игрока: ваниль
 * видит изменение, честно шлёт LookAndOnGround, обновляет lastYawClient и
 * считает физику от того же угла, что и сервер. По концу тика настоящий
 * угол возвращается, поэтому камера и мышь работают как обычно.
 *
 * Здесь же хранится последний УЖЕ ОТПРАВЛЕННЫЙ серверу угол: удары надо
 * проверять именно по нему. Пакет атаки уходит раньше, чем пакет движения
 * этого тика, поэтому сервер обрабатывает взмах со ЗНАЧЕНИЕМ ИЗ ПРОШЛОГО
 * пакета — если целиться по свежему углу, получаются флаги Hitboxes.
 */
public final class RotationSpoof {

	private RotationSpoof() {
	}

	/** Подмена сейчас наложена на сущность (идёт тик игрока). */
	private static boolean applied;

	/** Настоящий угол игрока, сохранённый на время подмены. */
	private static float realYaw;
	private static float realPitch;

	/** Спуфнутый угол (для рендера тела в F5). */
	private static float spoofYaw;
	private static float spoofPitch;

	/** Угол, который реально ушёл серверу последним пакетом движения. */
	private static float sentYaw;
	private static float sentPitch;
	private static boolean sentValid;

	public static void begin(float yaw, float pitch) {
		realYaw = yaw;
		realPitch = pitch;
		spoofYaw = yaw;
		spoofPitch = pitch;
		applied = true;
	}

	/** Получить спуфнутый yaw (для рендера тела в F5). */
	public static float spoofYaw() {
		return applied ? spoofYaw : realYaw;
	}

	/** Получить спуфнутый pitch (для рендера тела в F5). */
	public static float spoofPitch() {
		return applied ? spoofPitch : realPitch;
	}

	/** Установить спуфнутый угол (вызывается из AttackAura). */
	public static void setSpoof(float yaw, float pitch) {
		spoofYaw = yaw;
		spoofPitch = pitch;
	}

	public static void end() {
		applied = false;
	}

	public static boolean isApplied() {
		return applied;
	}

	/**
	 * Настоящий угол взгляда игрока.
	 * Во время подмены сущность возвращает спуфнутый yaw, поэтому всё,
	 * что должно считаться от «куда смотрит мышь» (коррекция ввода),
	 * обязано брать значение отсюда.
	 */
	public static float realYaw(float fallback) {
		return applied ? realYaw : fallback;
	}

	public static float realPitch(float fallback) {
		return applied ? realPitch : fallback;
	}

	/** Запомнить угол, ушедший серверу в этом тике. */
	public static void markSent(float yaw, float pitch) {
		sentYaw = yaw;
		sentPitch = pitch;
		sentValid = true;
	}

	public static boolean hasSent() {
		return sentValid;
	}

	public static float sentYaw() {
		return sentYaw;
	}

	public static float sentPitch() {
		return sentPitch;
	}

	public static void reset() {
		applied = false;
		sentValid = false;
	}
}
