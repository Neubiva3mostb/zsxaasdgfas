package ru.neuclient.client.module.impl.movement;

/** Чистая логика маршрута, без зависимостей от Minecraft. */
final class AutoPilotFlightController {
    static final double CRUISE_Y = 200.0;
    static final double ARRIVAL_RADIUS = 100.0;

    private boolean cruising;
    private float climbYaw;

    void reset(double y, float yaw) {
        cruising = y >= CRUISE_Y - 2.0;
        climbYaw = yaw;
    }

    boolean hasArrived(double x, double z, double targetX, double targetZ) {
        double dx = targetX - x;
        double dz = targetZ - z;
        return dx * dx + dz * dz <= ARRIVAL_RADIUS * ARRIVAL_RADIUS;
    }

    Steering steer(double x, double y, double z, double velocityY, double targetX, double targetZ) {
        // Выравниваемся заранее: у элитр есть инерция, мгновенная смена pitch
        // прямо на Y=200 иначе унесла бы игрока намного выше маршрута.
        double predictedY = y + velocityY * 8.0;
        if (!cruising && predictedY >= CRUISE_Y - 2.0) {
            cruising = true;
        } else if (cruising && y < CRUISE_Y - 15.0 && velocityY <= 0.0) {
            cruising = false;
        }

        if (!cruising) {
            // Сначала набираем высоту, не поворачивая к цели.
            return new Steering(climbYaw, -65.0f);
        }
        float yaw = (float) Math.toDegrees(Math.atan2(targetZ - z, targetX - x)) - 90.0f;
        // PD-регулятор: ошибка высоты + вертикальная скорость. Небольшой
        // отрицательный pitch компенсирует естественное снижение элитр.
        float pitch = (float) clamp((predictedY - CRUISE_Y) * 2.0 - 3.0, -30.0, 30.0);
        return new Steering(yaw, pitch);
    }

    static float approachAngle(float current, float target, float maxStep) {
        float difference = (target - current) % 360.0f;
        if (difference >= 180.0f) difference -= 360.0f;
        if (difference < -180.0f) difference += 360.0f;
        return current + (float) clamp(difference, -maxStep, maxStep);
    }

    private static double clamp(double value, double min, double max) {
        return Math.max(min, Math.min(max, value));
    }

    record Steering(float yaw, float pitch) {}
}
