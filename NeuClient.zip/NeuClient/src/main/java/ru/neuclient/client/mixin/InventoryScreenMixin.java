package ru.neuclient.client.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.font.MsdfFontRenderer;
import ru.neuclient.client.font.MsdfFonts;
import ru.neuclient.client.util.InventoryResetHelper;

/**
 * Отрисовка кнопки сброса в InventoryScreen с нативным MSDF-шрифтом.
 */
@Mixin(InventoryScreen.class)
public abstract class InventoryScreenMixin {

    @Inject(method = "render", at = @At("TAIL"))
    private void pc$renderResetButton(DrawContext context, int mouseX, int mouseY, float delta,
                                             CallbackInfo ci) {
        try {
            NeuClient client = NeuClient.getInstance();
            if (client == null || client.isPanicked()) {
                return;
            }

            MinecraftClient minecraft = MinecraftClient.getInstance();
            InventoryResetHelper.tick(minecraft);

            int x = minecraft.getWindow().getScaledWidth() / 2 - 40;
            int y = minecraft.getWindow().getScaledHeight() / 2 - 110;
            context.fill(x, y, x + 80, y + 20, 0xF0202020);
            context.fill(x, y, x + 80, y + 1, 0xFFFFFFFF);
            context.fill(x, y + 19, x + 80, y + 20, 0xFF4A4A4A);
            context.fill(x, y, x + 1, y + 20, 0xFFFFFFFF);
            context.fill(x + 79, y, x + 80, y + 20, 0xFF4A4A4A);
            MsdfFontRenderer.drawCenteredWithShadow(context, MsdfFonts.sfMedium(),
                    "Сбросить", x + 40, y + 5.5f, 0xFFFFFFFF, 9.0f);
        } catch (Throwable t) {
            NeuClient.LOGGER.error("[NeuClient] Ошибка отрисовки кнопки сброса", t);
        }
    }
}
