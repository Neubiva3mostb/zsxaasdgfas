package ru.neuclient.client.render;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;

/**
 * Один quad + SDF-фрагмент вместо десятков/сотен ctx.fill для скругления.
 * Радиус передаётся в Position.z и не влияет на порядок: depth-test выключен.
 */
public final class RoundedRectPipeline {

	public static final RenderPipeline PIPELINE = RenderPipelines.register(
			RenderPipeline.builder()
					.withLocation(Identifier.of("perfstream", "pipeline/rounded_rect"))
					.withVertexShader(Identifier.of("perfstream", "core/rounded_rect"))
					.withFragmentShader(Identifier.of("perfstream", "core/rounded_rect"))
					.withVertexFormat(VertexFormats.POSITION_TEXTURE_COLOR, VertexFormat.DrawMode.QUADS)
					.withUniform("DynamicTransforms", UniformType.UNIFORM_BUFFER)
					.withUniform("Projection", UniformType.UNIFORM_BUFFER)
					.withBlend(BlendFunction.TRANSLUCENT)
					.withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
					.withCull(false)
					.withColorWrite(true, true)
					.build()
	);

	public static void touch() {
	}

	private RoundedRectPipeline() {
	}
}
