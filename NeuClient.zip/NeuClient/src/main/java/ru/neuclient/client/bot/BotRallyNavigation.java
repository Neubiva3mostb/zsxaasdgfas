package ru.neuclient.client.bot;

import java.util.*;
import java.util.function.BiConsumer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.PlayerInput;
import net.minecraft.util.math.*;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.module.impl.misc.autowarden.PathFinder;

/** Persistent ground following. Updates only refresh an existing session; they never restart a stopped bot. */
public final class BotRallyNavigation {
    private final MinecraftClient mc;
    private BotGroupOrder order;
    private Object world,player;
    private PathFinder finder;
    private List<BlockPos> path=List.of();
    private int index,ticks,stuck,replanAt,nextReportAt;
    private long lastUpdateNanos;
    private boolean waiting;
    private Vec3d plannedGoal;
    private Vec3d last=Vec3d.ZERO;
    private boolean forward,jump;
    private BiConsumer<String,String> report;
    private UUID hitTarget;
    private long hitExpiresAt, lastHitAttempt;
    private int aimedTicks;
    public BotRallyNavigation(MinecraftClient mc) { this.mc=mc; }
    public boolean active() { return order!=null; }
    public static String conflict() {
        var neu=NeuClient.getInstance(); if(neu==null || neu.getModuleManager()==null)return "Клиент ещё загружается";
        for(Module m:neu.getModuleManager().getModules()) {
            if(!m.isEnabled())continue;
            String name=m.getName();
            // Only the two farming controllers block a rally; categories are not a conflict.
            if("AutoWarden".equals(name) || "TreeFarm".equals(name))
                return "Сначала выключите "+name;
        }
        return null;
    }
    public void start(BotGroupOrder next,BiConsumer<String,String> feedback) {
        cancel("Заменён новым приказом");
        clearHit();
        if(mc.player==null || mc.world==null || !mc.player.isAlive()) { feedback.accept("rejected","Бот не в игре / мёртв");return; }
        if(mc.currentScreen!=null || mc.player.hasVehicle() || mc.player.isGliding()) { feedback.accept("rejected","Закройте экран и завершите полёт/поездку");return; }
        String conflict=conflict(); if(conflict!=null) { feedback.accept("rejected",conflict); return; }
        if(!mc.world.getRegistryKey().getValue().toString().equals(next.dimension())) { feedback.accept("rejected","Другое измерение");return; }
        lastUpdateNanos=System.nanoTime();order=next;world=mc.world;player=mc.player;report=feedback;
        ticks=stuck=replanAt=index=nextReportAt=0;last=mc.player.getEntityPos();waiting=false;plannedGoal=null;
        feedback.accept("moving","Следую за главным");
    }
    /** Session-bound heartbeat/target refresh. Delayed updates cannot resurrect a cancelled order. */
    public void update(BotGroupOrder next) {
        if(!active() || !order.id().equals(next.id()) || !next.kind().equals("FOLLOW"))return;
        if(!BotGroupOrder.normalizeServer(order.server()).equals(BotGroupOrder.normalizeServer(next.server()))
                || !order.dimension().equals(next.dimension())) { cancel("Главный сменил сервер / измерение");return; }
        if(next.createdAt()<order.createdAt())return;
        order=next;lastUpdateNanos=System.nanoTime();
    }
    /** Принимаем удар только в рамках действующей FOLLOW-сессии и своего измерения. */
    public void onLeaderHit(BotGroupOrder hit) {
        if (!active() || !("FOLLOW".equals(order.kind()) || "GO".equals(order.kind())) || !order.id().equals(hit.id())
                || mc.player == null || mc.world == null || mc.currentScreen != null
                || !mc.world.getRegistryKey().getValue().toString().equals(hit.dimension())
                || !BotGroupOrder.normalizeServer(order.server()).equals(BotGroupOrder.normalizeServer(hit.server()))) return;
        UUID uuid = UUID.fromString(hit.text());
        LivingEntity target = findTarget(uuid);
        if (target == null || mc.player.squaredDistanceTo(target) > 144) return;
        hitTarget = uuid;
        hitExpiresAt = System.nanoTime() + 4_000_000_000L;
        aimedTicks = 0;
        path = List.of(); index = replanAt = 0; plannedGoal = null;
    }
    private LivingEntity findTarget(UUID uuid) {
        if (uuid == null || mc.world == null || mc.player == null) return null;
        for (Entity entity : mc.world.getEntities()) {
            if (!uuid.equals(entity.getUuid()) || !(entity instanceof LivingEntity living)
                    || entity == mc.player || !living.isAlive() || living.isSpectator()
                    || NeuClient.getInstance().getFriendManager().isFriend(entity.getName().getString())) continue;
            return living;
        }
        return null;
    }
    private void clearHit() {
        if (hitTarget != null) { path = List.of(); index = replanAt = 0; plannedGoal = null; }
        hitTarget = null; hitExpiresAt = lastHitAttempt = 0; aimedTicks = 0;
    }
    /** Удар реально отправлен серверу; больше не атакуем в ответ на это событие. */
    public void onAttackPacket(Entity entity) {
        if (hitTarget != null && entity != null && hitTarget.equals(entity.getUuid())) clearHit();
    }
    /** До атаки дать ванильному тику отправить поворот головы серверу. */
    private boolean tryHit(LivingEntity target) {
        Vec3d eye = mc.player.getEyePos(), box = target.getBoundingBox().getCenter();
        double x = MathHelper.clamp(eye.x, target.getBoundingBox().minX, target.getBoundingBox().maxX);
        double y = MathHelper.clamp(eye.y, target.getBoundingBox().minY, target.getBoundingBox().maxY);
        double z = MathHelper.clamp(eye.z, target.getBoundingBox().minZ, target.getBoundingBox().maxZ);
        if (eye.squaredDistanceTo(x,y,z) > 9.0 || !mc.player.canSee(target)) { aimedTicks = 0; return false; }
        forward = jump = false;
        double dx = box.x-eye.x, dy = box.y-eye.y, dz = box.z-eye.z;
        mc.player.setYaw((float)Math.toDegrees(Math.atan2(dz,dx))-90f);
        mc.player.setPitch((float)-Math.toDegrees(Math.atan2(dy,Math.hypot(dx,dz))));
        if (aimedTicks++ > 0 && mc.interactionManager != null
                && mc.player.getAttackCooldownProgress(0.5f) >= 0.9f
                && System.nanoTime()-lastHitAttempt > 250_000_000L) {
            lastHitAttempt = System.nanoTime();
            mc.interactionManager.attackEntity(mc.player,target);
            mc.player.swingHand(Hand.MAIN_HAND);
        }
        return true;
    }
    private double horizontalDistance(Vec3d goal) {
        return Math.hypot(mc.player.getX()-goal.x,mc.player.getZ()-goal.z);
    }
    private void waitForTarget(String message) {
        forward=jump=false;path=List.of();index=0;stuck=0;
        if(!waiting || ticks>=nextReportAt) { report.accept("waiting",message);nextReportAt=ticks+20; }
        waiting=true;
    }
    private boolean safe(BlockPos pos) {
        return mc.world.isChunkLoaded(pos.getX()>>4,pos.getZ()>>4) && finder.canStandAt(pos)
                && mc.world.getFluidState(pos).isEmpty() && mc.world.getFluidState(pos.down()).isEmpty();
    }
    private void plan(Vec3d destination) {
        forward=jump=false;
        replanAt=ticks+10;
        BlockPos start=mc.player.getBlockPos(),goal=BlockPos.ofFloored(destination.x,destination.y,destination.z);
        finder=new PathFinder(mc.world,new BlockPos(Math.min(start.getX(),goal.getX())-12,mc.world.getBottomY(),Math.min(start.getZ(),goal.getZ())-12),
                new BlockPos(Math.max(start.getX(),goal.getX())+12,mc.world.getBottomY()+mc.world.getHeight()-1,Math.max(start.getZ(),goal.getZ())+12));
        plannedGoal=destination;
        path=finder.find(start,goal,1);index=0;
        if(path==null || path.isEmpty() || path.stream().anyMatch(p -> !safe(p))) {
            replanAt=ticks+40;waitForTarget("Жду доступного пути к главному");
        }
    }
    public void tick() {
        if(!active())return;
        try {
            var neu=NeuClient.getInstance();
            if(neu==null || neu.isPanicked() || mc.world!=world || mc.player!=player || mc.player==null || !mc.player.isAlive() || mc.getNetworkHandler()==null) { cancel("Выход, смерть или смена мира");return; }
            if(mc.currentScreen!=null || mc.player.hasVehicle() || mc.player.isGliding() || mc.player.isTouchingWater()) { cancel("Движение отменено: экран / вода / полёт");return; }
            String conflict=conflict(); if(conflict!=null) { cancel(conflict);return; }
            if(System.nanoTime()-lastUpdateNanos>8_000_000_000L) { cancel("Нет свежей позиции главного");return; }
            ++ticks;
            LivingEntity target = hitTarget != null && System.nanoTime() < hitExpiresAt ? findTarget(hitTarget) : null;
            if (target == null || mc.player.squaredDistanceTo(target) > 144) clearHit();
            if (hitTarget == null) target = null;
            if (target != null && tryHit(target)) return;
            Vec3d goal = target == null ? new Vec3d(order.x(),order.y(),order.z()) : target.getEntityPos();
            if(horizontalDistance(goal)<=(waiting ? 3.5 : 2.5) && Math.abs(mc.player.getY()-goal.y)<=2) {
                waitForTarget(target == null ? "Рядом с главным — жду его движения" : "Жду возможности ударить цель");return;
            }
            if(mc.player.getEntityPos().distanceTo(goal)>128) {
                waitForTarget("Главный далеко — жду доступной позиции");return;
            }
            Vec3d pos=mc.player.getEntityPos();
            if(pos.squaredDistanceTo(last)<0.0025)stuck++;else stuck=0;last=pos;
            while(index<path.size() && Math.hypot(pos.x-path.get(index).getX()-0.5,pos.z-path.get(index).getZ()-0.5)<0.45 && Math.abs(pos.y-path.get(index).getY())<1.1)index++;
            boolean targetMoved=plannedGoal==null || plannedGoal.squaredDistanceTo(goal)>=2.25;
            boolean blocked=stuck>45 || (index<path.size() && !safe(path.get(index)));
            if(blocked) { replanAt=Math.max(replanAt,ticks+20);waitForTarget("Путь заблокирован — пробую снова"); }
            if(path.isEmpty() || index>=path.size() || (targetMoved && ticks>=replanAt)) {
                forward=jump=false;
                if(ticks>=replanAt) { stuck=0;plan(goal); } else return;
                if(!active() || path.isEmpty() || index>=path.size())return;
            }
            waiting=false;
            BlockPos node=path.get(index); Vec3d next=Vec3d.ofBottomCenter(node);
            double dx=next.x-pos.x,dz=next.z-pos.z;
            float targetYaw=(float)Math.toDegrees(Math.atan2(dz,dx))-90f;
            float diff=MathHelper.wrapDegrees(targetYaw-mc.player.getYaw());
            mc.player.setYaw(mc.player.getYaw()+MathHelper.clamp(diff,-12f,12f));
            forward=Math.abs(MathHelper.wrapDegrees(targetYaw-mc.player.getYaw()))<30;
            jump=forward && mc.player.isOnGround() && node.getY()>mc.player.getBlockY() && Math.hypot(dx,dz)<1.4;
            if(ticks%20==0)report.accept("moving","Иду: осталось ~"+(int)Math.ceil(Math.hypot(goal.x-pos.x,goal.z-pos.z))+" блоков");
        } catch(Throwable t) { NeuClient.LOGGER.error("[NeuBot] Ошибка группового маршрута",t);finish("failed","Ошибка построения маршрута"); }
    }
    public PlayerInput input(PlayerInput real) {
        if(!active())return real;
        if(mc.currentScreen!=null || real.forward() || real.backward() || real.left() || real.right() || real.jump() || real.sneak()) { cancel("Отменено ручным вводом / экраном");return real; }
        return new PlayerInput(forward,false,false,false,jump,false,false);
    }
    public void cancel(String reason) { if(active())finish("stopped",reason); }
    private void finish(String state,String message) {
        var callback=report;order=null;world=player=null;finder=null;path=List.of();forward=jump=false;report=null;clearHit();
        if(callback!=null)callback.accept(state,message);
    }
}
