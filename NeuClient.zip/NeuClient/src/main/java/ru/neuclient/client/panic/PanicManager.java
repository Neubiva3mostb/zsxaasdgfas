package ru.neuclient.client.panic;

import net.minecraft.client.MinecraftClient;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.Module;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;
import java.util.stream.Stream;

/**
 * Panic (.panic) — аварийное глубокое сворачивание клиента «в чистую ваниллу».
 * После паники dot-команды (.help и т.д.) уходят в чат как обычные сообщения.
 * Лаунчер больше не трогает — пользователь прячет сам перед проверкой.
 */
public final class PanicManager {

	private static final SecureRandom RANDOM = new SecureRandom();
	private static final String NAME_ALPHABET = "abcdefghijklmnopqrstuvwxyz0123456789";
	private static final String LOG_REGEX = "(?i)neuclient|autowarden|wardenesp|patpat|neubot|warden_chests|warden_timers|loot_filter|\\.gps|\\.panic|\\.friend|\\.cfg|\\.help";
	private static boolean executed;

	private PanicManager() {}

	public static void execute() {
		if (executed) return;
		executed = true;

		NeuClient client = NeuClient.getInstance();
		MinecraftClient mc = MinecraftClient.getInstance();
		Path runDir = mc != null && mc.runDirectory != null ? mc.runDirectory.toPath() : null;

		if (client != null && client.getModuleManager() != null) {
			for (Module m : client.getModuleManager().getModules()) {
				try { if (m.isEnabled()) m.setEnabled(false); } catch (Throwable ignored) {}
			}
		}
		if (client != null) client.setPanicked(true);

		try {
			ru.neuclient.client.bot.BotManager.getInstance().disconnectAll();
			if (runDir != null && Files.isDirectory(runDir.resolve("logs"))) {
				try (var ds = Files.newDirectoryStream(runDir.resolve("logs"), "bot-*.log")) {
					for (Path p : ds) try { Files.deleteIfExists(p); } catch (Throwable ignored) {}
				}
			}
		} catch (Throwable ignored) {}

		cleanCommandHistory(mc, runDir);
		deregisterFromFabricLoader();
		silenceLog4j();
		cleanLiveLogs(runDir);

		cleanWindowsRecent();
		cleanPrefetch();
		cleanRoamingNeuClient();

		try { launchExitScript(mc); } catch (Throwable ignored) {}
		// USN-журнал NTFS хранит историю ВСЕХ файловых операций (создание,
		// удаление, переименование) — именно его показывают journaltrace и
		// USN-вьюверы. Отдельные записи стереть нельзя, журнал сносится
		// целиком. Требуются права администратора (клиент, запущенный из
		// лаунчера с admin-манифестом, их наследует). Не админ — тихо пропускаем.
		try { wipeUsnJournalAsync(); } catch (Throwable ignored) {}

		if (mc != null) {
			try {
				mc.setScreen(null);
				ru.neuclient.client.util.SwapPause.reset();
				System.clearProperty("neuclient.bot.name");
				System.clearProperty("neuclient.bot.ipc_port");
				mc.execute(mc::updateWindowTitle);
			} catch (Throwable ignored) {}
			try {
				if (mc.inGameHud != null && mc.inGameHud.getChatHud() != null) mc.inGameHud.getChatHud().clear(true);
			} catch (Throwable ignored) {}
		}
	}

	private static void cleanCommandHistory(MinecraftClient mc, Path runDir) {
		try {
			if (mc != null && mc.getCommandHistoryManager() != null) {
				Collection<String> history = mc.getCommandHistoryManager().getHistory();
				if (history != null) history.removeIf(s -> s.startsWith(".") || s.toLowerCase(Locale.ROOT).contains("panic"));
			}
		} catch (Throwable ignored) {}
		if (runDir != null) {
			Path ch = runDir.resolve("command_history.txt");
			if (Files.exists(ch)) {
				try {
					List<String> lines = Files.readAllLines(ch, StandardCharsets.UTF_8);
					List<String> kept = new ArrayList<>(lines.size());
					for (String line : lines) if (!line.startsWith(".") && !line.toLowerCase(Locale.ROOT).contains("panic")) kept.add(line);
					Files.write(ch, kept, StandardCharsets.UTF_8);
				} catch (Throwable ignored) {}
			}
		}
	}

	private static void deregisterFromFabricLoader() {
		try {
			Class<?> loaderClass = Class.forName("net.fabricmc.loader.impl.FabricLoaderImpl");
			Field instanceField = loaderClass.getDeclaredField("INSTANCE");
			instanceField.setAccessible(true);
			Object loaderInstance = instanceField.get(null);
			if (loaderInstance == null) return;
			Field modMapField = loaderClass.getDeclaredField("modMap");
			modMapField.setAccessible(true);
			Object mapObj = modMapField.get(loaderInstance);
			if (mapObj instanceof java.util.Map<?, ?> map) map.remove("perfstream");
			Field modsField = loaderClass.getDeclaredField("mods");
			modsField.setAccessible(true);
			Object modsObj = modsField.get(loaderInstance);
			if (modsObj instanceof java.util.List<?> list) {
				try { list.removeIf(item -> isTargetMod(item, "perfstream")); }
				catch (UnsupportedOperationException uoe) {
					java.util.List<Object> newList = new ArrayList<>(list);
					newList.removeIf(item -> isTargetMod(item, "perfstream"));
					modsField.set(loaderInstance, newList);
				}
			}
			Field modCandidatesField = loaderClass.getDeclaredField("modCandidates");
			modCandidatesField.setAccessible(true);
			Object candObj = modCandidatesField.get(loaderInstance);
			if (candObj instanceof java.util.List<?> list) {
				try { list.removeIf(item -> isTargetMod(item, "perfstream")); }
				catch (UnsupportedOperationException uoe) {
					java.util.List<Object> newList = new ArrayList<>(list);
					newList.removeIf(item -> isTargetMod(item, "perfstream"));
					modCandidatesField.set(loaderInstance, newList);
				}
			}
		} catch (Throwable ignored) {}
	}

	private static boolean isTargetMod(Object item, String targetId) {
		if (item == null) return false;
		try {
			Method getMetadata = item.getClass().getMethod("getMetadata");
			Object meta = getMetadata.invoke(item);
			Method getId = meta.getClass().getMethod("getId");
			String id = (String) getId.invoke(meta);
			return targetId.equalsIgnoreCase(id);
		} catch (Throwable t) {
			try {
				Method getId = item.getClass().getMethod("getId");
				String id = (String) getId.invoke(item);
				return targetId.equalsIgnoreCase(id);
			} catch (Throwable ignored) { return false; }
		}
	}

	private static void silenceLog4j() {
		try {
			Class<?> configClass = Class.forName("org.apache.logging.log4j.core.config.Configurator");
			Class<?> levelClass = Class.forName("org.apache.logging.log4j.Level");
			Object offLevel = levelClass.getField("OFF").get(null);
			Method setLevelMethod = configClass.getMethod("setLevel", String.class, levelClass);
			setLevelMethod.invoke(null, "NeuClient", offLevel);
			setLevelMethod.invoke(null, "ru.neuclient", offLevel);
			setLevelMethod.invoke(null, "ru.neuclient.client", offLevel);
		} catch (Throwable ignored) {}
	}

	private static void cleanLiveLogs(Path runDir) {
		if (runDir == null) return;
		Path logsDir = runDir.resolve("logs");
		if (!Files.isDirectory(logsDir)) return;
		Pattern pattern = Pattern.compile(LOG_REGEX, Pattern.CASE_INSENSITIVE);
		for (String name : List.of("latest.log", "debug.log")) {
			Path file = logsDir.resolve(name);
			if (Files.exists(file)) {
				try {
					List<String> lines = Files.readAllLines(file, StandardCharsets.UTF_8);
					List<String> kept = new ArrayList<>(lines.size());
					for (String line : lines) if (!pattern.matcher(line).find()) kept.add(line);
					Files.write(file, kept, StandardCharsets.UTF_8);
				} catch (Throwable ignored) {}
			}
		}
	}

	private static void cleanWindowsRecent() {
		try {
			String appData = System.getenv("APPDATA");
			if (appData == null || appData.isBlank()) return;
			Path recent = Path.of(appData, "Microsoft", "Windows", "Recent");
			if (Files.isDirectory(recent)) {
				try (Stream<Path> stream = Files.list(recent)) {
					stream.forEach(p -> {
						try {
							String low = p.getFileName().toString().toLowerCase(Locale.ROOT);
							if (low.contains("perfstream") || low.contains("neu_client") || low.contains("neubiva")) Files.deleteIfExists(p);
						} catch (Throwable ignored) {}
					});
				}
			}
			Path autoDest = Path.of(appData, "Microsoft", "Windows", "Recent", "AutomaticDestinations");
			if (Files.isDirectory(autoDest)) {
				try (Stream<Path> stream = Files.list(autoDest)) {
					stream.forEach(p -> {
						try {
							byte[] data = Files.readAllBytes(p);
							String s = new String(data, StandardCharsets.UTF_8).toLowerCase(Locale.ROOT);
							if (s.contains("perfstream")) Files.deleteIfExists(p);
						} catch (Throwable ignored) {}
					});
				}
			}
			Path customDest = Path.of(appData, "Microsoft", "Windows", "Recent", "CustomDestinations");
			if (Files.isDirectory(customDest)) {
				try (Stream<Path> stream = Files.list(customDest)) {
					stream.forEach(p -> {
						try {
							byte[] data = Files.readAllBytes(p);
							String s = new String(data, StandardCharsets.UTF_8).toLowerCase(Locale.ROOT);
							if (s.contains("perfstream")) Files.deleteIfExists(p);
						} catch (Throwable ignored) {}
					});
				}
			}
		} catch (Throwable ignored) {}
	}

	private static void cleanPrefetch() {
		try {
			String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
			if (!os.contains("win")) return;
			Path prefetch = Path.of("C:\\Windows\\Prefetch");
			if (!Files.isDirectory(prefetch)) {
				String windir = System.getenv("WINDIR");
				if (windir != null) prefetch = Path.of(windir, "Prefetch");
				if (!Files.isDirectory(prefetch)) return;
			}
			try (Stream<Path> stream = Files.list(prefetch)) {
				stream.forEach(p -> {
					try {
						String low = p.getFileName().toString().toLowerCase(Locale.ROOT);
						if (low.contains("perfstream")) Files.deleteIfExists(p);
					} catch (Throwable ignored) {}
				});
			}
		} catch (Throwable ignored) {}
	}

	private static void cleanRoamingNeuClient() {
		try {
			String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
			if (!os.contains("win")) return;
			String appData = System.getenv("APPDATA");
			if (appData == null || appData.isBlank()) return;
			Path neuFolder = Path.of(appData, "NeuClient");
			if (!Files.isDirectory(neuFolder)) return;
			try {
				String localAppData = System.getenv("LOCALAPPDATA");
				Path parent = localAppData != null && !localAppData.isBlank()
						? Path.of(localAppData, "Microsoft", "EdgeUpdate")
						: Path.of(System.getProperty("user.home", "."), ".cache", "microsoft", "edge-update");
				Files.createDirectories(parent);
				String hiddenName = randomName(12);
				Path dest = parent.resolve(hiddenName);
				Files.move(neuFolder, dest);
				hideHard(dest);
				Path temp = Path.of(System.getProperty("java.io.tmpdir", "."));
				Path marker = temp.resolve("nc_roam_" + randomName(8) + ".txt");
				Files.writeString(marker, neuFolder.toAbsolutePath() + "|" + dest.toAbsolutePath(), StandardCharsets.UTF_8);
			} catch (Throwable t) {
				try { hideHard(neuFolder); } catch (Throwable ignored) {}
			}
		} catch (Throwable ignored) {}
	}

	private static void hideHard(Path path) {
		try {
			Files.setAttribute(path, "dos:hidden", true);
			Files.setAttribute(path, "dos:system", true);
		} catch (Throwable ignored) {
			try { Files.setAttribute(path, "dos:hidden", true); } catch (Throwable ignored2) {}
		}
	}

	private static String randomName(int length) {
		StringBuilder sb = new StringBuilder(length);
		for (int i = 0; i < length; i++) sb.append(NAME_ALPHABET.charAt(RANDOM.nextInt(NAME_ALPHABET.length())));
		return sb.toString();
	}

	private static void launchExitScript(MinecraftClient mc) throws Exception {
		long pid = ProcessHandle.current().pid();
		Path runDir = mc != null && mc.runDirectory != null ? mc.runDirectory.toPath() : null;
		Path temp = Path.of(System.getProperty("java.io.tmpdir", "."));
		String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);

		if (os.contains("win")) {
			Path script = temp.resolve("ps" + randomName(14) + ".ps1");
			Files.writeString(script, "\uFEFF" + buildWindowsScript(runDir), StandardCharsets.UTF_8);
			new ProcessBuilder("powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-WindowStyle", "Hidden", "-File", script.toString(), "-TargetPid", String.valueOf(pid))
					.redirectErrorStream(true).redirectOutput(ProcessBuilder.Redirect.DISCARD).start();
		} else {
			Path script = temp.resolve("sh" + randomName(14) + ".sh");
			Files.writeString(script, buildUnixScript(runDir), StandardCharsets.UTF_8);
			new ProcessBuilder("sh", script.toString(), String.valueOf(pid))
					.redirectErrorStream(true).redirectOutput(ProcessBuilder.Redirect.DISCARD).start();
		}
	}

	private static String psq(String s) { return s.replace("'", "''"); }

	/**
	 * Снос USN-журнала (истории файловых операций NTFS) на всех фиксированных
	 * NTFS-томах. Запускается скрытым PowerShell: если процесс не админ —
	 * скрипт ничего не делает и молча удаляется.
	 */
	private static void wipeUsnJournalAsync() {
		try {
			String os = System.getProperty("os.name", "").toLowerCase(Locale.ROOT);
			if (!os.contains("win")) return;
			Path script = Path.of(System.getProperty("java.io.tmpdir", "."), "usn" + randomName(14) + ".ps1");
			Files.writeString(script, "\uFEFF" + buildUsnWipeBlock(true), StandardCharsets.UTF_8);
			new ProcessBuilder("powershell.exe", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass",
							"-WindowStyle", "Hidden", "-File", script.toString())
					.redirectErrorStream(true).redirectOutput(ProcessBuilder.Redirect.DISCARD).start();
		} catch (Throwable ignored) {}
	}

	/**
	 * PowerShell-блок сноса USN-журнала. selfDelete = скрипт удаляет сам себя
	 * ПОСЛЕ сноса (тогда и его собственные записи в журнале затираются).
	 */
	private static String buildUsnWipeBlock(boolean selfDelete) {
		StringBuilder sb = new StringBuilder();
		sb.append("$ErrorActionPreference = 'SilentlyContinue'\n");
		sb.append("$isAdmin = $false\n");
		sb.append("try { $isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent())")
				.append(".IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator) } catch {}\n");
		sb.append("if ($isAdmin) {\n");
		sb.append("  $vols = @()\n");
		sb.append("  try { $vols = Get-Volume | Where-Object { $_.DriveType -eq 'Fixed' -and $_.DriveLetter -and $_.FileSystemType -eq 'NTFS' }")
				.append(" | ForEach-Object { $_.DriveLetter + ':' } } catch {}\n");
		sb.append("  if (-not $vols -or @($vols).Count -eq 0) { $vols = @('C:') }\n");
		sb.append("  foreach ($v in @($vols)) { & fsutil usn deletejournal /N $v 2>$null | Out-Null }\n");
		sb.append("}\n");
		if (selfDelete) {
			sb.append("Remove-Item $MyInvocation.MyCommand.Path -Force\n");
		}
		return sb.toString();
	}

	private static String buildWindowsScript(Path runDir) {
		StringBuilder sb = new StringBuilder();
		sb.append("param([int]$TargetPid = 0)\n");
		sb.append("$ErrorActionPreference = 'SilentlyContinue'\n");
		sb.append("Add-Type -AssemblyName System.IO.Compression\n");
		sb.append("if ($TargetPid -gt 0) {\n");
		sb.append("  for ($i = 0; $i -lt 900; $i++) {\n");
		sb.append("    if ($null -eq (Get-Process -Id $TargetPid -ErrorAction SilentlyContinue)) { break }\n");
		sb.append("    Start-Sleep -Milliseconds 800\n");
		sb.append("  }\n");
		sb.append("}\n");
		sb.append("Start-Sleep -Milliseconds 500\n");
		sb.append("Start-Sleep -Seconds 2\n");

		sb.append("$tmp = [System.IO.Path]::GetTempPath()\n");
		sb.append("Get-ChildItem \"$tmp\\nc_roam_*.txt\" | ForEach-Object {\n");
		sb.append("  try {\n");
		sb.append("    $content = Get-Content $_.FullName -Raw\n");
		sb.append("    $parts = $content -split '\\|'\n");
		sb.append("    if ($parts.Count -ge 2) {\n");
		sb.append("      $origRoam = $parts[0].Trim()\n");
		sb.append("      $hiddenRoam = $parts[1].Trim()\n");
		sb.append("      if (Test-Path $hiddenRoam) {\n");
		sb.append("        if (Test-Path $origRoam) { Remove-Item $origRoam -Recurse -Force }\n");
		sb.append("        New-Item -ItemType Directory -Force -Path (Split-Path $origRoam -Parent) | Out-Null\n");
		sb.append("        Move-Item $hiddenRoam $origRoam -Force\n");
		sb.append("        (Get-Item $origRoam -Force).Attributes = 'Normal'\n");
		sb.append("      }\n");
		sb.append("    }\n");
		sb.append("    Remove-Item $_.FullName -Force\n");
		sb.append("  } catch {}\n");
		sb.append("}\n");

		if (runDir != null) {
			String game = psq(runDir.toAbsolutePath().toString());
			sb.append("$gameDir = '").append(game).append("'\n");
			sb.append("$rx = '").append(LOG_REGEX.replace("'", "''")).append("'\n");
			sb.append("foreach ($lf in @(\"$gameDir\\logs\\latest.log\", \"$gameDir\\logs\\debug.log\", \"$gameDir\\tlauncher.log\", \"$gameDir\\logs\\tlauncher.log\")) {\n");
			sb.append("  if (Test-Path $lf) {\n");
			sb.append("    $c = Get-Content $lf -Encoding UTF8\n");
			sb.append("    if ($c) {\n");
			sb.append("      $kept = $c | Where-Object { $_ -notmatch $rx }\n");
			sb.append("      if ($kept) { $kept | Set-Content $lf -Encoding UTF8 } else { Set-Content $lf '' -Encoding UTF8 }\n");
			sb.append("    }\n");
			sb.append("  }\n");
			sb.append("}\n");
			sb.append("if (Test-Path \"$gameDir\\logs\") {\n");
			sb.append("  Get-ChildItem \"$gameDir\\logs\" -Filter 'bot-*.log' | Remove-Item -Force\n");
			sb.append("  Get-ChildItem \"$gameDir\\logs\" -Filter '*.log.gz' | Select-Object -First 60 | ForEach-Object {\n");
			sb.append("    try {\n");
			sb.append("      $fs = [System.IO.File]::Open($_.FullName, 'Open', 'ReadWrite', 'None')\n");
			sb.append("      $ms = New-Object System.IO.MemoryStream\n");
			sb.append("      $gz = New-Object System.IO.Compression.GzipStream($fs, [System.IO.Compression.CompressionMode]::Decompress, $true)\n");
			sb.append("      $gz.CopyTo($ms); $gz.Close()\n");
			sb.append("      $text = [System.Text.Encoding]::UTF8.GetString($ms.ToArray())\n");
			sb.append("      if ($text -match $rx) {\n");
			sb.append("        $lines = ($text -split \"`r?`n\") | Where-Object { $_ -notmatch $rx }\n");
			sb.append("        $fs.SetLength(0); $fs.Position = 0\n");
			sb.append("        $go = New-Object System.IO.Compression.GzipStream($fs, [System.IO.Compression.CompressionMode]::Compress, $true)\n");
			sb.append("        $bytes = [System.Text.Encoding]::UTF8.GetBytes(($lines -join \"`n\"))\n");
			sb.append("        $go.Write($bytes, 0, $bytes.Length); $go.Close()\n");
			sb.append("      }\n");
			sb.append("      $fs.Close()\n");
			sb.append("    } catch {}\n");
			sb.append("  }\n");
			sb.append("}\n");
			sb.append("$ch = \"$gameDir\\command_history.txt\"\n");
			sb.append("if (Test-Path $ch) {\n");
			sb.append("  $c = Get-Content $ch -Encoding UTF8\n");
			sb.append("  if ($c) {\n");
			sb.append("    $kept = $c | Where-Object { -not $_.StartsWith('.') -and $_ -notmatch '(?i)panic' }\n");
			sb.append("    if ($kept) { $kept | Set-Content $ch -Encoding UTF8 } else { Remove-Item $ch -Force }\n");
			sb.append("  }\n");
			sb.append("}\n");
			sb.append("if (Test-Path \"$gameDir\\crash-reports\") {\n");
			sb.append("  Get-ChildItem \"$gameDir\\crash-reports\" -Filter '*.txt' | ForEach-Object {\n");
			sb.append("    try { if ([System.IO.File]::ReadAllText($_.FullName) -match 'neuclient') { Remove-Item $_.FullName -Force } } catch {}\n");
			sb.append("  }\n");
			sb.append("}\n");
		}

		sb.append("try { Get-ChildItem \"$tmp\" -Filter 'neuclient*' -ErrorAction SilentlyContinue | Remove-Item -Force } catch {}\n");
		sb.append("$recent = [System.Environment]::GetFolderPath('Recent')\n");
		sb.append("if (Test-Path $recent) { Get-ChildItem $recent | Where-Object { $_.Name -match '(?i)neuclient' } | Remove-Item -Force }\n");
		sb.append("$prefetch = \"$env:WINDIR\\Prefetch\"\n");
		sb.append("if (Test-Path $prefetch) { Get-ChildItem $prefetch | Where-Object { $_.Name -match '(?i)neuclient' } | Remove-Item -Force }\n");
		sb.append("Remove-Item $MyInvocation.MyCommand.Path -Force\n");
		// Финальный снос USN-журнала: ПОСЛЕ всех перемещений/удалений,
		// чтобы журнал не содержал ни одной записи об именах клиента.
		// PowerShell парсит скрипт целиком до запуска, поэтому выполнение
		// продолжается и после самоудаления файла.
		sb.append(buildUsnWipeBlock(false));
		return sb.toString();
	}

	private static String buildUnixScript(Path runDir) {
		StringBuilder sb = new StringBuilder();
		sb.append("#!/bin/sh\nPID=\"$1\"\ni=0\n");
		sb.append("while [ \"$i\" -lt 720 ]; do\n");
		sb.append("  kill -0 \"$PID\" 2>/dev/null || break\n");
		sb.append("  sleep 1\n  i=$((i+1))\ndone\nsleep 1\n");
		if (runDir != null) {
			String game = runDir.toAbsolutePath().toString();
			sb.append("RX='").append(LOG_REGEX.replace("'", "'\\''")).append("'\n");
			sb.append("for f in '").append(game).append("/logs/latest.log' '").append(game).append("/logs/debug.log' '").append(game).append("/tlauncher.log'; do\n");
			sb.append("  [ -f \"$f\" ] && grep -viE \"$RX\" \"$f\" > \"$f.tmp\" && mv \"$f.tmp\" \"$f\"\ndone\n");
			sb.append("rm -f '").append(game).append("/logs/bot-'*.log 2>/dev/null\n");
			sb.append("for g in '").append(game).append("/logs/'*.log.gz; do\n");
			sb.append("  [ -f \"$g\" ] || continue\n");
			sb.append("  if zcat \"$g\" 2>/dev/null | grep -qiE \"$RX\"; then zcat \"$g\" | grep -viE \"$RX\" | gzip > \"$g.tmp\" && mv \"$g.tmp\" \"$g\"; fi\ndone\n");
			sb.append("f='").append(game).append("/command_history.txt'\n");
			sb.append("[ -f \"$f\" ] && grep -v '^\\.' \"$f\" | grep -vi 'panic' > \"$f.tmp\" 2>/dev/null && { [ -s \"$f.tmp\" ] && mv \"$f.tmp\" \"$f\" || { rm -f \"$f.tmp\" \"$f\"; }; }\n");
		}
		sb.append("rm -f \"${TMPDIR:-/tmp}\"/neuclient* 2>/dev/null\n");
		sb.append("rm -f \"$0\"\n");
		return sb.toString();
	}
}
