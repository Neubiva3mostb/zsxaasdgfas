package ru.neuclient.client.mixin;

import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.impl.movement.NoPushModule;
import ru.neuclient.client.module.impl.movement.NoWebModule;

/**
 * Два хука по физике Entity:
 *
 *  • pushAwayFrom — ванильный взаимный толчок сущностей (addVelocity ±0.05).
 *    NoPush («Игроки») отменяет вызов, если одна из сторон — наш игрок.
 *
 *  • slowMovement — единственное место, где выставляется movementMultiplier;
 *    паутина зовёт его с вектором (0.25, 0.05, 0.25). NoWeb либо отменяет
 *    вызов целиком (режим «Отмена»), либо подменяет вектор на ослабленный
 *    (режим «Смягчение»).
 */
@Mixin(Entity.class)
public abstract class EntityPushMixin {

	@Inject(method = "pushAwayFrom", at = @At("HEAD"), cancellable = true)
	private void pc$noPush(Entity other, CallbackInfo ci) {
		try {
			NoPushModule noPush = NeuClient.getInstance().getModuleManager().get(NoPushModule.class);
			if (noPush != null && noPush.isEnabled()
					&& noPush.shouldCancelEntityPush((Entity) (Object) this, other)) {
				ci.cancel();
			}
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка NoPush", t);
		}
	}

	@Inject(method = "slowMovement", at = @At("HEAD"), cancellable = true)
	private void pc$noWebCancel(BlockState state, Vec3d multiplier, CallbackInfo ci) {
		try {
			Entity self = (Entity) (Object) this;
			if (self != net.minecraft.client.MinecraftClient.getInstance().player) {
				return; // чужие сущности пусть вязнут в паутине как обычно
			}
			NoWebModule noWeb = NeuClient.getInstance().getModuleManager().get(NoWebModule.class);
			if (noWeb != null && noWeb.isEnabled() && noWeb.shouldCancelSlowdown(state)) {
				ci.cancel(); // паутины для физики как будто нет
			}
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка NoWeb", t);
		}
	}

	/**
	 * NoWeb, режим «Смягчение»: ослабляем сам вектор замедления.
	 *
	 * РАНЬШЕ ЗДЕСЬ БЫЛА РЕКУРСИЯ. Старый код отменял вызов через ci.cancel()
	 * и тут же звал self.slowMovement(state, softened) заново — а этот
	 * повторный вызов снова попадал в наш же @Inject. Получался бесконечный
	 * цикл на каждом тике в паутине: отсюда «очень сильно лагает».
	 *
	 * Теперь просто подменяем аргумент — ваниль выполняется ровно один раз.
	 */
	@ModifyVariable(method = "slowMovement", at = @At("HEAD"), argsOnly = true, index = 2)
	private Vec3d pc$noWebSoften(Vec3d multiplier) {
		try {
			Entity self = (Entity) (Object) this;
			if (self != net.minecraft.client.MinecraftClient.getInstance().player) {
				return multiplier;
			}
			NoWebModule noWeb = NeuClient.getInstance().getModuleManager().get(NoWebModule.class);
			if (noWeb == null || !noWeb.isEnabled()) {
				return multiplier;
			}
			// state здесь недоступен, но softenMultiplier проверяет только
			// режим — а вызов slowMovement с таким вектором делает именно
			// паутина (0.25, 0.05, 0.25)
			Vec3d softened = noWeb.softenMultiplier(multiplier);
			return softened != null ? softened : multiplier;
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка NoWeb (смягчение)", t);
			return multiplier;
		}
	}
}
