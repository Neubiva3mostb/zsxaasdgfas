package ru.neuclient.client.bot;

import java.util.*;

/** Per child-process duplicate suppression and one-shot text rate limit. No replay on reconnect. */
public final class BotOrderGuard {
    private final LinkedHashSet<String> seen=new LinkedHashSet<>();
    private long lastText=Long.MIN_VALUE/2;
    public String accept(BotGroupOrder order,long now) {
        order.validate(now);
        if(!seen.add(order.id()))return "duplicate";
        while(seen.size()>128)seen.remove(seen.iterator().next());
        if(order.kind().equals("TEXT")) {
            if(now-lastText<2000)return "cooldown";
            lastText=now;
        }
        return "ok";
    }
}
