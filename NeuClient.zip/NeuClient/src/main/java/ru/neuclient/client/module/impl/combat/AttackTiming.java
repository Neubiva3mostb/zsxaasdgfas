package ru.neuclient.client.module.impl.combat;

/** Общие правила момента удара для AttackAura и TriggerBot. */
public final class AttackTiming {
    private AttackTiming() {}

    public static boolean allowsAttack(boolean onlyCrits, boolean adaptive, boolean onGround, boolean canCrit) {
        // Строгая настройка «только криты» имеет приоритет над адаптивной.
        return (!onlyCrits || canCrit) && (!adaptive || onGround || canCrit);
    }
}
