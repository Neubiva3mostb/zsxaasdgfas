package ru.neuclient.client.module.impl.render;

import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.TextSetting;

/**
 * NameProtect — подменяет твой настоящий ник на любой другой ТОЛЬКО на твоём
 * экране: в чате (сообщения, килл-фид, смерти, /msg), таб-листе и над головой
 * от третьего лица. На сервере ник остаётся прежним — маскируется только
 * твой рендер. Полезно для скринов и стримов.
 *
 * Настройка «Ник» — отображаемый текст (по умолчанию NeuClient).
 */
public class NameProtectModule extends Module {

	/** Отображаемый ник (вводится с клавиатуры в ClickGUI). */
	private final TextSetting name = new TextSetting("Ник", "NeuClient", 24);

	public NameProtectModule() {
		super("NameProtect", "Подменяет твой ник на экране",
				Category.RENDER);
		addSettings(name);
	}

	/** Отображаемый ник (пустое/пробелы — откат на дефолт). */
	public String getFakeName() {
		String v = name.get();
		return v == null || v.isBlank() ? name.getDefault() : v;
	}
}
