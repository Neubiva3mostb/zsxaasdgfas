package ru.neuclient.client.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import ru.neuclient.client.NeuClient;

/**
 * Отправка сервисных сообщений клиента в локальный чат
 * (сообщения видит только сам игрок, на сервер они не уходят).
 */
public final class ChatUtil {

	private ChatUtil() {
	}

	/** Получить префикс [NeuClient] с акцентным цветом интерфейса. */
	private static Text getPrefix() {
		int accent = RenderUtil.accent();
		// Извлекаем RGB компоненты
		int r = (accent >> 16) & 0xFF;
		int g = (accent >> 8) & 0xFF;
		int b = accent & 0xFF;
		int rgb = (r << 16) | (g << 8) | b;
		
		// Создаём текст с кастомным RGB цветом
		return Text.literal("[")
				.formatted(Formatting.GRAY)
				.append(Text.literal("NeuClient").styled(s -> s.withColor(rgb)))
				.append(Text.literal("]").formatted(Formatting.GRAY))
				.append(Text.literal(" "));
	}

	public static void send(String message) {
		MinecraftClient client = MinecraftClient.getInstance();
		if (client.player != null) {
			client.player.sendMessage(getPrefix().copy().append(Text.literal(message)), false);
		} else {
			// Игрока (мира) ещё нет — пишем в лог, чтобы ничего не потерять
			NeuClient.LOGGER.info("[NeuClient][chat] {}", message);
		}
	}

	public static void error(String message) {
		MinecraftClient client = MinecraftClient.getInstance();
		if (client.player != null) {
			client.player.sendMessage(getPrefix().copy().append(Text.literal(message).formatted(Formatting.RED)), false);
		} else {
			NeuClient.LOGGER.info("[NeuClient][chat] {}", message);
		}
	}
}
