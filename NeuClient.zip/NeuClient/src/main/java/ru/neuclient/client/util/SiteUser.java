package ru.neuclient.client.util;

/**
 * Аккаунт сайта, под которым лаунчер выдал доступ в игру.
 *
 * Лаунчер передаёт в окружении процесса игры NEU_USER (логин сайта) и
 * NEU_UID (NEU-XXXXXXXX, выданный сервером при привязке HWID). В напрямую
 * запущенном jar этих переменных нет — тогда возвращаем fallback.
 * Всенепременно: это отображение именно АККАУНТА САЙТА, оно не
 * переключается при входе под альтом (см. AltManager) — за игровой ник
 * отвечает сессия, за «In клиент вошёл Пользователь» — SiteUser.
 */
public final class SiteUser {

	private SiteUser() {}

	/** Логин аккаунта сайта или null, если клиент запущен мимо лаунчера. */
	public static String username() {
		String u = System.getenv("NEU_USER");
		if (u == null || u.isBlank()) {
			u = System.getProperty("neu.user"); // dev-режим: -Dneu.user=...
		}
		return (u != null && !u.isBlank()) ? u.trim() : null;
	}

	/** Отображаемое имя: логин сайта, иначе ник текущей сессии. */
	public static String displayName(String sessionFallback) {
		String u = username();
		return u != null ? u : (sessionFallback == null ? "Player" : sessionFallback);
	}

	/** UID аккаунта сайта (NEU-…), null если мимо лаунчера. */
	public static String uid() {
		String u = System.getenv("NEU_UID");
		if (u == null || u.isBlank()) {
			u = System.getProperty("neu.uid");
		}
		return (u != null && !u.isBlank()) ? u.trim() : null;
	}
}
