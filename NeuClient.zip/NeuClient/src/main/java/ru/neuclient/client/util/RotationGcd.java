package ru.neuclient.client.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.MathHelper;

/**
 * Квантование углов под «сетку мыши» (GCD-фикс).
 *
 * ЗАЧЕМ ЭТО НУЖНО.
 * Мышь отдаёт ЦЕЛОЕ число отсчётов, а игра умножает их на фиксированный
 * шаг, который зависит только от ползунка чувствительности. Поэтому у
 * живого игрока КАЖДАЯ дельта угла кратна этому шагу: остаток от деления
 * всегда ноль. Аура же считает угол через atan2 и получает произвольное
 * дробное значение — остаток случайный.
 *
 * Анти-читу достаточно поделить дельту на шаг и посмотреть на остаток,
 * это очень дешёвая и надёжная проверка (у разных анти-читов она зовётся
 * GCD-check, «Constant rotations», «Sensitivity/GCD flaw»). Ни один
 * «плавный» доворот от неё не спасает: дело не в скорости поворота, а в
 * том, что угол не лежит на сетке.
 *
 * ВАНИЛЬНАЯ МАТЕМАТИКА (проверена по байткоду 1.21.11).
 *   Mouse#updateMouse:
 *     d = sensitivity * 0.6 + 0.2
 *     f = d * d * d * 8.0
 *     deltaX = cursorDeltaX * f
 *   Entity#changeLookDirection:
 *     yaw   += (float) (deltaX * 0.15)
 *     pitch += (float) (deltaY * 0.15)
 *
 * Отсюда минимальный шаг поворота (один «тик» мыши):
 *     step = (sens * 0.6 + 0.2)^3 * 8.0 * 0.15
 * При стандартной чувствительности 100 % (значение 0.5) step = 0.15°,
 * что совпадает с общеизвестным фактом про ваниль.
 *
 * КАК ПОЛЬЗОВАТЬСЯ.
 * Квантовать надо именно ДЕЛЬТУ (насколько повернулись), а не абсолютный
 * угол: сетка отсчитывается от предыдущего значения. Остаток от деления
 * копится между тиками ({@link Accumulator}), иначе при мелких шагах
 * поворот systematically недоворачивался бы до цели.
 */
public final class RotationGcd {

	private RotationGcd() {
	}

	/** Значение чувствительности, если игра ещё не готова. */
	private static final double FALLBACK_SENSITIVITY = 0.5;

	/**
	 * Шаг сетки поворота в градусах для текущей чувствительности.
	 * Всегда строго больше нуля.
	 */
	public static float step() {
		double sens = FALLBACK_SENSITIVITY;
		try {
			MinecraftClient mc = MinecraftClient.getInstance();
			if (mc != null && mc.options != null) {
				sens = mc.options.getMouseSensitivity().getValue();
			}
		} catch (Throwable ignored) {
			// Настройки недоступны — считаем по стандартной чувствительности
		}
		double d = sens * 0.6 + 0.2;
		double stepValue = d * d * d * 8.0 * 0.15;
		// При сенсе 0 % шаг вырождается в ~0.0038°, но нулём стать не может.
		// Защита на случай странных значений из модов на настройки.
		if (!(stepValue > 1.0E-6)) {
			return 1.0E-6f;
		}
		return (float) stepValue;
	}

	/**
	 * Округлить дельту угла до ближайшего узла сетки.
	 *
	 * @param delta желаемое изменение угла в градусах
	 * @param step  шаг сетки (см. {@link #step()})
	 * @return дельта, кратная шагу
	 */
	public static float quantize(float delta, float step) {
		return Math.round(delta / step) * step;
	}

	/**
	 * Накопитель остатка для одной оси.
	 *
	 * Если просто округлять каждую дельту, мелкие довороты (меньше
	 * половины шага) превращались бы в ноль и прицел не доходил бы до
	 * цели. Поэтому «потерянная» часть запоминается и добавляется к
	 * следующему запросу — ровно так же, как ведёт себя настоящая мышь
	 * с её субпиксельным накоплением.
	 */
	public static final class Accumulator {

		private float remainder;

		/** Сбросить накопленный остаток (смена цели, включение модуля). */
		public void reset() {
			remainder = 0.0f;
		}

		/**
		 * Квантовать дельту с учётом накопленного остатка.
		 *
		 * @param delta желаемое изменение угла
		 * @param step  шаг сетки
		 * @return изменение, кратное шагу (может быть 0, тогда остаток копится)
		 */
		public float apply(float delta, float step) {
			float wanted = delta + remainder;
			float snapped = quantize(wanted, step);
			remainder = wanted - snapped;
			// Страховка от разгона остатка при резкой смене шага
			// (игрок подвинул ползунок чувствительности прямо в бою).
			float cap = step * 4.0f;
			remainder = MathHelper.clamp(remainder, -cap, cap);
			return snapped;
		}
	}
}
