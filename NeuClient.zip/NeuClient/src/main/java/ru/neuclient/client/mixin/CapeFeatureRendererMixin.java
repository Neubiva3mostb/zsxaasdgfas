package ru.neuclient.client.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.feature.CapeFeatureRenderer;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.neuclient.client.module.impl.render.CapeModule;

/** Заменяет только локальный vanilla-cape на компактный HD-рендер. */
@Mixin(CapeFeatureRenderer.class)
public abstract class CapeFeatureRendererMixin {

	@Inject(method = "render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;ILnet/minecraft/client/render/entity/state/PlayerEntityRenderState;FF)V",
			at = @At("HEAD"), cancellable = true)
	private void pc$renderHdCape(MatrixStack matrices, OrderedRenderCommandQueue queue,
			int light, PlayerEntityRenderState state, float limbAngle, float limbDistance,
			CallbackInfo ci) {
		// Элитры важнее плаща: при надетой элитре (и в полёте на ней) HD-плащ
		// не рисуем вовсе — остаются чистые элитры. Без этого плащ висел
		// поверх/сквозь элитру. capeVisible — ванильный флаг «плащ виден».
		if (!state.capeVisible || state.isGliding
				|| state.equippedChestStack.isOf(net.minecraft.item.Items.ELYTRA)) {
			return;
		}
		MinecraftClient client = MinecraftClient.getInstance();
		CapeModule cape = CapeModule.active();
		if (cape == null || client == null || client.player == null
				|| state.id != client.player.getId()) {
			return;
		}
		CapeModule.renderHd(matrices, queue, light, state);
		ci.cancel();
	}
}
