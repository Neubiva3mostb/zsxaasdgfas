package ru.neuclient.client.module.impl.movement;

import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.GameMode;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.BooleanSetting;
import ru.neuclient.client.setting.ModeSetting;
import ru.neuclient.client.setting.NumberSetting;
import ru.neuclient.client.util.RotationSpoof;

/**
 * Wall Climb — подъём вдоль стены, два независимых режима.
 *
 * Режим «Обычный» работает как прежний spider-climb.
 *
 * Режим «Блоки» — ванильная последовательность подъёма по стене:
 *  1. выбирается блок в хотбаре и серверу сразу отправляется слот;
 *  2. прыжок запрашивается через PlayerInput, поэтому ваниль сама
 *     отправляет серверу правильную последовательность движения;
 *  3. перед установкой на один тик для сущности включается серверный
 *     yaw/pitch-spуф. Ваниль отправляет обычный пакет движения с этим
 *     углом, затем выполняется interactBlock, после чего серверу
 *     отправляется возврат к реальному углу;
 *  4. локальная камера не изменяется. В F5 PlayerBodyRendererMixin
 *     отображает тот же угол, который использовался для установки.
 *
 * Важно: сам блок ставится из AuraTickSpoofMixin после того, как ваниль
 * уже отправила пакет движения со спуфнутым углом. Поэтому порядок на
 * сервере получается «прыжок → движение/поворот → установка → возврат
 * обзора», а не «установка до пакета движения».
 */
public final class WallClimbModule extends Module {

	private final ModeSetting mode = new ModeSetting("Режим", "Обычный",
			"Обычный", "Блоки");
	private final NumberSetting climbSpeed = new NumberSetting("Скорость подъёма", 0.22, 0.05, 0.6, 0.01);
	private final BooleanSetting requireForward = new BooleanSetting("Только с W", true);

	/** Слот, выбранный до того, как модуль взял блок (-1 = не меняли). */
	private int previousSlot = -1;
	/** Пауза между постановками, в тиках. */
	private int placeCooldown = 0;

	/** Следующий прыжок будет добавлен в PlayerInput ближайшего тика. */
	private boolean forceJumpRequested;
	/** Блок, на котором игрок стоял перед текущим прыжком. */
	private BlockPos launchBlock;

	/** Ожидание тика, на котором ваниль отправит серверный спуф-угол. */
	private boolean rotationPending;
	/** Ожидание установки после отправки серверного спуф-угла. */
	private boolean placementPending;
	private BlockPos pendingTarget;
	private BlockHitResult pendingHit;

	/** Последний угол, рассчитанный на нужную грань блока. */
	private float spoofYaw;
	private float spoofPitch;
	/** Отдельное состояние для F5: держим отображение до ухода от стены. */
	private boolean visualSpoofing;

	public WallClimbModule() {
		super("Wall Climb", "Ползаешь по стене как паучек", Category.MOVEMENT);
		addSettings(mode, climbSpeed, requireForward);
	}

	@Override
	protected void onDisable() {
		clearTowerState();
		placeCooldown = 0;
		restoreSlot();
	}

	@Override
	public void onTick(MinecraftClient client) {
		ClientPlayerEntity player = client.player;
		if (player == null || client.world == null || client.interactionManager == null) {
			clearTowerState();
			restoreSlot();
			return;
		}
		if (player.hasVehicle() || player.isTouchingWater() || player.isClimbing()) {
			clearTowerState();
			return;
		}
		if (requireForward.get() && !client.options.forwardKey.isPressed()) {
			clearTowerState();
			restoreSlot();
			return;
		}

		if (isBlockMode()) {
			tickTower(client, player);
		} else {
			clearTowerState();
			tickSpider(player);
		}
	}

	// ===== Режим 1: ползём по стене =====

	private void tickSpider(ClientPlayerEntity player) {
		// Упираемся в стену и реально идём вперёд — лезем вверх
		if (player.horizontalCollision && isMoving(player)) {
			Vec3d velocity = player.getVelocity();
			player.setVelocity(velocity.x, climbSpeed.get(), velocity.z);
			player.fallDistance = 0.0;
		}
	}

	// ===== Режим 2: башня с блоками под себя =====

	private void tickTower(MinecraftClient client, ClientPlayerEntity player) {
		if (placeCooldown > 0) {
			placeCooldown--;
			return;
		}
		// В наблюдателе смысла нет
		if (client.interactionManager.getCurrentGameMode() == GameMode.SPECTATOR) {
			clearTowerState();
			restoreSlot();
			return;
		}
		// Работаем, только когда реально толкаемся в стену
		if (!player.horizontalCollision || !isMoving(player)) {
			clearTowerState();
			restoreSlot();
			return;
		}

		int blockSlot = findBlockInHotbar(player);
		if (blockSlot < 0) {
			clearTowerState();
			return; // блоков в хотбаре нет
		}
		selectSlot(client, player, blockSlot);

		BlockPos below = player.getBlockPos().down();
		boolean needBlock = client.world.getBlockState(below).isReplaceable();

		if (!needBlock) {
			// Опора под ногами есть — запоминаем именно этот блок. После
			// прыжка новый блок должен ставиться НА ЕГО ВЕРХНЮЮ ГРАНЬ,
			// а не на случайный соседний блок стены.
			// Не вызываем player.jump(): прыжок будет добавлен через
			// PlayerInput, чтобы сервер получил его обычным пакетом.
			if (player.isOnGround()) {
				launchBlock = below;
				forceJumpRequested = true;
			}
			return;
		}

		// Сначала пробуем блок, на котором игрок стоял до прыжка.
		// Если модуль включили уже в воздухе, используем ближайшую
		// валидную грань как запасной вариант.
		BlockHitResult hit = findLaunchSupport(client, below);
		if (hit == null) {
			hit = findSupport(client, below);
		}
		if (hit == null) {
			clearTowerState();
			return; // не к чему прислониться
		}

		// Ставим блок после вершины прыжка: к этому моменту сервер уже
		// получил jump-пакет предыдущего движения.
		Vec3d velocity = player.getVelocity();
		if (velocity.y > 0.1) {
			return; // ещё летим вверх, рано
		}

		queuePlacement(player, below, hit);
	}

	/** Подготовить установку на следующий PlayerEntity#tick. */
	private void queuePlacement(ClientPlayerEntity player, BlockPos target, BlockHitResult hit) {
		pendingTarget = target;
		pendingHit = hit;

		// Целимся именно в нужную грань, а не просто разворачиваемся на 180°.
		// Так yaw и pitch соответствуют фактической BlockHitResult.
		float[] rotation = rotationTo(player.getEyePos(), hit.getPos());
		spoofYaw = rotation[0];
		spoofPitch = rotation[1];

		rotationPending = true;
		placementPending = true;
		visualSpoofing = true;
	}

	/**
	 * Вызывается из AuraTickSpoofMixin в конце ClientPlayerEntity#tick,
	 * после того как ваниль отправила пакет движения со спуфнутым углом.
	 */
	public void performPendingPlacement(MinecraftClient client, ClientPlayerEntity player) {
		if (!placementPending) {
			return;
		}

		BlockPos target = pendingTarget;
		BlockHitResult hit = pendingHit;
		placementPending = false;
		rotationPending = false;
		pendingTarget = null;
		pendingHit = null;
		launchBlock = null;

		// Пока тик дошёл до установки, мир мог измениться. В таком случае
		// пропускаем interactBlock, но всё равно обязательно возвращаем
		// серверу настоящий обзор ниже.
		if (target != null && hit != null && client.world != null
				&& client.interactionManager != null
				&& client.world.getBlockState(target).isReplaceable()) {
			ActionResult result = client.interactionManager.interactBlock(player, Hand.MAIN_HAND, hit);
			if (result.isAccepted()) {
				player.swingHand(Hand.MAIN_HAND);
			}
		}

		// Возвращаем серверу настоящий обзор отдельным обычным пакетом.
		// RotationSpoof.realYaw/realPitch достают значения, сохранённые
		// миксином до временной подмены сущности.
		float realYaw = RotationSpoof.realYaw(player.getYaw());
		float realPitch = RotationSpoof.realPitch(player.getPitch());
		player.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(
				realYaw, realPitch, player.isOnGround(), player.horizontalCollision));
		RotationSpoof.markSent(realYaw, realPitch);

		placeCooldown = 2;
	}

	/** true, если WallClimb сейчас должен наложить угол на сущность на тик. */
	public boolean shouldApplySpoof() {
		return isEnabled() && isBlockMode() && (rotationPending || placementPending);
	}

	/** true, если F5 должен показывать последний рассчитанный угол. */
	public boolean isSpoofingForRender() {
		return isEnabled() && isBlockMode() && visualSpoofing;
	}

	public float getSpoofYaw() {
		return spoofYaw;
	}

	public float getSpoofPitch() {
		return spoofPitch;
	}

	/**
	 * Сохранить мировое направление движения на коротком тике установки.
	 * Пока сущность временно смотрит на грань блока, ваниль рассчитывает
	 * движение от spoofYaw. Возвращаем булевы направления относительно
	 * реального yaw, чтобы сервер не получил неожиданный боковой сдвиг.
	 */
	public float[] correctMovement(float forward, float strafe) {
		if (!shouldApplySpoof() || (forward == 0.0f && strafe == 0.0f)) {
			return new float[]{forward, strafe};
		}
		ClientPlayerEntity player = mc.player;
		if (player == null) {
			return new float[]{forward, strafe};
		}

		float trueYaw = RotationSpoof.realYaw(player.getYaw());
		float delta = MathHelper.wrapDegrees(spoofYaw - trueYaw);
		float localAngle = (float) Math.toDegrees(Math.atan2(-strafe, forward));
		float snapped = Math.round((localAngle - delta) / 45.0f) * 45.0f;
		float fixedForward = Math.round((float) Math.cos(Math.toRadians(snapped)));
		float fixedStrafe = -Math.round((float) Math.sin(Math.toRadians(snapped)));
		return new float[]{fixedForward, fixedStrafe};
	}

	public boolean isBlockMode() {
		return "Блоки".equals(mode.get());
	}

	/** Активный экземпляр для миксинов. */
	public static WallClimbModule active() {
		NeuClient client = NeuClient.getInstance();
		if (client == null || client.getModuleManager() == null) {
			return null;
		}
		WallClimbModule module = client.getModuleManager().get(WallClimbModule.class);
		return module != null && module.isEnabled() ? module : null;
	}

	/**
	 * Передать KeyboardInputMixin право добавить jump=true ровно на один
	 * тик. Прыжок остаётся ванильным: после этого PlayerEntity сам обновит
	 * скорость, а сервер увидит jump в обычном пакете движения.
	 */
	public boolean consumeForcedJump() {
		if (!isEnabled() || !isBlockMode() || !forceJumpRequested) {
			return false;
		}
		forceJumpRequested = false;
		return true;
	}

	private void clearTowerState() {
		forceJumpRequested = false;
		launchBlock = null;
		rotationPending = false;
		placementPending = false;
		pendingTarget = null;
		pendingHit = null;
		visualSpoofing = false;
	}

	/**
	 * Возвращает верхнюю грань блока, на котором игрок стоял перед
	 * прыжком. Именно к ней должен быть привязан следующий блок.
	 */
	private BlockHitResult findLaunchSupport(MinecraftClient client, BlockPos target) {
		if (launchBlock == null || !target.equals(launchBlock.up())) {
			return null;
		}
		BlockState state = client.world.getBlockState(launchBlock);
		if (state.isAir() || state.isReplaceable()) {
			return null;
		}
		Vec3d pos = new Vec3d(
				launchBlock.getX() + 0.5,
				launchBlock.getY() + 1.0,
				launchBlock.getZ() + 0.5);
		return new BlockHitResult(pos, Direction.UP, launchBlock, false);
	}

	/**
	 * Ищет, к какой грани уже существующего блока прислонить новый.
	 * Проверяем шесть соседей целевой позиции: нужен твёрдый блок, к грани
	 * которого ванилла разрешит поставить наш.
	 */
	private BlockHitResult findSupport(MinecraftClient client, BlockPos target) {
		for (Direction dir : Direction.values()) {
			BlockPos neighbor = target.offset(dir);
			BlockState state = client.world.getBlockState(neighbor);
			if (state.isAir() || state.isReplaceable()) {
				continue;
			}
			Direction side = dir.getOpposite();
			Vec3d center = Vec3d.ofCenter(neighbor).add(
					side.getOffsetX() * 0.5,
					side.getOffsetY() * 0.5,
					side.getOffsetZ() * 0.5);
			return new BlockHitResult(center, side, neighbor, false);
		}
		return null;
	}

	/** Первый слот хотбара с блоком, -1 если блоков нет. */
	private int findBlockInHotbar(ClientPlayerEntity player) {
		for (int i = 0; i < 9; i++) {
			ItemStack stack = player.getInventory().getStack(i);
			if (!stack.isEmpty() && stack.getItem() instanceof BlockItem) {
				return i;
			}
		}
		return -1;
	}

	/**
	 * Переключение слота с запоминанием исходного.
	 * InventoryUtil.selectSlot сразу шлёт серверу выбранный слот.
	 */
	private void selectSlot(MinecraftClient client, ClientPlayerEntity player, int slot) {
		int current = player.getInventory().getSelectedSlot();
		if (current == slot) {
			return;
		}
		if (previousSlot < 0) {
			previousSlot = current;
		}
		ru.neuclient.client.util.InventoryUtil.selectSlot(player, slot, client.interactionManager, false);
	}

	/** Возврат к слоту, который был выбран до работы модуля. */
	private void restoreSlot() {
		if (previousSlot < 0) {
			return;
		}
		ClientPlayerEntity player = mc.player;
		if (player != null && mc.interactionManager != null) {
			ru.neuclient.client.util.InventoryUtil.selectSlot(player, previousSlot, mc.interactionManager, false);
		}
		previousSlot = -1;
	}

	/** Рассчитать yaw/pitch от глаз игрока к конкретной точке блока. */
	private static float[] rotationTo(Vec3d eye, Vec3d point) {
		double dx = point.x - eye.x;
		double dy = point.y - eye.y;
		double dz = point.z - eye.z;
		float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0f;
		float pitch = (float) -Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz)));
		return new float[]{yaw, MathHelper.clamp(pitch, -90.0f, 90.0f)};
	}

	private boolean isMoving(ClientPlayerEntity player) {
		if (player.input == null) {
			return false;
		}
		Vec2f mv = player.input.getMovementInput();
		return mv.x != 0.0f || mv.y != 0.0f;
	}
}
