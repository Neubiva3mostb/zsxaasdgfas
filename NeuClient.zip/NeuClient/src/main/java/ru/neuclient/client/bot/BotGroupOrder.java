package ru.neuclient.client.bot;

import com.google.gson.*;
import java.util.Locale;
import java.util.UUID;

/** Versioned, one-line IPC. Explicit JSON keys remain stable after obfuscation. */
public record BotGroupOrder(String id, String kind, String server, String dimension,
                            double x, double y, double z, String text, long createdAt) {
    public static final String PREFIX="GROUP_ORDER:";
    public static final int VERSION=3;
    public static final long MAX_AGE_MS=10000;
    public static String normalizeServer(String server) {
        String s=server==null ? "":server.trim().toLowerCase(Locale.ROOT);
        if(s.endsWith(":25565"))s=s.substring(0,s.length()-6);
        return s;
    }
    public static String validateText(String raw) {
        if(raw==null || raw.length()>256 || raw.codePoints().anyMatch(c -> Character.isISOControl(c) || c==0xA7 || c==0x2028 || c==0x2029))
            throw new IllegalArgumentException("Одна строка, до 256 символов, без управляющих символов");
        String text=raw.trim();
        if(text.isEmpty() || text.equals("/"))throw new IllegalArgumentException("Введите команду /… или сообщение");
        if(text.startsWith("."))throw new IllegalArgumentException("Команды клиента с точкой здесь не выполняются");
        return text;
    }
    public void validate(long now) {
        if(id==null || id.length()!=36 || !UUID.fromString(id).toString().equalsIgnoreCase(id))throw new IllegalArgumentException("ID приказа");
        if(!java.util.Set.of("GO","FOLLOW","TEXT","STOP","HIT").contains(kind))throw new IllegalArgumentException("Тип приказа");
        if(!kind.equals("STOP") && (createdAt < now-MAX_AGE_MS || createdAt > now+2000))throw new IllegalArgumentException("Приказ устарел");
        if(server==null || server.isBlank() || server.length()>256 || server.chars().anyMatch(Character::isISOControl))throw new IllegalArgumentException("Адрес сервера");
        if(kind.equals("HIT")) {
            if(now-createdAt>2000)throw new IllegalArgumentException("Удар устарел");
            try { if(!UUID.fromString(text).toString().equalsIgnoreCase(text))throw new IllegalArgumentException("Цель"); }
            catch(Exception e) { throw new IllegalArgumentException("Цель", e); }
        }
        if(kind.equals("GO") || kind.equals("FOLLOW") || kind.equals("HIT")) {
            if(dimension==null || !dimension.matches("[a-z0-9_.-]+:[a-z0-9_/.-]+") || dimension.length()>128)throw new IllegalArgumentException("Измерение");
            if(!Double.isFinite(x) || !Double.isFinite(y) || !Double.isFinite(z) || Math.abs(x)>30000000 || Math.abs(z)>30000000 || Math.abs(y)>4096)
                throw new IllegalArgumentException("Координаты");
        }
        if(kind.equals("TEXT"))validateText(text);
    }
    public String encode() {
        JsonObject o=new JsonObject();o.addProperty("version",VERSION);o.addProperty("id",id);o.addProperty("kind",kind);
        o.addProperty("server",server);o.addProperty("dimension",dimension);o.addProperty("x",x);o.addProperty("y",y);o.addProperty("z",z);
        o.addProperty("text",text);o.addProperty("createdAt",createdAt);return PREFIX+o;
    }
    public static BotGroupOrder decode(String line,long now) {
        if(line==null || line.length()>4096 || !line.startsWith(PREFIX))throw new IllegalArgumentException("Формат IPC");
        JsonObject o=JsonParser.parseString(line.substring(PREFIX.length())).getAsJsonObject();
        if(o.get("version").getAsInt()!=VERSION)throw new IllegalArgumentException("Версия IPC");
        BotGroupOrder result=new BotGroupOrder(o.get("id").getAsString(),o.get("kind").getAsString(),o.get("server").getAsString(),
                o.get("dimension").getAsString(),o.get("x").getAsDouble(),o.get("y").getAsDouble(),o.get("z").getAsDouble(),
                o.get("text").getAsString(),o.get("createdAt").getAsLong());
        result.validate(now);return result;
    }
}
