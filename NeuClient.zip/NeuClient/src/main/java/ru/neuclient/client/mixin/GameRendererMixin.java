package ru.neuclient.client.mixin;

import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.impl.render.AspectRatioModule;
import ru.neuclient.client.module.impl.render.NoRenderModule;
import ru.neuclient.client.module.impl.render.ZoomModule;

/**
 * Хуки на GameRenderer:
 *  - NoRender: «Снесение тотема» — не показывать вылетающий на весь экран
 *    предмет при срабатывании тотема (showFloatingItem);
 *  - Zoom: умножаем FOV на плавный множитель модуля (getFov);
 *  - Aspect Ratio: подменяем соотношение сторон в матрице проекции
 *    (getBasicProjectionMatrix строит perspective(fov, w/h, near, far) —
 *    перехватываем именно аргумент aspect);
 *  - Hands: захват прохода руки (renderHand) в отдельную текстуру и
 *    композит эффекта «стеклянных рук» после его завершения.
 */
@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {

	@Inject(method = "showFloatingItem", at = @At("HEAD"), cancellable = true)
	private void pc$noTotemPop(ItemStack floatingItem, CallbackInfo ci) {
		NeuClient client = NeuClient.getInstance();
		if (client == null || client.getModuleManager() == null) {
			return;
		}
		NoRenderModule module = client.getModuleManager().get(NoRenderModule.class);
		if (module != null && module.noTotemPop()) {
			ci.cancel();
		}
	}

	@Inject(method = "getFov", at = @At("RETURN"), cancellable = true)
	private void pc$zoomFov(Camera camera, float tickDelta, boolean changingFov,
			CallbackInfoReturnable<Float> cir) {
		NeuClient client = NeuClient.getInstance();
		if (client == null || client.getModuleManager() == null) {
			return;
		}
		ZoomModule module = client.getModuleManager().get(ZoomModule.class);
		if (module == null || !module.isEnabled()) {
			return;
		}
		float multiplier = module.getFovMultiplier();
		if (multiplier < 1.0f) {
			cir.setReturnValue(cir.getReturnValue() * multiplier);
		}
	}

	/**
	 * Aspect Ratio: ваниль считает соотношение как
	 * framebufferWidth / framebufferHeight и передаёт вторым аргументом
	 * в Matrix4f.perspective(fovRad, aspect, near, far). Подменяем его
	 * на выбранное в модуле — картинка растягивается или сужается.
	 */
	@ModifyArg(method = "getBasicProjectionMatrix",
			at = @At(value = "INVOKE",
					target = "Lorg/joml/Matrix4f;perspective(FFFF)Lorg/joml/Matrix4f;"),
			index = 1)
	private float pc$aspectRatio(float vanillaAspect) {
		try {
			AspectRatioModule module = AspectRatioModule.active();
			if (module != null) {
				return module.getAspect();
			}
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка Aspect Ratio", t);
		}
		return vanillaAspect;
	}

	// ===== Hands («стеклянные руки») =====

	/**
	 * Включаем захват руки в текстуры модуля непосредственно ПЕРЕД
	 * renderItem — строго после того, как renderHand в начале сбросил
	 * отложенные команды (они не должны попасть в захват). Механизм —
	 * RenderSystem.output*TextureOverride, официальный для 1.21.11.
	 */
	@Inject(method = "renderHand",
			at = @At(value = "INVOKE",
					target = "Lnet/minecraft/client/render/item/HeldItemRenderer;renderItem(FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/network/ClientPlayerEntity;I)V"))
	private void pc$glassHandBegin(float tickProgress, boolean sleeping,
			org.joml.Matrix4f positionMatrix, CallbackInfo ci) {
		try {
			ru.neuclient.client.module.impl.render.HandsModule.beginCapture();
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка Hands (захват)", t);
			ru.neuclient.client.module.impl.render.HandsModule.resetCapture();
		}
	}

	/**
	 * На выходе из renderHand: рука полностью дорисована в нашу текстуру.
	 * Возвращаем ванилле цель вывода и композитим эффект на главный кадр.
	 */
	@Inject(method = "renderHand", at = @At("RETURN"))
	private void pc$glassHandEnd(float tickProgress, boolean sleeping,
			org.joml.Matrix4f positionMatrix, CallbackInfo ci) {
		if (!ru.neuclient.client.module.impl.render.HandsModule.isCapturing()) {
			return;
		}
		try {
			ru.neuclient.client.module.impl.render.HandsModule.endCaptureAndComposite();
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка Hands (композит)", t);
			ru.neuclient.client.module.impl.render.HandsModule.resetCapture();
		}
	}
}
