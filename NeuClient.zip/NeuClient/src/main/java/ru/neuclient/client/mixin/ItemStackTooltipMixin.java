package ru.neuclient.client.mixin;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipData;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.impl.misc.AuctionHelperFT;
import ru.neuclient.client.module.impl.misc.ShulkerPreviewModule;
import ru.neuclient.client.tooltip.ShulkerPreviewData;

import java.util.List;
import java.util.Optional;

/**
 * ShulkerPreview: два вплетения в сборку тултипа предмета.
 *  - getTooltipData: подсовываем ванилле набор данных для ВИЗУАЛЬНОЙ
 *    панели (иконки-сетка), которую отрисует ShulkerPreviewComponent;
 *  - getTooltip (хвост): строка-подсказка «Ctrl — показать всё».
 */
@Mixin(ItemStack.class)
public abstract class ItemStackTooltipMixin {

	@Inject(method = "getTooltipData", at = @At("HEAD"), cancellable = true)
	private void pc$shulkerPreviewData(CallbackInfoReturnable<Optional<TooltipData>> cir) {
		try {
			ShulkerPreviewModule preview = NeuClient.getInstance().getModuleManager()
					.get(ShulkerPreviewModule.class);
			if (preview == null || !preview.isEnabled()) {
				return;
			}
			ShulkerPreviewData data = preview.buildData((ItemStack) (Object) this);
			if (data != null) {
				cir.setReturnValue(Optional.of(data));
			}
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка данных ShulkerPreview", t);
		}
	}

	@Inject(method = "getTooltip", at = @At("TAIL"))
	private void pc$shulkerPreview(Item.TooltipContext context, PlayerEntity player,
			TooltipType type, CallbackInfoReturnable<List<Text>> cir) {
		try {
			ShulkerPreviewModule preview = NeuClient.getInstance().getModuleManager()
					.get(ShulkerPreviewModule.class);
			if (preview == null || !preview.isEnabled()) {
				return;
			}
			List<Text> lines = preview.buildExtraLines((ItemStack) (Object) this, type);
			if (!lines.isEmpty()) {
				cir.getReturnValue().addAll(lines);
			}
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка ShulkerPreview", t);
		}
	}

	@Inject(method = "getTooltip", at = @At("TAIL"))
	private void pc$auctionHelperTooltip(Item.TooltipContext context, PlayerEntity player,
			TooltipType type, CallbackInfoReturnable<List<Text>> cir) {
		try {
			AuctionHelperFT helper = NeuClient.getInstance().getModuleManager()
					.get(AuctionHelperFT.class);
			if (helper == null || !helper.isEnabled()) {
				return;
			}
			ItemStack stack = (ItemStack) (Object) this;
			Text line = helper.getPricePerUnitLine(stack);
			if (line != null) {
				cir.getReturnValue().add(line);
			}
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка AuctionHelper tooltip", t);
		}
	}
}
