package ru.neuclient.client.module.impl.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.font.MsdfFontRenderer;
import ru.neuclient.client.font.MsdfFonts;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.render.WorldToScreen;
import ru.neuclient.client.setting.BooleanSetting;
import ru.neuclient.client.setting.NumberSetting;
import ru.neuclient.client.util.RenderUtil;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * DamageIndicator — всплывающие цифры урона над целью.
 *
 * Как считается урон: каждый тик сравниваем текущее HP сущности с прошлым
 * запомненным значением. Падение HP и есть урон. Такой способ не требует
 * миксинов и работает одинаково для игроков и мобов, но у него есть
 * естественное ограничение: если за один тик сущность и потеряла HP, и
 * вылечилась, увидим только разницу.
 *
 * Отрисовка — в HUD-проходе (InGameHudMixin), позиция берётся проекцией
 * мировой точки над головой через WorldToScreen.project, так что цифры
 * «висят» в мире и уезжают вместе с целью.
 *
 * Цифры живут «Время жизни» тиков, поднимаются вверх и плавно гаснут.
 * У одной цели несколько попаданий не слипаются — каждое смещено
 * по горизонтали на детерминированный псевдослучайный сдвиг.
 */
public final class DamageIndicatorModule extends Module {

	private static final int MAX_POPUPS = 80;
	private static final float FONT = 13.0f;

	private final BooleanSetting players = new BooleanSetting("Игроки", true);
	private final BooleanSetting mobs = new BooleanSetting("Мобы", true);
	private final NumberSetting lifetime = new NumberSetting("Время жизни", 25, 5, 80, 1);

	/** Всплывающие цифры. */
	private final List<Popup> popups = new ArrayList<>();

	/** Прошлые HP по id сущности. */
	private final Map<Integer, Float> lastHealth = new HashMap<>();

	public DamageIndicatorModule() {
		super("DamageIndicator", "Показывает урон цифрами", Category.RENDER);
		addSettings(players, mobs, lifetime);
	}

	@Override
	protected void onEnable() {
		popups.clear();
		lastHealth.clear();
	}

	@Override
	protected void onDisable() {
		popups.clear();
		lastHealth.clear();
	}

	@Override
	public void onTick(MinecraftClient client) {
		if (client.world == null || client.player == null) {
			lastHealth.clear();
			return;
		}

		int life = (int) Math.max(5.0, lifetime.get());
		net.minecraft.util.math.Box area = client.player.getBoundingBox().expand(64.0);

		// 1. Собираем падения HP у живых сущностей рядом
		for (LivingEntity entity : client.world.getEntitiesByClass(LivingEntity.class, area, e -> true)) {
			float now = entity.getHealth();
			Float prev = lastHealth.put(entity.getId(), now);
			if (prev == null) {
				continue; // первый раз видим — сравнивать не с чем
			}
			float delta = prev.floatValue() - now;
			if (delta <= 0.0f) {
				continue; // урона нет (или лечение)
			}
			if (shouldShow(entity, client.player)) {
				addPopup(entity.getId(), delta, life);
			}
		}

		// 2. Разрослось — выкидываем записи сущностей, которых рядом уже нет
		if (lastHealth.size() > 512) {
			java.util.Set<Integer> present = new java.util.HashSet<>();
			for (LivingEntity e : client.world.getEntitiesByClass(LivingEntity.class, area, x -> true)) {
				present.add(e.getId());
			}
			lastHealth.keySet().removeIf(id -> !present.contains(id));
		}

		// 3. Тикаем существующие цифры
		for (Iterator<Popup> it = popups.iterator(); it.hasNext();) {
			if (--it.next().left <= 0) {
				it.remove();
			}
		}
	}

	private void addPopup(int entityId, float delta, int life) {
		if (popups.size() >= MAX_POPUPS) {
			popups.remove(0);
		}
		// Детерминированный сдвиг: у одной цели цифры не налезут друг на друга,
		// но между кадрами не прыгают
		float dx = (((entityId * 31) & 0xFF) / 255.0f - 0.5f) * 14.0f;
		popups.add(new Popup(entityId, delta, life, life, dx));
	}

	private boolean shouldShow(LivingEntity entity, ClientPlayerEntity selfPlayer) {
		// Свой урон не показываем: свои цифры заслоняют прицел
		if (selfPlayer != null && entity == selfPlayer) {
			return false;
		}
		if (entity instanceof PlayerEntity) {
			return players.get();
		}
		if (entity instanceof MobEntity) {
			return mobs.get();
		}
		return false;
	}

	// ===== Отрисовка =====

	/** Вызывается из InGameHudMixin после NameTags. */
	public static void renderAllHud(DrawContext ctx) {
		try {
			NeuClient client = NeuClient.getInstance();
			if (client == null || client.getModuleManager() == null) {
				return;
			}
			DamageIndicatorModule self = client.getModuleManager().get(DamageIndicatorModule.class);
			if (self == null || !self.isEnabled() || self.popups.isEmpty()) {
				return;
			}
			self.render(ctx, MinecraftClient.getInstance());
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка DamageIndicator", t);
		}
	}

	private void render(DrawContext ctx, MinecraftClient client) {
		if (client.world == null) {
			return;
		}
		float tickDelta = WorldToScreen.frameDelta;

		for (Popup popup : popups) {
			LivingEntity entity = findLiving(client, popup.entityId);
			if (entity == null || !entity.isAlive()) {
				continue;
			}
			Vec3d lerped = entity.getLerpedPos(tickDelta);
			double[] s = WorldToScreen.project(
					lerped.add(0.0, entity.getHeight() + 0.30, 0.0), client);
			if (s == null) {
				continue;
			}

			// Прогресс 0 → 1 за время жизни
			float progress = 1.0f - (float) popup.left / (float) popup.total;
			float rise = progress * 16.0f;
			float alpha = progress < 0.6f ? 1.0f : 1.0f - (progress - 0.6f) / 0.4f;
			if (alpha <= 0.02f) {
				continue;
			}

			String text = format(popup.amount);
			float w = MsdfFontRenderer.getWidth(MsdfFonts.sfMedium(), text, FONT);
			float x = (float) s[0] - w * 0.5f + popup.dx;
			float y = (float) s[1] - rise;

			int base = entity instanceof PlayerEntity ? 0xFFFFD24A : 0xFFF2F6FF;
			int color = ((int) (alpha * 255.0f) << 24) | (base & 0x00FFFFFF);

			// Тёмная подложка — цифры читаются на любом фоне
			MsdfFontRenderer.drawWithShadow(ctx, MsdfFonts.sfMedium(), text,
					x + 0.8f, y + 0.8f, ((int) (alpha * 160.0f) << 24), FONT);
			MsdfFontRenderer.drawWithShadow(ctx, MsdfFonts.sfMedium(), text,
					x, y, color, FONT);
		}
	}

	private LivingEntity findLiving(MinecraftClient client, int id) {
		net.minecraft.entity.Entity entity = client.world.getEntityById(id);
		return entity instanceof LivingEntity living ? living : null;
	}

	/** 6.0 вместо 6.00 — коротко, но без потери целых значений. */
	private static String format(float amount) {
		int whole = Math.round(amount * 10.0f);
		if (whole % 10 == 0) {
			return String.valueOf(whole / 10);
		}
		return String.valueOf(whole / 10.0f);
	}

	/** Одна всплывающая цифра. */
	private static final class Popup {
		final int entityId;
		final float amount;
		final int total;
		int left;
		final float dx;

		Popup(int entityId, float amount, int total, int left, float dx) {
			this.entityId = entityId;
			this.amount = amount;
			this.total = Math.max(1, total);
			this.left = left;
			this.dx = dx;
		}
	}
}
