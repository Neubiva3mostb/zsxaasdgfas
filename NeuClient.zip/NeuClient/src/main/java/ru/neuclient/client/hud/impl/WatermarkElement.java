package ru.neuclient.client.hud.impl;

import net.minecraft.client.gui.DrawContext;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.font.MsdfFontRenderer;
import ru.neuclient.client.font.MsdfFonts;
import ru.neuclient.client.hud.HudElement;
import ru.neuclient.client.module.impl.render.InterfaceModule;
import ru.neuclient.client.util.RenderUtil;
import ru.neuclient.client.util.TpsSync;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Инфо-панель (Watermark) NeuClient:
 *  - Верхний ряд: NeuClient │ Логин │ FPS │ Пинг │ Время
 *  - Нижний ряд: Координаты │ TPS │ BPS
 *  - Тонкие разделители, скруглённая подложка без сторонних значков.
 */
public class WatermarkElement extends HudElement {

	private static final float ROW_H = 13.5f;
	private static final float FONT_SIZE = 7.0f;
	private static final float LOGO_SIZE = 7.5f;
	private static final float PAD = 5.0f;
	private static final float SEC_GAP = 5.0f;

	private static long lastNano = System.nanoTime();
	private static int frameCount = 0;
	private static int currentFps = 60;

	public WatermarkElement() {
		super("watermark", 0, 5);
	}

	@Override
	public boolean isVisible() {
		return true;
	}

	@Override
	protected int getDefaultX() {
		return Math.max(0, (mc.getWindow().getScaledWidth() - width) / 2);
	}

	@Override
	protected int getDefaultY() {
		return 5;
	}

	private static void updateFps() {
		frameCount++;
		long now = System.nanoTime();
		if (now - lastNano >= 1_000_000_000L) {
			currentFps = frameCount;
			frameCount = 0;
			lastNano = now;
		}
	}

	private List<String> getTopSections() {
		updateFps();
		List<String> list = new ArrayList<>();
		InterfaceModule hud = NeuClient.getInstance().getInterfaceModule();

		// Логин аккаунта сайта (не игровой/альт-ник)
		if (hud.isElementVisible("nickname")) {
			String name = ru.neuclient.client.util.SiteUser.displayName(
					mc.player != null ? mc.player.getName().getString() : mc.getSession().getUsername());
			list.add(name);
		}
		// UID аккаунта сайта (NEU-XXXXXXXX)
		if (hud.isElementVisible("uid")) {
			String uid = ru.neuclient.client.util.SiteUser.uid();
			if (uid != null) list.add(uid);
		}
		// FPS
		if (hud.isElementVisible("fps")) {
			list.add(currentFps + " FPS");
		}
		// Пинг
		if (hud.isElementVisible("ping")) {
			int ping = 0;
			if (mc.getNetworkHandler() != null && mc.player != null) {
				var entry = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
				if (entry != null) ping = entry.getLatency();
			}
			list.add(ping + " ms");
		}
		// Время
		list.add(LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")));

		return list;
	}

	private List<String> getBottomSections() {
		List<String> list = new ArrayList<>();
		InterfaceModule hud = NeuClient.getInstance().getInterfaceModule();

		if (mc.player == null) return list;

		// Координаты
		if (hud.isElementVisible("coordinates")) {
			list.add(String.format(Locale.ROOT, "XYZ: %d %d %d",
					(int) mc.player.getX(), (int) mc.player.getY(), (int) mc.player.getZ()));
		}
		// TPS
		if (hud.isElementVisible("tps")) {
			list.add(String.format(Locale.ROOT, "%.1f TPS", TpsSync.getTps()));
		}
		// Скорость (BPS)
		if (hud.isElementVisible("bps")) {
			double dx = mc.player.getX() - mc.player.lastRenderX;
			double dz = mc.player.getZ() - mc.player.lastRenderZ;
			double bps = Math.sqrt(dx * dx + dz * dz) * 20.0;
			list.add(String.format(Locale.ROOT, "%.2f BPS", bps));
		}

		return list;
	}

	private float measureRowWidth(List<String> sections, boolean hasLogo) {
		float w = PAD;
		var textFont = MsdfFonts.sfMedium();

		if (hasLogo) {
			w += MsdfFontRenderer.getWidth(textFont, "NeuClient", LOGO_SIZE) + SEC_GAP + 1.0f + SEC_GAP;
		}
		for (int i = 0; i < sections.size(); i++) {
			if (i > 0) {
				w += 1.0f + SEC_GAP;
			}
			w += MsdfFontRenderer.getWidth(textFont, sections.get(i), FONT_SIZE) + SEC_GAP;
		}
		return w;
	}

	@Override
	protected void drawElement(DrawContext ctx, boolean editing) {
		List<String> top = getTopSections();
		List<String> bottom = getBottomSections();

		float topW = measureRowWidth(top, true);
		float bottomW = bottom.isEmpty() ? 0 : measureRowWidth(bottom, false);

		this.width = (int) Math.ceil(Math.max(topW, bottomW));
		this.height = (int) Math.ceil(bottom.isEmpty() ? ROW_H : ROW_H * 2 + 3);

		int x = getX();
		int y = getY();
		InterfaceModule im = NeuClient.getInstance().getInterfaceModule();
		int accent = im != null ? im.getWatermarkColor() : RenderUtil.accent();

		// Верхняя строка
		drawRow(ctx, x, y, topW, top, true, accent);

		// Нижняя строка (центрирована относительно блока)
		if (!bottom.isEmpty()) {
			float bottomX = x + (width - bottomW) / 2.0f;
			drawRow(ctx, (int) bottomX, (int) (y + ROW_H + 3), bottomW, bottom, false, accent);
		}
	}

	private void drawRow(DrawContext ctx, int rx, int ry, float rw, List<String> sections, boolean hasLogo, int accent) {
		int bg = 0xEE0B0B16;
		int sepColor = withAlpha(0xFFFFFFFF, 0x25);

		RenderUtil.roundRect(ctx, rx, ry, (int) rw, (int) ROW_H, 4, bg);
		RenderUtil.roundBorderEdge(ctx, rx, ry, (int) rw, (int) ROW_H, 4, withAlpha(accent, 0.33f));

		float cursor = rx + PAD;
		float textY = ry + (ROW_H - FONT_SIZE) / 2.0f - 0.5f;
		var textFont = MsdfFonts.sfMedium();

		if (hasLogo) {
			float logoW = MsdfFontRenderer.getWidth(textFont, "NeuClient", LOGO_SIZE);
			float logoY = ry + (ROW_H - LOGO_SIZE) / 2.0f - 0.5f;
			MsdfFontRenderer.drawWithShadow(ctx, textFont, "NeuClient", cursor, logoY, accent, LOGO_SIZE);
			cursor += logoW + SEC_GAP;

			// Разделитель
			ctx.fill((int) cursor, (int) (ry + 3), (int) (cursor + 1), (int) (ry + ROW_H - 3), sepColor);
			cursor += 1.0f + SEC_GAP;
		}

		for (int i = 0; i < sections.size(); i++) {
			if (i > 0) {
				ctx.fill((int) cursor, (int) (ry + 3), (int) (cursor + 1), (int) (ry + ROW_H - 3), sepColor);
				cursor += 1.0f + SEC_GAP;
			}
			String text = sections.get(i);
			MsdfFontRenderer.drawWithShadow(ctx, textFont, text, cursor, textY, 0xFFFFFFFF, FONT_SIZE);
			cursor += MsdfFontRenderer.getWidth(textFont, text, FONT_SIZE) + SEC_GAP;
		}
	}
}
