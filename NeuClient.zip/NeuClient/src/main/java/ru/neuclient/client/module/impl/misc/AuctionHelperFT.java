package ru.neuclient.client.module.impl.misc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.item.ItemStack;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.screen.slot.Slot;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;


import java.util.List;

/**
 * AuctionHelperFT (AuctionHelper FunTime)
 * Помощник для аукциона серверов Minecraft (FunTime, ReallyWorld и др.).
 * Ищет самые дешевые товары в открытом интерфейсе аукциона и подсвечивает их рамками:
 * - Зеленый: Самый дешевый предмет (Топ-1)
 * - Желтый: Второй по цене предмет (Топ-2)
 * - Красный: Третий по цене предмет (Топ-3)
 *
 * Распознаёт лоты по строке с ценой в lore предмета, а не по заголовку меню.
 * Это нужно для серверных ресурс-паков: они могут заменить заголовок аукциона
 * на название товара, например «Ржавчина пыль».
 */
public class AuctionHelperFT extends Module {

    // Настройки убраны — всегда подсветка 3 слотов

    // Координаты слотов для подсветки на экране
    private int bestSlotX = -1;
    private int bestSlotY = -1;

    private int medSlotX = -1;
    private int medSlotY = -1;

    private int thSlotX = -1;
    private int thSlotY = -1;

    public AuctionHelperFT() {
        super("AuctionHelper", "Подсветка самых дешевых товаров на аукционе", Category.MISC);
        // Настройки убраны — всегда подсветка 3 слотов
    }

    @Override
    public void onEnable() {
        resetCoords();
    }

    @Override
    public void onDisable() {
        resetCoords();
    }

    private void resetCoords() {
        bestSlotX = -1;
        bestSlotY = -1;
        medSlotX = -1;
        medSlotY = -1;
        thSlotX = -1;
        thSlotY = -1;
    }

    /**
     * Вызывается каждый тик. Ищет топ-3 самых дешевых предмета в текущем открытом GUI аукциона.
     */
    @Override
    public void onTick(MinecraftClient client) {
        if (mc.player == null || mc.world == null) {
            resetCoords();
            return;
        }

        if (mc.currentScreen instanceof HandledScreen<?> screen) {
            /*
             * Нельзя определять аукцион по screen.getTitle(): серверный resource pack
             * меняет «Поиск» на название выбранного товара («Ржавчина пыль» и т. п.).
             * Надёжный признак лота — строка с ценой в его lore. Если таких строк нет,
             * foundAnyPrice останется false и подсветка будет очищена ниже.
             */
            Slot slot1 = null;
            Slot slot2 = null;
            Slot slot3 = null;

            long fsPrice = Long.MAX_VALUE;
            long medPrice = Long.MAX_VALUE;
            long thPrice = Long.MAX_VALUE;

            boolean foundAnyPrice = false;

            for (Slot slot : screen.getScreenHandler().slots) {
                // Игнорируем слоты инвентаря игрока (обычно последние 36 слотов)
                if (slot.id >= screen.getScreenHandler().slots.size() - 36) {
                    continue;
                }

                ItemStack stack = slot.getStack();
                if (stack.isEmpty()) continue;

                long price = extractPriceFromStack(stack);
                if (price <= 0) continue;

                foundAnyPrice = true;

                if (price < fsPrice) {
                    // Сдвигаем старые цены вниз
                    thPrice = medPrice;
                    slot3 = slot2;

                    medPrice = fsPrice;
                    slot2 = slot1;

                    fsPrice = price;
                    slot1 = slot;
                } else if (true && price < medPrice) {
                    thPrice = medPrice;
                    slot3 = slot2;

                    medPrice = price;
                    slot2 = slot;
                } else if (true && price < thPrice) {
                    thPrice = price;
                    slot3 = slot;
                }
            }

            if (foundAnyPrice) {
                if (slot1 != null) {
                    bestSlotX = slot1.x;
                    bestSlotY = slot1.y;
                } else {
                    bestSlotX = -1;
                    bestSlotY = -1;
                }

                if (slot2 != null && true) {
                    medSlotX = slot2.x;
                    medSlotY = slot2.y;
                } else {
                    medSlotX = -1;
                    medSlotY = -1;
                }

                if (slot3 != null && true) {
                    thSlotX = slot3.x;
                    thSlotY = slot3.y;
                } else {
                    thSlotX = -1;
                    thSlotY = -1;
                }
            } else {
                resetCoords();
            }
        } else {
            resetCoords();
        }
    }

    /**
     * Проверка: является ли предмет аукционным лотом.
     * В лоре должны быть и "Цена:" и "Продавец:", иначе это не лот.
     */
    private boolean isAuctionLot(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return false;

        LoreComponent loreComponent = stack.get(DataComponentTypes.LORE);
        if (loreComponent == null) return false;

        boolean hasPrice = false;
        boolean hasSeller = false;

        for (net.minecraft.text.Text lineText : loreComponent.lines()) {
            String line = lineText.getString().replaceAll("§.", "").trim();
            String lower = line.toLowerCase();

            // Ищем строку с "Цена:" (также учитываем варианты написания)
            if (!hasPrice && (lower.contains("цена:") || lower.contains("ценa:") || lower.contains("price:") || lower.contains("стоимость:"))) {
                hasPrice = true;
            }
            // Ищем строку с "Продавец:"
            if (!hasSeller && (lower.contains("продавец:") || lower.contains("продавeц:") || lower.contains("seller:"))) {
                hasSeller = true;
            }

            if (hasPrice && hasSeller) return true;
        }
        return false;
    }

    /**
     * Парсинг цены из Lore ItemStack для 1.21.
     * Возвращает цену ЗА ШТУКУ (общая цена / количество в стаке).
     * Работает только если в лоре есть и "Цена:" и "Продавец:".
     */
    private long extractPriceFromStack(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return -1;

        // Лот валиден только если в лоре есть и цена, и продавец
        if (!isAuctionLot(stack)) return -1;

        LoreComponent loreComponent = stack.get(DataComponentTypes.LORE);
        if (loreComponent == null) return -1;

        List<net.minecraft.text.Text> lines = loreComponent.lines();
        for (net.minecraft.text.Text lineText : lines) {
            String line = lineText.getString().replaceAll("§.", "").toLowerCase().trim();

            // Ищем ключевые слова, указывающие на строку с ценой
            if (line.contains("цена:") || line.contains("ценa:") || line.contains("price:") || line.contains("стоимость:")) {
                int colonIndex = line.indexOf(':');
                if (colonIndex == -1) colonIndex = line.indexOf('：');

                String pricePart;
                if (colonIndex != -1) {
                    pricePart = line.substring(colonIndex + 1).trim();
                } else {
                    pricePart = line;
                }

                // Убираем мешающие цифры, вроде "1 шт." или "/шт"
                pricePart = pricePart.replaceAll("\\d+\\s*шт", "")
                                     .replaceAll("за\\s*шт", "")
                                     .replaceAll("/\\s*шт", "");

                long price = parsePrice(pricePart);
                if (price > 0) {
                    // Делим на количество, чтобы получить цену за штуку
                    int count = Math.max(1, stack.getCount());
                    return price / count;
                }
            }
        }
        return -1;
    }

    /**
     * Умный парсер числовых значений цен из текстовой строки с поддержкой k/m сокращений.
     */
    private long parsePrice(String pricePart) {
        pricePart = pricePart.toLowerCase().trim();

        // Проверяем наличие суффиксов k/m (тысячи/миллионы)
        boolean hasSuffix = false;
        char suffix = ' ';
        int suffixIndex = -1;

        for (int i = 0; i < pricePart.length(); i++) {
            char c = pricePart.charAt(i);
            if (c == 'k' || c == 'к' || c == 'm' || c == 'м') {
                hasSuffix = true;
                suffix = c;
                suffixIndex = i;
                break;
            }
        }

        if (hasSuffix && suffixIndex != -1) {
            // Для сокращений (например, "1.5M" или "2,3к")
            String numPart = pricePart.substring(0, suffixIndex).trim();
            StringBuilder clean = new StringBuilder();
            for (char c : numPart.toCharArray()) {
                if (Character.isDigit(c) || c == '.' || c == ',') {
                    clean.append(c);
                }
            }
            String numStr = clean.toString().replace(",", ".");
            if (numStr.isEmpty()) return -1;
            try {
                double val = Double.parseDouble(numStr);
                long multiplier = (suffix == 'm' || suffix == 'м') ? 1000000L : 1000L;
                return (long) (val * multiplier);
            } catch (NumberFormatException e) {
                return -1;
            }
        } else {
            // Для обычных длинных чисел (например, "$ 15 000" или "15.000 руб")
            StringBuilder clean = new StringBuilder();
            for (char c : pricePart.toCharArray()) {
                if (Character.isDigit(c)) {
                    clean.append(c);
                }
            }
            String numStr = clean.toString();
            if (numStr.isEmpty()) return -1;
            try {
                return Long.parseLong(numStr);
            } catch (NumberFormatException e) {
                return -1;
            }
        }
    }

    /**
     * Отрисовка цветных рамок поверх слотов в контейнере.
     * Вызывается из миксина HandledScreenMixin#render.
     */
    public void renderSlotHighlights(DrawContext context, int xOffset, int yOffset) {
        if (!isEnabled()) return;

        // 1. Самый дешевый (Топ-1) - Зеленый
        if (bestSlotX != -1 && bestSlotY != -1) {
            int x = xOffset + bestSlotX;
            int y = yOffset + bestSlotY;
            context.fill(x, y, x + 16, y + 16, 0x3F3AFF3A);
            drawBorder(context, x, y, 16, 16, 0xFF3AFF3A);
        }

        // 2. Второй по цене (Топ-2) - Желтый
        if (medSlotX != -1 && medSlotY != -1 && true) {
            int x = xOffset + medSlotX;
            int y = yOffset + medSlotY;
            context.fill(x, y, x + 16, y + 16, 0x3FFFFF3A);
            drawBorder(context, x, y, 16, 16, 0xFFFFFF3A);
        }

        // 3. Третий по цене (Топ-3) - Красный
        if (thSlotX != -1 && thSlotY != -1 && true) {
            int x = xOffset + thSlotX;
            int y = yOffset + thSlotY;
            context.fill(x, y, x + 16, y + 16, 0x3FFF3A3A);
            drawBorder(context, x, y, 16, 16, 0xFFFF3A3A);
        }
    }

    private void drawBorder(DrawContext context, int x, int y, int w, int h, int color) {
        context.fill(x, y, x + w, y + 1, color);
        context.fill(x, y + h - 1, x + w, y + h, color);
        context.fill(x, y + 1, x + 1, y + h - 1, color);
        context.fill(x + w - 1, y + 1, x + w, y + h - 1, color);
    }

    /**
     * Формирует строку "Цена за шт: N" для добавления в тултип.
     * Возвращает null если предмет не является аукционным лотом.
     */
    public net.minecraft.text.Text getPricePerUnitLine(ItemStack stack) {
        if (!isAuctionLot(stack)) return null;

        long pricePerUnit = extractPriceFromStack(stack);
        if (pricePerUnit <= 0) return null;

        return net.minecraft.text.Text.literal("§7Цена за шт: §f" + formatPrice(pricePerUnit));
    }

    /**
     * Форматирование цены: 1546 → "1.5к", 1234567 → "1.2м", 999 → "999".
     */
    private static String formatPrice(long price) {
        if (price >= 1_000_000) {
            double m = price / 1_000_000.0;
            if (m == Math.floor(m)) return String.format("%.0fм", m);
            return String.format("%.1fм", m).replace(",",".");
        }
        if (price >= 1_000) {
            double k = price / 1_000.0;
            if (k == Math.floor(k)) return String.format("%.0fк", k);
            return String.format("%.1fк", k).replace(",",".");
        }
        return String.valueOf(price);
    }
}