package ru.neuclient.client.module.impl.combat;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.BooleanSetting;
import ru.neuclient.client.setting.ModeSetting;
import ru.neuclient.client.setting.NumberSetting;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Random;

/**
 * AimBot — плавное наведение КАМЕРЫ на цель (по мотивам ClientSideCrystal:
 * доворот с коэффициентом сглаживания и ограничением шага за тик +
 * рандомизированное «дрожание» вокруг цели, имитирующее руку человека).
 *
 * Модуль двигает только реальную камеру игрока (setYaw/setPitch) — как
 * это сделала бы мышь. Никаких лишних пакетов и спуфов: для сервера это
 * выглядит как обычный поворот обзора.
 *
 * Выбор цели: типы целей (игроки / враждебные мобы / мирные мобы /
 * невидимые игроки), зона захвата FOV, дальность Range и приоритет —
 * «Дистанция», «Здоровье» или «Броня» (самая слабая).
 */
public class AimBotModule extends Module {

	// ===== Настройки наведения =====
	private final NumberSetting aimFov = new NumberSetting("Угол обзора", 180.0, 10.0, 360.0, 5.0);
	private final NumberSetting smooth = new NumberSetting("Плавность", 0.37, 0.05, 1.0, 0.01);
	private final NumberSetting maxStep = new NumberSetting("Максимальный шаг", 30.0, 5.0, 180.0, 5.0);
	private final NumberSetting range = new NumberSetting("Дистанция", 4.0, 2.0, 6.0, 0.25);
	/** Точка прицеливания по высоте: 0 = живот, 1 = верх головы, 0.6 = между телом и головой. */
	private final NumberSetting aimHeight = new NumberSetting("Высота наведения", 0.6, 0.0, 1.0, 0.05);
	private final NumberSetting wobbleAmpYaw = new NumberSetting("Дрожание по горизонтали", 3.2, 0.0, 15.0, 0.1);
	private final NumberSetting wobbleAmpPitch = new NumberSetting("Дрожание по вертикали", 2.2, 0.0, 15.0, 0.1);
	private final NumberSetting wobbleSpeed = new NumberSetting("Скорость дрожания", 0.045, 0.005, 0.3, 0.005);
	private final NumberSetting phaseChangeInterval = new NumberSetting("Интервал смены фазы", 40.0, 5.0, 200.0, 5.0);

	// ===== Настройки целей =====
	private final BooleanSetting players = new BooleanSetting("Игроки", true);
	private final BooleanSetting hostileMobs = new BooleanSetting("Враждебные мобы", true);
	private final BooleanSetting peacefulMobs = new BooleanSetting("Мирные мобы", false);
	private final BooleanSetting invisiblePlayers = new BooleanSetting("Невидимые игроки", false);
	private final ModeSetting priority = new ModeSetting("Приоритет", "Дистанция", "Дистанция", "Здоровье", "Броня");

	/** Текущая цель (может быть null). */
	private LivingEntity target;

	// ===== Состояние дрожания (как в ClientSideCrystal) =====
	private final Random random = new Random();
	private float phaseYaw;
	private float phasePitch;
	private int ticksSincePhaseChange;
	private float currentAmpYaw;
	private float currentAmpPitch;
	private float currentSpeedYaw;
	private float currentSpeedPitch;

	public AimBotModule() {
		super("AimBot", "Автоматическое наведение на цель", Category.COMBAT);
		// Скрываем все ползунки из ClickGUI кроме «Дистанция»
		aimFov.visibleWhen(() -> false);
		smooth.visibleWhen(() -> false);
		maxStep.visibleWhen(() -> false);
		aimHeight.visibleWhen(() -> false);
		wobbleAmpYaw.visibleWhen(() -> false);
		wobbleAmpPitch.visibleWhen(() -> false);
		wobbleSpeed.visibleWhen(() -> false);
		phaseChangeInterval.visibleWhen(() -> false);
		addSettings(aimFov, smooth, maxStep, range, aimHeight,
				wobbleAmpYaw, wobbleAmpPitch, wobbleSpeed, phaseChangeInterval,
				players, hostileMobs, peacefulMobs, invisiblePlayers, priority);
	}

	@Override
	protected void onEnable() {
		target = null;
		// Инициализируем дрожание сразу из настроек (не ждём первый интервал)
		currentAmpYaw = wobbleAmpYaw.get().floatValue();
		currentAmpPitch = wobbleAmpPitch.get().floatValue();
		currentSpeedYaw = wobbleSpeed.get().floatValue();
		currentSpeedPitch = wobbleSpeed.get().floatValue();
		ticksSincePhaseChange = 0;
	}

	@Override
	protected void onDisable() {
		target = null;
	}

	@Override
	public void onTick(MinecraftClient client) {
		if (client.player == null || client.world == null) {
			target = null;
			return;
		}
		if (client.currentScreen != null) {
			return; // GUI открыт — не крутим камеру
		}
		// Пока BowAimBot наводит на выстрел (лук/арбалет/трезубец) — камера его,
		// иначе два модуля будут дёргать обзор на разные цели
		BowAimBotModule bowAim = NeuClient.getInstance().getModuleManager().get(BowAimBotModule.class);
		if (bowAim != null && bowAim.isEnabled() && bowAim.isAiming()) {
			target = null;
			return;
		}
		target = findBestTarget(client);
		if (target == null) {
			return;
		}
		updateWobbleParameters();
		applyAimAssist(client, target);
	}

	// ===== ДРОЖАНИЕ (wobble) =====

	/** Раз в «Интервал смены фазы» тиков амплитуды и скорости фаз
	 * случайно «перезаряжаются» — направление дрейфа меняется. */
	private void updateWobbleParameters() {
		ticksSincePhaseChange++;
		if (ticksSincePhaseChange >= phaseChangeInterval.get().intValue()) {
			ticksSincePhaseChange = 0;
			currentAmpYaw = (float) (wobbleAmpYaw.get() * (0.65f + random.nextFloat() * 0.7f));
			currentAmpPitch = (float) (wobbleAmpPitch.get() * (0.65f + random.nextFloat() * 0.7f));
			currentSpeedYaw = (float) (wobbleSpeed.get() * (0.7f + random.nextFloat() * 0.9f));
			currentSpeedPitch = (float) (wobbleSpeed.get() * (0.7f + random.nextFloat() * 0.9f));
		}
		phaseYaw += currentSpeedYaw;
		phasePitch += currentSpeedPitch;
		float twoPi = (float) (Math.PI * 2.0);
		if (phaseYaw > twoPi) {
			phaseYaw -= twoPi;
		}
		if (phasePitch > twoPi) {
			phasePitch -= twoPi;
		}
	}

	// ===== НАВЕДЕНИЕ =====

	private void applyAimAssist(MinecraftClient client, LivingEntity targetEntity) {
		ClientPlayerEntity self = client.player;

		// Углы на точку прицеливания (слайдер «Высота наведения»: живот ↔ голова)
		Vec3d eyes = self.getEyePos();
		Vec3d center = aimPoint(targetEntity);
		Vec3d diff = center.subtract(eyes);
		double hDist = Math.sqrt(diff.x * diff.x + diff.z * diff.z);
		float targetYaw = (float) Math.toDegrees(Math.atan2(-diff.x, diff.z));
		float targetPitch = (float) -Math.toDegrees(Math.atan2(diff.y, hDist));

		// + дрожание
		targetYaw += (float) Math.sin(phaseYaw) * currentAmpYaw;
		targetPitch += (float) Math.sin(phasePitch) * currentAmpPitch;

		// Плавный доворот с ограничением шага за тик
		float dYaw = MathHelper.wrapDegrees(targetYaw - self.getYaw());
		float dPitch = targetPitch - self.getPitch();
		float step = maxStep.get().floatValue();
		float k = smooth.get().floatValue();

		float moveYaw = MathHelper.clamp(dYaw * k, -step, step);
		float movePitch = MathHelper.clamp(dPitch * k, -step, step);

		self.setYaw(self.getYaw() + moveYaw);
		self.setPitch(MathHelper.clamp(self.getPitch() + movePitch, -90.0f, 90.0f));
	}

	// ===== ВЫБОР ЦЕЛИ =====

	/** Точка прицеливания по цели: 0 — живот (~40% роста), 1 — глаза.
	 * По горизонтали — центр хитбокса. */
	private Vec3d aimPoint(LivingEntity entity) {
		Vec3d tgtEyes = entity.getEyePos();
		double bellyY = entity.getY() + entity.getHeight() * 0.4;
		double f = aimHeight.get();
		double aimY = bellyY + (tgtEyes.y - bellyY) * f;
		return new Vec3d(tgtEyes.x, aimY, tgtEyes.z);
	}

	/** Кандидаты внутри FOV и «Дистанция», отсортированные по приоритету. */
	private LivingEntity findBestTarget(MinecraftClient client) {
		ClientPlayerEntity self = client.player;
		Vec3d look = lookVector(self);
		Vec3d eyes = self.getEyePos();

		double r = range.get();
		Box box = self.getBoundingBox().expand(r + 1.0, r + 1.0, r + 1.0);
		float fovLimit = aimFov.get().floatValue();

		List<LivingEntity> candidates = new ArrayList<>();
		for (LivingEntity entity : client.world.getEntitiesByClass(LivingEntity.class, box, e -> true)) {
			if (!isValidTarget(client, entity, r)) {
				continue;
			}
			// Внутри зоны захвата (угла обзора)? Считаем по точке прицеливания
			Vec3d toTarget = aimPoint(entity).subtract(eyes).normalize();
			double dot = MathHelper.clamp(look.dotProduct(toTarget), -1.0, 1.0);
			float angle = (float) Math.toDegrees(Math.acos(dot));
			if (angle <= fovLimit) {
				candidates.add(entity);
			}
		}
		if (candidates.isEmpty()) {
			return null;
		}

		// Приоритет: Дистанция / Здоровье / Броня (самая слабая первая)
		Comparator<LivingEntity> comparator = switch (priority.get()) {
			case "Здоровье" -> Comparator.comparingDouble(LivingEntity::getHealth)
					.thenComparingDouble(self::squaredDistanceTo);
			case "Броня" -> Comparator.comparingInt(LivingEntity::getArmor)
					.thenComparingDouble(self::squaredDistanceTo);
			default -> Comparator.comparingDouble(self::squaredDistanceTo);
		};
		candidates.sort(comparator);
		return candidates.get(0);
	}

	/** Фильтр типов целей и невидимости (дружба из .friend — не трогаем). */
	private boolean isValidTarget(MinecraftClient client, LivingEntity entity, double r) {
		ClientPlayerEntity self = client.player;
		if (entity == null || entity == self || entity.getId() == self.getId() || !entity.isAlive()) {
			return false;
		}
		if (ru.neuclient.client.bot.BotManager.getInstance().isBot(entity.getName().getString())) {
			return false;
		}
		if (self.squaredDistanceTo(entity) > r * r) {
			return false;
		}
		if (entity instanceof PlayerEntity other) {
			if (other.isSpectator()) {
				return false;
			}
			if (!players.get()) {
				return false;
			}
			if (NeuClient.getInstance().getFriendManager().isFriend(other.getName().getString())) {
				return false;
			}
			// AntiBot: не наводимся на фейковых игроков
			if (AntiBotModule.isBot(other)) {
				return false;
			}
			if (other.isInvisible() && !invisiblePlayers.get()) {
				return false;
			}
			return true;
		}
		if (entity instanceof HostileEntity) {
			return hostileMobs.get();
		}
		if (entity instanceof AnimalEntity) {
			return peacefulMobs.get();
		}
		return false; // остальных существ (големы, жители и т.п.) не трогаем
	}

	/** Вектор взгляда из yaw/pitch (та же формула, что у ваниллы). */
	private static Vec3d lookVector(ClientPlayerEntity self) {
		float yawRad = self.getYaw() * 0.017453292f;
		float pitchRad = self.getPitch() * 0.017453292f;
		float cosPitch = MathHelper.cos(pitchRad);
		return new Vec3d(
				-MathHelper.sin(yawRad) * cosPitch,
				-MathHelper.sin(pitchRad),
				MathHelper.cos(yawRad) * cosPitch);
	}
}
