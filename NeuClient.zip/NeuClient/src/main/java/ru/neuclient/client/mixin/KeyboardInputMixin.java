package ru.neuclient.client.mixin;

import ru.neuclient.client.module.impl.combat.AttackAuraModule;
import ru.neuclient.client.module.impl.combat.ShiftTAPModule;
import ru.neuclient.client.module.impl.movement.TargetStrafeModule;
import ru.neuclient.client.module.impl.movement.AutoSprintModule;
import ru.neuclient.client.module.impl.movement.WallClimbModule;
import ru.neuclient.client.module.impl.player.FreeCamModule;

import net.minecraft.client.input.Input;
import net.minecraft.client.input.KeyboardInput;
import net.minecraft.util.PlayerInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.impl.combat.WTapModule;

/**
 * Единая коррекция ввода для SwapPause, NeuBot, FreeCam, WallClimb, TargetStrafe,
 * серверного rotation spoof, WTap и ShiftTAP.
 */
@Mixin(KeyboardInput.class)
public abstract class KeyboardInputMixin extends Input {

	@Inject(method = "tick", at = @At("TAIL"))
	private void pc$afterInputGathered(CallbackInfo ci) {
		// СЫРОЙ ввод до любой коррекции. AutoSprint считает серверный угол
		// именно по нему: ниже этот же movementVector будет перезаписан
		// коррекцией, и читать его оттуда уже нельзя.
		float rawForward = this.movementVector.y;
		float rawStrafe = this.movementVector.x;
		try {
            var bots = ru.neuclient.client.bot.BotManager.getInstance();
            if (bots.isRallying()) {
                this.playerInput = bots.rallyInput(this.playerInput);
                this.movementVector = new net.minecraft.util.math.Vec2f(
                        (this.playerInput.left() ? 1f : 0f) - (this.playerInput.right() ? 1f : 0f),
                        (this.playerInput.forward() ? 1f : 0f) - (this.playerInput.backward() ? 1f : 0f)).normalize();
                return;
            }
			// Пауза свапа важнее всех модулей движения.
			if (ru.neuclient.client.util.SwapPause.consumeForInputTick()) {
				this.playerInput = new PlayerInput(false, false, false, false,
						false, this.playerInput.sneak(), false);
				this.movementVector = new net.minecraft.util.math.Vec2f(0.0f, 0.0f);
				return;
			}

			// FreeCam оставляет тело игрока на месте.
			ru.neuclient.client.module.impl.player.FreeCamModule freecam =
					NeuClient.getInstance().getModuleManager().get(ru.neuclient.client.module.impl.player.FreeCamModule.class);
			if (freecam != null && freecam.isEnabled()) {
				this.playerInput = new PlayerInput(false, false, false, false, false, false, false);
				this.movementVector = new net.minecraft.util.math.Vec2f(0.0f, 0.0f);
				return;
			}

			// WallClimb добавляет jump=true через обычный PlayerInput.
			ru.neuclient.client.module.impl.movement.WallClimbModule wallClimb =
					NeuClient.getInstance().getModuleManager().get(ru.neuclient.client.module.impl.movement.WallClimbModule.class);
			if (wallClimb != null && wallClimb.consumeForcedJump()) {
				this.playerInput = new PlayerInput(
						this.playerInput.forward(),
						this.playerInput.backward(),
						this.playerInput.left(),
						this.playerInput.right(),
						true,
						this.playerInput.sneak(),
						this.playerInput.sprint());
			}

			// TargetStrafe получает приоритет над обычной коррекцией движения.
			ru.neuclient.client.module.impl.movement.TargetStrafeModule strafe =
					ru.neuclient.client.module.impl.movement.TargetStrafeModule.active();
			if (strafe != null) {
				ru.neuclient.client.module.impl.combat.AttackAuraModule aura =
						ru.neuclient.client.module.impl.combat.AttackAuraModule.active();
				float serverYaw = (wallClimb != null && wallClimb.shouldApplySpoof())
						? wallClimb.getSpoofYaw()
						: (aura != null && aura.isSpoofing()
								? aura.getSpoofYaw()
								: net.minecraft.client.MinecraftClient.getInstance().player.getYaw());

				float local = net.minecraft.util.math.MathHelper.wrapDegrees(
						strafe.getDesiredWorldAngle() - serverYaw);
				float snapped = Math.round(local / 45.0f) * 45.0f;
				float forward = Math.round((float) Math.cos(Math.toRadians(snapped)));
				float sideways = -Math.round((float) Math.sin(Math.toRadians(snapped)));
				boolean sprint = forward > 0.0f && !strafe.isChasing();
				if ((aura != null && aura.needsSprintOffForCrit())
					|| ru.neuclient.client.module.impl.combat.TriggerBotModule.shouldHoldSprintForCrit()) {
					sprint = false;
				}

				this.playerInput = new PlayerInput(
						forward > 0.0f, forward < 0.0f,
						sideways > 0.0f, sideways < 0.0f,
						strafe.wantsJump() || this.playerInput.jump(),
						this.playerInput.sneak(), sprint);
				this.movementVector = new net.minecraft.util.math.Vec2f(sideways, forward).normalize();

				// Важно: ранний return больше не пропускает ShiftTAP.
				ru.neuclient.client.module.impl.combat.ShiftTAPModule shiftTap =
						ru.neuclient.client.module.impl.combat.ShiftTAPModule.active();
				if (shiftTap != null && shiftTap.shouldForceSneak() && !this.playerInput.sneak()) {
					this.playerInput = new PlayerInput(
							this.playerInput.forward(), this.playerInput.backward(),
							this.playerInput.left(), this.playerInput.right(),
							this.playerInput.jump(), true, this.playerInput.sprint());
				}
				return;
			}

			// Если серверный угол временно отличается от камеры, сохраняем
			// мировое направление обычного ввода.
			ru.neuclient.client.module.impl.combat.AttackAuraModule aura =
					NeuClient.getInstance().getModuleManager().get(ru.neuclient.client.module.impl.combat.AttackAuraModule.class);
			boolean wallSpoof = wallClimb != null && wallClimb.shouldApplySpoof();
			boolean auraSpoof = aura != null && aura.isSpoofing();
			AutoSprintModule autoSprint = AutoSprintModule.active();
			boolean sprintSpoof = !wallSpoof && !auraSpoof
					&& autoSprint != null && autoSprint.shouldApplySpoof();
			if (wallSpoof || auraSpoof || sprintSpoof) {
				float[] fixed = wallSpoof
						? wallClimb.correctMovement(this.movementVector.y, this.movementVector.x)
						: (auraSpoof
								? aura.correctMovement(this.movementVector.y, this.movementVector.x)
								: autoSprint.correctMovement(this.movementVector.y, this.movementVector.x));
				float forward = fixed[0];
				float sideways = fixed[1];
				boolean sprint = this.playerInput.sprint()
						&& (!auraSpoof || !aura.shouldStopSprint());
				// «Во все стороны»: после коррекции движение стало «вперёд»,
				// поэтому спринт обязателен — иначе сервер увидит шаг.
				// Крит ауры важнее: без спринта ваниль засчитывает крит.
				if (sprintSpoof) {
					boolean critWait = (aura != null && aura.needsSprintOffForCrit())
					|| ru.neuclient.client.module.impl.combat.TriggerBotModule.shouldHoldSprintForCrit();
					sprint = forward > 0.0f && !critWait;
				}
				this.playerInput = new PlayerInput(
						forward > 0.0f, forward < 0.0f,
						sideways > 0.0f, sideways < 0.0f,
						this.playerInput.jump(), this.playerInput.sneak(), sprint);
				this.movementVector = new net.minecraft.util.math.Vec2f(sideways, forward).normalize();
			}

			WTapModule wtap = NeuClient.getInstance().getModuleManager().get(WTapModule.class);
			if (wtap != null && wtap.isBlockingForward() && this.playerInput.forward()) {
				this.playerInput = new PlayerInput(false, this.playerInput.backward(),
						this.playerInput.left(), this.playerInput.right(),
						this.playerInput.jump(), this.playerInput.sneak(), this.playerInput.sprint());
			}

			// ShiftTAP должен выполняться и при обычном вводе, и после WTap.
			ru.neuclient.client.module.impl.combat.ShiftTAPModule shiftTap =
					ru.neuclient.client.module.impl.combat.ShiftTAPModule.active();
			if (shiftTap != null && shiftTap.shouldForceSneak() && !this.playerInput.sneak()) {
				this.playerInput = new PlayerInput(
						this.playerInput.forward(), this.playerInput.backward(),
						this.playerInput.left(), this.playerInput.right(),
						this.playerInput.jump(), true, this.playerInput.sprint());
			}
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка W-Tap/FreeCam ввода", t);
		} finally {
			// Новый серверный угол — на следующий тик. Считаем в самом конце,
			// чтобы коррекция движения выше успела прочитать угол, который
			// реально стоит на сущности в ЭТОМ тике.
			try {
				AutoSprintModule autoSprint = AutoSprintModule.active();
				if (autoSprint != null) {
					autoSprint.refreshFromInput(rawForward, rawStrafe);
				}
			} catch (Throwable t) {
				NeuClient.LOGGER.error("[NeuClient] Ошибка AutoSprint (угол)", t);
			}
		}
	}
}
