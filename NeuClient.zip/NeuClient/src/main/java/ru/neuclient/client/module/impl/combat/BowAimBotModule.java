package ru.neuclient.client.module.impl.combat;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BowItem;
import net.minecraft.item.CrossbowItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.TridentItem;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.BooleanSetting;
import ru.neuclient.client.setting.NumberSetting;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * BowAimBot — наведение камеры на ближайшего игрока ТАК, ЧТОБЫ СТРЕЛА
 * РЕАЛЬНО ПОПАЛА: считается баллистика снаряда и упреждение по времени полёта.
 *
 * Что учитывается (ванильная физика снарядов):
 *  - Скорость вылета: лук — 0..3.0 по натяжению (BowItem.getPullProgress),
 *    арбалет — 3.15, трезубец — 2.5.
 *  - Каждый тик полёта: позиция += скорость; скорость *= 0.99 (драг);
 *    скорость.y -= 0.05 (гравитация). Из-за гравитации на дистанции прицел
 *    должен быть ВЫШЕ цели — высоту подбирает численный решатель.
 *  - Упреждение: скорость цели меряем сами (сдвиг позиции за тик),
 *    время полёта получаем из симуляции, целимся в точку
 *    «позиция цели + её скорость × время полёта × сила предикта».
 *    Стоящая цель — скорость ~0 — попадаем прямо в неё.
 *
 * Работает только пока игрок тянет лук/трезубец (isUsingItem) или держит
 * в руке УЖЕ ЗАРЯЖЕННЫЙ арбалет. Двигает только реальную камеру
 * (setYaw/setPitch) — для сервера это обычный поворот обзора.
 */
public class BowAimBotModule extends Module {

	// ===== Настройки (строго по спеке) =====
	/** Множитель упреждения: значение/2 × время полёта (2 = ровно время полёта). */
	private final NumberSetting prediction = new NumberSetting("Сила предикта", 2.0, 1.0, 5.0, 0.5);
	private final BooleanSetting bow = new BooleanSetting("Лук", true);
	private final BooleanSetting crossbow = new BooleanSetting("Арбалет", true);
	private final BooleanSetting trident = new BooleanSetting("Трезубец", true);

	// ===== Внутренние константы =====
	/** Сдвиг за тик меньше этого — считаем, что цель стоит на месте. */
	private static final double STILL_THRESHOLD = 0.09;
	/** Потолок скорости цели (блок/тик) — фильтр от телепортов/лаг-скачков. */
	private static final double MAX_TARGET_SPEED = 1.2;
	/** Доля доворота к цели за тик (0..1). */
	private static final float SMOOTH = 0.5f;
	/** Максимальный поворот камеры за тик (нужен быстрый захват перед выстрелом). */
	private static final float MAX_STEP = 45.0f;
	/** Забываем позиции игроков, которые дальше этого — чтобы не копить мусор. */
	private static final double TRACK_DROP_DIST_SQ = 150.0 * 150.0;

	/** Лаг-компенсация — базовая часть (тики): позиция чужих сущностей на клиенте
	 * интерполируется между серверными обновлениями (~3 тика). Плюс сюда же
	 * динамически добавляется пинг: данные о позиции цели едут до нас полпинга
	 * и наш выстрел едет до сервера полпинга — суммарно стрела всегда «бьёт»
	 * цель на сервере, где она на (ping/50) тиков «старше» её экранной позиции.
	 * Без этого по бегущей цели прицел ложится ровно на модельку, а мимо сервера. */
	private static final double LAG_TICKS_BASE = 3.0;

	// ===== Ванильная физика снарядов =====
	/** Драг скорости за тик (в воздухе). */
	private static final double DRAG = 0.99;
	/** Гравитация снаряда за тик. */
	private static final double GRAVITY = 0.05;
	/** Скорость стрелы арбалета (ванильная константа DEFAULT_SPEED). */
	private static final double CROSSBOW_SPEED = 3.15;
	/** Скорость броска трезубца (TridentItem.THROW_SPEED). */
	private static final double TRIDENT_SPEED = 2.5;

	/** Позиции игроков на прошлом тике (для расчёта скорости цели). */
	private final Map<UUID, Vec3d> lastPositions = new HashMap<>();

	/** true, если в последнем тике мы наводили камеру (чтобы AimBot не мешал). */
	private volatile boolean aiming = false;

	public BowAimBotModule() {
		super("BowAimBot", "Наведение на ближайшего игрока", Category.COMBAT);
		addSettings(prediction, bow, crossbow, trident);
	}

	@Override
	protected void onDisable() {
		lastPositions.clear();
		aiming = false;
	}

	/** AimBot сверяется по этому флагу и не перебивает наведение на выстрел. */
	public boolean isAiming() {
		return aiming;
	}

	@Override
	public void onTick(MinecraftClient client) {
		aiming = false;
		if (client.player == null || client.world == null) {
			lastPositions.clear();
			return;
		}
		if (client.currentScreen != null) {
			return; // GUI открыт — камеру не крутим
		}

		// Оружие в руках + его скорость снаряда (для лука — по натяжению)
		double projectileSpeed = getProjectileSpeed(client);
		if (projectileSpeed <= 0.0) {
			return; // лук/трезубец не натянут и заряженного арбалета нет
		}

		PlayerEntity targetEntity = findNearestPlayer(client);
		if (targetEntity == null) {
			return;
		}

		aiming = true;
		aimAtPredicted(client, targetEntity, projectileSpeed);
	}

	// ===== СОСТОЯНИЕ СТРЕЛЬБЫ И СКОРОСТЬ СНАРЯДА =====

	/** Оружие для выстрела в руках? Если да — возвращает скорость снаряда
	 * (блок/тик): лук по текущему натяжению, иначе 0 — значит, не целимся. */
	private double getProjectileSpeed(MinecraftClient client) {
		ClientPlayerEntity self = client.player;

		if (self.isUsingItem()) {
			Item item = self.getActiveItem().getItem();
			if (item instanceof BowItem && bow.get()) {
				// Скорость = 3.0 × натяжение; ниже 0.1 стрела вообще не вылетит
				float pull = BowItem.getPullProgress(self.getItemUseTime());
				return Math.max(pull * 3.0, 0.3);
			}
			if (item instanceof CrossbowItem && crossbow.get()) {
				return CROSSBOW_SPEED; // тянем — после зарядки стрела полетит на максимуме
			}
			if (item instanceof TridentItem && trident.get()) {
				return TRIDENT_SPEED;
			}
		}

		if (crossbow.get()) {
			ItemStack main = self.getMainHandStack();
			if (main.getItem() instanceof CrossbowItem && CrossbowItem.isCharged(main)) {
				return CROSSBOW_SPEED;
			}
			ItemStack off = self.getOffHandStack();
			if (off.getItem() instanceof CrossbowItem && CrossbowItem.isCharged(off)) {
				return CROSSBOW_SPEED;
			}
		}
		return 0.0;
	}

	// ===== ВЫБОР ЦЕЛИ =====

	/** Ближайший «честный» игрок: живой, не спектатор, не невидимый, не френд. */
	private PlayerEntity findNearestPlayer(MinecraftClient client) {
		ClientPlayerEntity self = client.player;
		PlayerEntity best = null;
		double bestDistSq = Double.MAX_VALUE;

		for (PlayerEntity other : client.world.getPlayers()) {
			if (other == self || !other.isAlive() || other.isSpectator()) {
				continue;
			}
			if (other.isInvisible()) {
				continue;
			}
			if (NeuClient.getInstance().getFriendManager().isFriend(other.getName().getString())) {
				continue;
			}
			double distSq = self.squaredDistanceTo(other);
			if (distSq < bestDistSq) {
				bestDistSq = distSq;
				best = other;
			}
		}
		return best;
	}

	// ===== ПРЕДИКТ + БАЛЛИСТИКА =====

	/** Скорость цели за тик (из своей памяти позиций) + итеративный расчёт
	 * упреждения по времени полёта и углов с компенсацией гравитации. */
	private void aimAtPredicted(MinecraftClient client, PlayerEntity targetEntity, double speed) {
		ClientPlayerEntity self = client.player;
		UUID id = targetEntity.getUuid();
		Vec3d pos = targetEntity.getEntityPos();

		// Скорость цели — реальный сдвиг за последний тик (блок/тик)
		Vec3d prev = lastPositions.put(id, pos);
		double vx = 0.0, vy = 0.0, vz = 0.0;
		if (prev != null) {
			vx = pos.x - prev.x;
			vz = pos.z - prev.z;
			// Вертикаль только если цель реально в воздухе (прыжок/полёт),
			// иначе на земле из-за гравитационного джиттера прицел будет гулять
			vy = targetEntity.isOnGround() ? 0.0 : pos.y - prev.y;
			if (Math.hypot(vx, vz) < STILL_THRESHOLD) {
				vx = 0.0;
				vz = 0.0;
			}
			// Анти-лаг: телепорт/откат не должен рвать прицел
			double total = Math.sqrt(vx * vx + vy * vy + vz * vz);
			if (total > MAX_TARGET_SPEED) {
				double k = MAX_TARGET_SPEED / total;
				vx *= k;
				vy *= k;
				vz *= k;
			}
		}

		// Целимся в верх груди (65% роста) — у стрелы должен быть запас по хитбоксу
		Vec3d base = new Vec3d(targetEntity.getX(), targetEntity.getY() + targetEntity.getHeight() * 0.65, targetEntity.getZ());
		Vec3d eye = self.getEyePos();
		double leadMultiplier = prediction.get() / 2.0; // 2 = ровно время полёта

		// Итеративно: время полёта → точка упреждения → новые углы → новое время.
		// Упреждение = скорость × (время полёта + лаг-компенсация) × сила предикта.
		double lagTicks = getLagTicks(client);
		double flatDist = Math.hypot(base.x - eye.x, base.z - eye.z);
		double flightTime = flatDist / speed; // стартовая оценка
		float wantYaw = 0.0f;
		float wantPitch = 0.0f;
		for (int i = 0; i < 3; i++) {
			double leadTicks = (flightTime + lagTicks) * leadMultiplier;
			Vec3d predicted = base.add(vx * leadTicks, vy * leadTicks, vz * leadTicks);
			float[] solution = solveAngles(eye, predicted, speed);
			wantYaw = solution[0];
			wantPitch = solution[1];
			flightTime = solution[2];
		}

		// Плавный доворот с ограничением шага за тик (как в AimBot)
		float dYaw = MathHelper.wrapDegrees(wantYaw - self.getYaw());
		float dPitch = wantPitch - self.getPitch();
		float moveYaw = MathHelper.clamp(dYaw * SMOOTH, -MAX_STEP, MAX_STEP);
		float movePitch = MathHelper.clamp(dPitch * SMOOTH, -MAX_STEP, MAX_STEP);

		self.setYaw(self.getYaw() + moveYaw);
		self.setPitch(MathHelper.clamp(self.getPitch() + movePitch, -90.0f, 90.0f));

		cleanupFarPlayers(client);
	}

	// ===== ЧИСЛЕННЫЙ РЕШАТЕЛЬ БАЛЛИСТИКИ =====

	/** Ищет yaw/pitch/время полёта так, чтобы снаряд прилетел в точку target
	 * с учётом драга и гравитации. Угол подбирается бинарным поиском по
	 * высоте снаряда на горизонтальной дистанции цели. */
	private static float[] solveAngles(Vec3d from, Vec3d target, double speed) {
		double dx = target.x - from.x;
		double dz = target.z - from.z;
		double relY = target.y - from.y;
		double horizDist = Math.hypot(dx, dz);

		// Бинарный поиск угла возвышения: чем больше угол, тем ВЫШЕ снаряд
		// на той же дистанции (строгая монотонность — сходится за ~25 шагов)
		double lo = -1.40; // ~ -80° (цель резко ниже)
		double hi = 1.52;  // ~ +87° (почти вертикально вверх — если далеко не долетает)
		double flightTime = horizDist / 2.0; // fallback-оценка
		for (int i = 0; i < 25; i++) {
			double mid = (lo + hi) * 0.5;
			double[] sim = simulateAtDistance(horizDist, mid, speed);
			if (sim[0] < relY) {
				lo = mid; // снаряд приходит НИЖЕ цели — поднимаем угол
			} else {
				hi = mid;
			}
			flightTime = sim[1];
		}
		double angle = (lo + hi) * 0.5;

		float yaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
		float pitch = (float) -Math.toDegrees(angle); // в MC минус = вверх
		return new float[] {yaw, pitch, (float) flightTime};
	}

	/** Один прогон полёта снаряда под углом elevation: возвращает
	 * [высоту над точкой старта на дистанции horizDist, время полёта в тиках].
	 * Порядок тика = ванильный: pos += vel; vel *= 0.99; vel.y -= 0.05. */
	private static double[] simulateAtDistance(double horizDist, double elevation, double speed) {
		double vh = Math.cos(elevation) * speed;
		double vy = Math.sin(elevation) * speed;
		double h = 0.0;
		double y = 0.0;
		for (int tick = 1; tick <= 400; tick++) {
			double prevH = h;
			double prevY = y;
			h += vh;
			y += vy;
			vh *= DRAG;
			vy = vy * DRAG - GRAVITY;
			if (h >= horizDist) {
				double k = (horizDist - prevH) / (h - prevH);
				return new double[] {prevY + (y - prevY) * k, (tick - 1) + k};
			}
		}
		// Не долетел даже за 400 тиков (слишком далеко/слабое натяжение):
		// вернём что есть — решатель задвинет прицел максимально вверх
		return new double[] {y, 400.0};
	}

	/** Текущая лаг-компенсация в тиках: базовая интерполяция + реальный пинг.
	 * Пинг берём из таба (PlayerListEntry), мс переводим в тики (1 тик = 50 мс). */
	private static double getLagTicks(MinecraftClient client) {
		if (client.getNetworkHandler() != null && client.player != null) {
			PlayerListEntry entry = client.getNetworkHandler().getPlayerListEntry(client.player.getUuid());
			if (entry != null) {
				return LAG_TICKS_BASE + entry.getLatency() / 50.0;
			}
		}
		return LAG_TICKS_BASE;
	}

	/** Удаляет из памяти игроков, ушедших дальше TRACK_DROP_DIST. */
	private void cleanupFarPlayers(MinecraftClient client) {
		if (lastPositions.size() < 4) {
			return; // пары позиций — мелочь, уборка не нужна
		}
		ClientPlayerEntity self = client.player;
		lastPositions.entrySet().removeIf(entry -> {
			PlayerEntity entity = client.world.getPlayerByUuid(entry.getKey());
			return entity == null || self.squaredDistanceTo(entity) > TRACK_DROP_DIST_SQ;
		});
	}
}
