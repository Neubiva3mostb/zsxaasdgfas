package ru.neuclient.client.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * Короткая остановка игрока вокруг работы с инвентарём.
 *
 * ЗАЧЕМ.
 * Серверы отклоняют клики по слотам, пришедшие вместе с пакетом
 * движения: живой игрок сначала замирает, потом лезет в рюкзак.
 *
 * ================== ПОЧЕМУ ПРЕЖНЯЯ ВЕРСИЯ НЕ РАБОТАЛА ==================
 *
 * Она была флагом «погасить ближайший ввод», а сам клик уходил СРАЗУ.
 * Порядок внутри клиентского тика такой:
 *
 *   START_CLIENT_TICK        → боевые модули
 *   ClientPlayerEntity#tick
 *        tickMovement → input.tick()      ← здесь читается пауза
 *        sendMovementPackets()            ← здесь уходит пакет движения
 *   END_CLIENT_TICK          → обычные модули (AutoSwap, AutoTotem…)
 *
 * Свапперы тикают в КОНЦЕ тика (см. ModuleManager#isCombatTicked — там
 * только аура, аимбот и триггербот). Значит на тике N клик улетал уже
 * ПОСЛЕ пакета бегущего игрока, а флаг гасил ввод только на тике N+1.
 * Клик и «стоячий» пакет физически не могли встретиться — сервер видел
 * ровно то, от чего защищались: работу с инвентарём на полном бегу.
 *
 * Вторая половина проблемы: обнуления ввода мало. travel() применяет к
 * уже накопленной скорости только трение (×0.91 за тик), поэтому игрок
 * за «стоп-тик» проезжал ~91 % расстояния, а флаг спринта не снимался
 * вовсе.
 *
 * ======================= КАК СДЕЛАНО СЕЙЧАС =======================
 *
 * Пауза стала планировщиком: модуль не кликает сам, а ОТДАЁТ действие
 * сюда через {@link #submit}. Дальше цикл на три тика:
 *
 *   тик N    модуль ставит действие в очередь            → ARMED
 *   тик N+1  input.tick() обнуляет ввод и снимает спринт → STOPPED,
 *            серверу уходит пакет СТОЯЩЕГО игрока,
 *            в конце тика (до модулей) выполняется клик
 *   тик N+2  ввод настоящий, спринт возвращается         → IDLE
 *
 * Серверу приходит человеческая картина: …бегу, бегу, ВСТАЛ (и снял
 * спринт), клик по слоту, побежал дальше. Клик гарантированно стоит
 * после «стоячего» пакета, а не до него.
 *
 * ПОЧЕМУ СПРИНТ СНИМАЕТСЯ ЧЕРЕЗ setSprinting, А НЕ ПАКЕТОМ ВРУЧНУЮ.
 * Ваниль сама шлёт STOP_SPRINTING, увидев смену флага, и сама же
 * возвращает спринт, пока зажата клавиша бега. Ручной пакет дал бы
 * дубль и рассинхрон с клиентской симуляцией.
 *
 * ПОЧЕМУ СКОРОСТЬ НЕ ОБНУЛЯЕТСЯ НАСИЛЬНО. Живой игрок, отпустивший
 * клавиши, тормозит с коэффициентом 0.91, а не в ноль. Мгновенная
 * потеря всей инерции невозможна для человека, и prediction-античиты
 * (Grim) ловят её как рассинхрон симуляции.
 *
 * ОЧЕРЕДЬ, А НЕ СЧЁТЧИК. Если действий пришло несколько, каждое
 * получает свой цикл остановки. Очередь всегда убывает (по одному за
 * цикл) и полностью чистится в {@link #reset}, поэтому «залипнуть»,
 * как это делал прежний счётчик пауз инвентаря, ей нечем.
 */
public final class SwapPause {

	/** Разумный потолок очереди: столько действий подряд не бывает. */
	private static final int MAX_QUEUE = 8;
	/**
	 * Сколько тиков ждать прохода ввода, прежде чем выполнить действие
	 * без паузы. Страховка на случай, когда input.tick() не вызывается
	 * вовсе (игра на паузе, игрок ещё не заспавнился): предмет должен
	 * доехать в любом случае, зависнуть в очереди он не имеет права.
	 */
	private static final int ARM_TIMEOUT_TICKS = 4;

	/** Стадия цикла остановки. */
	private enum Phase {
		/** Ничего не запрошено. */
		IDLE,
		/** Действие ждёт ближайшего прохода ввода. */
		ARMED,
		/** Ввод обнулён в этом тике — в конце тика выполняем действие. */
		STOPPED,
		/** Действие выполнено, на следующем тике возвращаем спринт. */
		RESTORING
	}

	private static volatile Phase phase = Phase.IDLE;
	private static final Deque<Runnable> queue = new ArrayDeque<>();
	private static int armedTicks;
	private static boolean wasSprinting;
	private static boolean running;

	private SwapPause() {
	}

	/**
	 * Поставить действие с инвентарём в очередь на исполнение «стоя».
	 *
	 * Действие (клик по слоту, смена выбранной ячейки) выполнится через
	 * тик — сразу после того, как серверу уйдёт пакет стоящего игрока,
	 * и ДО тика модулей, чтобы они уже видели результат.
	 *
	 * @return true — принято в очередь; false — очередь переполнена и
	 *         действие выполнено немедленно, без паузы (лучше без
	 *         остановки, чем потерять предмет)
	 */
	public static boolean submit(Runnable action) {
		if (action == null) {
			return false;
		}
		if (queue.size() >= MAX_QUEUE) {
			run(action);
			return false;
		}
		queue.addLast(action);
		if (phase == Phase.IDLE) {
			phase = Phase.ARMED;
			armedTicks = 0;
		}
		return true;
	}

	/**
	 * Есть ли ещё НЕВЫПОЛНЕННЫЕ отложенные действия.
	 *
	 * Модули со своими автоматами состояний обязаны пропускать тик,
	 * пока это true: их следующий шаг рассчитан на уже переложенный
	 * предмет, а он переложится только в конце цикла.
	 *
	 * В фазе RESTORING с пустой очередью занятости уже нет: клик
	 * выполнен в начале этого же тика (SwapPause#tick идёт до тика
	 * модулей), клиентский инвентарь обновлён, и предмет можно
	 * использовать прямо сейчас — ждать возврата спринта незачем.
	 * Иначе каждое действие стоило бы 100 мс вместо 50.
	 */
	public static boolean isBusy() {
		return !queue.isEmpty() || phase == Phase.ARMED || phase == Phase.STOPPED;
	}

	/**
	 * Прочитать запрос остановки. Зовётся ровно один раз за проход
	 * KeyboardInput#tick из KeyboardInputMixin.
	 *
	 * Здесь же снимается спринт: мы находимся внутри tickMovement, то
	 * есть до sendMovementPackets, — ваниль успеет отправить серверу
	 * STOP_SPRINTING в этом же тике.
	 *
	 * @return true, если этот проход ввода нужно обнулить
	 */
	public static boolean consumeForInputTick() {
		if (phase != Phase.ARMED) {
			return false;
		}
		phase = Phase.STOPPED;
		stopSprint();
		return true;
	}

	/**
	 * Идёт ли прямо сейчас тик остановки (ввод обнулён, спринт снят).
	 *
	 * Нужен AutoSprint: он тикает в конце тика и иначе вернул бы спринт
	 * ровно в тот тик, в котором мы его сняли, — как это было с критами
	 * ауры.
	 */
	public static boolean isStopping() {
		return phase == Phase.STOPPED;
	}

	/**
	 * Тик планировщика. Зовётся в начале ModuleManager#tick, то есть в
	 * КОНЦЕ клиентского тика (пакет движения уже улетел) и ДО тика
	 * модулей (они увидят результат действия сразу).
	 */
	public static void tick() {
		ClientPlayerEntity player = player();
		if (player == null) {
			reset();
			return;
		}

		switch (phase) {
			case STOPPED -> {
				// Пакет стоящего игрока ушёл — самое время для клика.
				Runnable action = queue.pollFirst();
				if (action != null) {
					run(action);
				}
				phase = Phase.RESTORING;
			}
			case ARMED -> {
				// Проход ввода почему-то не случился — не держим предмет
				// в очереди вечно.
				if (++armedTicks > ARM_TIMEOUT_TICKS) {
					Runnable action = queue.pollFirst();
					if (action != null) {
						run(action);
					}
					phase = Phase.RESTORING;
				}
			}
			case RESTORING -> {
				restoreSprint(player);
				if (queue.isEmpty()) {
					phase = Phase.IDLE;
				} else {
					// Следующее действие получает свою собственную
					// остановку: пачка кликов в одном тике выглядела бы
					// для сервера ещё хуже, чем клик на бегу.
					phase = Phase.ARMED;
					armedTicks = 0;
				}
			}
			default -> {
			}
		}
	}

	/** Полный сброс (смена мира, .panic, выключение модуля). */
	public static void reset() {
		queue.clear();
		phase = Phase.IDLE;
		armedTicks = 0;
		wasSprinting = false;
	}

	// ===================== Внутреннее =====================

	/**
	 * Флаг «мы прямо сейчас внутри отложенного действия».
	 *
	 * Нужен перехватчику пакетов InvMove: клик, который отправляет сам
	 * планировщик, повторно откладывать нельзя — он бы кружил вечно.
	 */
	public static boolean isRunning() {
		return running;
	}

	private static void run(Runnable action) {
		running = true;
		try {
			action.run();
		} catch (Throwable t) {
			ru.neuclient.client.NeuClient.LOGGER.error(
					"[NeuClient] Ошибка отложенного действия с инвентарём", t);
		} finally {
			running = false;
		}
	}

	/**
	 * Снять спринт на время остановки.
	 * Флаг меняем у сущности — пакет ваниль отправит сама.
	 */
	private static void stopSprint() {
		ClientPlayerEntity player = player();
		wasSprinting = player != null && player.isSprinting();
		if (wasSprinting) {
			player.setSprinting(false);
		}
	}

	/**
	 * Вернуть спринт после остановки.
	 *
	 * Обычно это уже сделала ваниль (клавиша бега всё ещё зажата) или
	 * AutoSprint — здесь только страховка для случая, когда спринт был
	 * включён программно. Возвращаем лишь при реальном движении: спринт
	 * без движения вперёд сервер не принимает.
	 */
	private static void restoreSprint(ClientPlayerEntity player) {
		if (wasSprinting && !player.isSprinting() && MoveUtil.isMoving(player)) {
			player.setSprinting(true);
		}
		wasSprinting = false;
	}

	private static ClientPlayerEntity player() {
		MinecraftClient client = MinecraftClient.getInstance();
		return client == null ? null : client.player;
	}
}
