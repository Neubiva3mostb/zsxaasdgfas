package ru.neuclient.client.module.impl.combat;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ShieldItem;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.util.InventoryUtil;
import ru.neuclient.client.util.SwapUtil;

/**
 * ShieldBreaker — сбивает щит противника топором, по-легитному и НЕ в один тик.
 *
 * Если цель ПРЯМО СЕЙЧАС блокирует щитом, ванильный удар откладывается,
 * и вся связка разносится по тикам — ровно как делал бы живой игрок:
 *  - тик N:   топор легитно берётся в руку (выбор слота хотбара с мгновенной
 *             синкой серверу, либо свап инвентарь↔хотбар), удар отменяется;
 *  - тик N+1: модуль сам выполняет отложенный удар уже топором;
 *  - тик N+2: слот/предметы возвращаются, как было до связки.
 *
 * Если игрок держит ЛКМ и на тике N+1 ваниль сама бьёт (топор уже в руке),
 * отложенный удар отменяем — двойных пакетов не будет.
 * Работает и с ручными ударами, и с ударами AimBot/TriggerBot.
 */
public class ShieldBreakerModule extends Module {

	/** Цель отложенного на тик удара (null = нет отложенного удара). */
	private Entity pendingTarget;
	/** true = на этом тике надо вернуть слот/предметы обратно. */
	private boolean restorePending;
	/** Слот хотбара, который надо вернуть после связки (-1 = не меняли). */
	private int restoreSlot = -1;
	/** Слот инвентаря, с которым делали свап (-1 = свапа не было). */
	private int restoreInvSlot = -1;
	/** true = attackEntity сейчас вызван нами самими (защита от рекурсии). */
	private boolean processing;

	public ShieldBreakerModule() {
		super("ShieldBreaker", "Ломает щит при ударе", Category.COMBAT);
	}

	/** Занят ли модуль своей связкой (свой удар/ожидание) — другим не лезть. */
	public boolean isBusy() {
		return processing || pendingTarget != null;
	}

	/**
	 * HEAD миксина атаки.
	 * @return true — удар надо отменить (мы выполним его топором на следующем тике).
	 */
	public boolean onAttackStart(PlayerEntity player, Entity target) {
		if (processing) {
			return false; // наш собственный вызов — пропускаем без новых свапов
		}

		// Цель — живое существо, которое СЕЙЧАС стоит в блоке именно щитом
		if (!(target instanceof LivingEntity living) || !living.isBlocking()) {
			return false;
		}
		if (!(living.getBlockingItem().getItem() instanceof ShieldItem)) {
			return false;
		}

		PlayerInventory inv = player.getInventory();
		int current = inv.getSelectedSlot();
		if (inv.getStack(current).getItem() instanceof AxeItem) {
			// Топор уже в руке: если ждали наш удар — ванильный удар идёт сам,
			// отложенный отменяем, возврат предметов запланирован
			if (pendingTarget != null) {
				pendingTarget = null;
				restorePending = true;
			}
			return false;
		}

		// Ищем топор: сначала хотбар (переключение слота с мгновенной синкой
		// серверу; остановка на один тик берётся внутри selectSlot)…
		int hotbarAxe = InventoryUtil.findInHotbar(player, s -> s.getItem() instanceof AxeItem);
		if (hotbarAxe >= 0) {
			InventoryUtil.selectSlot(player, hotbarAxe, mc.interactionManager);
			restoreSlot = current;
		} else {
			// …потом глубокий инвентарь. Единый механизм клиента (SwapUtil):
			// три клика PICKUP прямо из мира, без открытия экрана. Остановка
			// та же самая. Топор меняется местами с текущей ячейкой хотбара.
			int inventoryAxe = InventoryUtil.findInInventory(player, s -> s.getItem() instanceof AxeItem);
			if (inventoryAxe < 0 || mc.interactionManager == null) {
				return false; // топора нет вовсе — бьём чем есть
			}
			int currentSlot = player.getInventory().getSelectedSlot();
			if (!SwapUtil.swapToHotbar(mc, player, inventoryAxe, currentSlot)) {
				return false;
			}
			restoreInvSlot = inventoryAxe; // откат тем же свапом
		}

		// Свап сделан — сам удар переносим на следующий тик (разносим по тикам)
		pendingTarget = target;
		return true;
	}

	@Override
	public void onTick(MinecraftClient client) {
		// Смена слота и свап уходят на сервер отложенно — на тик позже
		// вызова, вместе с пакетом стоящего игрока (см. SwapPause).
		// Ударить раньше, чем это отработало, значит ударить ещё старым
		// предметом: щит не пробьётся, а связка потратится впустую.
		if (ru.neuclient.client.util.SwapPause.isBusy()) {
			return;
		}

		// Шаг 1: исполняем отложенный удар уже с топором в руке
		if (pendingTarget != null) {
			Entity target = pendingTarget;
			pendingTarget = null;
			if (client.player != null && client.interactionManager != null && target.isAlive()) {
				processing = true;
				try {
					client.interactionManager.attackEntity(client.player, target);
				} finally {
					processing = false;
				}
			}
			restorePending = true; // возврат — следующим тиком
			return;
		}

		// Шаг 2: возвращаем слот/предметы, как было до связки
		if (restorePending) {
			restorePending = false;
			restore(client.player);
		}
	}

	/** Возврат слота/предметов после связки. */
	private void restore(PlayerEntity player) {
		if (player == null) {
			restoreSlot = -1;
			restoreInvSlot = -1;
			return;
		}
		if (restoreSlot >= 0) {
			InventoryUtil.selectSlot(player, restoreSlot, mc.interactionManager);
			restoreSlot = -1;
		}
		if (restoreInvSlot >= 0 && mc.interactionManager != null) {
			SwapUtil.swapToHotbar(mc, player, restoreInvSlot,
					player.getInventory().getSelectedSlot());
			restoreInvSlot = -1;
		}
	}


	@Override
	protected void onDisable() {
		pendingTarget = null;
		restorePending = false;
		restoreSlot = -1;
		restoreInvSlot = -1;
		processing = false;
	}
}
