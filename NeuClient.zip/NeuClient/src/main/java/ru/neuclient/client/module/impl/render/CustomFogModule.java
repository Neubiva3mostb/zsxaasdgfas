package ru.neuclient.client.module.impl.render;

import net.minecraft.client.MinecraftClient;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.ColorSetting;
import ru.neuclient.client.setting.NumberSetting;

/**
 * CustomFog — кастомный туман.
 */
public final class CustomFogModule extends Module {

    private final ColorSetting color = new ColorSetting("Цвет", 0xFF4A88FF);
    private final NumberSetting distance = new NumberSetting("Дальность", 64.0, 8.0, 512.0, 8.0);

    public CustomFogModule() {
        super("CustomFog", "Настраивает туман в мире", Category.RENDER);
        addSettings(color, distance);
    }

    public float getDistance() {
        return distance.get().floatValue();
    }

    public float getRed() {
        return color.getRed() / 255.0f;
    }

    public float getGreen() {
        return color.getGreen() / 255.0f;
    }

    public float getBlue() {
        return color.getBlue() / 255.0f;
    }

    public boolean shouldOverrideColor() {
        return isEnabled();
    }

    public static CustomFogModule get() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc == null) return null;
        ru.neuclient.client.NeuClient client = ru.neuclient.client.NeuClient.getInstance();
        if (client == null || client.getModuleManager() == null) return null;
        CustomFogModule module = client.getModuleManager().get(CustomFogModule.class);
        return module != null && module.isEnabled() ? module : null;
    }
}
