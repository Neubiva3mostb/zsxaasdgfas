package ru.neuclient.client.module.impl.player;

import net.minecraft.client.MinecraftClient;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.TextSetting;
import ru.neuclient.client.util.ChatUtil;

import java.util.Locale;

/**
 * Auto Auth — автоматический вход/регистрация на серверах с авторизацией.
 *
 * ИДЕЯ. На FunTime и подобных серверах при входе требует «/login <пароль>»
 * или «/reg <пароль> <пароль>», и каждый раз печатать это вручную утомляет.
 * Модуль следит за чатом и по характерным фразам/командам в сообщении сам
 * отправляет нужную команду с заранее заданным паролем.
 *
 * ДВА ПАРОЛЯ. «Пароль авторизации» уходит с /login по подсказкам входа
 * («авторизуйтесь», «войдите в игру», «/login»), «Пароль регистрации» —
 * с /reg по подсказкам регистрации («зарегистрируйтесь», «/reg»,
 * «/register»). Поле с пустым паролем просто не триггерится: если игрок
 * зарегистрирован, подсказка регистрации ему не страшна.
 *
 * ЗАДЕРЖКА ОТПРАВКИ. Сообщение-подсказка может прийти раньше, чем сервер
 * примет команды (мир ещё грузится). Команда ставится в очередь и уходит
 * не сразу: ждём появления игрока в мире и короткую паузу (500 мс), чтобы
 * сервер успел «договорить». Повторная подсказка в течение 2.5 секунд
 * после отправки игнорируется — иначе цикл «подсказка → отправка → снова
 * та же подсказка в логе» мог бы заспамить чат командами.
 *
 * ХУК. Сообщения приходят из ChatHudMixin (как у AutoAccept): там виден
 * любой текст, который сервер показал в чате, в виде сырой строки.
 */
public final class AutoAuthModule extends Module {

	/** Пауза между получением подсказки и отправкой команды, мс. */
	private static final long SEND_DELAY_MS = 500L;
	/** Анти-спам: не реагируем на подсказки чаще, чем раз в этот интервал. */
	private static final long REPEAT_GUARD_MS = 2500L;

	/** Пароль для /login. */
	private final TextSetting loginPassword = new TextSetting("Пароль авторизации", "", 32);
	/** Пароль для /reg. */
	private final TextSetting regPassword = new TextSetting("Пароль регистрации", "", 32);

	/** Отложенная команда («/login ...» или «/reg ...»), ждёт своего тика. */
	private String pendingCommand;
	/** Когда пришла подсказка, по которой поставлена очередь. */
	private long promptAt;
	/** Когда в последний раз реально отправляли команду. */
	private long lastSentAt;

	public AutoAuthModule() {
		super("Auto Auth", "Автоматически вводит пароль при авторизации и регистрации", Category.PLAYER);
		addSettings(loginPassword, regPassword);
	}

	/**
	 * Хук из ChatHudMixin для входящих сообщений сервера.
	 * Разбираем сырой текст (без цветовых кодов — getString их уже снимает).
	 */
	public void onChatMessage(String rawMessage) {
		if (!isEnabled() || rawMessage == null || rawMessage.isBlank()) {
			return;
		}
		String lower = rawMessage.toLowerCase(Locale.ROOT);

		// Подсказки регистрации → /reg <пароль регистрации>.
		if ((lower.contains("зарегистрируйтесь") || lower.contains("зарегистрируйся")
				|| lower.contains("/reg ") || lower.contains("/reg")
				|| lower.contains("/register"))
				&& !regPassword.get().isEmpty()) {
			queue("/reg " + regPassword.get());
		}
		// Подсказки входа → /login <пароль авторизации>.
		if ((lower.contains("авторизуйтесь") || lower.contains("авторизуйся")
				|| lower.contains("войдите в игру") || lower.contains("авторизация")
				|| lower.contains("/login"))
				&& !loginPassword.get().isEmpty()) {
			queue("/login " + loginPassword.get());
		}
	}

	@Override
	public void onTick(MinecraftClient client) {
		String command = pendingCommand;
		if (command == null) {
			return;
		}
		if (client.player == null || client.getNetworkHandler() == null) {
			return; // мир ещё не загрузился — ждём
		}
		long now = System.currentTimeMillis();
		if (now - promptAt < SEND_DELAY_MS) {
			return; // даём серверу «договорить»
		}

		// sendChatCommand принимает команду без ведущего слеша.
		client.getNetworkHandler().sendChatCommand(command.substring(1));
		ChatUtil.send("AutoAuth: отправлено «" + command + "»");
		pendingCommand = null;
		lastSentAt = now;
	}

	/** Поставить команду в очередь (с защитой от повторных срабатываний). */
	private void queue(String command) {
		if (command.equals(pendingCommand)) {
			return; // уже ждёт отправки
		}
		if (System.currentTimeMillis() - lastSentAt < REPEAT_GUARD_MS) {
			return; // только что отправляли — это повтор той же подсказки
		}
		pendingCommand = command;
		promptAt = System.currentTimeMillis();
	}

	@Override
	protected void onDisable() {
		pendingCommand = null;
	}

	/** Хук-доступ для ChatHudMixin: включённый экземпляр или null. */
	public static AutoAuthModule active() {
		NeuClient client = NeuClient.getInstance();
		if (client == null || client.getModuleManager() == null) {
			return null;
		}
		AutoAuthModule module = client.getModuleManager().get(AutoAuthModule.class);
		return module != null && module.isEnabled() ? module : null;
	}
}
