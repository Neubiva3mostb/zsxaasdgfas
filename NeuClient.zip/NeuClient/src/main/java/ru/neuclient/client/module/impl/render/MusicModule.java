package ru.neuclient.client.module.impl.render;

import net.minecraft.client.util.InputUtil;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.KeyBindSetting;
import ru.neuclient.client.util.MediaBridge;

/**
 * Music — медиа-плеер в HUD: трек из Spotify / Яндекс Музыки / любого
 * плеера Windows (системные медиа-контролы) + бинды управления:
 * пауза/play, предыдущий и следующий трек (системные медиа-клавиши,
 * работают даже когда игра в фоне… нет — когда игра в фокусе; плееру
 * всё равно, откуда пришла клавиша).
 */
public final class MusicModule extends Module {

	private final KeyBindSetting pauseKey = new KeyBindSetting("Пауза/Play", KeyBindSetting.NONE);
	private final KeyBindSetting prevKey = new KeyBindSetting("Предыдущий", KeyBindSetting.NONE);
	private final KeyBindSetting nextKey = new KeyBindSetting("Следующий", KeyBindSetting.NONE);

	/** Состояние клавиш с прошлого тика (детект фронта нажатия). */
	private boolean lastPause;
	private boolean lastPrev;
	private boolean lastNext;

	public MusicModule() {
		super("Music", "Трек в HUD + управление плеером", Category.RENDER);
		addSettings(pauseKey, prevKey, nextKey);
	}

	@Override
	protected void onEnable() {
		MediaBridge.get().ensureStarted();
	}

	@Override
	public void onTick(net.minecraft.client.MinecraftClient client) {
		if (client.getWindow() == null) {
			return;
		}
		MediaBridge bridge = MediaBridge.get();
		bridge.ensureStarted();
		bridge.tickKeepAlive();

		// В ClickGUI/инвентаре/чате бинды плеера не срабатывают
		// (и фронт сбрасывается, чтобы после закрытия не выстрелило)
		boolean blocked = blockingScreen(client);
		boolean pause = !blocked && pressed(client, pauseKey.get());
		boolean prev = !blocked && pressed(client, prevKey.get());
		boolean next = !blocked && pressed(client, nextKey.get());

		if (pause && !lastPause) {
			bridge.sendCommand("playpause");
		}
		if (prev && !lastPrev) {
			bridge.sendCommand("prev");
		}
		if (next && !lastNext) {
			bridge.sendCommand("next");
		}
		lastPause = pause;
		lastPrev = prev;
		lastNext = next;
	}

	private static boolean pressed(net.minecraft.client.MinecraftClient client, int key) {
		return key != KeyBindSetting.NONE && InputUtil.isKeyPressed(client.getWindow(), key);
	}
}
