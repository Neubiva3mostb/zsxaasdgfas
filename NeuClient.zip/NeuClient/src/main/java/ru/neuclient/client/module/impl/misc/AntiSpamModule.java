package ru.neuclient.client.module.impl.misc;

import net.minecraft.text.Text;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;

import java.util.LinkedHashMap;

/**
 * AntiSpam — схлопывает одинаковые сообщения чата в одну строку.
 *
 * Раньше модуль дописывал счётчик к каждому повтору, но строк всё равно
 * становилось много. Теперь повтор НЕ выводится отдельной строкой: он
 * подавляется, а уже показанное сообщение обновляет счётчик «[n]» на месте.
 * В итоге десять одинаковых строк превращаются в одну «сообщение [10]».
 *
 * Сравнение по нормализованному ключу: без цветовых кодов §/&, лишних
 * пробелов, в нижнем регистре. Цифры значимы — реклама с разными ценами
 * считается разными сообщениями.
 *
 * Окно повтора — 30 секунд: если сообщение не повторялось полминуты,
 * следующее снова пойдёт как новое (со счётчика 1).
 *
 * ВАЖНО. Меняется только отображение: история команд, входящие пакеты и
 * логика клиента (AutoAccept и т.п.) работают по-прежнему.
 */
public final class AntiSpamModule extends Module {

	/** Окно, внутри которого одинаковое сообщение считается повтором. */
	private static final long WINDOW_MS = 30_000L;

	private static final int MAX_KEYS = 256;

	/** Ключ -> время последнего повтора. */
	private final LinkedHashMap<String, Long> seen = new LinkedHashMap<>();
	/** Ключ -> сколько раз сообщение уже приходило. */
	private final LinkedHashMap<String, Integer> counts = new LinkedHashMap<>();

	public AntiSpamModule() {
		super("AntiSpam", "Не даёт даунам спамить", Category.MISC);
	}

	@Override
	protected void onEnable() {
		seen.clear();
		counts.clear();
	}

	@Override
	protected void onDisable() {
		seen.clear();
		counts.clear();
	}

	/**
	 * Учитывает сообщение и возвращает его номер повтора.
	 *
	 * @return 1 — первое сообщение (показывать как обычно);
	 *         >=2 — повтор (нужно подавить и обновить существующую строку);
	 *         если модуль выключен, всегда 1.
	 */
	public static int onMessage(Text message) {
		try {
			if (message == null) {
				return 1;
			}
			NeuClient owner = NeuClient.getInstance();
			if (owner == null || owner.getModuleManager() == null) {
				return 1;
			}
			AntiSpamModule self = owner.getModuleManager().get(AntiSpamModule.class);
			if (self == null || !self.isEnabled()) {
				return 1;
			}
			return self.track(message);
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка AntiSpam", t);
			return 1;
		}
	}

	private int track(Text message) {
		String key = normalize(message.getString());
		if (key.isEmpty()) {
			return 1;
		}
		long now = System.currentTimeMillis();
		Long last = seen.get(key);
		boolean fresh = last == null || now - last > WINDOW_MS;
		int count = fresh ? 1 : counts.getOrDefault(key, 1) + 1;

		seen.remove(key);
		seen.put(key, now);
		counts.remove(key);
		counts.put(key, count);
		trimIfNeeded();
		return count;
	}

	/** Ключ сравнения для исходящего сообщения (без хвостового счётчика). */
	public static String keyOf(Text message) {
		return message == null ? "" : normalize(stripCounter(message.getString()));
	}

	/** Ключ сравнения для уже показанной строки (у неё может быть «[n]» в конце). */
	public static String keyOfLine(Text lineContent) {
		return lineContent == null ? "" : normalize(stripCounter(lineContent.getString()));
	}

	/** Убирает хвостовой счётчик « [123]», чтобы ключ строки совпал с ключом сообщения. */
	private static String stripCounter(String s) {
		if (s == null) {
			return "";
		}
		return s.replaceAll("\\s*\\[\\d+\\]\\s*$", "");
	}

	/** Ключ сравнения: без цветов, лишних пробелов, в нижнем регистре. */
	private static String normalize(String text) {
		if (text == null) {
			return "";
		}
		StringBuilder sb = new StringBuilder(text.length());
		boolean space = false;
		for (int i = 0; i < text.length(); i++) {
			char c = text.charAt(i);
			if (c == '§' || c == '&') {
				i++;
				continue;
			}
			if (Character.isWhitespace(c)) {
				space = true;
				continue;
			}
			if (space && sb.length() > 0) {
				sb.append(' ');
				space = false;
			}
			sb.append(Character.toLowerCase(c));
		}
		return sb.toString();
	}

	private void trimIfNeeded() {
		while (seen.size() > MAX_KEYS) {
			String oldest = seen.keySet().iterator().next();
			seen.remove(oldest);
			counts.remove(oldest);
		}
	}
}
