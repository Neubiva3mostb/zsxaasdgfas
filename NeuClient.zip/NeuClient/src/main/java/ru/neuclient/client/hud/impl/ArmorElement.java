package ru.neuclient.client.hud.impl;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.ItemStack;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.font.MsdfFontRenderer;
import ru.neuclient.client.font.MsdfFonts;
import ru.neuclient.client.hud.HudElement;
import ru.neuclient.client.util.RenderUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Виджет «Броня» NeuClient:
 *  - Шапка «Броня»
 *  - Предметы экипировки с иконкой и процентом прочности
 */
public class ArmorElement extends HudElement {

	private static final EquipmentSlot[] ORDER = {
			EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
	};

	private static final float HEADER_H = 13.5f;
	private static final float ROW_H = 15.0f;
	private static final float ROW_STEP = 17.0f;
	private static final float FONT_SIZE = 6.5f;

	public ArmorElement() {
		super("armor", 4, 94);
	}

	@Override
	protected int getDefaultX() {
		return 4;
	}

	@Override
	protected int getDefaultY() {
		return 200;
	}

	@Override
	protected void drawElement(DrawContext ctx, boolean editing) {
		List<ItemStack> pieces = new ArrayList<>();
		if (mc.player != null) {
			for (EquipmentSlot slot : ORDER) {
				ItemStack stack = mc.player.getEquippedStack(slot);
				if (!stack.isEmpty()) {
					pieces.add(stack);
				}
			}
		}

		if (pieces.isEmpty() && !editing) {
			this.width = 0;
			this.height = 0;
			return;
		}

		var textFont = MsdfFonts.sfMedium();
		float targetWidth = MsdfFontRenderer.getWidth(textFont, "Броня", FONT_SIZE) + 16.0f;

		for (ItemStack stack : pieces) {
			String pct = percentOf(stack);
			float rowW = 20.0f + 14.0f + MsdfFontRenderer.getWidth(textFont, pct, FONT_SIZE) + 8.0f;
			targetWidth = Math.max(targetWidth, rowW);
		}

		this.width = (int) Math.ceil(targetWidth);
		int rowsCount = editing && pieces.isEmpty() ? 1 : pieces.size();
		this.height = (int) Math.ceil(HEADER_H + 3.0f + rowsCount * ROW_STEP);

		int x = getX();
		int y = getY();
		var im = NeuClient.getInstance().getInterfaceModule();
		int accent = im != null ? im.getArmorColor() : RenderUtil.accent();
		int bg = 0xEE0B0B16;

		// Заголовок
		RenderUtil.roundRect(ctx, x, y, width, (int) HEADER_H, 4, bg);
		RenderUtil.roundBorderEdge(ctx, x, y, width, (int) HEADER_H, 4, withAlpha(accent, 0.33f));

		float headerTextY = y + (HEADER_H - FONT_SIZE) / 2.0f - 0.5f;
		MsdfFontRenderer.drawWithShadow(ctx, textFont, "Броня", x + 6.0f, headerTextY, 0xFFFFFFFF, FONT_SIZE);

		// Предметы
		float contentY = y + HEADER_H + 3.0f;

		if (pieces.isEmpty() && editing) {
			RenderUtil.roundRect(ctx, x, (int) contentY, width, (int) ROW_H, 4, bg);
			MsdfFontRenderer.drawWithShadow(ctx, textFont, "Нет брони", x + 6, contentY + 4,
					withAlpha(0xFFFFFFFF, 0x66), FONT_SIZE);
			return;
		}

		for (ItemStack stack : pieces) {
			RenderUtil.roundRect(ctx, x, (int) contentY, width, (int) ROW_H, 4, bg);
			RenderUtil.roundBorderEdge(ctx, x, (int) contentY, width, (int) ROW_H, 4, withAlpha(accent, 0.22f));

			// Иконка предмета
			ctx.getMatrices().pushMatrix();
			ctx.getMatrices().translate(x + 3, contentY + 1.5f);
			ctx.getMatrices().scale(0.7f, 0.7f);
			ctx.drawItem(stack, 0, 0);
			ctx.getMatrices().popMatrix();

			// Процент
			String pct = percentOf(stack);
			float pctY = contentY + (ROW_H - FONT_SIZE) / 2.0f - 0.5f;
			MsdfFontRenderer.drawWithShadow(ctx, textFont, pct, x + 20, pctY, accent, FONT_SIZE);

			contentY += ROW_STEP;
		}
	}

	private String percentOf(ItemStack stack) {
		if (!stack.isDamageable() || stack.getMaxDamage() <= 0) {
			return "100%";
		}
		int left = stack.getMaxDamage() - stack.getDamage();
		return Math.max(0, left * 100 / stack.getMaxDamage()) + "%";
	}
}
