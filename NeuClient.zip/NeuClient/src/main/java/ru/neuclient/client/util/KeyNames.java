package ru.neuclient.client.util;

import org.lwjgl.glfw.GLFW;

import java.util.HashMap;
import java.util.Map;

/**
 * Переводит GLFW-коды клавиш в короткие читаемые имена
 * (для отображения биндов в ClickGUI и HUD).
 */
public final class KeyNames {

	/** Код "без бинда" по соглашению всего клиента. */
	public static final int NONE = -1;

	/** Спец-клавиши, для которых glfwGetKeyName возвращает null. */
	private static final Map<Integer, String> SPECIAL = new HashMap<>();

	static {
		SPECIAL.put(GLFW.GLFW_KEY_ESCAPE, "ESC");
		SPECIAL.put(GLFW.GLFW_KEY_RIGHT_SHIFT, "RSHIFT");
		SPECIAL.put(GLFW.GLFW_KEY_LEFT_SHIFT, "LSHIFT");
		SPECIAL.put(GLFW.GLFW_KEY_RIGHT_CONTROL, "RCTRL");
		SPECIAL.put(GLFW.GLFW_KEY_LEFT_CONTROL, "LCTRL");
		SPECIAL.put(GLFW.GLFW_KEY_RIGHT_ALT, "RALT");
		SPECIAL.put(GLFW.GLFW_KEY_LEFT_ALT, "LALT");
		SPECIAL.put(GLFW.GLFW_KEY_SPACE, "SPACE");
		SPECIAL.put(GLFW.GLFW_KEY_ENTER, "ENTER");
		SPECIAL.put(GLFW.GLFW_KEY_TAB, "TAB");
		SPECIAL.put(GLFW.GLFW_KEY_BACKSPACE, "BACKSPACE");
		SPECIAL.put(GLFW.GLFW_KEY_UP, "UP");
		SPECIAL.put(GLFW.GLFW_KEY_DOWN, "DOWN");
		SPECIAL.put(GLFW.GLFW_KEY_LEFT, "LEFT");
		SPECIAL.put(GLFW.GLFW_KEY_RIGHT, "RIGHT");
		SPECIAL.put(GLFW.GLFW_KEY_CAPS_LOCK, "CAPS");
		SPECIAL.put(GLFW.GLFW_KEY_INSERT, "INSERT");
		SPECIAL.put(GLFW.GLFW_KEY_DELETE, "DEL");
		SPECIAL.put(GLFW.GLFW_KEY_HOME, "HOME");
		SPECIAL.put(GLFW.GLFW_KEY_END, "END");
		SPECIAL.put(GLFW.GLFW_KEY_PAGE_UP, "PGUP");
		SPECIAL.put(GLFW.GLFW_KEY_PAGE_DOWN, "PGDN");
		for (int i = 0; i <= 9; i++) {
			SPECIAL.put(GLFW.GLFW_KEY_KP_0 + i, "NUM" + i);
		}
		for (int i = 1; i <= 12; i++) {
			SPECIAL.put(GLFW.GLFW_KEY_F1 + i - 1, "F" + i);
		}
	}

	private KeyNames() {
	}

	/** Короткое имя клавиши; для отсутствующего бинда — "NONE". */
	public static String getName(int keyCode) {
		if (keyCode == NONE || keyCode == GLFW.GLFW_KEY_UNKNOWN) {
			return "NONE";
		}
		// Коды 1–7 в GLFW заняты кнопками мыши (клавиатура начинается с 32).
		String mouse = mouseName(keyCode);
		if (mouse != null) {
			return mouse;
		}
		String name = GLFW.glfwGetKeyName(keyCode, 0);
		if (name != null && !name.isEmpty()) {
			return name.toUpperCase(Locale());
		}
		return "KEY_" + keyCode;
	}

	/**
	 * Имя кнопки мыши для биндов («СКМ» — нажатие колеса) или null,
	 * если код — не кнопка мыши. ЛКМ (0) не используем: её код совпадает
	 * с GLFW_KEY_UNKNOWN, который занят под «нет бинда».
	 */
	public static String mouseName(int code) {
		return switch (code) {
			case GLFW.GLFW_MOUSE_BUTTON_RIGHT -> "ПКМ";
			case GLFW.GLFW_MOUSE_BUTTON_MIDDLE -> "СКМ";
			case 3 -> "МС4";
			case 4 -> "МС5";
			case 5 -> "МС6";
			case 6 -> "МС7";
			case 7 -> "МС8";
			default -> null;
		};
	}

	/** Это код кнопки мыши, а не клавиши? */
	public static boolean isMouse(int code) {
		return mouseName(code) != null;
	}

	private static java.util.Locale Locale() {
		return java.util.Locale.ROOT;
	}
}
