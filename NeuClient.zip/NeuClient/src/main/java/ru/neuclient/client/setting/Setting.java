package ru.neuclient.client.setting;

import com.google.gson.JsonElement;

/**
 * Базовый класс настройки модуля.
 * Умеет сериализоваться в JSON (для конфигов) и вызывать слушателя изменений.
 *
 * @param <T> тип значения настройки
 */
public abstract class Setting<T> {

	private final String name;
	private final T defaultValue;
	private T value;

	/** Опциональный слушатель (используется, например, темой HUD). */
	private Runnable changeListener;

	/**
	 * Условие видимости настройки в ClickGUI (null — видна всегда).
	 *
	 * Нужно модулям с режимами: например, у AttackAura настройки Legit
	 * не имеют смысла в режиме SpookyTime и наоборот. Скрытая настройка
	 * продолжает жить и сохраняться в конфиг — прячется только строка в GUI.
	 */
	private java.util.function.BooleanSupplier visibleWhen;

	protected Setting(String name, T defaultValue) {
		this.name = name;
		this.defaultValue = defaultValue;
		this.value = defaultValue;
	}

	public String getName() {
		return name;
	}

	public T get() {
		return value;
	}

	public T getDefault() {
		return defaultValue;
	}

	public void set(T newValue) {
		this.value = newValue;
		if (changeListener != null) {
			changeListener.run();
		}
		// Любое изменение параметра — повод обновить default.json
		ru.neuclient.client.module.Module.markConfigDirty();
	}

	/** Установка без вызова слушателя (нужно редко). */
	public void setSilent(T newValue) {
		this.value = newValue;
	}

	public Setting<T> onChange(Runnable listener) {
		this.changeListener = listener;
		return this;
	}

	/** Показывать настройку только когда условие истинно. */
	public Setting<T> visibleWhen(java.util.function.BooleanSupplier condition) {
		this.visibleWhen = condition;
		return this;
	}

	/** Видна ли настройка сейчас (для отрисовки в ClickGUI). */
	public boolean isVisible() {
		return visibleWhen == null || visibleWhen.getAsBoolean();
	}

	/** Значение в JSON для сохранения в конфиг. */
	public abstract JsonElement toJson();

	/** Восстановление значения из JSON (с применением слушателя). */
	public abstract void fromJson(JsonElement element);
}
