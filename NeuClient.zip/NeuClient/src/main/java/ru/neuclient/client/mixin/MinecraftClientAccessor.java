package ru.neuclient.client.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.session.Session;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Доступ к приватному полю сессии клиента.
 * Нужен Alt Manager'у для оффлайн-смены ника: новая Session подставляется
 * в MinecraftClient, и игра дальше представляется новым именем.
 */
@Mixin(MinecraftClient.class)
public interface MinecraftClientAccessor {

	/**
	 * Поле final, поэтому связка @Mutable + @Accessor:
	 * Mixin снимает модификатор final при применении аксессора.
	 */
	@Mutable
	@Accessor("session")
	void pc$setSession(Session session);

	/**
	 * Кулдаун правой кнопки (ваниль ставит 4 тика после удачного ПКМ).
	 * NoDelay читает и обнуляет его в нужных контекстах.
	 */
	@Accessor("itemUseCooldown")
	int pc$getItemUseCooldown();

	@Accessor("itemUseCooldown")
	void pc$setItemUseCooldown(int value);
}
