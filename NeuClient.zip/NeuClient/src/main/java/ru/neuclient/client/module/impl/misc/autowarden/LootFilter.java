package ru.neuclient.client.module.impl.misc.autowarden;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.util.ClientPaths;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

/**
 * Фильтр лута AutoWarden: что забирать из сундуков вардена.
 * Сферы, талисманы, отмычки и топовые зелья лутаются всегда.
 */
public final class LootFilter {

	/** Запись фильтра: id, отображаемое имя, ванильный предмет (для иконки/сравнения) и ключевое слово в имени (для кастомных). */
	public record Entry(String id, String label, Item icon, String nameKey, boolean defaultOn) {}

	public static final List<Entry> ENTRIES = List.of(
		new Entry("netherite_pickaxe", "Незеритовая кирка", Items.NETHERITE_PICKAXE, null, true),
		new Entry("diamond_pickaxe", "Алмазная кирка", Items.DIAMOND_PICKAXE, null, true),
		new Entry("diamond_sword", "Алмазный меч", Items.DIAMOND_SWORD, null, false),
		new Entry("diamond_helmet", "Алмазный шлем", Items.DIAMOND_HELMET, null, false),
		new Entry("diamond_chestplate", "Алмазный нагрудник", Items.DIAMOND_CHESTPLATE, null, false),
		new Entry("diamond_leggings", "Алмазные поножи", Items.DIAMOND_LEGGINGS, null, false),
		new Entry("diamond_boots", "Алмазные ботинки", Items.DIAMOND_BOOTS, null, false),
		new Entry("netherite_sword", "Незеритовый меч", Items.NETHERITE_SWORD, null, true),
		new Entry("netherite_helmet", "Незеритовый шлем", Items.NETHERITE_HELMET, null, false),
		new Entry("netherite_chestplate", "Незеритовый нагрудник", Items.NETHERITE_CHESTPLATE, null, false),
		new Entry("netherite_leggings", "Незеритовые поножи", Items.NETHERITE_LEGGINGS, null, false),
		new Entry("netherite_boots", "Незеритовые ботинки", Items.NETHERITE_BOOTS, null, false),
		new Entry("arrow_light", "Световая стрела", Items.SPECTRAL_ARROW, "световая стрела", true),
		new Entry("arrow_pain", "Мучительная стрела", Items.TIPPED_ARROW, "мучительная стрела", true),
		new Entry("arrow_blood", "Кровавая стрела", Items.TIPPED_ARROW, "кровавая стрела", true),
		new Entry("arrow_heal", "Стрела терапии", Items.TIPPED_ARROW, "стрела терапии", true),
		new Entry("arrow_ice", "Стрела обледенения", Items.TIPPED_ARROW, "стрела обледенения", true),
		new Entry("arrow_zeus", "Стрела Зевса", Items.TIPPED_ARROW, "стрела зевса", true),
		new Entry("skin_sly", "Коварный скин", Items.PAPER, "коварный скин", true),
		new Entry("skin_ice", "Ледяной скин", Items.PAPER, "ледяной скин", true),
		new Entry("skin_cursed", "Проклятый скин", Items.PAPER, "проклятый скин", true),
		new Entry("skin_pain", "Мучительный скин", Items.PAPER, "мучительный скин", true),
		new Entry("skin_singular", "Сингулярный скин", Items.PAPER, "сингулярный скин", true),
		new Entry("skin_inevitable", "Неизбежный скин", Items.PAPER, "неизбежный скин", true),
		new Entry("skin_flame", "Пламенный скин", Items.PAPER, "пламенный скин", true),
		new Entry("skin_dragon", "Драконий скин", Items.PAPER, "драконий скин", true),
		new Entry("diamond", "Алмазы", Items.DIAMOND, null, true),
		new Entry("diamond_block", "Алмазный блок", Items.DIAMOND_BLOCK, null, true),
		new Entry("ender_pearl", "Эндер-жемчуг", Items.ENDER_PEARL, null, true),
		new Entry("xp_bottle", "Пузырёк опыта", Items.EXPERIENCE_BOTTLE, null, true),
		new Entry("copper_ingot", "Медный слиток", Items.COPPER_INGOT, null, false),
		new Entry("anvil", "Наковальня", Items.ANVIL, null, false),
		new Entry("plast", "Пласт", Items.DRIED_KELP, "пласт", true),
		new Entry("spider_eye", "Маринованный паучий глаз", Items.FERMENTED_SPIDER_EYE, null, false),
		new Entry("fire_ball", "Огенный шар", Items.FIRE_CHARGE, "огенный шар", true),
		new Entry("breeze_rod", "Вихревой стержень", Items.BREEZE_ROD, null, true),
		new Entry("shulker_egg", "Яйцо призыва шалкера", Items.SHULKER_SPAWN_EGG, null, true),
		new Entry("shulker_shell", "Панцирь шалкера", Items.SHULKER_SHELL, null, true),
		new Entry("leather", "Кожа", Items.LEATHER, null, false),
		// Головы мобов (голова игрока = сфера, лутается всегда отдельно)
		new Entry("skeleton_skull", "Голова скелета", Items.SKELETON_SKULL, null, true),
		new Entry("wither_skeleton_skull", "Голова визер-скелета", Items.WITHER_SKELETON_SKULL, null, true),
		new Entry("zombie_head", "Голова зомби", Items.ZOMBIE_HEAD, null, true),
		new Entry("creeper_head", "Голова крипера", Items.CREEPER_HEAD, null, true),
		new Entry("piglin_head", "Голова пиглина", Items.PIGLIN_HEAD, null, true),
		new Entry("dragon_head", "Голова дракона", Items.DRAGON_HEAD, null, true),
		// Ресурсы
		new Entry("gold_ingot", "Золотой слиток", Items.GOLD_INGOT, null, true),
		new Entry("emerald", "Изумруд", Items.EMERALD, null, true),
		new Entry("iron_ingot", "Железный слиток", Items.IRON_INGOT, null, true),
		new Entry("blaze_rod", "Огненный стержень", Items.BLAZE_ROD, null, true),
		new Entry("enchanted_book", "Чародейская книга", Items.ENCHANTED_BOOK, null, true),
		new Entry("beacon", "Маяк", Items.BEACON, null, true),
		new Entry("totem", "Тотем бессмертия", Items.TOTEM_OF_UNDYING, null, true),
		new Entry("enchanted_gapple", "Зачарованное золотое яблоко", Items.ENCHANTED_GOLDEN_APPLE, null, true),
		new Entry("gapple", "Золотое яблоко", Items.GOLDEN_APPLE, null, true),
		new Entry("reinforced_deepslate", "Укреплённый глубинный сланец", Items.REINFORCED_DEEPSLATE, null, true),
		new Entry("firework", "Фейрверк", Items.FIREWORK_ROCKET, null, true),
		new Entry("bookshelf", "Книжная полка", Items.BOOKSHELF, null, true),
		new Entry("nautilus_shell", "Раковина наутилуса", Items.NAUTILUS_SHELL, null, true),
		new Entry("elytra", "Элитры", Items.ELYTRA, null, true),
		new Entry("netherite_ingot", "Незеритовый слиток", Items.NETHERITE_INGOT, null, true),
		new Entry("netherite_scrap", "Незеритовый лом", Items.NETHERITE_SCRAP, null, true),
		new Entry("diamond_axe", "Алмазный топор", Items.DIAMOND_AXE, null, true),
		new Entry("netherite_axe", "Незеритовый топор", Items.NETHERITE_AXE, null, true),
		new Entry("echo_shard", "Осколок эха", Items.ECHO_SHARD, null, true),
		// Кастомные предметы по имени
		new Entry("freeze_snowball", "Снежок заморозка", Items.SNOWBALL, "снежок заморозка", true),
		new Entry("silver", "Серебро", Items.IRON_NUGGET, "серебро", true),
		new Entry("trapka", "Трапка", Items.NETHERITE_SCRAP, "трапка", true),
		new Entry("airdrop", "Аирдроп", Items.REDSTONE_TORCH, "аирдроп", true),
		new Entry("undeath_altar", "Алтарь нежити", Items.END_PORTAL_FRAME, "алтарь нежити", true),
		// Модификаторы: имя вида «N Модификатор N» — матчится регэкспом (см. shouldLoot)
		new Entry("modifier", "Модификаторы", Items.NETHER_STAR, null, true),
		new Entry("disorient", "Дезориентация", Items.ENDER_EYE, "дезориентация", true),
		new Entry("tnt", "Динамит", Items.TNT, null, true)
	);

	/** Всегда лутаемое по ключевому слову в имени. */
	private static final String[] ALWAYS_NAME_KEYS = {
		"сфера", "талисман", "отмычка",
		"хлопушка", "святая вода", "зелье гнева", "зелье палладина", "зелье паладина",
		"зелье ассасина", "зелье радиации", "снотворное"
	};

	/** «Модификаторы»: в имени есть «N Модификатор N» (числа по бокам слова). */
	private static final Pattern MODIFIER_NAME = Pattern.compile("\\d+\\s*модификатор\\s*\\d+");

	private static final Set<String> enabled = new LinkedHashSet<>();
	private static boolean loaded;

	private LootFilter() {}

	private static Path file() {
		return ClientPaths.file("loot_filter.json");
	}

	public static synchronized void load() {
		if (loaded) return;
		loaded = true;
		enabled.clear();
		Path f = file();
		if (Files.exists(f)) {
			try {
				JsonElement el = JsonParser.parseString(Files.readString(f));
				if (el.isJsonArray()) {
					for (JsonElement e : el.getAsJsonArray()) enabled.add(e.getAsString());
					// Разовая миграция: новые категории сразу включаем. Маркер
					// *_seen защищает от повторного включения, если категорию
					// выключили руками в фильтре.
					boolean migrated = false;
					if (!enabled.contains("modifier") && !enabled.contains("modifier_seen")) {
						enabled.add("modifier");
						enabled.add("modifier_seen");
						migrated = true;
					}
					if (!enabled.contains("disorient") && !enabled.contains("disorient_seen")) {
						enabled.add("disorient");
						enabled.add("disorient_seen");
						migrated = true;
					}
					if (!enabled.contains("totem") && !enabled.contains("totem_seen")) {
						enabled.add("totem");
						enabled.add("totem_seen");
						migrated = true;
					}
					if (!enabled.contains("skins_seen")) {
						// Обновлённый набор скинов — включаем сразу все
						for (Entry e : ENTRIES) if (e.id().startsWith("skin_")) enabled.add(e.id());
						enabled.add("skins_seen");
						migrated = true;
					}
					if (migrated) save();
					return;
				}
			} catch (Exception e) {
				NeuClient.LOGGER.warn("[AutoWarden] Не удалось прочитать loot_filter.json", e);
			}
		}
		resetDefaults();
	}

	public static synchronized void save() {
		try {
			JsonArray arr = new JsonArray();
			for (String s : enabled) arr.add(s);
			Gson gson = new GsonBuilder().setPrettyPrinting().create();
			Files.createDirectories(file().getParent());
			Files.writeString(file(), gson.toJson(arr));
		} catch (Exception e) {
			NeuClient.LOGGER.warn("[AutoWarden] Не удалось сохранить loot_filter.json", e);
		}
	}

	public static synchronized boolean isEnabled(Entry e) {
		load();
		return enabled.contains(e.id());
	}

	public static synchronized void set(Entry e, boolean on) {
		load();
		if (on) enabled.add(e.id()); else enabled.remove(e.id());
		save();
	}

	public static synchronized void setAll(boolean on) {
		load();
		enabled.clear();
		if (on) for (Entry e : ENTRIES) enabled.add(e.id());
		save();
	}

	public static synchronized void resetDefaults() {
		enabled.clear();
		for (Entry e : ENTRIES) if (e.defaultOn()) enabled.add(e.id());
		save();
	}

	/** Полный текст предмета: имя + lore, нижний регистр, без цветов. */
	private static String fullText(ItemStack st) {
		StringBuilder sb = new StringBuilder(st.getName().getString());
		LoreComponent lore = st.get(DataComponentTypes.LORE);
		if (lore != null) for (Text t : lore.lines()) sb.append('\n').append(t.getString());
		return sb.toString().replaceAll("§.", "").toLowerCase(Locale.ROOT);
	}

	private static String nameOnly(ItemStack st) {
		return st.getName().getString().replaceAll("§.", "").toLowerCase(Locale.ROOT);
	}

	/** Нужно ли забирать этот предмет из сундука. */
	public static boolean shouldLoot(ItemStack st) {
		if (st == null || st.isEmpty()) return false;
		load();
		String name = nameOnly(st);
		String full = fullText(st);

		// Всегда: сферы (голова), талисманы (тотем), отмычки (крюк), топовые зелья
		if (st.isOf(Items.PLAYER_HEAD) && full.contains("сфера")) return true;
		if (st.isOf(Items.TOTEM_OF_UNDYING) && full.contains("талисман")) return true;
		if (st.isOf(Items.FISHING_ROD) && full.contains("отмычка")) return true;
		for (String k : ALWAYS_NAME_KEYS) {
			if (name.contains(k)) return true;
		}

		for (Entry e : ENTRIES) {
			if (!enabled.contains(e.id())) continue;
			if ("modifier".equals(e.id())) {
				// Только регэксп «N Модификатор N»: звезда-иконка в GUI — просто
				// картинка, сами звёзды без такого имени лутать не надо.
				if (MODIFIER_NAME.matcher(name).find()) return true;
				continue;
			}
			if (e.nameKey() != null) {
				if (name.contains(e.nameKey())) return true;
			} else if (st.isOf(e.icon()) && !hasCustomName(st)) {
				return true;
			} else if (st.isOf(e.icon())) {
				// кастомные варианты ванильных предметов (например именованный алмаз) тоже берём
				return true;
			}
		}
		return false;
	}

	private static boolean hasCustomName(ItemStack st) {
		return st.get(DataComponentTypes.CUSTOM_NAME) != null;
	}

	public static List<Entry> search(String query) {
		if (query == null || query.isBlank()) return ENTRIES;
		String q = query.toLowerCase(Locale.ROOT).trim();
		List<Entry> out = new ArrayList<>();
		for (Entry e : ENTRIES) if (e.label().toLowerCase(Locale.ROOT).contains(q)) out.add(e);
		return out;
	}
}
