package ru.neuclient.client.hud;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.font.MsdfFontRenderer;
import ru.neuclient.client.font.MsdfFonts;
import ru.neuclient.client.hud.impl.ActiveModulesElement;
import ru.neuclient.client.hud.impl.ArmorElement;
import ru.neuclient.client.hud.impl.CoordsElement;
import ru.neuclient.client.hud.impl.EffectsElement;
import ru.neuclient.client.hud.impl.FpsElement;
import ru.neuclient.client.hud.impl.NicknameElement;
import ru.neuclient.client.hud.impl.PingElement;
import ru.neuclient.client.hud.impl.TargetHudElement;
import ru.neuclient.client.hud.impl.TpsElement;
import ru.neuclient.client.hud.impl.WatermarkElement;
import ru.neuclient.client.module.impl.render.InterfaceModule;
import ru.neuclient.client.util.RenderUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Менеджер HUD: владеет всеми элементами, рисует их поверх игры
 * и обслуживает перетаскивание.
 */
public class HudManager {

	private final List<HudElement> elements = new ArrayList<>();

	private HudElement dragging;
	private HudElement scaleMenuFor;
	private int menuX;
	private int menuY;

	private static final int MENU_ROW_H = 14;
	private static final int MENU_W = 48;

	public HudManager() {
		elements.add(new WatermarkElement());
		elements.add(new NicknameElement());
		elements.add(new CoordsElement());
		elements.add(new PingElement());
		elements.add(new FpsElement());
		elements.add(new TpsElement());
		elements.add(new ArmorElement());
		elements.add(new EffectsElement());
		elements.add(new ActiveModulesElement());
		elements.add(new TargetHudElement());
		elements.add(new ru.neuclient.client.hud.impl.MediaElement());
	}

	public List<HudElement> getElements() {
		return elements;
	}

	public void render(DrawContext ctx, boolean editing) {
		InterfaceModule hud = NeuClient.getInstance().getInterfaceModule();
		if (hud == null || !hud.isEnabled()) {
			return;
		}
		ru.neuclient.client.util.ScaleUtil.begin(ctx);
		for (HudElement e : elements) {
			if (e.isVisible()) {
				e.render(ctx, editing);
			}
		}

		if (editing && scaleMenuFor != null) {
			drawScaleMenu(ctx);
		} else if (!editing) {
			scaleMenuFor = null;
		}
		ru.neuclient.client.util.ScaleUtil.end(ctx);
	}

	public boolean openScaleMenu(double mx, double my) {
		HudElement picked = pick(mx, my);
		if (picked == null) {
			scaleMenuFor = null;
			return false;
		}
		scaleMenuFor = picked;
		menuX = (int) mx;
		menuY = (int) my;
		return true;
	}

	public boolean clickScaleMenu(double mx, double my) {
		if (scaleMenuFor == null) {
			return false;
		}
		int rows = HudElement.SCALES.length;
		boolean inside = mx >= menuX && mx <= menuX + MENU_W
				&& my >= menuY && my <= menuY + rows * MENU_ROW_H + 2;
		if (!inside) {
			scaleMenuFor = null;
			return false;
		}
		int index = (int) ((my - menuY - 1) / MENU_ROW_H);
		if (index >= 0 && index < rows) {
			scaleMenuFor.setScale(HudElement.SCALES[index]);
		}
		scaleMenuFor = null;
		return true;
	}

	public boolean isScaleMenuOpen() {
		return scaleMenuFor != null;
	}

	private void drawScaleMenu(DrawContext ctx) {
		int rows = HudElement.SCALES.length;
		int h = rows * MENU_ROW_H + 2;

		RenderUtil.roundRect(ctx, menuX, menuY, MENU_W, h, 4, HudElement.cardBg());

		int y = menuY + 1;
		for (float s : HudElement.SCALES) {
			int percent = Math.round(s * 100.0f);
			boolean current = Math.abs(scaleMenuFor.getScale() - s) < 0.01f;
			int color = current
					? RenderUtil.accent()
					: HudElement.withAlpha(0xFFFFFFFF, 0xCC);
			if (current) {
				ctx.fill(menuX + 1, y, menuX + MENU_W - 1, y + MENU_ROW_H,
						HudElement.withAlpha(RenderUtil.accent(), 0x22));
			}
			MsdfFontRenderer.drawWithShadow(ctx, MsdfFonts.sfMedium(),
					percent + "%", menuX + 6, y + (MENU_ROW_H - 9) / 2f, color, 9.0f);
			y += MENU_ROW_H;
		}
	}

	public HudElement pick(double mx, double my) {
		for (int i = elements.size() - 1; i >= 0; i--) {
			HudElement e = elements.get(i);
			if (e.isVisible() && e.contains(mx, my)) {
				return e;
			}
		}
		return null;
	}

	public boolean beginDrag(double mx, double my) {
		HudElement picked = pick(mx, my);
		if (picked == null) {
			return false;
		}
		dragging = picked;
		picked.startDrag(mx, my);
		return true;
	}

	public void dragTo(double mx, double my) {
		if (dragging == null) {
			return;
		}
		int vw = ru.neuclient.client.util.ScaleUtil.getVirtualWidth();
		int vh = ru.neuclient.client.util.ScaleUtil.getVirtualHeight();
		dragging.dragTo(mx, my, vw, vh);
	}

	public void endDrag() {
		dragging = null;
	}

	public boolean isDragging() {
		return dragging != null;
	}
}
