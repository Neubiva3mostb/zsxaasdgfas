package ru.neuclient.client.mixin;

import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.impl.render.SpinnerModule;

/**
 * Spinner: вращение собственной модели в виде от третьего лица.
 *
 * ПОЧЕМУ ИМЕННО ЗДЕСЬ.
 * updateRenderState — последняя стадия перед отрисовкой: ваниль
 * переписывает сюда углы из сущности, и дальше рендер работает уже
 * только с этой копией. Меняя bodyYaw тут, мы:
 *  • не трогаем саму сущность, поэтому настоящий угол игрока цел;
 *  • ничего не ломаем в сети — пакеты движения собираются из сущности,
 *    а не из состояния рендера;
 *  • не конфликтуем со спуфом ауры (AuraTickSpoofMixin), который живёт
 *    в тике игрока и к рендеру отношения не имеет.
 *
 * Ставим TAIL: ваниль сначала сама заполнит все поля, и только потом
 * мы поверх подменим угол корпуса.
 *
 * ГОЛОВУ НЕ КРУТИМ ОТДЕЛЬНО.
 * relativeHeadYaw — это разница между головой и корпусом. Ваниль
 * ограничивает её ±50°, чтобы шея не выворачивалась. Достаточно
 * повернуть корпус: голова поедет вместе с ним, а взгляд останется
 * повёрнутым туда, куда игрок реально смотрит.
 */
@Mixin(LivingEntityRenderer.class)
public abstract class PlayerSpinRenderMixin {

	@Inject(method = "updateRenderState(Lnet/minecraft/entity/LivingEntity;"
			+ "Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;F)V",
			at = @At("TAIL"))
	private void pc$spinSelf(LivingEntity entity, LivingEntityRenderState state,
			float tickDelta, CallbackInfo ci) {
		try {
			SpinnerModule spinner = SpinnerModule.active();
			if (spinner == null || !spinner.shouldSpinSelf(entity)) {
				return;
			}
			float angle = spinner.currentAngle();
			// Корпус крутим, взгляд (pitch) не трогаем: вертикаль должна
			// остаться там, куда смотрит игрок, иначе модель кувыркается.
			state.bodyYaw = angle;
			// Голова следует за корпусом: обнуляем относительный доворот,
			// иначе ваниль зажмёт его лимитом шеи и голова будет
			// «отставать» от тела рывками.
			state.relativeHeadYaw = 0.0f;
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка Spinner", t);
		}
	}

	/** На всякий случай ловим и обобщённую перегрузку (Entity-версия). */
	@Inject(method = "updateRenderState(Lnet/minecraft/entity/Entity;"
			+ "Lnet/minecraft/client/render/entity/state/EntityRenderState;F)V",
			at = @At("TAIL"), require = 0)
	private void pc$spinSelfGeneric(Entity entity,
			net.minecraft.client.render.entity.state.EntityRenderState state,
			float tickDelta, CallbackInfo ci) {
		try {
			if (!(state instanceof LivingEntityRenderState living)) {
				return;
			}
			SpinnerModule spinner = SpinnerModule.active();
			if (spinner == null || !spinner.shouldSpinSelf(entity)) {
				return;
			}
			living.bodyYaw = spinner.currentAngle();
			living.relativeHeadYaw = 0.0f;
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка Spinner (generic)", t);
		}
	}
}
