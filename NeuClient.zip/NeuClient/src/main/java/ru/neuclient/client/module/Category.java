package ru.neuclient.client.module;

/**
 * Категории модулей ClickGUI.
 * Порядок объявления = порядок панелей слева направо.
 */
public enum Category {

	COMBAT("Combat"),
	MOVEMENT("Movement"),
	RENDER("Render"),
	PLAYER("Player"),
	MISC("Misc");

	private final String displayName;

	Category(String displayName) {
		this.displayName = displayName;
	}

	/** Имя в заголовке панели. */
	public String getDisplayName() {
		return displayName;
	}
}
