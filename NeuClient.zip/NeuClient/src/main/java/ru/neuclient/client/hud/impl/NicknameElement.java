package ru.neuclient.client.hud.impl;

import net.minecraft.client.gui.DrawContext;
import ru.neuclient.client.hud.HudElement;

/**
 * Ник игрока — карточка [Nick │ имя] в общем стиле HUD.
 * Имя берётся из текущей сессии (меняется после входа через Alt Manager).
 */
public class NicknameElement extends HudElement {

	public NicknameElement() {
		super("nickname", 4, 22);
	}

	@Override
	public boolean isVisible() {
		if (ru.neuclient.client.NeuClient.getInstance().getInterfaceModule().isElementVisible("watermark")) return false;
		return super.isVisible();
	}

	@Override
	protected void drawElement(DrawContext ctx, boolean editing) {
		// Ник аккаунта сайта (fallback — сессия, если попали мимо лаунчера)
		String value = ru.neuclient.client.util.SiteUser.displayName(mc.getSession().getUsername());
		this.width = valueCardWidth("Nick", value);
		this.height = CARD_H;
		drawValueCard(ctx, getX(), getY(), width, "Nick", value);
	}
}
