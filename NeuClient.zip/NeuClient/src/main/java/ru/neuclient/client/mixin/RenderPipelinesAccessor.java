package ru.neuclient.client.mixin;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.minecraft.client.gl.RenderPipelines;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Расширяет доступ к private полю RenderPipelines.RENDERTYPE_LINES_SNIPPET.
 *
 * В Minecraft 1.21.11 это поле стало private — моды не могут создавать
 * свои линии-слои без accessor'а.
 */
@Mixin(RenderPipelines.class)
public interface RenderPipelinesAccessor {

	@Accessor(value = "RENDERTYPE_LINES_SNIPPET")
	static RenderPipeline.Snippet pc$getLinesSnippet() {
		throw new AssertionError();
	}
}
