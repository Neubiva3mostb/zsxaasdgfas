package ru.neuclient.client.module.impl.combat;

import net.minecraft.entity.Entity;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.NumberSetting;

/**
 * W-Tap — классический приём сброса отдачи (reset KB).
 *
 * Как работает: когда клиент бьёт сущность (перехват в
 * ClientPlayerInteractionManager#attackEntity), модуль на короткое
 * настраиваемое время "отпускает" клавишу W (движение вперёд),
 * а затем она сама возвращается — благодаря этому спринт прерывается
 * и следующий удар снова идёт "с разбега", увеличивая отбрасывание.
 *
 * Технически отжатие делается в Mixin KeyboardInput#tick: на время окна
 * мы подменяем флажок forward в PlayerInput на false. Реальное состояние
 * клавиши W не трогаем, поэтому "отпускание" корректно длится ровно окно.
 */
public class WTapModule extends Module {

	/** Задержка отжатия W в миллисекундах (по умолчанию 50, как в ТЗ). */
	private final NumberSetting delay = new NumberSetting("Задержка", 50, 10, 300, 5);

	/** Момент (System.currentTimeMillis), до которого W удерживается отжатой. */
	private volatile long releaseUntil = 0L;

	public WTapModule() {
		super("W-Tap", "Сам делает W-Tap", Category.COMBAT);
		addSettings(delay);
	}

	/**
	 * Вызывается миксином при успешной атаке клиентом любой сущности.
	 */
	public void onAttack(Entity target) {
		if (!isEnabled()) {
			return;
		}
		releaseUntil = System.currentTimeMillis() + delay.get().longValue();
	}

	/** true, пока идёт окно отжатия W (читает KeyboardInputMixin). */
	public boolean isBlockingForward() {
		return isEnabled() && System.currentTimeMillis() < releaseUntil;
	}

	public NumberSetting getDelaySetting() {
		return delay;
	}
}
