package ru.neuclient.client.util;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import ru.neuclient.client.NeuClient;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * Одноразовый сброс предметов игрока из экрана инвентаря.
 *
 * Для каждого занятого слота отправляется то же действие, что и при Ctrl+Q:
 * {@link SlotActionType#THROW} с кнопкой 1. Пауза между отправками составляет
 * 75 мс; выполнение идёт в render-проходе клиента, поэтому не блокирует игру.
 */
public final class InventoryResetHelper {

    private static final long SLOT_DELAY_NANOS = 75_000_000L;
    private static final Deque<Integer> pendingSlotIds = new ArrayDeque<>();

    private static boolean running;
    private static long nextDropNanos;

    private InventoryResetHelper() {
    }

    /** Начать сброс всех занятых слотов PlayerInventory в открытом инвентаре. */
    public static void start(MinecraftClient client) {
        cancel();

        if (!canRun(client)) {
            return;
        }

        for (Slot slot : client.player.currentScreenHandler.slots) {
            // Не трогаем сетку крафта и результат крафта: только настоящий инвентарь
            // игрока, включая броню, основную сетку, хотбар и вторую руку.
            if (slot.inventory == client.player.getInventory() && slot.hasStack()) {
                pendingSlotIds.addLast(slot.id);
            }
        }

        if (!pendingSlotIds.isEmpty()) {
            running = true;
            nextDropNanos = System.nanoTime();
        }
    }

    /** Вызывается каждый кадр, пока открыт InventoryScreen. */
    public static void tick(MinecraftClient client) {
        if (!running) {
            return;
        }

        if (!canRun(client)) {
            cancel();
            return;
        }

        // Мгновенно: выбрасываем все оставшиеся слоты за один проход.
        while (!pendingSlotIds.isEmpty()) {
            int slotId = pendingSlotIds.removeFirst();
            if (slotId < 0 || slotId >= client.player.currentScreenHandler.slots.size()) {
                continue;
            }

            Slot slot = client.player.currentScreenHandler.getSlot(slotId);
            ItemStack stack = slot.getStack();
            if (slot.inventory != client.player.getInventory() || stack.isEmpty()) {
                continue;
            }

            // button=1 + THROW — ванильный эквивалент Ctrl+Q (выбросить весь стак).
            client.interactionManager.clickSlot(
                    client.player.currentScreenHandler.syncId,
                    slotId,
                    1,
                    SlotActionType.THROW,
                    client.player
            );
        }

        cancel();
    }

    /** Немедленно остановить сброс; вызывается также при .panic. */
    public static void cancel() {
        pendingSlotIds.clear();
        running = false;
        nextDropNanos = 0L;
    }

    public static boolean isRunning() {
        return running;
    }

    private static boolean canRun(MinecraftClient client) {
        NeuClient neuClient = NeuClient.getInstance();
        return client != null
                && client.player != null
                && client.interactionManager != null
                && client.currentScreen instanceof InventoryScreen
                && (neuClient == null || !neuClient.isPanicked());
    }
}
