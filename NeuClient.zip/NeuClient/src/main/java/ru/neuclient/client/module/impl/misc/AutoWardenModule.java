package ru.neuclient.client.module.impl.misc;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.function.Predicate;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BlockEntityType;
import net.minecraft.block.entity.SignBlockEntity;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.hud.ClientBossBar;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.entity.Entity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.WardenEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.potion.Potion;
import net.minecraft.potion.Potions;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.RaycastContext;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.mixin.BossBarHudAccessor;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.module.impl.misc.autowarden.PathFinder;
import ru.neuclient.client.module.impl.misc.autowarden.Walker;
import ru.neuclient.client.module.impl.render.WardenESP;
import ru.neuclient.client.module.impl.misc.autowarden.LootFilter;
import ru.neuclient.client.setting.BooleanSetting;
import ru.neuclient.client.setting.ButtonSetting;
import ru.neuclient.client.setting.NumberSetting;
import ru.neuclient.client.setting.Setting;
import ru.neuclient.client.setting.TextSetting;
import ru.neuclient.client.util.ChatUtil;

public class AutoWardenModule extends Module {
   private final TextSetting baseAn = new TextSetting("Номер анархии базы", "2", 8);
   private final TextSetting wardenAn = new TextSetting("Номер анархии вардена", "1", 8);
   private final TextSetting supplySign = new TextSetting("Табличка расходников", "расход", 32);
   private final NumberSetting chestsPerRun = new NumberSetting("Сундуков за заход", 3.0, 1.0, 5.0, 1.0);
   private final BooleanSetting useSpeed = new BooleanSetting("Зелья скорости", true);
   private final ButtonSetting filterBtn = new ButtonSetting("Фильтр", () -> this.mc.setScreen(new ru.neuclient.client.ui.LootFilterScreen(this.mc.currentScreen)));
   // Фиксированные параметры (в GUI не выводятся)
   private static final String HOME_CMD = "/home home";
   private static final int TP_SECONDS = 8;
   private static final int CARROT_COUNT = 3;
   private static final int POTION_COUNT = 1;
   private static final int EAT_BELOW = 19;
   private static final double WARDEN_SNEAK_DIST = 10.0;
   /** Дальше этой дистанции варден считается «рядом» для детекта агра. */
   private static final double WARDEN_AGGRO_DIST = 8.0;
   /** Урон свежее этого окна считается признаком агра вардена. */
   private static final long AGGRO_HURT_WINDOW_MS = 3000L;
   /** Сколько после исчезновения босс-бара ждать подтверждения конца PvP. */
   private static final long PVP_GRACE_MS = 4000L;
   /** Первые столько мс после захода на анархию вардена игнорируем варденов. */
   private static final long WARDEN_IGNORE_MS = 5000L;
   /** Звук вардена свежее этого окна — признак того, что он рядом и активен. */
   private static final long WARDEN_SOUND_WINDOW_MS = 2500L;
   private static final int AREA_X1 = -1934;
   private static final int AREA_Z1 = -1932;
   private static final int AREA_X2 = -2067;
   private static final int AREA_Z2 = -2068;
   private static final String PVP_BAR = "режим";
   private static final int GO_AT_SECONDS = 30;
   private static final boolean NO_TIMER_CHESTS = false;
   private static final boolean DEBUG = false;
   private static final String DEATH_TEXT = "Помянем. Вы погибли!";
   private static final double CITY_NEAR_DIST = 60.0;
   private static AutoWardenModule instance;
   private volatile boolean deathFlag;
   private AutoWardenModule.State state = AutoWardenModule.State.IDLE;
   private int stateTicks;
   private int actionCooldown;
   private PathFinder pathFinder;
   private Walker walker;
   private final Set<BlockPos> visitedNoTimer = new HashSet<>();
   private final Set<BlockPos> knownChests = new HashSet<>();
   private final Set<BlockPos> lootedChests = new HashSet<>();
   /** Не открываем вовсе (бочки и т.п.). */
   private final Set<BlockPos> skipChests = new HashSet<>();
   /** Точка, к которой идём, чтобы увидеть сундук за стеной. */
   private BlockPos visionSpot;
   /** Спуф-взгляд на сундук: его видят сервер и F5, камера от 1-го лица не дёргается. */
   private float spoofYaw;
   private float spoofPitch;
   /** Сундук, у которого стоим в ожидании таймера (для сброса счётчика при смене цели). */
   private BlockPos standingAt;
   /** До какого времени (мс) стоим у сундука в ожидании таймера. */
   private long standUntilMs;
   /** Временный отказ от сундука: до какого времени его не выбирать (не нашёлся путь / не открылся). */
   private final Map<BlockPos, Long> pathFailUntil = new HashMap<>();
   /** «Горящий» сундук, к которому привержены: не перескакиваем на другой, пока этот не откроется. */
   private BlockPos burnCommit;
   private final Set<BlockPos> readyChests = new HashSet<>();
   /** Сундуки, у которых мы когда-либо достоверно видели живой таймер. */
   private final Set<BlockPos> timedChests = new HashSet<>();
   private final Map<BlockPos, Long> zeroSince = new java.util.HashMap<>();
   private final Map<BlockPos, Integer> nearNoTimerTicks = new java.util.HashMap<>();
   private final Set<BlockPos> lastTimerKeys = new HashSet<>();
   private BlockPos targetChest;
   private BlockPos roamTarget;
   private BlockPos supplyChest;
   private BlockPos storageChest;
   private int lastWorldChangeTick;
   private boolean sawWorldChange;
   private ClientWorld lastWorld;
   private boolean consuming;
   private int consumeSlotBackup = -1;
   private ItemStack consumeBackupStack = ItemStack.EMPTY;
   private int consumeTicks;
   private int consumeRetryTicks;
   /** Слот хотбара, из которого работаем (0..8). */
   private int consumeHotbarSlot = -1;
   /** Ранее выбранный слот хотбара — вернём его после еды/питья. */
   private int consumePrevSelected = -1;
   /** true, если предмет изначально лежал НЕ в хотбаре (значит был свап). */
   private boolean consumeWasSwapped;
   private int lootedThisRun;
   private boolean knownChestsDirty;
   private long pvpSince;
   /** Когда последний раз был виден PvP босс-бар (защита от мигания). */
   private long lastPvpSeenAt;
   /** Здоровье на прошлом тике — детект свежего урона. */
   private float lastTrackedHealth = -1.0f;
   /** Когда нас последний раз ударили. */
   private long lastHurtAt;
   /** Когда варден последний раз подал голос в радиусе агра. */
   private long lastWardenSoundAt;
   /** Сколько тиков подряд ближайший варден держит голову на нас. */
   private int wardenFacingTicks;
   /** Когда мы зашли на анархию вардена (0 = мы не на варден-стороне). */
   private long wardenSideSince;
   /** Когда был отправлен последний /an (детект двойного лива). */
   private long anSentAt;
   /** Последний /an был ДОМОЙ (на базовую анархию), а не на варденку. */
   private boolean anToBase;
   /** Когда в последний раз сменился мир (сервер/анархия). */
   private long worldChangedAt;
   /** Сколько тиков подряд не удаётся найти точку/путь для блуждания (эскалация фолбэков). */
   private int noRoamTicks;
   /** Подряд наблюдаемых «застрял»: 2 подряд — манёвр отхода на чистую точку. */
   private int stuckStrikes;
   /** Точка отхода при застревании (например, между заборами). */
   private BlockPos escapeSpot;
   /** До какого времени идёт манёвр отхода. */
   private long escapeUntilMs;
   /** Неудачных попыток еды/питья подряд (защита от цикла «пьём → сорвалось → снова»). */
   private int consumeFails;
   /** Пауза перед новыми попытками выпить/поесть после серии неудач, в тиках. */
   private int consumePauseTicks;

   public AutoWardenModule() {
      super("AutoWarden", "Автофарм сундуков вардена", Category.MISC);
      this.addSettings(new Setting[]{this.baseAn, this.wardenAn, this.supplySign, this.chestsPerRun, this.useSpeed, this.filterBtn});
      instance = this;
      ClientReceiveMessageEvents.GAME.register((msg, overlay) -> onChat(msg));
      ClientReceiveMessageEvents.CHAT.register((msg, signed, sender, params, ts) -> onChat(msg));
   }

   protected void onEnable() {
      this.walker = new Walker(this.mc);
      this.visitedNoTimer.clear();
      this.visionSpot = null;
      this.standingAt = null;
      this.standUntilMs = 0L;
      this.pathFailUntil.clear();
      this.burnCommit = null;
      this.knownChests.clear();
      this.loadKnownChests();
      this.lootedChests.clear();
      this.readyChests.clear();
      this.timedChests.clear();
      this.lastTimerKeys.clear();
      this.zeroSince.clear();
      this.nearNoTimerTicks.clear();
      this.targetChest = null;
      this.roamTarget = null;
      this.consuming = false;
      this.deathFlag = false;
      this.lootedThisRun = 0;
      this.noRoamTicks = 0;
      this.stuckStrikes = 0;
      this.escapeSpot = null;
      this.escapeUntilMs = 0L;
      this.consumeFails = 0;
      this.consumePauseTicks = 0;
      this.lastPvpSeenAt = 0L;
      this.pvpSince = 0L;
      this.lastTrackedHealth = -1.0f;
      this.lastHurtAt = 0L;
      this.lastWardenSoundAt = 0L;
      this.wardenFacingTicks = 0;
      this.wardenSideSince = 0L;
      this.anSentAt = 0L;
      this.anToBase = false;
      this.worldChangedAt = 0L;
      this.lastWorld = this.mc.world;
      WardenESP esp = (WardenESP)NeuClient.getInstance().getModuleManager().get(WardenESP.class);
      if (esp != null && !esp.isEnabled()) {
         esp.setEnabled(true);
      }

      this.setState(AutoWardenModule.State.BASE_FIND_SUPPLY);
   }

   protected void onDisable() {
      if (this.walker != null) {
         this.walker.stop();
      }

      if (this.mc.player != null && this.mc.currentScreen instanceof HandledScreen) {
         this.mc.player.closeHandledScreen();
      }

      this.restoreAfterConsume();
      this.setState(AutoWardenModule.State.IDLE);
   }

   private static void onChat(Text msg) {
      AutoWardenModule m = instance;
      if (m != null && m.isEnabled() && msg != null && msg.getString().contains(DEATH_TEXT)) {
         m.deathFlag = true;
      }
   }

   private void handleDeath(ClientPlayerEntity p) {
      this.deathFlag = false;
      if (this.state == AutoWardenModule.State.DEAD_WAIT) {
         return;
      }

      this.restoreAfterConsume();
      if (this.walker != null) {
         this.walker.stop();
      }

      if (this.mc.currentScreen instanceof HandledScreen) {
         p.closeHandledScreen();
      }

      this.targetChest = null;
      this.roamTarget = null;
      this.lootedThisRun = 0;
      this.noRoamTicks = 0;
      this.consumeFails = 0;
      this.consumePauseTicks = 0;
      this.setState(AutoWardenModule.State.DEAD_WAIT);
   }

   /**
    * Варден заагрился вне PvP: экстренный /anN домой и полный цикл заново —
    * база, сложить лут, взять морковь/зелья, снова на фарм.
    */
   private void triggerWardenEscape(ClientPlayerEntity p) {
      if (this.walker != null) {
         this.walker.stop();
      }

      if (this.mc.currentScreen instanceof HandledScreen) {
         p.closeHandledScreen();
      }

      this.restoreAfterConsume();
      this.targetChest = null;
      this.roamTarget = null;
      this.edgeTarget = null;
      this.lootedThisRun = 0;
      // GO_BASE_AN при отсутствии PvP отправит /anN и приведёт к
      // WAIT_BASE_WORLD -> BASE_FIND_STORAGE -> ... -> BASE_FIND_SUPPLY.
      this.setState(AutoWardenModule.State.GO_BASE_AN);
   }

   private void deadWait(ClientPlayerEntity p) {
      if (p.isDead() || p.getHealth() <= 0.0F) {
         if (this.stateTicks % 20 == 0) {
            p.requestRespawn();
         }

         this.stateTicks = 0;
      } else if (this.stateTicks > 60 && this.mc.currentScreen == null) {
         // Если после отправки /an мир уже сменился — команда УСПЕЛА
         // отработать (мы на базовой анархии, просто умерли по пути).
         // Повторный /an — тот самый двойной лив, который ломал цикл.
         // Guard «двойного лива» только если последний /an был ДОМОЙ и мир
        // после него сменился (мы уже на базе). Смена мира после /an НА
        // ВАРДЕНКУ — это просто старт цикла фарма: после смерти на варденке
        // /an домой отправить ОБЯЗАТЕЛЬНО, иначе бот ищет сундук базы там,
        // где его нет, и падает с «Рядом (4 блока) нет сундука...».
         if (this.anToBase && this.anSentAt > 0L && this.worldChangedAt > this.anSentAt) {
            this.setState(AutoWardenModule.State.BASE_FIND_STORAGE);
         } else {
            this.setState(AutoWardenModule.State.GO_BASE_AN);
         }
      }
   }

   private void setState(AutoWardenModule.State s) {


      this.state = s;
      this.stateTicks = 0;
      this.actionCooldown = 0;
   }

   private void fail(String msg) {
      ChatUtil.error("[AutoWarden] " + msg);
      this.setEnabled(false);
   }

   public void onTick(MinecraftClient client) {
      ClientPlayerEntity p = this.mc.player;
      if (p != null && this.mc.world != null) {
         this.stateTicks++;
         if (this.actionCooldown > 0) {
            this.actionCooldown--;
         }

         if (this.mc.world != this.lastWorld) {
            this.lastWorld = this.mc.world;
            this.sawWorldChange = true;
            this.lastWorldChangeTick = this.stateTicks;
            this.worldChangedAt = System.currentTimeMillis();
            this.pathFinder = null;
            // Смена мира: цели прошлого мира недействительны — горящий сундук
            // с той анархии не должен тянуть бота по координатам этой.
            this.targetChest = null;
            this.burnCommit = null;
            this.standingAt = null;
            this.visionSpot = null;
            this.standUntilMs = 0L;
            this.escapeSpot = null;
            this.stuckStrikes = 0;
            if (this.walker != null) {
               this.walker.stop();
            }
         }

         if (this.deathFlag && this.state != AutoWardenModule.State.IDLE) {
            this.handleDeath(p);
         }

         // Первые WARDEN_IGNORE_MS после захода на анархию вардена полностью
         // игнорируем варденов: телепорт может высадить прямо рядом с ними,
         // присед и тревога в эту секунду только мешают.
         long nowMs = System.currentTimeMillis();
         if (this.isOnWardenSide()) {
            if (this.wardenSideSince == 0L) {
               this.wardenSideSince = nowMs;
            }
         } else {
            this.wardenSideSince = 0L;
         }

         boolean ignoreWardens = this.wardenSideSince != 0L
            && nowMs - this.wardenSideSince < WARDEN_IGNORE_MS;

         // Детект агра: свежий урон, голос вардена рядом или длительное
         // «смотрение» тела вардена на нас. Тревога — только на «полевой»
         // фазе и вне PvP.
         if (this.isOnWardenSide()) {
            float hpNow = p.getHealth();
            if (this.lastTrackedHealth >= 0.0f && hpNow < this.lastTrackedHealth - 0.01f) {
               this.lastHurtAt = nowMs;
            }

            this.lastTrackedHealth = hpNow;
            if (!ignoreWardens
               && this.state != AutoWardenModule.State.GO_EDGE
               && this.state != AutoWardenModule.State.GO_BASE_AN
               && !this.isPvp()) {
               WardenEntity nearest = this.nearestWardenEntity(p);
               double dist = nearest == null
                  ? Double.MAX_VALUE
                  : Math.sqrt(nearest.squaredDistanceTo(p.getX(), p.getY(), p.getZ()));

               // «Тело смотрит на нас»: варден держит голову на игрока
               // дольше 10 тиков подряд — потерял нас из виду он бы отвёл.
               if (nearest != null && dist <= WARDEN_AGGRO_DIST && this.isWardenFacingPlayer(nearest, p)) {
                  this.wardenFacingTicks++;
               } else {
                  this.wardenFacingTicks = 0;
               }

               boolean recentHurt = nowMs - this.lastHurtAt < AGGRO_HURT_WINDOW_MS;
               boolean recentSound = nowMs - this.lastWardenSoundAt < WARDEN_SOUND_WINDOW_MS;
               if (nearest != null && dist <= WARDEN_AGGRO_DIST
                  && (recentHurt || recentSound || this.wardenFacingTicks >= 10)) {
                  this.triggerWardenEscape(p);
               }
            } else {
               this.wardenFacingTicks = 0;
            }
         } else {
            this.lastTrackedHealth = p.getHealth();
            this.wardenFacingTicks = 0;
         }

         if (!this.isOnWardenSide() || !this.tickConsume(p)) {
            switch (this.state) {
               case IDLE:
               default:
                  break;
               case DEAD_WAIT:
                  this.deadWait(p);
                  break;
               case WARDEN_CHECK:
                  this.wardenCheck(p);
                  break;
               case BASE_FIND_SUPPLY:
                  this.baseFindSupply(p);
                  break;
               case BASE_OPEN_SUPPLY:
                  this.openChest(this.supplyChest, AutoWardenModule.State.BASE_TAKE_SUPPLY, "сундук расхода");
                  break;
               case BASE_TAKE_SUPPLY:
                  this.baseTakeSupply(p);
                  break;
               case GO_WARDEN_AN:
                  this.sendAn(this.anCmd(this.wardenAn), AutoWardenModule.State.WAIT_WORLD);
                  break;
               case WAIT_WORLD:
                  this.waitWorld(AutoWardenModule.State.WARDEN_CHECK);
                  break;
               case SEND_HOME:
                  this.sendHome();
                  break;
               case WAIT_TP:
                  this.waitTp(p);
                  break;
               case CLEAN_HOTBAR:
                  this.cleanHotbar(p, AutoWardenModule.State.ROAM);
                  break;
               case ROAM:
                  this.roam(p);
                  break;
               case GO_CHEST:
                  this.goChest(p);
                  break;
               case LOOT_OPEN:
                  this.openChest(this.targetChest, AutoWardenModule.State.LOOT_TAKE, "сундук вардена");
                  break;
               case LOOT_TAKE:
                  this.lootTake(p);
                  break;
               case PVP_WAIT:
                  this.pvpWait(p);
                  break;
               case GO_EDGE:
                  this.goEdge(p);
                  break;
               case GO_BASE_AN:
                  // В PvP-режиме /anN (это и есть лив) не отправляем: иначе нас
                  // убьют/выкинут посреди режима. Пока режим активен — бежим к
                  // краю; команда уйдёт СРАЗУ после его спада.
                  if (this.isPvp()) {
                     this.runToEdgeWhilePvp(p);
                  } else {
                     this.sendAn(this.anCmd(this.baseAn), AutoWardenModule.State.WAIT_BASE_WORLD);
                  }
                  break;
               case WAIT_BASE_WORLD:
                  this.waitWorld(AutoWardenModule.State.BASE_FIND_STORAGE);
                  break;
               case BASE_FIND_STORAGE:
                  this.baseFindStorage(p);
                  break;
               case BASE_OPEN_STORAGE:
                  this.openChest(this.storageChest, AutoWardenModule.State.BASE_PUT_LOOT, "сундук для лута");
                  break;
               case BASE_PUT_LOOT:
                  this.basePutLoot(p);
            }
         }

         // Присед у вардена и тишина у скалка. В любом состоянии,
         // поверх любых клавиш Walker'а.
         this.tickWardenSneak(p, ignoreWardens);
      }
   }

   /** Держит шифт, пока варден ближе WARDEN_SNEAK_DIST блоков; спринт при этом гасим. */
   private void tickWardenSneak(ClientPlayerEntity p, boolean ignoreWardens) {
      boolean close = !ignoreWardens && this.nearestWardenDist(p) <= WARDEN_SNEAK_DIST;
      this.mc.options.sneakKey.setPressed(close);
      if (close && this.mc.options.sprintKey.isPressed()) {
         this.mc.options.sprintKey.setPressed(false);
      }
      // Прыжок возле вардена НЕ гасим: с зажатым шифтом ваниль спускает
      // с блока/края безопасно, без прыжка бот повисал на спуске.
   }

   private boolean isOnWardenSide() {
      return this.state == AutoWardenModule.State.CLEAN_HOTBAR
         || this.state == AutoWardenModule.State.GO_EDGE
         || this.state == AutoWardenModule.State.ROAM
         || this.state == AutoWardenModule.State.GO_CHEST
         || this.state == AutoWardenModule.State.LOOT_OPEN
         || this.state == AutoWardenModule.State.LOOT_TAKE
         || this.state == AutoWardenModule.State.PVP_WAIT;
   }

   private void baseFindSupply(ClientPlayerEntity p) {
      this.supplyChest = this.findChestNear(p.getBlockPos(), 4, true);
      if (this.supplyChest == null) {
         if (this.stateTicks > 40) {
            this.fail("Рядом (4 блока) нет сундука с табличкой «" + (String)this.supplySign.get() + "».");
         }
      } else {
         this.setState(AutoWardenModule.State.BASE_OPEN_SUPPLY);
      }
   }

   private void baseTakeSupply(ClientPlayerEntity p) {
      GenericContainerScreenHandler h = this.openedContainer();
      if (h == null) {
         if (this.stateTicks > 60) {
            this.setState(AutoWardenModule.State.BASE_OPEN_SUPPLY);
         }
      } else if (this.actionCooldown <= 0) {
         int rows = h.getRows();
         int chestSlots = rows * 9;
         int needPotion = (int)Math.round((double)POTION_COUNT) - this.countInPlayer(p, AutoWardenModule::isInvisPotion);
         // Еда — любая съедобная (компонент FOOD), не только золотая морковь.
         int needFood = (int)Math.round((double)CARROT_COUNT) - this.countInPlayer(p, AutoWardenModule::isFood);
         int needSpeed = (Boolean)this.useSpeed.get() ? (int)Math.round((double)POTION_COUNT) - this.countInPlayer(p, AutoWardenModule::isSpeedPotion) : 0;
         if (needPotion <= 0 && needFood <= 0 && needSpeed <= 0) {
            p.closeHandledScreen();
            this.setState(AutoWardenModule.State.GO_WARDEN_AN);
         } else {
            if (this.freePlayerSlots(h, chestSlots) <= 0) {
               p.closeHandledScreen();
               this.fail("В инвентаре нет места под расходники.");
               return;
            }

            for (int i = 0; i < chestSlots; i++) {
               ItemStack st = h.getSlot(i).getStack();
               if (!st.isEmpty()) {
                  if (needPotion > 0 && isInvisPotion(st)) {
                     this.takeExactly(h, i, Math.min(needPotion, st.getCount()), p);
                     this.actionCooldown = 8;
                     return;
                  }

                  if (needFood > 0 && isFood(st)) {
                     this.takeExactly(h, i, Math.min(needFood, st.getCount()), p);
                     this.actionCooldown = 8;
                     return;
                  }

                  if (needSpeed > 0 && isSpeedPotion(st)) {
                     this.takeExactly(h, i, Math.min(needSpeed, st.getCount()), p);
                     this.actionCooldown = 8;
                     return;
                  }
               }
            }

            p.closeHandledScreen();
            if (needPotion > 0) {
               this.fail("В сундуке расхода нет зелья невидимости.");
            } else if (needFood > 0) {
               this.fail("В сундуке расхода нет еды.");
            } else {
               this.fail("В сундуке расхода нет зелья скорости.");
            }
         }
      }
   }

   /** Берёт ровно count предметов из одного стака: поднимает стак, кладёт count по одному в пустой слот игрока, остаток возвращает. */
   private void takeExactly(ScreenHandler h, int slot, int count, ClientPlayerEntity p) {
      ItemStack st = h.getSlot(slot).getStack();
      if (st.getCount() <= count) {
         this.mc.interactionManager.clickSlot(h.syncId, slot, 0, SlotActionType.QUICK_MOVE, p);
         return;
      }

      int chestSlots = ((GenericContainerScreenHandler)h).getRows() * 9;
      int target = -1;

      for (int i = chestSlots; i < h.slots.size(); i++) {
         if (h.getSlot(i).getStack().isEmpty()) {
            target = i;
            break;
         }
      }

      if (target < 0) {
         return;
      }

      this.mc.interactionManager.clickSlot(h.syncId, slot, 0, SlotActionType.PICKUP, p);

      for (int i = 0; i < count; i++) {
         this.mc.interactionManager.clickSlot(h.syncId, target, 1, SlotActionType.PICKUP, p);
      }

      this.mc.interactionManager.clickSlot(h.syncId, slot, 0, SlotActionType.PICKUP, p);
   }

   private int freePlayerSlots(ScreenHandler h, int chestSlots) {
      int free = 0;

      for (int i = chestSlots; i < h.slots.size(); i++) {
         if (h.getSlot(i).getStack().isEmpty()) {
            free++;
         }
      }

      return free;
   }

   private String anCmd(TextSetting n) {
      String v = ((String)n.get()).trim().replaceAll("[^0-9]", "");
      return "/an" + (v.isEmpty() ? "1" : v);
   }

   private void sendAn(String cmd, AutoWardenModule.State next) {
      if (this.walker != null) {
         this.walker.stop();
      }

      if (this.mc.currentScreen instanceof HandledScreen) {
         this.mc.player.closeHandledScreen();
      }

      this.sawWorldChange = false;
      String c = cmd == null ? "" : cmd.trim();
      if (c.startsWith("/")) {
         c = c.substring(1);
      }

      this.mc.getNetworkHandler().sendChatCommand(c);
      this.anSentAt = System.currentTimeMillis();
      this.anToBase = next == AutoWardenModule.State.WAIT_BASE_WORLD;
      this.setState(next);
   }

   private void waitWorld(AutoWardenModule.State next) {
      // Раньше здесь ждали ФАКТА смены мира — и это ломало цикл: если /anN
      // уходил в момент смерти, сервер отвечал «Вы уже подключены к этому
      // серверу!», мир не менялся, и по таймауту модуль падал с «команда
      // не сработала?». Теперь просто держим паузу 1 секунду после команды
      // и идём дальше по циклу без проверки смены мира.
      if (this.stateTicks >= 20) {
         this.sawWorldChange = false;
         this.setState(next);
      }
   }

   private void sendHome() {
      String cmd = (HOME_CMD).trim();
      if (cmd.startsWith("/")) {
         cmd = cmd.substring(1);
      }

      this.mc.getNetworkHandler().sendChatCommand(cmd);
      this.sawWorldChange = false;
      this.setState(AutoWardenModule.State.WAIT_TP);
   }

   private void waitTp(ClientPlayerEntity p) {
      if (this.walker != null) {
         this.walker.releaseKeys();
      }

      if (!this.consuming && this.stateTicks > 5) {
         if (!p.hasStatusEffect(StatusEffects.INVISIBILITY)) {
            this.startConsume(p, AutoWardenModule::isInvisPotion);
         } else if ((Boolean)this.useSpeed.get() && !p.hasStatusEffect(StatusEffects.SPEED)) {
            this.startConsume(p, AutoWardenModule::isSpeedPotion);
         }
      }

      this.tickConsume(p);
      if ((double)this.stateTicks >= (double)TP_SECONDS * 20.0 + 20.0 && !this.consuming) {
         this.setState(AutoWardenModule.State.CLEAN_HOTBAR);
      }
   }

   /** Расстояние по горизонтали от игрока до границы зоны вардена (0 — уже внутри). */
   private double distToCity(ClientPlayerEntity p) {
      BlockPos a = this.areaMin();
      BlockPos b = this.areaMax();
      double dx = Math.max(0.0, Math.max(a.getX() - p.getX(), p.getX() - (b.getX() + 1)));
      double dz = Math.max(0.0, Math.max(a.getZ() - p.getZ(), p.getZ() - (b.getZ() + 1)));
      return Math.hypot(dx, dz);
   }

   /** Перед /home: если мы уже рядом с городом вардена — команда не нужна, сразу к делу. */
   private void wardenCheck(ClientPlayerEntity p) {
      if (this.walker != null) {
         this.walker.releaseKeys();
      }

      if (this.stateTicks < 10) {
         return;
      }

      double d = this.distToCity(p);
      if (d <= CITY_NEAR_DIST) {
         this.sawWorldChange = false;
         this.setState(AutoWardenModule.State.WAIT_TP);
      } else {

         this.sendHome();
      }
   }

   private void cleanHotbar(ClientPlayerEntity p, AutoWardenModule.State next) {
      if (this.walker != null) {
         this.walker.releaseKeys();
      }

      if (!this.consuming && (this.mc.currentScreen == null || this.mc.currentScreen instanceof HandledScreen) && this.actionCooldown <= 0) {
         ScreenHandler h = p.playerScreenHandler;

         for (int hb = 36; hb <= 44; hb++) {
            if (!h.getSlot(hb).getStack().isEmpty()) {
               int free = -1;

               for (int inv = 9; inv <= 35; inv++) {
                  if (h.getSlot(inv).getStack().isEmpty()) {
                     free = inv;
                     break;
                  }
               }

               if (free >= 0) {
                  this.mc.interactionManager.clickSlot(h.syncId, hb, 0, SlotActionType.PICKUP, p);
                  this.mc.interactionManager.clickSlot(h.syncId, free, 0, SlotActionType.PICKUP, p);
               } else {
                  // Инвентарь полон — иначе вечный цикл: хотбар грязный, а
                  // переложить некуда, и бот стоит на месте навсегда (классика
                  // после лута сундуков). Выбрасываем стак с хотбара: THROW
                  // с button=1 роняет весь стак. Потеря хлама, но бот живой.
                  this.mc.interactionManager.clickSlot(h.syncId, hb, 1, SlotActionType.THROW, p);
               }

               this.actionCooldown = 3;
               return;
            }
         }

         if (next != null) {
            this.setState(next);
         }
      }
   }

   private boolean hotbarDirty(ClientPlayerEntity p) {
      for (int i = 0; i < 9; i++) {
         if (!p.getInventory().getStack(i).isEmpty()) {
            return true;
         }
      }

      return false;
   }

   private BlockPos areaMin() {
      return new BlockPos(
         (int)Math.min((double)AREA_X1, (double)AREA_X2), -64, (int)Math.min((double)AREA_Z1, (double)AREA_Z2)
      );
   }

   private BlockPos areaMax() {
      return new BlockPos(
         (int)Math.max((double)AREA_X1, (double)AREA_X2), 320, (int)Math.max((double)AREA_Z1, (double)AREA_Z2)
      );
   }

   private boolean inArea(BlockPos p) {
      BlockPos a = this.areaMin();
      BlockPos b = this.areaMax();
      return p.getX() >= a.getX()
         && p.getX() <= b.getX()
         && p.getZ() >= a.getZ()
         && p.getZ() <= b.getZ();
   }

   private PathFinder pf() {
      if (this.pathFinder == null || this.mc.world != this.lastWorld) {
         this.pathFinder = new PathFinder(this.mc.world, this.areaMin(), this.areaMax());
      }

      // Вардена больше не объезжаем: путь строится как будто его нет,
      // а при близком вардене бот просто переходит на шифт (tickWardenSneak).
      this.pathFinder.setDangers(new ArrayList<>(), 0.0);
      return this.pathFinder;
   }

   private boolean pvpBarVisible() {
      try {
         Map<UUID, ClientBossBar> bars = ((BossBarHudAccessor)this.mc.inGameHud.getBossBarHud()).pc$getBossBars();
         String want = (PVP_BAR).toLowerCase(Locale.ROOT);

         for (ClientBossBar b : bars.values()) {
            String s = b.getName().getString().replaceAll("§.", "").toLowerCase(Locale.ROOT);
            if (s.contains(want)) {
               return true;
            }
         }
      } catch (Throwable var6) {
      }

      return false;
   }

   /** PvP-режим считается активным, только если босс-бар висит непрерывно ≥ 3 с (защита от мигающих баров). */
   private boolean isPvp() {
      long now = System.currentTimeMillis();
      if (this.pvpBarVisible()) {
         this.lastPvpSeenAt = now;
         if (this.pvpSince == 0L) {
            this.pvpSince = now;
         }
      } else if (this.pvpSince != 0L && now - this.lastPvpSeenAt > PVP_GRACE_MS) {
         // Бара нет дольше PVP_GRACE_MS — режим реально кончился. Короткое
         // мигание босс-бара сброс не делает: бот не должен отправить /anN
         // в паузе между двумя показами бара посреди PvP.
         this.pvpSince = 0L;
         return false;
      } else if (this.pvpSince == 0L) {
         return false;
      }

      // Бар виден прямо сейчас (или только что был, в пределах grace) — режим
      // активен СРАЗУ. Прежний «прогрев» 3 с от первого появления оставлял
      // окно, в котором бот успевал выйти в самом начале PvP.
      return true;
   }

   private java.nio.file.Path chestsFile() {
      return ru.neuclient.client.util.ClientPaths.file("warden_chests.json");
   }

   private void loadKnownChests() {
      try {
         java.nio.file.Path f = this.chestsFile();
         if (java.nio.file.Files.exists(f)) {
            com.google.gson.JsonElement el = com.google.gson.JsonParser.parseString(java.nio.file.Files.readString(f));
            if (el.isJsonArray()) {
               for (com.google.gson.JsonElement e : el.getAsJsonArray()) {
                  com.google.gson.JsonArray a = e.getAsJsonArray();
                  BlockPos pos = new BlockPos(a.get(0).getAsInt(), a.get(1).getAsInt(), a.get(2).getAsInt());
                  if (this.inArea(pos)) {
                     this.knownChests.add(pos);
                  }
               }
            }
         }
      } catch (Exception ignored) {
      }
   }

   private void saveKnownChests() {
      try {
         com.google.gson.JsonArray arr = new com.google.gson.JsonArray();
         for (BlockPos c : this.knownChests) {
            com.google.gson.JsonArray a = new com.google.gson.JsonArray();
            a.add(c.getX());
            a.add(c.getY());
            a.add(c.getZ());
            arr.add(a);
         }

         java.nio.file.Files.writeString(this.chestsFile(), arr.toString());
      } catch (Exception ignored) {
      }
   }

   private void scanChests(ClientPlayerEntity p) {
      BlockPos c = p.getBlockPos();
      int r = 32;

      for (int x = -r; x <= r; x++) {
         for (int z = -r; z <= r; z++) {
            for (int y = -12; y <= 12; y++) {
               BlockPos pos = c.add(x, y, z);
               if (this.inArea(pos)) {
                  BlockEntity be = this.mc.world.getBlockEntity(pos);
                  if (be != null
                     && (
                        be.getType() == BlockEntityType.CHEST
                           || be.getType() == BlockEntityType.TRAPPED_CHEST
                     )) {
                     if (this.knownChests.add(pos)) {
                        this.knownChestsDirty = true;
                     }
                  } else if (this.knownChests.contains(pos) && this.mc.world.isChunkLoaded(pos)
                     && pos.getSquaredDistance(p.getX(), p.getY(), p.getZ()) < 64.0) {
                     // Сундука больше нет — забываем
                     this.knownChests.remove(pos);
                     this.knownChestsDirty = true;
                  }
               }
            }
         }
      }

      if (this.knownChestsDirty) {
         this.knownChestsDirty = false;
         this.saveKnownChests();
      }
   }

   private WardenESP esp() {
      WardenESP esp = (WardenESP)NeuClient.getInstance().getModuleManager().get(WardenESP.class);
      if (esp != null && !esp.isEnabled()) {
         esp.setEnabled(true);
      }

      return esp;
   }

   /** Синхронизирует состояние таймеров WardenESP: сундуки с истёкшим таймером попадают в readyChests. */
   private Map<BlockPos, long[]> syncTimers() {
      WardenESP esp = this.esp();
      Map<BlockPos, long[]> timers = esp != null ? esp.getActiveChests() : Map.of();

      for (Entry<BlockPos, long[]> e : timers.entrySet()) {
         BlockPos pos = e.getKey();
         int sec = esp.getRemainingSeconds(e.getValue());
         if (this.lootedChests.contains(pos) && !this.lastTimerKeys.contains(pos)) {
            this.lootedChests.remove(pos);
         }

         if (sec > 0) {
            // Живой таймер — запоминаем, что сундук «на таймере».
            this.timedChests.add(pos);
         }

         if (sec <= 0 && !this.lootedChests.contains(pos)) {
            this.zeroSince.putIfAbsent(pos, System.currentTimeMillis());
         }
      }

      for (BlockPos old : this.lastTimerKeys) {
         if (!timers.containsKey(old) && !this.lootedChests.contains(old)) {
            this.readyChests.add(old);
            this.zeroSince.remove(old);
         }
      }

      long nowMs = System.currentTimeMillis();
      this.zeroSince.entrySet().removeIf(e -> {
         if (!timers.containsKey(e.getKey())) {
            return true;
         } else if (nowMs - e.getValue() > 15000L) {
            this.readyChests.add(e.getKey());
            return true;
         } else {
            return false;
         }
      });

      this.lastTimerKeys.clear();
      this.lastTimerKeys.addAll(timers.keySet());
      this.readyChests.removeAll(this.lootedChests);
      return timers;
   }

   private boolean isChestReady(BlockPos pos) {
      // Достоверно знаем, что таймер истёк (стойка пропала / отсчёт дошёл до нуля).
      if (this.readyChests.contains(pos)) {
         return true;
      }

      WardenESP esp = this.esp();
      boolean tracked = esp != null && esp.getActiveChests().containsKey(pos);
      if (tracked) {
         // Сундук на живом таймере — открывать рано.
         return false;
      }

      // Ранее видели у него таймер, а сейчас таймера нет. Если отсчёт дошёл до
      // нуля — готов. Если данных нет ВООБЩЕ (left = -1) — голограмма не видна:
      // либо таймер истёк и стойка исчезла, либо сервер залагал и не показывает
      // её. В обоих случаях пробуем открыть: если таймер на самом деле идёт,
      // сундук просто не откроется — бот уйдёт на кулдаун и вернётся.
      if (this.timedChests.contains(pos)) {
         return this.secondsLeft(pos) != -1 ? this.secondsLeft(pos) == 0 : true;
      }

      // Сундук никогда не был под таймером — он свободен.
      return true;
   }

   private int secondsLeft(BlockPos pos) {
      WardenESP esp = this.esp();
      if (esp == null) {
         return -1;
      } else {
         long[] d = esp.getActiveChests().get(pos);
         return d == null ? (this.readyChests.contains(pos) ? 0 : -1) : Math.max(0, esp.getRemainingSeconds(d));
      }
   }

   /** Ближайший известный сундук в зоне вардена, у которого нет таймера в WardenESP. */
   private BlockPos nearestNoTimerChest(ClientPlayerEntity p, Map<BlockPos, long[]> timers) {
      BlockPos nearest = null;
      double nd = Double.MAX_VALUE;

      for (BlockPos c : this.knownChests) {
         if (!timers.containsKey(c) && !this.visitedNoTimer.contains(c) && !this.lootedChests.contains(c)
            && !this.skipChests.contains(c) && !this.isPathFailed(c)) {
            double d = c.getSquaredDistance(p.getX(), p.getY(), p.getZ());
            if (d < nd) {
               nd = d;
               nearest = c;
            }
         }
      }

      return nearest;
   }

   private BlockPos pickTarget(ClientPlayerEntity p) {
      Map<BlockPos, long[]> timers = this.syncTimers();

      // ПРИОРИТЕТ 1 (по ТЗ): сундук БЕЗ таймера в радиусе 5 блоков — быстрый
      // лут. Радиус мал осознанно: «без таймера» дальше может быть просто
      // НЕПРОГРУЖЕННЫМ сундуком (таймер неизвестен) — таким место в разведке
      // (приоритет 3), а не поверх горящего (<30 с) сундука.
      BlockPos best = null;
      double nd = Double.MAX_VALUE;

      for (BlockPos c : this.knownChests) {
         if (!timers.containsKey(c) && !this.visitedNoTimer.contains(c) && !this.lootedChests.contains(c)
            && !this.skipChests.contains(c) && !this.isPathFailed(c)) {
            double d = c.getSquaredDistance(p.getX(), p.getY(), p.getZ());
            if (d <= 25.0 && d < nd) {
               nd = d;
               best = c;
            }
         }
      }

      if (best != null) {
         return best;
      }

      // ПРИОРИТЕТ 2: «горящий» (таймер < 30 c). Приверженность: выбранный
      // горящий сундук держим до самого открытия — мигнувшая на секунду
      // голограмма (лаг сервера) больше не отправит бота убегать за секунды
      // до открытия.
      if (this.burnCommit != null) {
         long[] cd = timers.get(this.burnCommit);
         if (cd != null && !this.lootedChests.contains(this.burnCommit)
            && !this.skipChests.contains(this.burnCommit) && !this.isPathFailed(this.burnCommit)) {
            int sec = this.esp().getRemainingSeconds(cd);
            if (sec >= 0 && sec <= GO_AT_SECONDS + 5) {
               return this.burnCommit;
            }
         }
         this.burnCommit = null;
      }

      // Сначала «горящие» (таймер < GO_AT_SECONDS): вот-вот откроются — они
      // важнее любых готовых, иначе бот разберёт по пути другие сундуки и
      // опоздает к открытию.
      int burnSec = Integer.MAX_VALUE;
      for (Entry<BlockPos, long[]> e : timers.entrySet()) {
         if (this.lootedChests.contains(e.getKey()) || this.skipChests.contains(e.getKey())
            || this.isPathFailed(e.getKey())) {
            continue;
         }

         int sec = this.esp().getRemainingSeconds(e.getValue());
         if (sec > 0 && sec <= GO_AT_SECONDS && sec < burnSec) {
            burnSec = sec;
            best = e.getKey();
         }
      }

      if (best != null) {
         this.burnCommit = best;
         return best;
      }

      for (BlockPos c : this.readyChests) {
         // Сундук, у которого уже были и не смогли открыть (visitedNoTimer),
         // или уже обчищенный, брать нельзя — иначе цикл «подошёл → стоял
         // 5 секунд у закрытого сундука → ушёл → снова подошёл».
         if (this.visitedNoTimer.contains(c) || this.lootedChests.contains(c) || this.skipChests.contains(c)
            || this.isPathFailed(c)) {
            continue;
         }

         double d = c.getSquaredDistance(p.getX(), p.getY(), p.getZ());
         if (d < nd) {
            nd = d;
            best = c;
         }
      }

      if (best != null) {
         return best;
      }

      BlockPos noTimer = this.nearestNoTimerChest(p, timers);
      if (noTimer != null) {
         return noTimer;
      }

      WardenESP esp = this.esp();
      int bestSec = Integer.MAX_VALUE;
      int limit = (int)Math.round((double)GO_AT_SECONDS);

      for (Entry<BlockPos, long[]> e : timers.entrySet()) {
         if (!this.lootedChests.contains(e.getKey()) && !this.isPathFailed(e.getKey())) {
            int sec = esp.getRemainingSeconds(e.getValue());
            if (sec <= limit && sec < bestSec) {
               bestSec = sec;
               best = e.getKey();
            }
         }
      }

      return best;
   }

   private void roam(ClientPlayerEntity p) {
      // PvP-режим здесь ничего не меняет: сундуки открываем как обычно,
      // ограничение только на отправку /anN (см. GO_BASE_AN).
      if (this.hotbarDirty(p)) {
         this.cleanHotbar(p, null);
         return;
      }

      if (this.unstick(p)) {
         return;
      }

      if (this.stateTicks % 10 == 0) {
         this.scanChests(p);
      }

      BlockPos target = this.pickTarget(p);
      if (target != null) {
         this.targetChest = target;
         this.walker.stop();
         this.setState(AutoWardenModule.State.GO_CHEST);
      } else {
         if (this.ensureRoamPath(p)) {
            this.walker.tick();
         }
      }
   }

   /**
    * Гарантирует живой путь для блуждания. false — в этот тик построить не
    * удалось, НО благодаря эскалации это не превращается в вечное стояние:
    * 2 сек ищем точки ближе, 6 сек — игнорируя вардена, затем идём к
    * ближайшей точке, куда вообще можно встать.
    */
   private boolean ensureRoamPath(ClientPlayerEntity p) {
      // Идёт манёвр отхода — блуждание не перебивает его.
      if (this.escapeSpot != null) {
         return false;
      }

      if (this.walker.hasPath() && !this.walker.isStuck() && !this.walker.reachedGoal()) {
         this.noRoamTicks = 0;
         return true;
      }

      if (this.walker.isStuck()) {
         this.stuckStrikes++;
         if (this.stuckStrikes >= 2) {
            this.startEscape(p);
            return false;
         }
      }

      boolean relaxed = this.noRoamTicks > 40;
      boolean desperate = this.noRoamTicks > 120;
      BlockPos t = this.randomRoamPoint(p, relaxed ? 25.0 : 225.0);
      if (t == null && desperate) {
         t = this.nearestStandable(p, 10);
      }

      if (t == null) {
         this.noRoamTicks++;
         return false;
      }

      List<BlockPos> path = this.pf().find(p.getBlockPos(), t, 2.0);
      if (path == null && desperate) {
         BlockPos near = this.nearestStandable(p, 12);
         if (near != null) {
            List<BlockPos> nearPath = this.pf().find(p.getBlockPos(), near, 1.2);
            if (nearPath != null) {
               t = near;
               path = nearPath;
            }
         }
      }

      if (path == null) {
         this.noRoamTicks++;
         return false;
      }

      this.noRoamTicks = 0;
      this.roamTarget = t;
      this.walker.setPath(path, t, 2.0);
      return true;
   }

   /** Ближайшая точка не ближе 2 блоков, где можно стоять (крайний фолбэк). */
   private BlockPos nearestStandable(ClientPlayerEntity p, int r) {
      BlockPos c0 = p.getBlockPos();
      BlockPos best = null;
      double bd = Double.MAX_VALUE;

      for (int x = -r; x <= r; x++) {
         for (int y = -4; y <= 4; y++) {
            for (int z = -r; z <= r; z++) {
               if (x == 0 && z == 0) continue;
               BlockPos c = c0.add(x, y, z);
               if (this.pf().canStandAt(c)) {
                  double d = c.getSquaredDistance(c0);
                  if (d >= 4.0 && d < bd) {
                     bd = d;
                     best = c;
                  }
               }
            }
         }
      }

      return best;
   }

   private BlockPos edgeTarget;

   /** Точка у случайного края территории (в полосе 3–8 блоков от границы). */
   private BlockPos randomEdgePoint(ClientPlayerEntity p) {
      Random rnd = new Random();
      BlockPos a = this.areaMin();
      BlockPos b = this.areaMax();
      int py = p.getBlockPos().getY();

      // Ближайшая к игроку сторона — так убегаем от центра по кратчайшей
      double dx0 = p.getX() - a.getX();
      double dx1 = (b.getX() + 1) - p.getX();
      double dz0 = p.getZ() - a.getZ();
      double dz1 = (b.getZ() + 1) - p.getZ();
      int nearestSide = dx0 <= dx1 && dx0 <= dz0 && dx0 <= dz1 ? 0 : dx1 <= dz0 && dx1 <= dz1 ? 1 : dz0 <= dz1 ? 2 : 3;

      for (int attempt = 0; attempt < 60; attempt++) {
         int side = attempt < 30 ? nearestSide : rnd.nextInt(4);
         int inset = 3 + rnd.nextInt(6);
         int x;
         int z;
         switch (side) {
            case 0 -> { x = a.getX() + inset; z = a.getZ() + rnd.nextInt(b.getZ() - a.getZ() + 1); }
            case 1 -> { x = b.getX() - inset; z = a.getZ() + rnd.nextInt(b.getZ() - a.getZ() + 1); }
            case 2 -> { z = a.getZ() + inset; x = a.getX() + rnd.nextInt(b.getX() - a.getX() + 1); }
            default -> { z = b.getZ() - inset; x = a.getX() + rnd.nextInt(b.getX() - a.getX() + 1); }
         }

         for (int y = py + 16; y >= py - 16; y--) {
            BlockPos c = new BlockPos(x, y, z);
            if (this.pf().canStandAt(c) && !this.pf().isDangerous(c.down())) {
               return c;
            }
         }
      }

      return null;
   }

   /** Насколько далеко от центра зоны (0 — центр, 1 — граница). */
   private double centerFactor(ClientPlayerEntity p) {
      BlockPos a = this.areaMin();
      BlockPos b = this.areaMax();
      double cx = (a.getX() + b.getX() + 1) / 2.0;
      double cz = (a.getZ() + b.getZ() + 1) / 2.0;
      double hx = (b.getX() - a.getX() + 1) / 2.0;
      double hz = (b.getZ() - a.getZ() + 1) / 2.0;
      return Math.max(Math.abs(p.getX() - cx) / hx, Math.abs(p.getZ() - cz) / hz);
   }

   /**
    * Лив: пока PvP — бежим к краю зоны (от центра), а как только режим
    * спал — уходим МГНОВЕННО, не добегая до точки и не дожидаясь таймеров.
    */
   private void goEdge(ClientPlayerEntity p) {
      if (this.hotbarDirty(p)) {
         this.cleanHotbar(p, null);
         return;
      }

      if (!this.isPvp()) {
         this.setState(AutoWardenModule.State.GO_BASE_AN);
         return;
      }

      this.runToEdgeWhilePvp(p);
   }

   /** Пока длится PvP: держим бег к краю зоны, чтобы к спаду режима быть подальше от людей. */
   private void runToEdgeWhilePvp(ClientPlayerEntity p) {
      if (this.stateTicks == 1 && this.walker != null) {
         this.edgeTarget = null;
      }

      if (this.edgeTarget == null || this.walker.isStuck() || !this.walker.hasPath()) {
         this.edgeTarget = this.randomEdgePoint(p);
         if (this.edgeTarget == null) {
            return;
         }

         List<BlockPos> path = this.pf().find(p.getBlockPos(), this.edgeTarget, 2.5);
         if (path == null) {
            this.edgeTarget = null;
            return;
         }

         this.walker.setPath(path, this.edgeTarget, 2.5);
      }

      this.walker.tick();
   }

   /** Случайная точка блуждания: minDistSq — мин. квадрат дистанции до игрока. */
   private BlockPos randomRoamPoint(ClientPlayerEntity p, double minDistSq) {
      Random rnd = new Random();
      BlockPos a = this.areaMin();
      BlockPos b = this.areaMax();

      for (int attempt = 0; attempt < 40; attempt++) {
         int x = a.getX() + rnd.nextInt(b.getX() - a.getX() + 1);
         int z = a.getZ() + rnd.nextInt(b.getZ() - a.getZ() + 1);
         int py = p.getBlockPos().getY();

         for (int y = py + 12; y >= py - 12; y--) {
            BlockPos c = new BlockPos(x, y, z);
            if (this.pf().canStandAt(c) && !this.pf().isDangerous(c.down())) {
               if (c.getSquaredDistance(p.getX(), p.getY(), p.getZ()) > minDistSq) {
                  return c;
               }
               break;
            }
         }
      }

      return null;
   }

   /** Дистанция до ближайшего живого вардена (Double.MAX_VALUE, если их нет). */
   private double nearestWardenDist(ClientPlayerEntity p) {
      double best = Double.MAX_VALUE;

      for (Entity e : this.mc.world.getEntities()) {
         if (e instanceof WardenEntity w && w.isAlive()) {
            double d = w.squaredDistanceTo(p.getX(), p.getY(), p.getZ());
            if (d < best) {
               best = d;
            }
         }
      }

      return best == Double.MAX_VALUE ? best : Math.sqrt(best);
   }

   /** Ближайший живой варден или null, если он дальше WARDEN_AGGRO_DIST. */
   private WardenEntity nearestWardenEntity(ClientPlayerEntity p) {
      WardenEntity best = null;
      double bd = Double.MAX_VALUE;

      for (Entity e : this.mc.world.getEntities()) {
         if (e instanceof WardenEntity w && w.isAlive()) {
            double d = w.squaredDistanceTo(p.getX(), p.getY(), p.getZ());
            if (d < bd) {
               bd = d;
               best = w;
            }
         }
      }

      return bd <= WARDEN_AGGRO_DIST * WARDEN_AGGRO_DIST ? best : null;
   }

   /** Смотрит ли варден головой на игрока (в пределах 35°). */
   private boolean isWardenFacingPlayer(WardenEntity w, ClientPlayerEntity p) {
      double dx = p.getX() - w.getX();
      double dz = p.getZ() - w.getZ();
      float want = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
      float diff = Math.abs(MathHelper.wrapDegrees(w.getHeadYaw() - want));
      return diff <= 35.0f;
   }

   /**
    * Хук из SoundSystemMixin: варден подал голос в (x, y, z). Слышим мы
    * его только на дистанции слышимости, так что звук в радиусе агра —
    * прямой признак, что варден рядом и активен.
    */
   public static void onWardenSound(double x, double y, double z) {
      AutoWardenModule m = instance;
      if (m == null || !m.isEnabled() || m.mc.player == null || m.mc.world == null) {
         return;
      }

      if (m.mc.player.squaredDistanceTo(x, y, z) <= WARDEN_AGGRO_DIST * WARDEN_AGGRO_DIST) {
         m.lastWardenSoundAt = System.currentTimeMillis();
      }
   }

   /**
    * Манёвр отхода: бот застрял (обычно в заборах) дважды подряд — уводим
    * его на ближайшую ЧИСТУЮ от заборов точку, после чего обычная логика
    * перестраивает путь уже со свободного места.
    */
   private void startEscape(ClientPlayerEntity p) {
      this.stuckStrikes = 0;
      BlockPos spot = this.findEscapeSpot(p, 6);
      if (spot == null) {
         return;
      }

      List<BlockPos> path = this.pf().find(p.getBlockPos(), spot, 1.2);
      if (path == null) {
         return;
      }

      this.escapeSpot = spot;
      this.escapeUntilMs = System.currentTimeMillis() + 4000L;
      this.walker.stop();
      this.walker.setPath(path, spot, 1.2);
   }

   /** Идёт ли сейчас манёвр отхода (true — обычная навигация в этом тике отменяется). */
   private boolean unstick(ClientPlayerEntity p) {
      if (this.escapeSpot == null) {
         return false;
      }

      long now = System.currentTimeMillis();
      double d = Math.hypot(
         (double)this.escapeSpot.getX() + 0.5 - p.getX(),
         (double)this.escapeSpot.getZ() + 0.5 - p.getZ()
      );
      if (now > this.escapeUntilMs || d <= 1.2 && Math.abs((double)this.escapeSpot.getY() - p.getY()) <= 2.0) {
         this.escapeSpot = null;
         this.walker.stop();
         return false;
      }

      if (!this.walker.hasPath() || this.walker.isStuck()) {
         List<BlockPos> path = this.pf().find(p.getBlockPos(), this.escapeSpot, 1.2);
         if (path == null) {
            this.escapeSpot = null;
            this.walker.stop();
            return false;
         }

         this.walker.setPath(path, this.escapeSpot, 1.2);
      }

      this.walker.tick();
      return true;
   }

   /** Ближайшая точка, где можно стоять и рядом (в радиусе 1) нет заборов. */
   private BlockPos findEscapeSpot(ClientPlayerEntity p, int r) {
      BlockPos c0 = p.getBlockPos();
      BlockPos best = null;
      double bd = Double.MAX_VALUE;

      for (int x = -r; x <= r; x++) {
         for (int y = -1; y <= 1; y++) {
            for (int z = -r; z <= r; z++) {
               BlockPos c = c0.add(x, y, z);
               double d = c.getSquaredDistance(c0);
               if (d < 4.0 || !this.pf().canStandAt(c) || this.fenceNear(c)) {
                  continue;
               }

               if (d < bd) {
                  bd = d;
                  best = c;
               }
            }
         }
      }

      return best;
   }

   /** Есть ли забор (коллизия выше 1 блока) вплотную к клетке. */
   private boolean fenceNear(BlockPos c) {
      for (int dx = -1; dx <= 1; dx++) {
         for (int dz = -1; dz <= 1; dz++) {
            BlockPos n = c.add(dx, 0, dz);
            VoxelShape shape = this.mc.world.getBlockState(n).getCollisionShape(this.mc.world, n);
            if (!shape.isEmpty() && shape.getMax(Direction.Axis.Y) > 1.0001) {
               return true;
            }
         }
      }

      return false;
   }

   private void goChest(ClientPlayerEntity p) {
      // Манёвр отхода важнее навигации к сундуку.
      if (this.unstick(p)) {
         return;
      }

      // PvP-режим не мешает дойти до сундука и открыть его.
      if (this.targetChest == null) {
         this.setState(AutoWardenModule.State.ROAM);
      } else {
         double dist = Math.hypot(
            (double)this.targetChest.getX() + 0.5 - p.getX(), (double)this.targetChest.getZ() + 0.5 - p.getZ()
         );
         if (this.stateTicks % 20 == 0) {
            int left = this.secondsLeft(this.targetChest);
            // Приверженному горящему сундуку разрешаем небольшой подъём
            // таймера (ресинк голограммы), не бросая его на кулдаун.
            int tolerate = this.targetChest.equals(this.burnCommit) ? GO_AT_SECONDS + 5 : GO_AT_SECONDS;
            if (left > tolerate && !this.readyChests.contains(this.targetChest) && dist > 2.6) {
               // Ещё в пути — а там длинный таймер. Пауза 60 с (не вечный
               // пропуск: сундук мог быть не прогружен, вернёмся на круге).
               // Если уже СТОИМ у сундука — не уходим: дедлайн ниже решит.
               this.pathFailUntil.put(this.targetChest, System.currentTimeMillis() + 60000L);
               this.burnCommit = null;
               this.targetChest = null;
               this.walker.stop();
               this.setState(AutoWardenModule.State.ROAM);
               return;
            }

            // Дошли и стоим у сундука — цель НЕ меняем: уже почти открытый
            // важнее любого другого. Переоценка только пока ещё в пути.
            if (dist > 2.6 || Math.abs((double)this.targetChest.getY() - p.getY()) > 2.5) {
               BlockPos better = this.pickTarget(p);
               if (better != null && !better.equals(this.targetChest)) {
                  this.targetChest = better;
                  this.walker.stop();
               }
            }
         }
         if (dist <= 2.6 && Math.abs((double)this.targetChest.getY() - p.getY()) <= 2.5) {
            this.walker.stop();
            // Открываем ТОЛЬКО если таймер достоверно истёк. Если он ещё тикает —
            // ждём рядом. Горящий (<30 с) по ТЗ ждём ДО ОТКРЫТИЯ: дедлайн
            // фиксируется в момент прихода (таймер + запас) и только продлевается.
            // Раньше cap пересчитывался от ТЕКУЩЕГО таймера каждый тик, «полз»
            // вниз вслед за отсчётом — и бот уходил за 3–5 с до открытия.
            if (this.isChestReady(this.targetChest)) {
               this.standingAt = null;
               this.standUntilMs = 0L;
               this.setState(AutoWardenModule.State.LOOT_OPEN);
            } else {
               long nowMs = System.currentTimeMillis();
               if (!this.targetChest.equals(this.standingAt)) {
                  this.standingAt = this.targetChest;
                  // Неизвестный/длинный таймер — не стоим дольше 5 с.
                  this.standUntilMs = nowMs + 5000L;
               }

               int left = this.secondsLeft(this.targetChest);
               boolean timed = this.timedChests.contains(this.targetChest);
               boolean burning = timed && left > 0 && left <= GO_AT_SECONDS;
               boolean imminent = timed && left == 0;
               if (burning) {
                  // Таймер + 10 с запаса. Только ПРОДЛЕВАЕМ: ресинк голограммы
                  // мог поднять отсчёт (лаг сервера) — не повод бросать сундук.
                  long need = nowMs + (long)left * 1000L + 10000L;
                  if (need > this.standUntilMs) {
                     this.standUntilMs = need;
                  }
               } else if (imminent) {
                  long need = nowMs + 25000L;
                  if (need > this.standUntilMs) {
                     this.standUntilMs = need;
                  }
               }

               if (nowMs > this.standUntilMs) {
                  // Пауза 30 с и к другим сундукам (не навсегда).
                  this.pathFailUntil.put(this.targetChest, nowMs + 30000L);
                  this.standingAt = null;
                  this.standUntilMs = 0L;
                  this.targetChest = null;
                  this.walker.stop();
                  this.setState(AutoWardenModule.State.ROAM);
                  return;
               }

               if (imminent) {
                  // Таймер уже нулевой, но syncTimers ещё не подтвердил готовность —
                  // синхронизируем вручную, чтобы не ждать лишний тик.
                  this.syncTimers();
               }
            }
         } else {
            if (this.walker.isStuck()) {
               this.stuckStrikes++;
            } else if (this.walker.hasPath()) {
               this.stuckStrikes = 0;
            }

            if (!this.walker.hasPath() || this.walker.isStuck() || !this.targetChest.equals(this.walker.getGoal())) {
               if (this.stuckStrikes >= 2) {
                  // Дважды застряли подряд — отходим на чистую точку.
                  this.startEscape(p);
                  return;
               }

               List<BlockPos> path = this.pf().find(p.getBlockPos(), this.targetChest, 2.0);
               if (path == null) {
                  // Не вечно: через 30 с снова попробуем (чанки могли догрузиться).
                  this.pathFailUntil.put(this.targetChest, System.currentTimeMillis() + 30000L);

                  this.targetChest = null;
                  this.setState(AutoWardenModule.State.ROAM);
                  return;
               }

               this.walker.setPath(path, this.targetChest, 2.0);
            }

            this.walker.tick();
         }
      }
   }

   private void openChest(BlockPos pos, AutoWardenModule.State next, String what) {
      ClientPlayerEntity p = this.mc.player;
      if (pos == null) {
         this.setState(AutoWardenModule.State.ROAM);
      } else {
         if (this.openedContainer() != null) {
            this.visionSpot = null;
            if (this.walker != null) {
               this.walker.stop();
            }

            this.setState(next);
         } else if (this.stateTicks > 100) {
            this.visionSpot = null;
            if (this.walker != null) {
               this.walker.stop();
            }

            if (next == AutoWardenModule.State.LOOT_TAKE) {
               // Временно (60 с), а не навсегда: сундук мог быть просто
               // не прогружен — вернёмся к нему на следующем круге.
               this.pathFailUntil.put(pos, System.currentTimeMillis() + 60000L);
               this.setState(AutoWardenModule.State.ROAM);
            } else {
               this.fail("Не удалось открыть " + what + ".");
            }
         } else if (!this.isRealChest(pos)) {
            // Бочки и прочие контейнеры не открываем вовсе.
            this.visionSpot = null;
            if (next == AutoWardenModule.State.LOOT_TAKE) {
               this.skipChests.add(pos);
               this.lootedChests.add(pos);
               this.setState(AutoWardenModule.State.ROAM);
            } else if (this.stateTicks > 60) {
               this.fail("Не удалось открыть " + what + ".");
            }
         } else if (next == AutoWardenModule.State.LOOT_TAKE
            && this.timedChests.contains(pos) && this.secondsLeft(pos) > 0) {
            // Таймер ПОДТВЕРЖДЁННО идёт (голограмма видна и тикает) — открывать
            // рано. Нет данных (лаг, голограмма не видна) — пробуем открыть.
            this.visionSpot = null;
            this.setState(AutoWardenModule.State.ROAM);
         } else if (!this.canSeeChest(p, pos)) {
            // Сквозь стену не открываем: обходим, чтобы увидеть сундук.
            this.repositionForVision(p, pos);
         } else {
            this.visionSpot = null;
            if (this.walker != null) {
               this.walker.releaseKeys();
            }

            if (this.actionCooldown <= 0) {
            Vec3d eye = p.getEyePos();
            Vec3d tgt = Vec3d.ofCenter(pos);
            double dx = tgt.x - eye.x;
            double dy = tgt.y - eye.y;
            double dz = tgt.z - eye.z;
            double hd = Math.hypot(dx, dz);
            float yaw = (float)(Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
            float pitch = (float)(-Math.toDegrees(Math.atan2(dy, hd)));
            this.spoofYaw = MathHelper.wrapDegrees(yaw);
            this.spoofPitch = MathHelper.clamp(pitch, -90.0F, 90.0F);
            BlockHitResult hit = new BlockHitResult(tgt, Direction.UP, pos, false);
            this.mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, hit);
               p.swingHand(Hand.MAIN_HAND);
               this.actionCooldown = 15;
            }
         }
      }
   }

   /** Активный AutoWarden для спуф-миксинов (серверный угол + F5). */
   public static AutoWardenModule active() {
      AutoWardenModule m = instance;
      return m != null && m.isEnabled() ? m : null;
   }

   /** Бот сейчас крутит «серверную» голову: взгляд на сундук или ходьба по пути. */
   public boolean isSpoofing() {
      return this.mc.player != null && (this.isChestLook() || this.walker != null && this.walker.isSpoofing());
   }

   public float getSpoofYaw() {
      return this.isChestLook() ? this.spoofYaw : this.walker != null ? this.walker.getSpoofYaw() : this.spoofYaw;
   }

   public float getSpoofPitch() {
      return this.isChestLook() ? this.spoofPitch : this.walker != null ? this.walker.getSpoofPitch() : this.spoofPitch;
   }

   /** Открытие сундука: бот наводит серверную голову на сундук. */
   private boolean isChestLook() {
      AutoWardenModule.State s = this.state;
      return s == AutoWardenModule.State.LOOT_OPEN
         || s == AutoWardenModule.State.BASE_OPEN_SUPPLY
         || s == AutoWardenModule.State.BASE_OPEN_STORAGE;
   }

   /** Сундук, от которого недавно отказались (нет пути/не открылся) — пропускаем до конца кулдауна. */
   private boolean isPathFailed(BlockPos c) {
      Long until = this.pathFailUntil.get(c);
      if (until == null) {
         return false;
      } else if (until > System.currentTimeMillis()) {
         return true;
      } else {
         this.pathFailUntil.remove(c);
         return false;
      }
   }

   /** Это настоящий сундук (не бочка и не пустота). */
   private boolean isRealChest(BlockPos pos) {
      BlockEntity be = this.mc.world.getBlockEntity(pos);
      return be != null
         && (be.getType() == BlockEntityType.CHEST || be.getType() == BlockEntityType.TRAPPED_CHEST);
   }

   /** Виден ли сундук из глаз игрока (сквозь стены И заборы не открываем). */
   private boolean canSeeChest(ClientPlayerEntity p, BlockPos pos) {
      return this.canSeeFrom(p, p.getEyePos(), pos);
   }

   private boolean canSeeFrom(ClientPlayerEntity p, Vec3d eye, BlockPos chest) {
      return this.visibleFrom(p, eye, chest) && !this.blockedByFence(eye, chest);
   }

   /**
    * Забор/ограда (коллизия ВЫШЕ 1 блока) на линии взгляд→сундук. Обычный
    * рейкаст пропускает взгляд «чуть поверх» забора, а сервер такое открытие
    * отклоняет: считаем линию перекрытой, если она проходит выше верха
    * заборного блока менее чем на 0.35 — тогда бот обходит, а не тыкает
    * сундук через ограду.
    */
   private boolean blockedByFence(Vec3d eye, BlockPos target) {
      Vec3d b = Vec3d.ofCenter(target);
      double len = eye.distanceTo(b);
      if (len < 0.01) {
         return false;
      }

      int steps = (int)Math.ceil(len / 0.3);
      for (int i = 0; i <= steps; i++) {
         double t = (double)i / (double)steps;
         double x = MathHelper.lerp(t, eye.x, b.x);
         double y = MathHelper.lerp(t, eye.y, b.y);
         double z = MathHelper.lerp(t, eye.z, b.z);
         BlockPos bp = BlockPos.ofFloored(x, y, z);
         BlockState st = this.mc.world.getBlockState(bp);
         VoxelShape shape = st.getCollisionShape(this.mc.world, bp);
         double top = shape.isEmpty() ? 0.0 : shape.getMax(Direction.Axis.Y);
         if (top > 1.0001 && y < (double)bp.getY() + top + 0.35) {
            return true;
         }
      }

      return false;
   }

   /** Луч из точки eye до центра target: true, если упёрся только в сам target или ни во что. */
   private boolean visibleFrom(ClientPlayerEntity p, Vec3d eye, BlockPos target) {
      BlockHitResult hit = this.mc.world.raycast(
         new RaycastContext(eye, Vec3d.ofCenter(target),
            RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, p)
      );
      return hit.getType() == HitResult.Type.MISS || target.equals(hit.getBlockPos());
   }

   /** Глаза игрока, если бы он стоял в этой точке. */
   private Vec3d eyeAt(BlockPos spot) {
      return new Vec3d(spot.getX() + 0.5, spot.getY() + this.p_eyeHeight(), spot.getZ() + 0.5);
   }

   private double p_eyeHeight() {
      return this.mc.player != null ? this.mc.player.getStandingEyeHeight() : 1.62;
   }

   /** Сундук за стеной: находим точку рядом, откуда он виден, и идём туда. */
   private void repositionForVision(ClientPlayerEntity p, BlockPos chest) {
      if (this.walker == null) {
         return;
      }

      // Уже идём на рабочую точку — продолжаем, пока не дойдём.
      if (this.visionSpot != null
         && this.canSeeFrom(p, this.eyeAt(this.visionSpot), chest)
         && this.visionSpot.getSquaredDistance(p.getX(), p.getY(), p.getZ()) > 1.0) {
         this.walker.tick();
         return;
      }

      BlockPos best = null;
      double bd = Double.MAX_VALUE;
      BlockPos feet = p.getBlockPos();

      for (int dy = -1; dy <= 1; dy++) {
         for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
               if (dx == 0 && dz == 0 && dy == 0) {
                  continue;
               }

               BlockPos spot = chest.add(dx, dy, dz);
               if (!this.pf().canStandAt(spot) || !this.canSeeFrom(p, this.eyeAt(spot), chest)) {
                  continue;
               }

               double d = spot.getSquaredDistance(feet);
               if (d < bd) {
                  bd = d;
                  best = spot;
               }
            }
         }
      }

      if (best == null) {
         // Обойти не смогли — таймаут (>100 тиков) сам пропустит сундук.
         this.walker.stop();
         return;
      }

      this.visionSpot = best;
      List<BlockPos> path = this.pf().find(feet, best, 0.8);
      if (path == null) {
         this.visionSpot = null;
         this.walker.stop();
         return;
      }

      this.walker.setPath(path, best, 0.8);
      this.walker.tick();
   }

   private void lootTake(ClientPlayerEntity p) {
      GenericContainerScreenHandler h = this.openedContainer();
      if (h == null) {
         if (this.stateTicks > 40) {
            this.setState(AutoWardenModule.State.LOOT_OPEN);
         }
      } else if (this.actionCooldown <= 0) {
         int chestSlots = h.getRows() * 9;

         for (int i = 0; i < chestSlots; i++) {
            if (LootFilter.shouldLoot(h.getSlot(i).getStack())) {
               if (!this.playerInventoryFull(h, chestSlots)) {
                  this.mc.interactionManager.clickSlot(h.syncId, i, 0, SlotActionType.QUICK_MOVE, p);
                  this.actionCooldown = 1;
                  return;
               }
               break;
            }
         }

         p.closeHandledScreen();
         this.lootedChests.add(this.targetChest);
         this.readyChests.remove(this.targetChest);
         this.visitedNoTimer.add(this.targetChest);
         this.lootedThisRun++;
         int limit = Math.max(1, (int)Math.round((Double)this.chestsPerRun.get()));
         this.targetChest = null;
         if (this.lootedThisRun >= limit) {
            this.setState(AutoWardenModule.State.GO_EDGE);
         } else {
            this.setState(AutoWardenModule.State.ROAM);
         }
      }
   }

   private boolean playerInventoryFull(ScreenHandler h, int chestSlots) {
      for (int i = chestSlots; i < h.slots.size(); i++) {
         if (h.getSlot(i).getStack().isEmpty()) {
            return false;
         }
      }

      return true;
   }

   private void pvpWait(ClientPlayerEntity p) {
      if (!this.isPvp()) {
         this.walker.stop();
         int limit = Math.max(1, (int)Math.round((Double)this.chestsPerRun.get()));
         this.setState(this.lootedThisRun >= limit ? AutoWardenModule.State.GO_EDGE : AutoWardenModule.State.ROAM);
      } else {
         if (this.hotbarDirty(p)) {
            this.cleanHotbar(p, null);
            return;
         }

         if (this.ensureRoamPath(p)) {
            this.walker.tick();
         }
      }
   }

   private void baseFindStorage(ClientPlayerEntity p) {
      this.storageChest = this.findChestNear(p.getBlockPos(), 4, false);
      if (this.storageChest == null) {
         if (this.stateTicks > 40) {
            this.fail("Рядом (4 блока) нет сундука без таблички для лута.");
         }
      } else {
         this.setState(AutoWardenModule.State.BASE_OPEN_STORAGE);
      }
   }

   private void basePutLoot(ClientPlayerEntity p) {
      GenericContainerScreenHandler h = this.openedContainer();
      if (h == null) {
         if (this.stateTicks > 60) {
            this.setState(AutoWardenModule.State.BASE_OPEN_STORAGE);
         }
      } else if (this.actionCooldown <= 0) {
         int chestSlots = h.getRows() * 9;

         for (int i = chestSlots; i < h.slots.size(); i++) {
            ItemStack st = h.getSlot(i).getStack();
            if (!st.isEmpty() && st.isOf(Items.GLASS_BOTTLE)) {
               // Пустые бутылки из-под зелий в сундук лута НЕ сдаём — мусор.
               this.mc.interactionManager.clickSlot(h.syncId, i, 1, SlotActionType.THROW, p);
               this.actionCooldown = 2;
               return;
            }

            if (!st.isEmpty() && !isFood(st) && !isInvisPotion(st) && !isSpeedPotion(st)) {
               this.mc.interactionManager.clickSlot(h.syncId, i, 0, SlotActionType.QUICK_MOVE, p);
               this.actionCooldown = 2;
               return;
            }
         }

         p.closeHandledScreen();
         this.lootedChests.clear();
         this.visitedNoTimer.clear();
         this.visionSpot = null;
         this.standingAt = null;
         this.standUntilMs = 0L;
         this.pathFailUntil.clear();
         this.burnCommit = null;
         this.readyChests.clear();
         this.lastTimerKeys.clear();
         this.lootedThisRun = 0;
         this.setState(AutoWardenModule.State.BASE_FIND_SUPPLY);
      }
   }

   private BlockPos findChestNear(BlockPos c, int r, boolean withSign) {
      String want = ((String)this.supplySign.get()).toLowerCase(Locale.ROOT);
      BlockPos best = null;
      double bd = Double.MAX_VALUE;

      for (int x = -r; x <= r; x++) {
         for (int y = -r; y <= r; y++) {
            for (int z = -r; z <= r; z++) {
               BlockPos pos = c.add(x, y, z);
               BlockEntity be = this.mc.world.getBlockEntity(pos);
               if (be != null
                  && (
                     be.getType() == BlockEntityType.CHEST
                        || be.getType() == BlockEntityType.TRAPPED_CHEST
                  )) {
                  boolean hasSign = this.signNear(pos, want);
                  boolean anySign = this.signNear(pos, null);
                  if (withSign == hasSign && (withSign || !anySign)) {
                     double d = pos.getSquaredDistance(c);
                     if (d < bd) {
                        bd = d;
                        best = pos;
                     }
                  }
               }
            }
         }
      }

      return best;
   }

   private boolean signNear(BlockPos chest, String text) {
      for (int x = -1; x <= 1; x++) {
         for (int y = -1; y <= 1; y++) {
            for (int z = -1; z <= 1; z++) {
               if (this.mc.world.getBlockEntity(chest.add(x, y, z)) instanceof SignBlockEntity sign) {
                  if (text == null) {
                     return true;
                  }

                  StringBuilder sb = new StringBuilder();

                  for (Text t : sign.getFrontText().getMessages(false)) {
                     sb.append(t.getString()).append(' ');
                  }

                  for (Text t : sign.getText(false).getMessages(false)) {
                     sb.append(t.getString()).append(' ');
                  }

                  if (sb.toString().toLowerCase(Locale.ROOT).contains(text)) {
                     return true;
                  }
               }
            }
         }
      }

      return false;
   }

   private GenericContainerScreenHandler openedContainer() {
      return this.mc.player != null
            && this.mc.player.currentScreenHandler instanceof GenericContainerScreenHandler g
            && this.mc.currentScreen instanceof HandledScreen
         ? g
         : null;
   }

   private static boolean isSpeedPotion(ItemStack st) {
      if (!st.isOf(Items.POTION)) {
         return false;
      } else {
         PotionContentsComponent pc = (PotionContentsComponent)st.get(DataComponentTypes.POTION_CONTENTS);
         if (pc == null) {
            return false;
         } else {
            if (pc.potion().isPresent()) {
               RegistryEntry<Potion> pot = (RegistryEntry<Potion>)pc.potion().get();
               if (pot == Potions.SWIFTNESS || pot == Potions.LONG_SWIFTNESS || pot == Potions.STRONG_SWIFTNESS) {
                  return true;
               }
            }

            for (StatusEffectInstance eff : pc.getEffects()) {
               if (eff.getEffectType() == StatusEffects.SPEED) {
                  return true;
               }
            }

            return false;
         }
      }
   }

   /** Любая еда: предмет с компонентом FOOD (морковь, мясо, гапл — что угодно). */
   private static boolean isFood(ItemStack st) {
      return st.get(DataComponentTypes.FOOD) != null;
   }

   private static boolean isInvisPotion(ItemStack st) {
      if (!st.isOf(Items.POTION)) {
         return false;
      } else {
         PotionContentsComponent pc = (PotionContentsComponent)st.get(DataComponentTypes.POTION_CONTENTS);
         if (pc == null) {
            return false;
         } else {
            if (pc.potion().isPresent()) {
               RegistryEntry<Potion> pot = (RegistryEntry<Potion>)pc.potion().get();
               if (pot == Potions.INVISIBILITY || pot == Potions.LONG_INVISIBILITY) {
                  return true;
               }
            }

            for (StatusEffectInstance eff : pc.getEffects()) {
               if (eff.getEffectType() == StatusEffects.INVISIBILITY) {
                  return true;
               }
            }

            return false;
         }
      }
   }

   private int countInPlayer(ClientPlayerEntity p, Predicate<ItemStack> pred) {
      int n = 0;

      for (int i = 0; i < 36; i++) {
         ItemStack st = p.getInventory().getStack(i);
         if (pred.test(st)) {
            n += st.getCount();
         }
      }

      return n;
   }

   /** Полная остановка: сброс пути + отпускание клавиш + гашение инерции. */
   private void fullStop(ClientPlayerEntity p) {
      if (this.walker != null) {
         this.walker.stop();
      }

      this.hardStop(p);
   }

   private void hardStop(ClientPlayerEntity p) {
      if (this.walker != null) {
         this.walker.releaseKeys();
      }

      this.mc.options.forwardKey.setPressed(false);
      this.mc.options.backKey.setPressed(false);
      this.mc.options.leftKey.setPressed(false);
      this.mc.options.rightKey.setPressed(false);
      this.mc.options.sprintKey.setPressed(false);
      this.mc.options.jumpKey.setPressed(false);
      if (p.isSprinting()) {
         p.setSprinting(false);
      }

      Vec3d v = p.getVelocity();
      if (p.isOnGround() && (Math.abs(v.x) > 0.01 || Math.abs(v.z) > 0.01)) {
         p.setVelocity(v.x * 0.3, v.y, v.z * 0.3);
      }
   }

   private boolean startConsume(ClientPlayerEntity p, Predicate<ItemStack> pred) {
      if (this.mc.currentScreen != null) {
         return false;
      }

      int found = -1;
      for (int i = 0; i < 36; i++) {
         if (pred.test(p.getInventory().getStack(i))) {
            found = i;
            break;
         }
      }

      if (found < 0) {
         return false;
      }

      // Шаг 1: полностью останавливаемся, чтобы не пить/есть на бегу.
      this.fullStop(p);

      // Шаг 2: свапаем предмет в выбранный слот хотбара.
      int hot = 8;
      this.consumeSlotBackup = found;
      this.consumeWasSwapped = found >= 9;
      if (found >= 9) {
         this.mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, found, hot, SlotActionType.SWAP, p);
      } else {
         hot = found;
      }

      this.consumePrevSelected = p.getInventory().getSelectedSlot();
      this.consumeHotbarSlot = hot;
      p.getInventory().setSelectedSlot(hot);
      this.consuming = true;
      this.consumeTicks = 0;
      return true;
   }

   private boolean tickConsume(ClientPlayerEntity p) {
      if (this.consumeRetryTicks > 0) {
         this.consumeRetryTicks--;
         this.hardStop(p);
         return true;
      }

      if (this.consumePauseTicks > 0) {
         this.consumePauseTicks--;
      }

      if (!this.consuming) {
         // Защита от вечного цикла «пьём → сорвалось → снова»: после серии
         // неудач берём паузу, чтобы бот не простаивал под анимацией питья.
         if (this.consumePauseTicks > 0) {
            return false;
         }

         if ((double)p.getHungerManager().getFoodLevel() <= (double)EAT_BELOW
            && this.mc.currentScreen == null
            && this.state != AutoWardenModule.State.LOOT_TAKE
            && this.state != AutoWardenModule.State.LOOT_OPEN) {
            // Едим ЛЮБУЮ еду, а не только золотую морковь.
            if (!this.startConsume(p, AutoWardenModule::isFood)) {
               return false;
            }
         } else {
            if (this.mc.currentScreen != null
               || this.state == AutoWardenModule.State.LOOT_TAKE
               || this.state == AutoWardenModule.State.LOOT_OPEN
               || this.state == AutoWardenModule.State.WAIT_TP
               || this.state == AutoWardenModule.State.WARDEN_CHECK) {
               return false;
            }

            if (!p.hasStatusEffect(StatusEffects.INVISIBILITY)) {
               if (!this.startConsume(p, AutoWardenModule::isInvisPotion)) {
                  return false;
               }
            } else if ((Boolean)this.useSpeed.get() && !p.hasStatusEffect(StatusEffects.SPEED)) {
               if (!this.startConsume(p, AutoWardenModule::isSpeedPotion)) {
                  return false;
               }
            } else {
               return false;
            }
         }
      }

      if (!this.consuming) {
         return false;
      }

      this.consumeTicks++;
      // Шаги 1 и 4 держим на каждом тике: стоим намертво, пока пьём/едим.
      this.fullStop(p);

      ItemStack inHand = p.getMainHandStack();
      boolean isConsumable = isFood(inHand) || isInvisPotion(inHand) || isSpeedPotion(inHand);

      // Шаг 3: собственно действие — держим Use, пока предмет в руке расходуемый.
      if (isConsumable && this.consumeTicks > 2) {
         this.mc.options.useKey.setPressed(true);
      } else {
         this.mc.options.useKey.setPressed(false);
      }

      if ((isConsumable || this.consumeTicks <= 6) && this.consumeTicks <= 80) {
         return true;
      }

      // Действие завершилось (или не удалось):
      boolean ok = this.consumeTicks <= 80 && !isConsumable;
      this.mc.options.useKey.setPressed(false);
      // Шаг 4: возвращаем остаток (пустой бутылёк и т.п.) и слот хотбара.
      this.restoreAfterConsume();
      if (!ok) {
         this.consumeFails++;
         this.consumeRetryTicks = 30;
         this.fullStop(p);
         // Три попытки подряд провалились — consume что-то системно ломает
         // (толкают, сервер лагает). Пауза 30 сек: бот продолжает дела,
         // а не стоит у зелья в цикле попыток.
         if (this.consumeFails >= 3) {
            this.consumeFails = 0;
            this.consumePauseTicks = 600;
         }
      } else {
         this.consumeFails = 0;
      }

      return !ok;
   }

   private void restoreAfterConsume() {
      if (this.mc.options != null) {
         this.mc.options.useKey.setPressed(false);
      }

      this.consuming = false;
      ClientPlayerEntity p = this.mc.player;
      if (p != null) {
         int hot = this.consumeHotbarSlot >= 0 ? this.consumeHotbarSlot : 8;

         if (this.consumeWasSwapped && this.consumeSlotBackup >= 9) {
            // Предмет брали из инвентаря — меняемся обратно: остаток (пустой бутылёк
            // или ничего, если стак доели) уйдёт в исходный слот, а вещь, что лежала
            // в хотбаре, вернётся на своё место. SWAP двусторонний, поэтому делаем его
            // всегда, даже когда в руке уже пусто.
            this.mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, this.consumeSlotBackup, hot, SlotActionType.SWAP, p);
         }

         // Возвращаем ранее выбранный слот хотбара.
         if (this.consumePrevSelected >= 0 && this.consumePrevSelected <= 8) {
            p.getInventory().setSelectedSlot(this.consumePrevSelected);
         }

         this.consumeSlotBackup = -1;
         this.consumeHotbarSlot = -1;
         this.consumePrevSelected = -1;
         this.consumeWasSwapped = false;
      }
   }

   private static enum State {
      IDLE,
      DEAD_WAIT,
      WARDEN_CHECK,
      BASE_FIND_SUPPLY,
      BASE_OPEN_SUPPLY,
      BASE_TAKE_SUPPLY,
      GO_WARDEN_AN,
      WAIT_WORLD,
      SEND_HOME,
      WAIT_TP,
      CLEAN_HOTBAR,
      ROAM,
      GO_CHEST,
      LOOT_OPEN,
      LOOT_TAKE,
      PVP_WAIT,
      GO_EDGE,
      GO_BASE_AN,
      WAIT_BASE_WORLD,
      BASE_FIND_STORAGE,
      BASE_OPEN_STORAGE,
      BASE_PUT_LOOT;
   }
}
