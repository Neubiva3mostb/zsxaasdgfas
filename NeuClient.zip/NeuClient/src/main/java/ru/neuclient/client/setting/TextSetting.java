package ru.neuclient.client.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

/**
 * Текстовая настройка: строка, вводимая с клавиатуры в ClickGUI.
 * В GUI строка показывает [значение], ЛКМ по ней — ввод (печать, Backspace,
 * Ctrl+Backspace — очистить, Enter/Esc — закончить).
 */
public class TextSetting extends Setting<String> {

	/** Максимальная длина значения (символов). */
	private final int maxLength;

	public TextSetting(String name, String defaultValue) {
		this(name, defaultValue, 24);
	}

	public TextSetting(String name, String defaultValue, int maxLength) {
		super(name, defaultValue);
		this.maxLength = maxLength;
	}

	public int getMaxLength() {
		return maxLength;
	}

	@Override
	public JsonElement toJson() {
		return new JsonPrimitive(get());
	}

	@Override
	public void fromJson(JsonElement element) {
		if (element != null && element.isJsonPrimitive() && element.getAsJsonPrimitive().isString()) {
			set(element.getAsString());
		}
	}
}
