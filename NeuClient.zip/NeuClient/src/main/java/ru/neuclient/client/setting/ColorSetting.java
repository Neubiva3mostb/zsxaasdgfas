package ru.neuclient.client.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

import java.awt.Color;

/**
 * Настройка цвета (ARGB).
 * Поддерживает HSB (оттенки, тон) и RGB (0..255).
 */
public class ColorSetting extends Setting<Integer> {

	private boolean expanded = false;

	private float hue = 0.73f;
	private float saturation = 0.64f;
	private float brightness = 1.0f;
	private int alpha = 255;

	public ColorSetting(String name, int defaultRgb) {
		super(name, defaultRgb | 0xFF000000);
		updateHsbFromRgb(defaultRgb);
	}

	public boolean isExpanded() {
		return expanded;
	}

	public void setExpanded(boolean expanded) {
		this.expanded = expanded;
	}

	public void toggleExpanded() {
		this.expanded = !this.expanded;
	}

	public float getHue() {
		return hue;
	}

	public float getSaturation() {
		return saturation;
	}

	public float getBrightness() {
		return brightness;
	}

	public int getRed() {
		return (get() >> 16) & 0xFF;
	}

	public int getGreen() {
		return (get() >> 8) & 0xFF;
	}

	public int getBlue() {
		return get() & 0xFF;
	}

	public int getAlpha() {
		return (get() >> 24) & 0xFF;
	}

	public void setHsb(float h, float s, float b) {
		this.hue = Math.max(0f, Math.min(1f, h));
		this.saturation = Math.max(0f, Math.min(1f, s));
		this.brightness = Math.max(0f, Math.min(1f, b));
		int rgb = Color.HSBtoRGB(this.hue, this.saturation, this.brightness) & 0x00FFFFFF;
		set((alpha << 24) | rgb);
	}

	public void setRgb(int r, int g, int b) {
		r = Math.max(0, Math.min(255, r));
		g = Math.max(0, Math.min(255, g));
		b = Math.max(0, Math.min(255, b));
		int argb = (alpha << 24) | (r << 16) | (g << 8) | b;
		updateHsbFromRgb(argb);
		set(argb);
	}

	public void setRed(int r) {
		setRgb(r, getGreen(), getBlue());
	}

	public void setGreen(int g) {
		setRgb(getRed(), g, getBlue());
	}

	public void setBlue(int b) {
		setRgb(getRed(), getGreen(), b);
	}

	private void updateHsbFromRgb(int rgb) {
		int r = (rgb >> 16) & 0xFF;
		int g = (rgb >> 8) & 0xFF;
		int b = rgb & 0xFF;
		this.alpha = (rgb >> 24) & 0xFF;
		if (this.alpha == 0) this.alpha = 255;
		float[] hsb = Color.RGBtoHSB(r, g, b, null);
		this.hue = hsb[0];
		this.saturation = hsb[1];
		this.brightness = hsb[2];
	}

	public String getHex() {
		return String.format("#%06X", get() & 0x00FFFFFF);
	}

	@Override
	public JsonElement toJson() {
		return new JsonPrimitive(get());
	}

	@Override
	public void fromJson(JsonElement element) {
		if (element != null && element.isJsonPrimitive()) {
			int val = element.getAsInt();
			updateHsbFromRgb(val);
			set(val);
		}
	}
}
