package ru.neuclient.client.module.impl.render;

import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.NumberSetting;

/**
 * BigHead — увеличивает голову ТОЛЬКО у твоего персонажа.
 *
 * Работает локально: масштабируется часть модели «head» у рендер-стейта
 * с id твоего игрока. На других игроков и на сервер не влияет.
 */
public final class BigHeadModule extends Module {

	private final NumberSetting size = new NumberSetting("Размер", 1.5, 1.0, 3.0, 0.1);

	public BigHeadModule() {
		super("BigHead", "Большая голова у твоего персонажа", Category.RENDER);
		addSettings(size);
	}

	/** Множитель размера головы (1.0 — обычная). */
	public float getScale() {
		return size.get().floatValue();
	}
}
