package ru.neuclient.client.module.impl.movement;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;

/**
 * Strafe — множитель скорости в воздухе (только в прыжке).
 *
 * Модуль работает как множитель: сохраняет наземную скорость и умножает
 * её на коэффициент при прыжке. Не бустит скорость — только масштабирует
 * ту, что уже была набрана на земле.
 *
 * Множитель: 0.500 (минимальный), минимальная скорость: 0.600.
 * Только в прыжке: всегда включено.
 */
public final class StrafeModule extends Module {

	/** Потолок горизонтальной скорости — страховка от улёта в стратосферу флагов. */
	private static final double MAX_HORIZONTAL = 0.98;

	/** Множитель — типa 0.500 (минимальный). */
	private static final double MULTIPLIER = 0.500;
	/** Минимальная скорость — 0.600. */
	private static final double MIN_SPEED = 0.600;

	/** Горизонтальная скорость, зафиксированная в момент отрыва от земли. */
	private double savedSpeed;
	/** Был ли игрок на земле на прошлом тике. */
	private boolean wasOnGround = true;

	public StrafeModule() {
		super("Strafe", "Позволяет быстро перемещаться в воздухе", Category.MOVEMENT);
		// Настройки убраны: только в прыжке всегда on, множитель 0.500, мин скорость 0.600
	}

	@Override
	protected void onEnable() {
		savedSpeed = 0.0;
		wasOnGround = true;
	}

	@Override
	public void onTick(MinecraftClient client) {
		ClientPlayerEntity player = client.player;
		if (player == null || client.world == null) {
			return;
		}
		if (player.hasVehicle() || player.isTouchingWater() || player.isInLava()
				|| player.isClimbing() || player.isGliding()) {
			wasOnGround = player.isOnGround();
			return;
		}

		Vec3d velocity = player.getVelocity();
		boolean onGround = player.isOnGround();

		if (onGround) {
			// На земле просто запоминаем текущую скорость — её и «унесём» в воздух
			savedSpeed = Math.hypot(velocity.x, velocity.z);
			wasOnGround = true;
			return;
		}

		// Только в прыжке: работаем лишь если оторвались от земли вверх
		if (!wasOnGround && velocity.y < 0 && player.fallDistance > 1.5) {
			return;
		}
		wasOnGround = false;

		if (!isMoving(player)) {
			return; // без ввода не разгоняем — иначе улетишь, просто упав с блока
		}

		// Множитель 0.500 — не бустит, а масштабирует сохранённую скорость
		double target = Math.max(savedSpeed, MIN_SPEED) * MULTIPLIER;
		target = Math.min(target, MAX_HORIZONTAL);

		double[] motion = motionTowardsInput(player, target);
		player.setVelocity(motion[0], velocity.y, motion[1]);
	}

	// ===== Утилиты =====

	private boolean isMoving(ClientPlayerEntity player) {
		return ru.neuclient.client.util.MoveUtil.isMoving(player);
	}

	private static double[] motionTowardsInput(ClientPlayerEntity player, double speed) {
		return ru.neuclient.client.util.MoveUtil.motionTowardsInput(player, speed);
	}
}
