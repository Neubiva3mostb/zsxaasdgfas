package ru.neuclient.client.mixin;

import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/** Доступ к jumpingCooldown для модуля NoJumpDelay. */
@Mixin(LivingEntity.class)
public interface LivingEntityAccessor {

	@Accessor("jumpingCooldown")
	void pc$setJumpingCooldown(int jumpingCooldown);
}
