package ru.neuclient.client.render;

import ru.neuclient.client.module.impl.render.ZoomModule;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import ru.neuclient.client.mixin.GameRendererAccessor;

/**
 * Проекция мировых координат на экран (для оверлея NameTags).
 *
 * Как устроено:
 *  1. Каждый кадр в событии END_MAIN (Fabric world-render) захватываем
 *     верхнюю матрицу позиции (model-view) и камеру — это ТОЧНЫЕ данные
 *     кадра, который потом увидит игрок.
 *  2. Позже в HUD-проходе (InGameHud) точки проецируются этими же
 *     матрицами: clip = proj × modelView × vec4(world − camera, 1),
 *     NDC = clip / w → экран. За камерой (w ≤ 0) точки отбрасываются.
 *
 * Тонкости версий: у события Fabric стек иногда уже «сдвинут на камеру»,
 * иногда содержит только поворот, а иногда (1.21.11) это чистая
 * model-view, которую надо собрать самим из yaw/pitch камеры —
 * автодетектируем оба случая по пробной трансформации.
 */
public final class WorldToScreen {

	private static final Matrix4f modelView = new Matrix4f();
	private static double camX;
	private static double camY;
	private static double camZ;
	/** Текущий тик-дельта кадра (ставится из InGameHudMixin перед рендером). */
	public static float frameDelta = 1.0f;

	private static boolean valid;

	private WorldToScreen() {
	}

	/** Захват матриц кадра (из WorldRenderEvents.END_MAIN). */
	public static void capture(MatrixStack matrices, Camera camera) {
		Matrix4f mv = new Matrix4f(matrices.peek().getPositionMatrix());

		camX = camera.getCameraPos().x;
		camY = camera.getCameraPos().y;
		camZ = camera.getCameraPos().z;

		// Есть ли в матрице поворот? Смотрим, куда уходят базисные векторы
		// (трансляция при transformDirection игнорируется)
		org.joml.Vector3f ux = mv.transformDirection(1.0f, 0.0f, 0.0f, new org.joml.Vector3f());
		org.joml.Vector3f uy = mv.transformDirection(0.0f, 1.0f, 0.0f, new org.joml.Vector3f());
		boolean noRotation = ux.distanceSquared(1.0f, 0.0f, 0.0f) < 1.0E-6
				&& uy.distanceSquared(0.0f, 1.0f, 0.0f) < 1.0E-6;

		if (noRotation) {
			// Поворота в матрице нет — строим view сами РОВНО как ванилла
			// в WorldRenderer: rotation(conjugate(camera.getRotation())).
			// (Ручная сборка из yaw/pitch давала неверный знак/порядок
			// поворотов — точки «уплывали» вслед за мышью.)
			org.joml.Quaternionf q = new org.joml.Quaternionf(camera.getRotation()).conjugate();
			modelView.identity().rotation(q);
		} else {
			// Поворот уже есть — это и есть настоящая view-матрица кадра.
			modelView.set(mv);
			// Если матрица ещё и содержит сдвиг камеры (probe ≈ −camPos),
			// обнуляем трансляцию: вычитание камеры делаем сами при проекции.
			Vector4f probe = new Vector4f(0.0f, 0.0f, 0.0f, 1.0f).mul(mv);
			double dx = probe.x + camX;
			double dy = probe.y + camY;
			double dz = probe.z + camZ;
			boolean preTranslated = dx * dx + dy * dy + dz * dz < 1.0;
			if (preTranslated) {
				modelView.m30(0.0f);
				modelView.m31(0.0f);
				modelView.m32(0.0f);
			}
		}
		valid = true;
	}

	/** Мировая точка → масштабированные экранные координаты GUI, или null за камерой. */
	public static double[] project(Vec3d world, MinecraftClient client) {
		if (!valid) {
			return null;
		}
		Matrix4f projection = projectionMatrix(client);

		Vector4f clip = new Vector4f(
				(float) (world.x - camX),
				(float) (world.y - camY),
				(float) (world.z - camZ),
				1.0f);
		clip.mul(modelView);
		clip.mul(projection);
		if (clip.w <= 1.0E-4f) {
			return null; // позади камеры/срез
		}
		float ndcX = clip.x / clip.w;
		float ndcY = clip.y / clip.w;
		double sx = (ndcX * 0.5 + 0.5) * client.getWindow().getScaledWidth();
		double sy = (0.5 - ndcY * 0.5) * client.getWindow().getScaledHeight();
		return new double[] {sx, sy};
	}

	/**
	 * Матрица проекции с FOV как у текущего кадра.
	 *
	 * Учитываются ТРИ источника изменения угла обзора:
	 *  • базовый FOV из настроек;
	 *  • ванильный множитель (спринт, натяжение лука, эффекты) —
	 *    интерполированный между прошлым и текущим тиком;
	 *  • наш Zoom.
	 *
	 * Про Zoom отдельно. Он применяется хуком в GameRenderer#getFov,
	 * то есть уже ПОСЛЕ того, как ваниль посчитала свой множитель.
	 * Здесь же матрица собиралась вручную из options.getFov(), минуя
	 * этот хук, — поэтому при зуме мир на экране приближался, а метки
	 * (NameTags, TargetESP, трейсеры) считались по широкому FOV и
	 * разъезжались с моделями. Умножаем на тот же множитель, что и
	 * рендер, и проекция снова совпадает с картинкой.
	 */
	private static Matrix4f projectionMatrix(MinecraftClient client) {
		int baseFov = client.options.getFov().getValue();
		GameRendererAccessor gr = (GameRendererAccessor) client.gameRenderer;
		float mult = MathHelper.lerp(frameDelta,
				gr.pc$getLastFovMultiplier(),
				gr.pc$getFovMultiplier());
		float fov = MathHelper.clamp(baseFov * mult, 1.0f, 180.0f);
		fov = MathHelper.clamp(fov * zoomMultiplier(), 1.0f, 180.0f);
		return client.gameRenderer.getBasicProjectionMatrix(fov);
	}

	/** Множитель FOV от модуля Zoom (1.0 — зума нет). */
	private static float zoomMultiplier() {
		try {
			ru.neuclient.client.NeuClient neu = ru.neuclient.client.NeuClient.getInstance();
			if (neu == null || neu.getModuleManager() == null) {
				return 1.0f;
			}
			ru.neuclient.client.module.impl.render.ZoomModule zoom =
					neu.getModuleManager().get(ru.neuclient.client.module.impl.render.ZoomModule.class);
			if (zoom == null || !zoom.isEnabled()) {
				return 1.0f;
			}
			// Берём сглаженное внутри кадра значение: зум считается раз
			// в тик, а кадров больше — иначе метки дёргались бы при наезде.
			float m = zoom.getFovMultiplier(frameDelta);
			// Хук в GameRendererMixin применяет множитель только когда он
			// меньше единицы — повторяем то же условие, иначе проекция
			// разошлась бы с картинкой в обратную сторону.
			return m < 1.0f ? m : 1.0f;
		} catch (Throwable t) {
			return 1.0f;
		}
	}
}
