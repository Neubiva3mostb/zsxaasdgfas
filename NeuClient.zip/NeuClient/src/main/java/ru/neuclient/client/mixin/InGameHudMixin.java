package ru.neuclient.client.mixin;

import ru.neuclient.client.module.impl.render.NameTagsModule;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.bot.BotManager;
import ru.neuclient.client.module.impl.render.DurabilityAlertModule;
import ru.neuclient.client.module.impl.render.NoRenderModule;

import ru.neuclient.client.module.impl.render.WardenESP;

/**
 * Встраивает отрисовку HUD в конец ванильного InGameHud#render.
 * Когда открыт чат — включаем режим редактирования (рамки + перетаскивание).
 */
@Mixin(InGameHud.class)
public abstract class InGameHudMixin {

	@Inject(method = "render", at = @At("TAIL"))
	private void pc$renderNeuHud(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
		try {
			NeuClient client = NeuClient.getInstance();
			if (client == null || client.isPanicked() || client.getHudManager() == null) {
				return;
			}
			// В чате HUD можно перетаскивать → показываем рамки редактирования
			boolean editing = MinecraftClient.getInstance().currentScreen instanceof ChatScreen;
			client.getHudManager().render(context, editing);

			// Баннер окна бота, если это дочерний процесс
			if (BotManager.getInstance().isChildBot()) {
				String banner = "§a● Аккаунт: §f" + BotManager.getInstance().getBotNickname()
						+ " §8| §fКнопка «Вернуться» в ClickGUI (RShift)";
				int w = MinecraftClient.getInstance().textRenderer.getWidth(banner);
				int sw = context.getScaledWindowWidth();
				context.fill(sw / 2 - w / 2 - 8, 6, sw / 2 + w / 2 + 8, 22, 0xCC111116);
				context.drawText(MinecraftClient.getInstance().textRenderer, banner, sw / 2 - w / 2, 10, 0xFFFFFFFF, true);
			}

			// Оверлеи поверх мира (проекция якорная): рядок иконок руки/брони
			// и панели над игроками. Траектории теперь рисуются в мире
			// (AFTER_ENTITIES, NeuClient) — здесь им делать нечего.
			ru.neuclient.client.render.WorldToScreen.frameDelta = tickCounter.getTickProgress(false);
			ru.neuclient.client.module.impl.render.NameTagsModule.renderAllHud(context);
			ru.neuclient.client.config.GpsManager.renderAllHud(context);
			ru.neuclient.client.module.impl.render.PointersModule.renderAllHud(context);
			ru.neuclient.client.module.impl.render.DamageIndicatorModule.renderAllHud(context);

			// Предупреждение DurabilityAlert по центру экрана
			DurabilityAlertModule.renderAlert(context);

			// WardenESP уведомление
			WardenESP.renderAlert(context);
			WardenESP.renderWardenMarkers(context);
		} catch (Throwable t) {
			// HUD не должен уронить кадр
			NeuClient.LOGGER.error("[NeuClient] Ошибка рендера HUD", t);
		}
	}

	/**
	 * NoRender: «Оверлей тыквы» — не рисуем затемняющую маску тыквы на голове.
	 * Остальные оверлеи (снег/виньетка) не трогаем — фильтр по имени текстуры.
	 */
	@Inject(method = "renderOverlay", at = @At("HEAD"), cancellable = true)
	private void pc$noPumpkinOverlay(DrawContext context, Identifier texture, float opacity,
			CallbackInfo ci) {
		try {
			NeuClient client = NeuClient.getInstance();
			if (client == null || client.getModuleManager() == null) {
				return;
			}
			NoRenderModule module = client.getModuleManager().get(NoRenderModule.class);
			if (module != null && module.noPumpkinOverlay()
					&& texture.getPath().contains("pumpkin")) {
				ci.cancel();
			}
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка NoRender (тыква)", t);
		}
	}
}
