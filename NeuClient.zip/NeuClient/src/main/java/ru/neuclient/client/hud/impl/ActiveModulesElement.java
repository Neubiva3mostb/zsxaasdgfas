package ru.neuclient.client.hud.impl;

import net.minecraft.client.gui.DrawContext;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.font.MsdfFontRenderer;
import ru.neuclient.client.font.MsdfFonts;
import ru.neuclient.client.hud.HudElement;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.util.KeyNames;
import ru.neuclient.client.util.RenderUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Виджет «Бинды» NeuClient:
 *  - Аккуратная шапка «Бинды»
 *  - Строки активных модулей с клавишей бинда
 */
public class ActiveModulesElement extends HudElement {

	private static final float HEADER_H = 13.5f;
	private static final float ROW_H = 11.5f;
	private static final float ROW_STEP = 13.5f;
	private static final float FONT_SIZE = 6.5f;

	public ActiveModulesElement() {
		super("activemodules", 4, 100);
	}

	@Override
	protected int getDefaultX() {
		return Math.max(4, mc.getWindow().getScaledWidth() - width - 6);
	}

	@Override
	protected int getDefaultY() {
		return 35;
	}

	private List<Module> collect() {
		List<Module> result = new ArrayList<>();
		for (Module m : NeuClient.getInstance().getModuleManager().getModules()) {
			if (m.isEnabled() && !m.isHidden() && m.getKeyBind() != KeyNames.NONE) {
				result.add(m);
			}
		}
		return result;
	}

	@Override
	protected void drawElement(DrawContext ctx, boolean editing) {
		List<Module> modules = collect();

		if (modules.isEmpty() && !editing) {
			this.width = 0;
			this.height = 0;
			return;
		}

		var textFont = MsdfFonts.sfMedium();

		float targetWidth = MsdfFontRenderer.getWidth(textFont, "Бинды", FONT_SIZE) + 16.0f;

		if (editing && modules.isEmpty()) {
			float sampleW = MsdfFontRenderer.getWidth(textFont, "AttackAura", FONT_SIZE) + 16.0f
					+ MsdfFontRenderer.getWidth(textFont, "[R]", FONT_SIZE) + 8.0f;
			targetWidth = Math.max(targetWidth, sampleW);
		} else {
			for (Module m : modules) {
				String bindText = "[" + m.getBindName() + "]";
				float rowW = MsdfFontRenderer.getWidth(textFont, m.getName(), FONT_SIZE) + 14.0f
						+ MsdfFontRenderer.getWidth(textFont, bindText, FONT_SIZE) + 8.0f;
				targetWidth = Math.max(targetWidth, rowW);
			}
		}

		this.width = (int) Math.ceil(targetWidth);
		int rowsCount = editing && modules.isEmpty() ? 1 : modules.size();
		this.height = (int) Math.ceil(HEADER_H + 3.0f + rowsCount * ROW_STEP);

		int x = getX();
		int y = getY();
		var im = NeuClient.getInstance().getInterfaceModule();
		int accent = im != null ? im.getBindsColor() : RenderUtil.accent();
		int bg = 0xEE0B0B16;

		// Заголовок
		RenderUtil.roundRect(ctx, x, y, width, (int) HEADER_H, 4, bg);
		RenderUtil.roundBorderEdge(ctx, x, y, width, (int) HEADER_H, 4, withAlpha(accent, 0.33f));

		float headerTextY = y + (HEADER_H - FONT_SIZE) / 2.0f - 0.5f;
		MsdfFontRenderer.drawWithShadow(ctx, textFont, "Бинды", x + 6.0f, headerTextY, 0xFFFFFFFF, FONT_SIZE);

		// Список модулей
		float contentY = y + HEADER_H + 3.0f;

		if (editing && modules.isEmpty()) {
			drawRow(ctx, x, (int) contentY, width, "Пример", "[R]", accent, bg);
			return;
		}

		for (Module m : modules) {
			String bindStr = "[" + m.getBindName() + "]";
			drawRow(ctx, x, (int) contentY, width, m.getName(), bindStr, accent, bg);
			contentY += ROW_STEP;
		}
	}

	private void drawRow(DrawContext ctx, int rx, int ry, int rw, String name, String bind,
						 int accent, int bg) {
		RenderUtil.roundRect(ctx, rx, ry, rw, (int) ROW_H, 4, bg);
		RenderUtil.roundBorderEdge(ctx, rx, ry, rw, (int) ROW_H, 4, withAlpha(accent, 0.22f));

		var textFont = MsdfFonts.sfMedium();

		// Название модуля
		float textY = ry + (ROW_H - FONT_SIZE) / 2.0f - 0.5f;
		MsdfFontRenderer.drawWithShadow(ctx, textFont, name, rx + 6.0f, textY, 0xFFFFFFFF, FONT_SIZE);

		// Бинд
		float bindW = MsdfFontRenderer.getWidth(textFont, bind, FONT_SIZE);
		float bindX = rx + rw - 6.0f - bindW;
		MsdfFontRenderer.drawWithShadow(ctx, textFont, bind, bindX, textY, accent, FONT_SIZE);
	}
}
