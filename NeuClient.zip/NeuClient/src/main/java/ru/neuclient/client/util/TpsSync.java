package ru.neuclient.client.util;

import net.minecraft.util.math.MathHelper;

import java.util.Arrays;

/**
 * TpsSync — трекер серверного TPS (тикрейта) и синхронизация боевых таймингов.
 *
 * Отслеживает WorldTimeUpdateS2CPacket и вычисляет реальный серверный TPS
 * на скользящем окне последних 20 пакетов.
 * Предоставляет коэффициент синхронизации (tpsFactor) для компенсации
 * серверных лагов и задержек при расчёте кулдауна оружия и дистанции досягаемости.
 */
public final class TpsSync {

    private static final int SAMPLES = 20;
    private static final float[] sampleHistory = new float[SAMPLES];
    private static int sampleIndex = 0;
    private static long lastTimeUpdateMillis = -1L;
    private static float currentTps = 20.0f;

    static {
        Arrays.fill(sampleHistory, 20.0f);
    }

    private TpsSync() {}

    /**
     * Вызывается при получении WorldTimeUpdateS2CPacket от сервера.
     */
    public static void onTimeUpdate() {
        long now = System.currentTimeMillis();
        if (lastTimeUpdateMillis != -1L) {
            long delta = now - lastTimeUpdateMillis;
            if (delta > 0) {
                // Сервер отправляет WorldTimeUpdate каждые 20 тиков (в идеале раз в 1000 мс)
                float tps = 20.0f / (delta / 1000.0f);
                tps = MathHelper.clamp(tps, 0.1f, 20.0f);

                sampleHistory[sampleIndex] = tps;
                sampleIndex = (sampleIndex + 1) % SAMPLES;

                float sum = 0.0f;
                for (float s : sampleHistory) {
                    sum += s;
                }
                currentTps = sum / SAMPLES;
            }
        }
        lastTimeUpdateMillis = now;
    }

    /**
     * Сброс при смене мира/сервера.
     */
    public static void reset() {
        lastTimeUpdateMillis = -1L;
        currentTps = 20.0f;
        Arrays.fill(sampleHistory, 20.0f);
        sampleIndex = 0;
    }

    /**
     * Текущий скользящий TPS сервера (обычно от 0 до 20).
     */
    public static float getTps() {
        return currentTps;
    }

    /**
     * Коэффициент замедления сервера:
     * 20.0 TPS -> 1.0f
     * 10.0 TPS -> 0.5f
     */
    public static float getTpsFactor() {
        return MathHelper.clamp(currentTps / 20.0f, 0.2f, 1.0f);
    }

    /**
     * Корректировка кулдауна атаки под реальный TPS сервера.
     * Если сервер лагает, кулдаун на сервере восстанавливается медленнее,
     * чем клиентский локальный индикатор.
     */
    public static float getAdjustedCooldownProgress(float clientProgress) {
        float factor = getTpsFactor();
        if (factor >= 0.98f) {
            return clientProgress;
        }
        // Масштабируем прогресс с учётом серверного тикрейта
        return MathHelper.clamp(clientProgress * factor, 0.0f, 1.0f);
    }
}
