package ru.neuclient.client.module.impl.combat;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;

/**
 * ShiftTAP — автоматически приседает (sneak) в момент удара по игроку.
 *
 * Механика:
 *  • При атаке другого игрока (PlayerEntity) — включается окно на 2 тика,
 *    в течение которых серверу уходит sneak=true вместо реального ввода.
 *  • Это имитирует «Shift-TAP» — технику, при которой игрок на мгновение
 *    приседает при ударе, сбрасывая спринт и делая удар более «чистым»
 *    для античитов (Grim, Vulcan и др. не штрафуют за спринт-хит).
 *
 * Интеграция:
 *  • PlayerEntityAttackMixin вызывает {@link #onAttack(Entity)} при ударе.
 *  • KeyboardInputMixin вызывает {@link #shouldForceSneak()} каждый тик ввода.
 */
public final class ShiftTAPModule extends Module {

	/** Окно форсирования sneak: количество оставшихся тиков. */
	private int sneakTicks = 0;

	public ShiftTAPModule() {
		super("ShiftTAP", "Автоматически приседает в момент удара по игроку", Category.COMBAT);
		// Настроек нет — просто вкл/выкл
	}

	/**
	 * Вызывается из PlayerEntityAttackMixin при ударе локального игрока.
	 * Если цель — другой игрок, включаем окно sneak на 2 тика.
	 */
	public void onAttack(Entity target) {
		if (!isEnabled()) {
			return;
		}
		if (target instanceof PlayerEntity) {
			sneakTicks = 2;
		}
	}

	/**
	 * Вызывается каждый тик из onTick.
	 * Уменьшает счётчик окна sneak.
	 */
	@Override
	public void onTick(MinecraftClient client) {
		if (sneakTicks > 0) {
			sneakTicks--;
		}
	}

	/**
	 * Вызывается из KeyboardInputMixin после сбора ввода.
	 * true — нужно подменить sneak=true на этот тик.
	 */
	public boolean shouldForceSneak() {
		return isEnabled() && sneakTicks > 0;
	}

	@Override
	protected void onEnable() {
		sneakTicks = 0;
	}

	@Override
	protected void onDisable() {
		sneakTicks = 0;
	}

	/** Активный экземпляр модуля (null — выключен). */
	public static ShiftTAPModule active() {
		var c = ru.neuclient.client.NeuClient.getInstance();
		if (c == null || c.getModuleManager() == null) {
			return null;
		}
		ShiftTAPModule m = c.getModuleManager().get(ShiftTAPModule.class);
		return m != null && m.isEnabled() ? m : null;
	}
}
