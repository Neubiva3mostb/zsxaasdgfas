package ru.neuclient.client.module.impl.movement;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.FireworksComponent;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.config.GpsManager;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.util.InventoryUtil;
import ru.neuclient.client.util.SwapPause;
import ru.neuclient.client.util.SwapUtil;

import java.util.List;

/**
 * Реальный полёт на элитрах: экипировка, взлёт, Y=200, последняя .gps.
 * Углы меняются ДО физики/отправки движения; предметы — обычными кликами
 * инвентаря и выбором хотбара, ракеты используются только основной рукой.
 */
public final class AutoPilotModule extends Module {
    private static final int TAKEOFF_TIMEOUT = 100;
    private static final int INVENTORY_TIMEOUT = 40;
    private static final int GLIDE_RETRY_TICKS = 5;
    private static final int HAND_READY_TICKS = 2;

    private final AutoPilotFlightController flight = new AutoPilotFlightController();
    private final AutoPilotLookController look = new AutoPilotLookController();
    private ClientPlayerEntity pilot;
    private ClientWorld flightWorld;
    private int takeoffTicks;
    private int rocketCooldown;
    private int glideRetry;
    private boolean wasGliding;
    private float launchYaw;
    private int originalSlot = -1;
    private int rocketSlot = -1;
    private int handReadyTicks;
    private boolean equipAttempted;
    private boolean rocketTransferAttempted;
    private boolean inventoryPending;
    private int inventoryWaitTicks;
    private int inventorySettleTicks;
    // Отложенная операция старого включения не должна сработать после
    // отключения, повторного включения, портала или смены игрока.
    private long session;

    public AutoPilotModule() {
        super("AutoPilot", "Сам летит по .gps",
                Category.MOVEMENT);
    }

    @Override
    protected void onEnable() {
        reset();
        if (mc.player == null || mc.world == null || mc.interactionManager == null) {
            setEnabled(false);
            return;
        }
        pilot = mc.player;
        flightWorld = mc.world;
        GpsManager.Marker target = latestMarker();
        if (target == null) {
            stop("Сначала поставь метку: .gps <x> <z>");
            return;
        }
        if (arrived(target)) {
            setEnabled(false);
            return;
        }
        if (!checkFlightConditions()) return;
        if (!hasRockets()) {
            stop("Нужны ракеты без звёзд в инвентаре, хотбаре или второй руке.");
            return;
        }
        if (!wearingElytra() && findElytraSlot() < 0) {
            stop("Нет исправных элитр в инвентаре.");
            return;
        }
        launchYaw = pilot.getYaw();
        flight.reset(pilot.getY(), launchYaw);
        wasGliding = pilot.isGliding();
    }

    /**
     * Вызывается из AuraTickSpoofMixin в HEAD ClientPlayerEntity.tick.
     * Эти yaw/pitch НЕ восстанавливаются: камера, физика элитр, предмет
     * в руке и обычные PlayerMoveC2SPacket используют один и тот же взгляд.
     */
    public void beforePlayerTick(ClientPlayerEntity player) {
        if (!isEnabled() || player != pilot || mc.world != flightWorld || mc.isPaused()) return;
        GpsManager.Marker target = latestMarker();
        if (target == null || arrived(target)) return;
        if (!checkFlightConditions()) return;
        AutoPilotFlightController.Steering desired = player.isGliding()
                ? flight.steer(player.getX(), player.getY(), player.getZ(), player.getVelocity().y,
                        target.x(), target.z())
                : new AutoPilotFlightController.Steering(launchYaw, -60.0f);
        AutoPilotFlightController.Steering rotation = look.step(player.getYaw(), player.getPitch(),
                desired.yaw(), desired.pitch(), player.isGliding());
        player.setYaw(rotation.yaw());
        player.setPitch(rotation.pitch());
    }

    /** Не скрываем от сервера настоящий взгляд под ротацией другого модуля. */
    public void stopForRotationConflict() {
        stop("Другой модуль подменяет повороты. Отключи его перед AutoPilot.");
    }

    public static AutoPilotModule active() {
        NeuClient neu = NeuClient.getInstance();
        if (neu == null || neu.getModuleManager() == null) return null;
        AutoPilotModule module = neu.getModuleManager().get(AutoPilotModule.class);
        return module != null && module.isEnabled() ? module : null;
    }

    @Override
    public void onTick(MinecraftClient client) {
        if (client.player == null || client.world == null || client.interactionManager == null
                || client.player != pilot || client.world != flightWorld) {
            setEnabled(false);
            return;
        }
        if (client.isPaused()) return;
        GpsManager.Marker target = latestMarker();
        if (target == null) {
            setEnabled(false);
            return;
        }
        if (arrived(target)) {
            setEnabled(false);
            return;
        }
        if (!checkFlightConditions()) return;
        if (rocketCooldown > 0) rocketCooldown--;
        if (glideRetry > 0) glideRetry--;
        if (wasGliding && (!pilot.isGliding() || !wearingElytra())) {
            stop("Полёт на элитрах прерван.");
            return;
        }
        if (pilot.isGliding() && pilot.horizontalCollision) {
            stop("Препятствие на пути. Управление возвращено тебе.");
            return;
        }
        if (inventoryPending) {
            if (++inventoryWaitTicks > INVENTORY_TIMEOUT) stop("Не удалось завершить работу с инвентарём.");
            return;
        }
        if (inventorySettleTicks > 0) {
            inventorySettleTicks--;
            return;
        }
        if (!ensureElytra(client)) return;
        // Подготавливаем основную руку до прыжка; в полёте заранее выбранный
        // стак остаётся видимым, никаких select/use/restore за один тик.
        if ((rocketCooldown == 0 || !pilot.isGliding()) && !prepareRocketHand(client)) return;

        if (!pilot.isGliding()) {
            // Плавно поднять взгляд ДО отрыва от земли, без первого резкого
            // скачка pitch и без запуска фейерверка в землю.
            if (pilot.isOnGround() && pilot.getPitch() > -50.0f) return;
            if (++takeoffTicks > TAKEOFF_TIMEOUT) {
                stop("Не удалось взлететь за 5 секунд. Нужна свободная площадка.");
                return;
            }
            if (pilot.isOnGround()) {
                if (!client.world.isSpaceEmpty(pilot, pilot.getBoundingBox().stretch(0.0, 1.5, 0.0))) {
                    stop("Недостаточно места над головой для взлёта.");
                    return;
                }
                if (glideRetry == 0) {
                    pilot.jump();
                    glideRetry = GLIDE_RETRY_TICKS;
                }
                return;
            }
            if (glideRetry == 0 && pilot.checkGliding()) {
                pilot.networkHandler.sendPacket(new ClientCommandC2SPacket(
                        pilot, ClientCommandC2SPacket.Mode.START_FALL_FLYING));
                glideRetry = GLIDE_RETRY_TICKS;
            }
            return; // сначала сервер получает запрос раскрытия, затем ракету
        }
        wasGliding = true;
        // При включении в воздухе даём плавному повороту поднять нос,
        // прежде чем разгоняться вверх из низкой точки.
        if (pilot.getY() < 185.0 && pilot.getPitch() > -25.0f) return;
        if (rocketCooldown == 0 && !pilot.isUsingItem() && !SwapPause.isBusy()) useRocket(client);
    }

    private boolean checkFlightConditions() {
        if (!pilot.isAlive() || pilot.isSpectator() || pilot.hasVehicle()
                || pilot.isTouchingWater() || pilot.isInLava() || pilot.isClimbing()
                || pilot.getAbilities().flying) {
            stop("В текущем состоянии нельзя лететь на элитрах.");
            return false;
        }
        NeuClient neu = NeuClient.getInstance();
        if (neu != null && neu.getModuleManager() != null) {
            for (String name : new String[]{"Blink", "Air Struck", "FreeCam"}) {
                Module other = neu.getModuleManager().getByName(name);
                if (other != null && other.isEnabled()) {
                    stop("Отключи " + name + ": он мешает обычной отправке движений серверу.");
                    return false;
                }
            }
        }
        return true;
    }

    private boolean wearingElytra() {
        return isUsableElytra(pilot.getEquippedStack(EquipmentSlot.CHEST));
    }

    private static boolean isUsableElytra(ItemStack stack) {
        return stack.isOf(Items.ELYTRA) && LivingEntity.canGlideWith(stack, EquipmentSlot.CHEST);
    }

    /** Слот PlayerScreenHandler, включая вторую руку. */
    private int findElytraSlot() {
        for (int i = 0; i < 36; i++) {
            if (isUsableElytra(pilot.getInventory().getStack(i))) return SwapUtil.toScreenSlot(i);
        }
        return isUsableElytra(pilot.getOffHandStack()) ? SwapUtil.OFFHAND_SLOT : -1;
    }

    private boolean ensureElytra(MinecraftClient client) {
        if (wearingElytra()) return true;
        if (equipAttempted) {
            stop("Не удалось надеть элитры. Проверь нагрудник и инвентарь.");
            return false;
        }
        int source = findElytraSlot();
        if (source < 0) {
            stop("Нет исправных элитр в инвентаре.");
            return false;
        }
        if (!canChangeInventory(client)) return false;
        if (!pilot.playerScreenHandler.getSlot(6).canTakeItems(pilot)) {
            stop("Нагрудник нельзя снять.");
            return false;
        }
        if (SwapPause.isBusy()) return false;
        equipAttempted = true;
        queueInventory(client, () -> {
            if (!isUsableElytra(pilot.playerScreenHandler.getSlot(source).getStack())
                    || !pilot.playerScreenHandler.getSlot(6).canTakeItems(pilot) || wearingElytra()) return;
            int syncId = pilot.playerScreenHandler.syncId;
            if (source >= 36 && source <= 44) {
                client.interactionManager.clickSlot(syncId, 6, source - 36, SlotActionType.SWAP, pilot);
            } else {
                // Штатные клики: элитры -> грудь, прежний нагрудник -> источник.
                // Вся цепочка за одну операцию, без предмета на курсоре между тиками.
                client.interactionManager.clickSlot(syncId, source, 0, SlotActionType.PICKUP, pilot);
                client.interactionManager.clickSlot(syncId, 6, 0, SlotActionType.PICKUP, pilot);
                client.interactionManager.clickSlot(syncId, source, 0, SlotActionType.PICKUP, pilot);
            }
        });
        return false;
    }

    private boolean arrived(GpsManager.Marker target) {
        return flight.hasArrived(pilot.getX(), pilot.getZ(), target.x(), target.z());
    }

    private GpsManager.Marker latestMarker() {
        NeuClient neu = NeuClient.getInstance();
        GpsManager gps = neu == null ? null : neu.getGpsManager();
        if (gps == null) return null;
        List<GpsManager.Marker> markers = gps.markers();
        return markers.isEmpty() ? null : markers.get(markers.size() - 1);
    }

    private boolean hasRockets() {
        return isSafeRocket(pilot.getOffHandStack())
                || InventoryUtil.findInHotbar(pilot, AutoPilotModule::isSafeRocket) >= 0
                || InventoryUtil.findInInventory(pilot, AutoPilotModule::isSafeRocket) >= 0;
    }

    private static boolean isSafeRocket(ItemStack stack) {
        if (stack.isEmpty() || !stack.isOf(Items.FIREWORK_ROCKET)) return false;
        FireworksComponent fireworks = stack.get(DataComponentTypes.FIREWORKS);
        return fireworks == null || fireworks.explosions().isEmpty();
    }

    private boolean prepareRocketHand(MinecraftClient client) {
        int selected = pilot.getInventory().getSelectedSlot();
        if (isSafeRocket(pilot.getMainHandStack())) {
            if (rocketSlot != selected) handReadyTicks = 0;
            rocketSlot = selected;
            rocketTransferAttempted = false;
            return ++handReadyTicks >= HAND_READY_TICKS;
        }
        handReadyTicks = 0;
        if (rocketTransferAttempted) {
            stop("Ракеты не переместились в руку. Проверь инвентарь.");
            return false;
        }
        if (SwapPause.isBusy() || pilot.isUsingItem()) return false;
        int hotbar = InventoryUtil.findInHotbar(pilot, AutoPilotModule::isSafeRocket);
        if (hotbar >= 0) {
            selectRocketSlot(client, hotbar);
            return false; // сервер и другие игроки увидят руку ДО использования
        }
        int inventory = InventoryUtil.findInInventory(pilot, AutoPilotModule::isSafeRocket);
        int source = inventory >= 0 ? SwapUtil.toScreenSlot(inventory)
                : (isSafeRocket(pilot.getOffHandStack()) ? SwapUtil.OFFHAND_SLOT : -1);
        if (source < 0) {
            stop("Ракеты закончились. Управление возвращено тебе.");
            return false;
        }
        if (!canChangeInventory(client)) return false;
        // По возможности пустой хотбар; если заполнен, сохраняем предмет
        // текущей руки и меняем соседний слот. Ничего не выбрасываем.
        int destination = (selected + 1) % 9;
        for (int i = 0; i < 9; i++) {
            if (pilot.getInventory().getStack(i).isEmpty()) { destination = i; break; }
        }
        final int slot = destination;
        rocketTransferAttempted = true;
        queueInventory(client, () -> {
            if (!isSafeRocket(pilot.playerScreenHandler.getSlot(source).getStack())) return;
            client.interactionManager.clickSlot(pilot.playerScreenHandler.syncId,
                    source, slot, SlotActionType.SWAP, pilot);
            selectRocketSlot(client, slot);
        });
        return false;
    }

    private void selectRocketSlot(MinecraftClient client, int slot) {
        if (originalSlot < 0) originalSlot = pilot.getInventory().getSelectedSlot();
        InventoryUtil.selectSlot(pilot, slot, client.interactionManager, false);
        rocketSlot = slot;
        handReadyTicks = 0;
    }

    private boolean canChangeInventory(MinecraftClient client) {
        if (SwapUtil.canInteract(client, pilot)) return true;
        stop("Закрой контейнер и убери предмет с курсора для автоматического свапа.");
        return false;
    }

    private void queueInventory(MinecraftClient client, Runnable action) {
        ClientPlayerEntity owner = pilot;
        ClientWorld world = flightWorld;
        long expectedSession = session;
        inventoryPending = true;
        inventoryWaitTicks = 0;
        SwapPause.submit(() -> {
            if (!isEnabled() || session != expectedSession || pilot != owner
                    || client.player != owner || client.world != world) return;
            try {
                GpsManager.Marker target = latestMarker();
                // Пауза могла закончиться уже после удаления метки/прибытия.
                if (target != null && !arrived(target) && SwapUtil.canInteract(client, owner)) action.run();
            } finally {
                inventoryPending = false;
                inventorySettleTicks = 2;
            }
        });
    }

    private void useRocket(MinecraftClient client) {
        if (handReadyTicks < HAND_READY_TICKS || !isSafeRocket(pilot.getMainHandStack())) return;
        FireworksComponent fireworks = pilot.getMainHandStack().get(DataComponentTypes.FIREWORKS);
        int duration = fireworks == null ? 0 : fireworks.flightDuration();
        if (client.interactionManager.interactItem(pilot, Hand.MAIN_HAND).isAccepted()) {
            pilot.swingHand(Hand.MAIN_HAND); // обычная анимация руки, с пакетом серверу
            rocketCooldown = 10 * (1 + duration) + 12;
        } else {
            stop("Не удалось использовать ракету.");
        }
    }

    private void stop(String reason) {
        error(reason);
        setEnabled(false);
    }

    private void error(String text) {
        if (mc.player != null) mc.player.sendMessage(Text.literal("§c[AutoPilot] §f" + text), false);
    }

    @Override
    protected void onDisable() {
        // Руку возвращаем только в том же мире/на том же игроке, если её
        // ещё контролируем. Элитры оставляем надетыми, скорость не гасим.
        if (mc.player == pilot && mc.world == flightWorld && pilot != null
                && mc.interactionManager != null && originalSlot >= 0
                && pilot.getInventory().getSelectedSlot() == rocketSlot) {
            InventoryUtil.selectSlot(pilot, originalSlot, mc.interactionManager, false);
        }
        reset();
    }

    private void reset() {
        session++;
        look.reset();
        pilot = null;
        flightWorld = null;
        takeoffTicks = rocketCooldown = glideRetry = handReadyTicks = 0;
        inventoryWaitTicks = inventorySettleTicks = 0;
        originalSlot = rocketSlot = -1;
        inventoryPending = equipAttempted = rocketTransferAttempted = wasGliding = false;
    }
}
