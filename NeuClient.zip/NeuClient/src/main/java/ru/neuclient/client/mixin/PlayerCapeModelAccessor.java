package ru.neuclient.client.mixin;

import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.PlayerCapeModel;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/** Доступ к cape-part vanilla-модели для HD-текстуры. */
@Mixin(PlayerCapeModel.class)
public interface PlayerCapeModelAccessor {

	@Accessor("cape")
	ModelPart pc$getCape();

}
