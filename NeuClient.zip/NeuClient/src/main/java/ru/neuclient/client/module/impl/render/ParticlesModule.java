package ru.neuclient.client.module.impl.render;

import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.render.ParticleRenderLayer;
import ru.neuclient.client.render.WorldRenderUtil;
import ru.neuclient.client.setting.ColorSetting;
import ru.neuclient.client.setting.ModeSetting;
import ru.neuclient.client.setting.NumberSetting;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

/**
 * Particles — визуальные частицы вокруг игрока с плавным движением и физикой.
 *
 * Настройки:
 *  • Форма: Сердечки, Снежинки, Искры, Звёздочки, Кристаллы
 *  • Свой цвет (палитра с оттенками, тоном и RGB-слайдерами)
 *  • Количество, Размер, Скорость, Радиус, Время жизни
 */
public final class ParticlesModule extends Module {

	private static final String HEARTS = "Сердечки";
	private static final String SNOWFLAKES = "Снежинки";
	private static final String SPARKS = "Искры";
	private static final String STARS = "Звёздочки";
	private static final String DIAMONDS = "Кристаллы";

	private static final int HARD_LIMIT = 600;
	/** Косинус половины угла отсечения по обзору камеры (~110°). */
	private static final double CULL_COS = -0.35;

	private final ModeSetting shape = new ModeSetting("Форма", HEARTS,
			HEARTS, SNOWFLAKES, SPARKS, STARS, DIAMONDS);
	private final ColorSetting color = new ColorSetting("Свой цвет", 0xFF7A5CFF);
	private final NumberSetting count = new NumberSetting("Количество", 150.0, 20.0, 500.0, 10.0);
	private final NumberSetting size = new NumberSetting("Размер", 0.55, 0.15, 1.8, 0.05);
	private final NumberSetting speed = new NumberSetting("Скорость", 1.0, 0.2, 2.5, 0.1);
	private final NumberSetting distance = new NumberSetting("Радиус", 24.0, 6.0, 50.0, 2.0);
	private final NumberSetting lifetime = new NumberSetting("Время жизни", 70.0, 20.0, 200.0, 10.0);

	private final List<Particle> particles = new ArrayList<>();
	private final Random random = new Random();

	public ParticlesModule() {
		super("Particles", "Визуальные частички", Category.RENDER);
		addSettings(shape, color, count, size, speed, distance, lifetime);
	}

	private static final class Particle {
		double x, y, z;
		double vx, vy, vz;
		int age, maxAge;
		float phase, spin;

		Particle(double x, double y, double z, double vx, double vy, double vz,
				int maxAge, float phase, float spin) {
			this.x = x; this.y = y; this.z = z;
			this.vx = vx; this.vy = vy; this.vz = vz;
			this.maxAge = maxAge; this.phase = phase; this.spin = spin;
		}
	}

	@Override
	protected void onEnable() {
		particles.clear();
	}

	@Override
	protected void onDisable() {
		particles.clear();
	}

	@Override
	public void onTick(MinecraftClient client) {
		if (client.player == null || client.world == null) {
			particles.clear();
			return;
		}

		Vec3d center = client.player.getEntityPos();
		double radius = distance.get();
		int maxAge = lifetime.get().intValue();
		double spd = speed.get();

		// Обновление физики частиц
		Iterator<Particle> it = particles.iterator();
		while (it.hasNext()) {
			Particle p = it.next();

			p.x += p.vx * spd;
			p.y += p.vy * spd;
			p.z += p.vz * spd;

			// Плавная вихревая турбулентность
			double turb = 0.06 * spd;
			p.vx += Math.sin((p.age + p.phase) * turb) * 0.0012;
			p.vz += Math.cos((p.age + p.phase) * turb) * 0.0012;
			p.vx *= 0.985;
			p.vz *= 0.985;

			p.age++;

			if (p.age >= p.maxAge) {
				respawn(p, center, radius, maxAge, client);
			}

			// Проверка дальности от игрока
			double dx = p.x - center.x;
			double dz = p.z - center.z;
			double dy = Math.abs(p.y - center.y);
			if (dx * dx + dz * dz > (radius + 6.0) * (radius + 6.0) || dy > 22.0) {
				respawn(p, center, radius, maxAge, client);
			}
		}

		// Поддержание плотности частиц
		int target = Math.min(count.get().intValue(), HARD_LIMIT);
		while (particles.size() > target) {
			particles.remove(particles.size() - 1);
		}
		int toSpawn = Math.min(target - particles.size(), 12);
		for (int i = 0; i < toSpawn; i++) {
			Particle p = new Particle(0, 0, 0, 0, 0, 0, maxAge, 0, 0);
			respawn(p, center, radius, maxAge, client);
			p.age = random.nextInt(Math.max(1, p.maxAge));
			particles.add(p);
		}
	}

	/** Спавн частицы в воздушном объеме вокруг игрока. */
	private void respawn(Particle p, Vec3d center, double radius, int maxAge, MinecraftClient client) {
		double angle = random.nextDouble() * Math.PI * 2.0;
		double dist = radius * Math.sqrt(random.nextDouble());

		p.x = center.x + Math.cos(angle) * dist;
		p.z = center.z + Math.sin(angle) * dist;
		p.age = 0;
		p.maxAge = (int) (maxAge * (0.6 + random.nextDouble() * 0.8));
		p.phase = random.nextFloat() * 100.0f;
		p.spin = (random.nextFloat() - 0.5f) * 0.20f;
		p.vx = (random.nextDouble() - 0.5) * 0.012;
		p.vz = (random.nextDouble() - 0.5) * 0.012;

		String curShape = shape.get();
		if (SNOWFLAKES.equals(curShape)) {
			// Снежинки спавнятся сверху и медленно падают
			p.y = center.y + 3.5 + random.nextDouble() * 14.0;
			p.vy = -0.018 - random.nextDouble() * 0.022;
			p.vx += (random.nextDouble() - 0.5) * 0.008;
			p.vz += (random.nextDouble() - 0.5) * 0.008;
		} else {
			// Остальные парят и поднимаются вокруг игрока
			p.y = center.y - 2.5 + random.nextDouble() * 8.5;
			p.vy = 0.008 + random.nextDouble() * 0.014;
		}

		p.y = adjustAirY(client, p.x, p.y, p.z);
	}

	private double adjustAirY(MinecraftClient client, double x, double y, double z) {
		if (client.world == null) return y;
		BlockPos.Mutable bp = new BlockPos.Mutable((int) Math.floor(x), (int) Math.floor(y), (int) Math.floor(z));
		for (int i = 0; i < 8; i++) {
			if (client.world.getBlockState(bp).isAir()) {
				return bp.getY() + 0.2;
			}
			bp.setY(bp.getY() + 1);
		}
		return y;
	}

	public void renderWorld(WorldRenderContext context, MinecraftClient client) {
		if (particles.isEmpty() || context.commandQueue() == null) return;
		Camera camera = client.gameRenderer.getCamera();
		Vec3d cam = camera.getCameraPos();
		MatrixStack matrices = context.matrices();
		float tickDelta = client.getRenderTickCounter().getTickProgress(false);

		float yaw = (float) Math.toRadians(camera.getYaw());
		float pitch = (float) Math.toRadians(camera.getPitch());
		Vec3d right = new Vec3d(Math.cos(yaw), 0, Math.sin(yaw));
		Vec3d up = new Vec3d(
				-Math.sin(yaw) * Math.sin(pitch),
				Math.cos(pitch),
				Math.cos(yaw) * Math.sin(pitch));

		double baseSize = size.get();
		String form = shape.get();

		int baseTint = color.get();
		float defR = WorldRenderUtil.red(baseTint);
		float defG = WorldRenderUtil.green(baseTint);
		float defB = WorldRenderUtil.blue(baseTint);

		matrices.push();
		matrices.translate(-cam.x, -cam.y, -cam.z);

		Vec3d look = new Vec3d(
				-Math.sin(yaw) * Math.cos(pitch),
				-Math.sin(pitch),
				Math.cos(yaw) * Math.cos(pitch));

		context.commandQueue().submitCustom(matrices, ParticleRenderLayer.LAYER, (entry, buffer) -> {
			Matrix4f m = entry.getPositionMatrix();
			float[] uvCell = cellFor(form);

			for (Particle p : particles) {
				double px = p.x + p.vx * tickDelta;
				double py = p.y + p.vy * tickDelta;
				double pz = p.z + p.vz * tickDelta;

				double lifeProgress = (p.age + tickDelta) / p.maxAge;
				float alpha = (float) Math.sin(lifeProgress * Math.PI) * 0.85f;
				if (alpha <= 0.02f) continue;

				// Отсечение по полю зрения камеры (включая F5)
				double dx = px - cam.x;
				double dy = py - cam.y;
				double dz = pz - cam.z;
				double distSq = dx * dx + dy * dy + dz * dz;
				if (distSq > 0.3) {
					double dist = Math.sqrt(distSq);
					double dot = (dx * look.x + dy * look.y + dz * look.z) / dist;
					if (dot < CULL_COS) continue;

					double angle = p.spin * (p.age + tickDelta) * 0.15;
					float t = p.phase - (float) Math.floor(p.phase);

					// Дыхание масштаба частицы
					double breath = 1.0 + 0.10 * Math.sin(p.phase + (p.age + tickDelta) * 0.15);
					double psize = baseSize * (0.80 + 0.40 * t) * breath;

					float cr = clamp01(defR + (t - 0.5f) * 0.16f);
					float cg = clamp01(defG + (t - 0.5f) * 0.12f);
					float cb = clamp01(defB - (t - 0.5f) * 0.10f);

					// Отрисовка формы из атласа
					drawTexturedQuad(buffer, m, px, py, pz, right, up,
							psize, uvCell, cr, cg, cb, alpha, angle);
				}
			}
		});

		matrices.pop();
	}

	// ===== Текстуры атласа (512x256) =====
	private static final float[] HEART_UV   = {0.002f, 0.004f, 0.248f, 0.496f};
	private static final float[] SNOW_UV    = {0.252f, 0.004f, 0.498f, 0.496f};
	private static final float[] SPARK_UV   = {0.502f, 0.004f, 0.748f, 0.496f};
	private static final float[] STAR_UV    = {0.752f, 0.004f, 0.998f, 0.496f};
	private static final float[] DIAMOND_UV = {0.252f, 0.504f, 0.498f, 0.996f};

	private static float[] cellFor(String form) {
		if (SNOWFLAKES.equals(form)) return SNOW_UV;
		if (SPARKS.equals(form)) return SPARK_UV;
		if (STARS.equals(form)) return STAR_UV;
		if (DIAMONDS.equals(form)) return DIAMOND_UV;
		return HEART_UV;
	}

	private static void drawTexturedQuad(net.minecraft.client.render.VertexConsumer buffer, Matrix4f m,
			double cx, double cy, double cz, Vec3d right, Vec3d up, double size,
			float[] uv, float r, float g, float b, float a, double angle) {
		if (a <= 0.004f) return;
		double s = size * 0.5;
		double ca = Math.cos(angle), sa = Math.sin(angle);
		double u0 = uv[0], v0 = uv[1], u1 = uv[2], v1 = uv[3];
		double[][] c = {
				{-s, -s, u0, v1},
				{ s, -s, u1, v1},
				{ s,  s, u1, v0},
				{-s,  s, u0, v0}};
		for (double[] corner : c) {
			double ru = corner[0] * ca - corner[1] * sa;
			double rv = corner[0] * sa + corner[1] * ca;
			double x = cx + right.x * ru + up.x * rv;
			double y = cy + right.y * ru + up.y * rv;
			double z = cz + right.z * ru + up.z * rv;
			buffer.vertex(m, (float) x, (float) y, (float) z)
					.texture((float) corner[2], (float) corner[3])
					.color(r, g, b, a);
		}
	}

	private static float clamp01(float v) {
		return v < 0.0f ? 0.0f : (v > 1.0f ? 1.0f : v);
	}

	public static void renderAllWorld(WorldRenderContext context) {
		var modules = ru.neuclient.client.NeuClient.getInstance().getModuleManager();
		if (modules == null) return;
		ParticlesModule self = modules.get(ParticlesModule.class);
		if (self != null && self.isEnabled()) {
			self.renderWorld(context, MinecraftClient.getInstance());
		}
	}
}
