package ru.neuclient.client.ui;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;
import ru.neuclient.client.font.MsdfFontRenderer;
import ru.neuclient.client.font.MsdfFonts;
import ru.neuclient.client.module.impl.misc.PotionThrowerModule;
import ru.neuclient.client.module.impl.misc.PotionThrowerModule.PotionGroup;
import ru.neuclient.client.util.KeyNames;
import ru.neuclient.client.util.NeuSounds;
import ru.neuclient.client.util.RenderUtil;

import java.util.List;

/**
 * Колесо выбора зелий для Potion Thrower.
 *
 * КАК ПОЛЬЗОВАТЬСЯ. Зажал бинд («Кнопка колеса») — открылось колесо со
 * всеми метательными зельями инвентаря. Не отпуская, навёл мышкой на
 * нужное зелье — отпустил бинд: зелье брошено по взгляду, колесо
 * закрылось. Отпустил в центре/мимо секторов — просто закрылось, ничего
 * не брошено. Клик любой кнопкой — отмена без броска. Esc — тоже отмена.
 *
 * ВИД. По кругу вокруг центра — чипы с иконкой зелья, количеством и
 * именем рядом. Никакой центральной панели: выбранное видно по подсветке
 * самого чипа. Если метательных зелий нет — плавающая надпись по центру.
 *
 * ОТПУСКАНИЕ БИНДА. Экран не получает событий «отжатия» произвольной
 * клавиши/кнопки, поэтому состояние бинда опрашиваем каждый кадр через
 * GLFW (кнопки мыши) / InputUtil (клавиши). Сразу после открытия даём
 * 150 мс грейс — чтобы сверхкороткий клик не закрыл колесо до того, как
 * игрок начал целиться.
 */
public class PotionWheelScreen extends Screen {

	/** Размер шрифта имён. */
	private static final float FS = 6.5f;
	/** Радиус кружка-чипа под иконку. */
	private static final float CHIP_R = 14.0f;
	/** Максимальная ширина подписи до обрезки. */
	private static final float LABEL_MAX_W = 74.0f;
	/** Грейс после открытия, мс: раньше этого отпускание игнорируется. */
	private static final long RELEASE_GRACE_MS = 150;

	private final Screen parent;
	private final PotionThrowerModule module;

	private List<PotionGroup> groups = List.of();
	private int hovered = -1;
	private float alpha;
	private boolean closing;
	private long lastMs = System.currentTimeMillis();
	private long openedAt;

	public PotionWheelScreen(Screen parent, PotionThrowerModule module) {
		super(Text.literal("Potion Thrower"));
		this.parent = parent;
		this.module = module;
	}

	@Override
	protected void init() {
		groups = module.collectGroups();
		openedAt = System.currentTimeMillis();
	}

	// ===== Геометрия =====

	private int radius() {
		int n = Math.max(groups.size(), 1);
		return Math.min(115, 52 + n * 6);
	}

	private float cx() {
		return width / 2.0f;
	}

	private float cy() {
		return height / 2.0f;
	}

	/** Позиция сектора i на круге (нулевой — сверху, дальше по часовой). */
	private float entryX(int i) {
		double ang = Math.toRadians(-90.0 + i * 360.0 / groups.size());
		return (float) (cx() + radius() * Math.cos(ang));
	}

	private float entryY(int i) {
		double ang = Math.toRadians(-90.0 + i * 360.0 / groups.size());
		return (float) (cy() + radius() * Math.sin(ang));
	}

	/** Индекс сектора под курсором, -1 если курсор в центре/за кругом. */
	private int hoveredIndex(double mx, double my) {
		int n = groups.size();
		if (n == 0) {
			return -1;
		}
		double dx = mx - cx();
		double dy = my - cy();
		double dist = Math.sqrt(dx * dx + dy * dy);
		if (dist < radius() * 0.45 || dist > radius() + CHIP_R + 4) {
			return -1;
		}
		double ang = Math.toDegrees(Math.atan2(dy, dx)) + 90.0; // 0 = верх
		if (ang < 0) {
			ang += 360.0;
		}
		return (int) Math.round(ang * n / 360.0) % n;
	}

	/** Зажат ли ещё бинд колеса (кнопка мыши или клавиша). */
	private boolean bindHeld() {
		int bind = module.wheelButtonKey();
		if (KeyNames.isMouse(bind)) {
			return GLFW.glfwGetMouseButton(client.getWindow().getHandle(), bind)
					== GLFW.GLFW_PRESS;
		}
		return InputUtil.isKeyPressed(client.getWindow(), bind);
	}

	// ===== Отрисовка =====

	@Override
	public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
		if (client.world != null) ctx.applyBlur();
		ctx.fill(0, 0, width, height, a(0x90000000));
	}

	@Override
	public void render(DrawContext ctx, int mx, int my, float delta) {
		super.render(ctx, mx, my, delta);

		long now = System.currentTimeMillis();
		float dt = Math.min((now - lastMs) / 1000f, 0.1f);
		lastMs = now;
		if (closing) {
			alpha = Math.max(0f, alpha - dt * 8f);
			if (alpha <= 0f) {
				client.setScreen(parent);
				return;
			}
		} else {
			alpha = Math.min(1f, alpha + dt * 8f);
		}

		hovered = hoveredIndex(mx, my);

		// ГЛАВНОЕ ДЕЙСТВИЕ: игрок ОТПУСТИЛ бинд. Наводился на зелье —
		// бросаем его; отпустил в центре/мимо — просто закрываем.
		if (!closing && now - openedAt > RELEASE_GRACE_MS && !bindHeld()) {
			finish();
		}

		int accent = RenderUtil.accent();

		if (groups.isEmpty()) {
			txtC(ctx, "Нет зелий в инвентаре", cx(), cy() - FS / 2f, RenderUtil.textDim(), FS);
			return;
		}

		// Сектора по кругу: чип с иконкой + подписи рядом. Без центральной
		// панели — выбор виден по подсветке чипа.
		for (int i = 0; i < groups.size(); i++) {
			PotionGroup g = groups.get(i);
			float ex = entryX(i);
			float ey = entryY(i);
			boolean hover = i == hovered;
			float r = hover ? CHIP_R + 3.0f : CHIP_R;

			if (hover) {
				RenderUtil.circle(ctx, (int) ex, (int) ey, r + 1.5f, a(RenderUtil.shade(accent, 0.9f)));
			}
			RenderUtil.circle(ctx, (int) ex, (int) ey, r, a(hover ? 0xF8202028 : 0xE814141C));

			// Иконка зелья
			ctx.getMatrices().pushMatrix();
			ctx.getMatrices().translate(ex - 8, ey - 8);
			ctx.drawItem(g.sample, 0, 0);
			ctx.getMatrices().popMatrix();

			// Количество и имя — возле самого зелья
			String cnt = "×" + g.total;
			txtC(ctx, cnt, ex, ey + r + 1.5f, hover ? RenderUtil.TEXT : RenderUtil.textDim(), FS);
			txtC(ctx, trim(g.name), ex, ey + r + 10.0f, hover ? RenderUtil.TEXT : RenderUtil.textDim(), FS);
		}
	}

	/** Отпускание бинда: бросить выбранный сектор (если был) и закрыться. */
	private void finish() {
		if (hovered >= 0) {
			NeuSounds.play(NeuSounds.SETTINGS);
			module.throwGroup(groups.get(hovered), client);
		}
		close();
	}

	// ===== Ввод =====

	@Override
	public boolean mouseClicked(Click click, boolean doubled) {
		// Любой клик — отмена без броска (бросок только отпусканием бинда).
		close();
		return true;
	}

	@Override
	public boolean keyPressed(KeyInput input) {
		if (input.key() == GLFW.GLFW_KEY_ESCAPE) {
			close();
			return true;
		}
		return super.keyPressed(input);
	}

	@Override
	public boolean charTyped(CharInput input) {
		return true; // печатать в колесе нечего
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	@Override
	public void close() {
		closing = true;
	}

	// ===== Утилиты отрисовки (в стиле остальных экранов) =====

	private int a(int color) {
		int base = color >>> 24;
		if (base == 0) base = 255;
		return (Math.max(0, Math.min(255, (int) (base * alpha))) << 24) | (color & 0xFFFFFF);
	}

	private void txt(DrawContext ctx, String s, float x, float y, int color, float size) {
		MsdfFontRenderer.drawWithShadow(ctx, MsdfFonts.sfRegular(), s, x, y, a(color), size);
	}

	private float tw(String s, float size) {
		return MsdfFontRenderer.getWidth(MsdfFonts.sfRegular(), s, size);
	}

	private void txtC(DrawContext ctx, String s, float cx, float y, int color, float size) {
		txt(ctx, s, cx - tw(s, size) / 2f, y, color, size);
	}

	/** Обрезать длинное имя под ширину подписи. */
	private String trim(String s) {
		String out = s;
		while (out.length() > 1 && tw(out + "…", FS) > LABEL_MAX_W) {
			out = out.substring(0, out.length() - 1);
		}
		return out.length() == s.length() ? out : out + "…";
	}
}
