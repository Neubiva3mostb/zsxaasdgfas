package ru.neuclient.client.module.impl.render;

import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import org.joml.Matrix4f;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.render.WorldRenderUtil;
import ru.neuclient.client.setting.ColorSetting;
import ru.neuclient.client.util.RenderUtil;

/**
 * BlockOverlay — заливка блока, на который направлен взгляд.
 *
 * Вместо чёрной ванильной рамки блок подсвечивается мягкой заливкой
 * цветом темы клиента (акцент из панели «Цвета» ClickGUI).
 *
 * КАК ВЫБИРАЕТСЯ БЛОК.
 * Берётся mc.crosshairTarget — ровно тот рейкаст, которым пользуется сама
 * игра для взаимодействия: он существует только для блока В ЗОНЕ ДОСЯГАЕМОСТИ
 * (blockInteractionRange), то есть до блока действительно можно коснуться.
 * В режимах наблюдателя и когда прицел в воздухе/сущности — подсветки нет.
 *
 * Заливка повторяет outline-shape блока: плиты подсвечиваются половинкой,
 * лестницы — своей реальной геометрией, а не полным кубом.
 *
 * Честность: ни одного пакета, чисто визуал поверх клиентских данных.
 */
public final class BlockOverlayModule extends Module {

	/** Прозрачность заливки. */
	private static final float FILL_ALPHA = 0.25f;
	/** Микро-раздувание заливки наружу, чтобы не мерцала о грань блока. */
	private static final double INFLATE = 0.002;

	private final ColorSetting color = new ColorSetting("Цвет", 0xFF7A5CFF);

	public BlockOverlayModule() {
		super("BlockOverlay", "Заливка блока под прицелом", Category.RENDER);
		addSettings(color);
	}

	// ===== Рендер (AFTER_ENTITIES, из NeuClient) =====

	private void renderWorld(WorldRenderContext context, MinecraftClient client) {
		if (context.commandQueue() == null || client.player == null || client.world == null) {
			return;
		}

		// Только блок в зоне досягаемости — до него реально можно коснуться
		if (client.crosshairTarget == null
				|| client.crosshairTarget.getType() != HitResult.Type.BLOCK
				|| !(client.crosshairTarget instanceof BlockHitResult hit)
				|| client.player.isSpectator()) {
			return;
		}

		BlockPos pos = hit.getBlockPos();
		ClientWorld world = client.world;
		if (world.getBlockState(pos).isAir()) {
			return;
		}

		VoxelShape shape = world.getBlockState(pos).getOutlineShape(world, pos);
		if (shape.isEmpty()) {
			return;
		}

		Vec3d cam = client.gameRenderer.getCamera().getCameraPos();
		MatrixStack matrices = context.matrices();

		int accent = color.get();
		float r = WorldRenderUtil.red(accent);
		float g = WorldRenderUtil.green(accent);
		float b = WorldRenderUtil.blue(accent);

		matrices.push();
		matrices.translate(-cam.x, -cam.y, -cam.z);

		context.commandQueue().submitCustom(matrices, WorldRenderUtil.QUADS, (entry, buffer) -> {
			Matrix4f m = entry.getPositionMatrix();
			shape.forEachBox((x1, y1, z1, x2, y2, z2) ->
					fillBox(buffer, m,
							pos.getX() + x1, pos.getY() + y1, pos.getZ() + z1,
							pos.getX() + x2, pos.getY() + y2, pos.getZ() + z2,
							r, g, b, FILL_ALPHA));
		});

		matrices.pop();
	}

	/** Шесть граней параллелепипеда, слегка раздутых наружу от центра. */
	private static void fillBox(VertexConsumer buffer, Matrix4f m,
			double x1, double y1, double z1, double x2, double y2, double z2,
			float r, float g, float b, float a) {
		// Раздуваем от центра бокса, чтобы грани не совпадали с гранями блока
		double cx = (x1 + x2) / 2.0, cy = (y1 + y2) / 2.0, cz = (z1 + z2) / 2.0;
		double ex = (x2 - x1) / 2.0 + INFLATE, ey = (y2 - y1) / 2.0 + INFLATE, ez = (z2 - z1) / 2.0 + INFLATE;
		double bx1 = cx - ex, by1 = cy - ey, bz1 = cz - ez;
		double bx2 = cx + ex, by2 = cy + ey, bz2 = cz + ez;

		// Верх / низ
		WorldRenderUtil.quad(buffer, m, bx1, by2, bz1, bx2, by2, bz1, bx2, by2, bz2, bx1, by2, bz2, r, g, b, a);
		WorldRenderUtil.quad(buffer, m, bx1, by1, bz1, bx1, by1, bz2, bx2, by1, bz2, bx2, by1, bz1, r, g, b, a);
		// Север / юг (Z)
		WorldRenderUtil.quad(buffer, m, bx1, by1, bz1, bx2, by1, bz1, bx2, by2, bz1, bx1, by2, bz1, r, g, b, a);
		WorldRenderUtil.quad(buffer, m, bx1, by1, bz2, bx1, by2, bz2, bx2, by2, bz2, bx2, by1, bz2, r, g, b, a);
		// Запад / восток (X)
		WorldRenderUtil.quad(buffer, m, bx1, by1, bz1, bx1, by2, bz1, bx1, by2, bz2, bx1, by1, bz2, r, g, b, a);
		WorldRenderUtil.quad(buffer, m, bx2, by1, bz1, bx2, by1, bz2, bx2, by2, bz2, bx2, by2, bz1, r, g, b, a);
	}

	// ===== Диспетчер (из NeuClient) =====

	public static void renderAllWorld(WorldRenderContext context) {
		NeuClient client = NeuClient.getInstance();
		if (client == null || client.getModuleManager() == null) {
			return;
		}
		BlockOverlayModule self = client.getModuleManager().get(BlockOverlayModule.class);
		if (self != null && self.isEnabled()) {
			self.renderWorld(context, MinecraftClient.getInstance());
		}
	}
}
