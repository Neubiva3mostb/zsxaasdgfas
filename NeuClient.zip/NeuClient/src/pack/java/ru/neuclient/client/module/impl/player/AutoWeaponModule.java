package ru.neuclient.client.module.impl.player;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.hit.EntityHitResult;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.util.InventoryUtil;
import ru.neuclient.client.util.SwapPause;
import ru.neuclient.client.util.SwapUtil;

/** Автоматически выбирает только лучший меч при наведении на сущность. */
public final class AutoWeaponModule extends Module {

	public AutoWeaponModule() {
		super("AutoWeapon", "Выбирает лучший меч при атаке", Category.PLAYER);
	}

	@Override
	public void onTick(MinecraftClient client) {
		ClientPlayerEntity player = client.player;
		if (player == null || client.world == null || client.interactionManager == null
				|| client.currentScreen != null || SwapPause.isBusy()) {
			return;
		}
		if (!(client.crosshairTarget instanceof EntityHitResult hit)
				|| !(hit.getEntity() instanceof LivingEntity target)
				|| !target.isAlive() || target == player) {
			return;
		}

		int currentSlot = player.getInventory().getSelectedSlot();
		int currentScore = swordScore(player.getMainHandStack());
		int bestSlot = -1;
		int bestScore = currentScore;

		for (int slot = 0; slot < 9; slot++) {
			int score = swordScore(player.getInventory().getStack(slot));
			if (score > bestScore) {
				bestScore = score;
				bestSlot = slot;
			}
		}

		if (bestSlot >= 0) {
			InventoryUtil.selectSlot(player, bestSlot, client.interactionManager);
			return;
		}

		// Если меча нет в хотбаре, помещаем лучший меч в текущую ячейку.
		int inventorySlot = findBestInventorySword(player, bestScore);
		if (inventorySlot < 0) {
			return;
		}
		if (SwapUtil.swapToHotbar(client, player, inventorySlot, currentSlot)) {
			InventoryUtil.selectSlot(player, currentSlot, client.interactionManager);
		}
	}

	private int findBestInventorySword(ClientPlayerEntity player, int minimumScore) {
		int bestSlot = -1;
		int bestScore = minimumScore;
		for (int slot = 9; slot <= 35; slot++) {
			int score = swordScore(player.getInventory().getStack(slot));
			if (score > bestScore) {
				bestScore = score;
				bestSlot = slot;
			}
		}
		return bestSlot;
	}

	/**
	 * Оценка только для мечей: материал важнее, затем учитывается
	 * уровень «Остроты». Например, алмазный меч Sharpness II будет
	 * лучше обычного алмазного, но незеритовый без чар всё равно выше.
	 */
	private int swordScore(ItemStack stack) {
		if (!isSword(stack)) {
			return 0;
		}

		int materialScore = 1;
		if (stack.isOf(Items.WOODEN_SWORD)) materialScore = 1;
		if (stack.isOf(Items.GOLDEN_SWORD)) materialScore = 2;
		if (stack.isOf(Items.STONE_SWORD)) materialScore = 3;
		if (stack.isOf(Items.IRON_SWORD)) materialScore = 4;
		if (stack.isOf(Items.DIAMOND_SWORD)) materialScore = 5;
		if (stack.isOf(Items.NETHERITE_SWORD)) materialScore = 6;

		int sharpness = 0;
		for (var entry : stack.getEnchantments().getEnchantmentEntries()) {
			if (entry.getKey().matchesKey(Enchantments.SHARPNESS)) {
				sharpness = entry.getIntValue();
				break;
			}
		}
		return materialScore * 100 + sharpness * 10;
	}

	/** В 1.21.11 SwordItem удалён: меч определяется по vanilla item id. */
	private boolean isSword(ItemStack stack) {
		return !stack.isEmpty()
				&& (stack.isOf(Items.WOODEN_SWORD)
				|| stack.isOf(Items.GOLDEN_SWORD)
				|| stack.isOf(Items.STONE_SWORD)
				|| stack.isOf(Items.IRON_SWORD)
				|| stack.isOf(Items.DIAMOND_SWORD)
				|| stack.isOf(Items.NETHERITE_SWORD));
	}

}
