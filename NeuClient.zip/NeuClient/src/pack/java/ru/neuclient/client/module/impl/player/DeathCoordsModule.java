package ru.neuclient.client.module.impl.player;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.DeathScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.BlockPos;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.util.ChatUtil;

/** Пишет координаты смерти локального игрока в чат. */
public final class DeathCoordsModule extends Module {

	private boolean announced;

	public DeathCoordsModule() {
		super("DeathCoords", "Пишет координаты смерти в чат", Category.PLAYER);
	}

	@Override
	public void onTick(MinecraftClient client) {
		ClientPlayerEntity player = client.player;
		if (player == null || client.world == null) {
			return;
		}

		boolean dead = player.isDead() || player.getHealth() <= 0.0f
				|| client.currentScreen instanceof DeathScreen;
		if (dead && !announced) {
			BlockPos pos = player.getBlockPos();
			String dimension = client.world.getRegistryKey().getValue().toString();
			ChatUtil.send("Смерть: X=" + pos.getX() + " Y=" + pos.getY()
					+ " Z=" + pos.getZ() + " (" + dimension + ")");
			announced = true;
		} else if (!dead && player.isAlive()) {
			announced = false;
		}
	}

	@Override
	protected void onDisable() {
		announced = false;
	}
}
