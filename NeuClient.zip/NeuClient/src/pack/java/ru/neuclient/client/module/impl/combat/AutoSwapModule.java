package ru.neuclient.client.module.impl.combat;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.util.InputUtil;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.BooleanSetting;
import ru.neuclient.client.setting.KeyBindSetting;
import ru.neuclient.client.setting.ModeSetting;
import ru.neuclient.client.util.SwapPause;
import ru.neuclient.client.util.SwapUtil;

import java.util.Locale;

/**
 * Auto Swap — по клавише кладёт во вторую руку нужный предмет,
 * переключаясь между двумя выбранными вариантами.
 *
 * ЧТО ДЕЛАЕТ КНОПКА.
 * Смотрит, что сейчас в оффхенде: если там «первый предмет» — кладёт
 * «второй», иначе кладёт «первый». То есть одна клавиша циклически
 * перекидывает щит↔тотем (или любую другую пару) — ровно как в
 * референсе.
 *
 * Если в обеих настройках выбран ОДИН И ТОТ ЖЕ предмет (Тотем/Тотем),
 * кнопка работает как обмен с инвентарём: пока в инвентаре есть ещё
 * один такой же предмет, каждое нажатие меняет местами оффхенд и
 * ячейку с этим предметом (свежий — в руку, использованный — в
 * инвентарь). Когда второй экземпляр закончился, кнопка становится
 * переключателем «достать / убрать».
 *
 * КАК ПЕРЕКЛАДЫВАЕТСЯ.
 * Одним пакетом SlotActionType.SWAP с кнопкой 40 — это ванильная
 * клавиша F, атомарный обмен слота с оффхендом. Вокруг клика
 * запрашивается SwapPause: движение гаснет на один пакет, чтобы для
 * сервера предмет доставал стоящий игрок.
 *
 * ВОЗВРАТ СЛОТОВ ЗДЕСЬ РУЧНОЙ — и это не упущение. Модуль работает
 * как переключатель: первое нажатие достаёт щит, второе возвращает
 * тотем на его же место (SWAP симметричен). Автовозврат по таймеру
 * отбирал бы у игрока щит ровно тогда, когда он его держит осознанно.
 *
 * Прежняя версия делала ШЕСТЬ кликов PICKUP (через курсор, с обменом
 * двух слотов между собой) и отправляла их через прежний SwapFreeze,
 * который ждал полной остановки игрока — до 20 тиков. В бою это означало, что
 * щит появлялся в руке через секунду после нажатия либо не появлялся
 * вовсе: любой отклонённый сервером клик оставлял предмет на курсоре.
 *
 * Клавиша по умолчанию не задана (None) — биндится в настройках.
 */
public final class AutoSwapModule extends Module {

	/** Кнопка оффхенда в SlotActionType.SWAP (ванильная клавиша F). */
	private static final int OFFHAND_SWAP_BUTTON = 40;
	/** Антидребезг клавиши, мс. */
	private static final long KEY_COOLDOWN_MS = 100L;

	// Варианты предметов
	private static final String SHIELD = "Щит";
	private static final String TOTEM = "Тотем";
	private static final String GAPPLE = "Золотое яблоко";
	private static final String SPHERE = "Сфера";

	private final KeyBindSetting swapKey = new KeyBindSetting("Кнопка свапа", KeyBindSetting.NONE);
	private final ModeSetting firstItem = new ModeSetting("Первый предмет", SHIELD,
			SHIELD, TOTEM, GAPPLE, SPHERE);
	private final ModeSetting secondItem = new ModeSetting("Второй предмет", TOTEM,
			SHIELD, TOTEM, GAPPLE, SPHERE);
	private final BooleanSetting onlyEnchanted = new BooleanSetting("Только чар. тотемы", false);

	/** Состояние клавиши на прошлом тике (детект фронта нажатия). */
	private boolean prevKeyDown;
	/** Момент последнего свапа — антидребезг. */
	private long lastSwap;
	/**
	 * Ячейка (0–35), откуда предмет уехал в оффхенд.
	 * Нужна режиму «предмет сам с собой»: повторное нажатие кладёт
	 * предмет ровно туда, откуда он был взят. -1 — свапа не было.
	 */
	private int lastSwapSlot = -1;

	public AutoSwapModule() {
		super("Auto Swap", "По бинду меняет два предмета местами", Category.COMBAT);
		addSettings(swapKey, firstItem, secondItem, onlyEnchanted);
	}

	@Override
	public void onTick(MinecraftClient client) {
		// Считываем клавишу даже при GUI: удержание в меню не должно
		// превращаться в новый фронт нажатия сразу после его закрытия.
		int key = swapKey.get();
		boolean down = client.getWindow() != null && key != KeyBindSetting.NONE
				&& InputUtil.isKeyPressed(client.getWindow(), key);
		boolean pressed = down && !prevKeyDown;
		prevKeyDown = down;

		ClientPlayerEntity player = client.player;
		if (blockingScreen(client) || player == null || client.world == null
				|| client.interactionManager == null || player.currentScreenHandler != player.playerScreenHandler
				|| !player.playerScreenHandler.getCursorStack().isEmpty() || !pressed) {
			return;
		}
		if (System.currentTimeMillis() - lastSwap < KEY_COOLDOWN_MS) {
			return; // антидребезг
		}

		// Меняем два предмета местами
		if (performSwap(client, player)) {
			lastSwap = System.currentTimeMillis();
		}
	}

	/**
	 * Кладёт в оффхенд нужный из двух предметов.
	 *
	 * Логика референса: если в руке уже лежит «первый предмет», значит
	 * пора доставать «второй», и наоборот. Один пакет SWAP — предмет из
	 * найденного слота меняется местами с оффхендом.
	 *
	 * @return true — свап отправлен
	 */
	private boolean performSwap(MinecraftClient client, ClientPlayerEntity player) {
		ItemStack offhand = player.getOffHandStack();

		int slot;

		if (firstItem.get().equals(secondItem.get())) {
			// ОДИН И ТОТ ЖЕ ПРЕДМЕТ В ОБОИХ НАСТРОЙКАХ (например Тотем/Тотем).
			if (matches(offhand, firstItem.get())) {
				// Предмет уже в оффхенде. Если в инвентаре лежит ЕЩЁ один
				// такой же — меняем их местами одним пакетом SWAP: свежий
				// экземпляр встаёт в руку, использованный уходит на его
				// место в инвентаре. Именно этого ждёшь от пары одинаковых
				// предметов: нажатие — и они поменялись местами.
				//
				// Раньше модуль в этой ситуации шёл «убирать» предмет в
				// пустой слот (рука пустела), а при полном инвентаре
				// молча выходил — и пара «один в руке, другой в
				// инвентаре» не свапалась вовсе.
				//
				// findItem ищет по слотам 0–35, оффхенд в этот диапазон
				// не входит — сам с собой предмет не совпадёт. Если
				// второй экземпляр лежит в основной руке (выбранная
				// ячейка хотбара), SWAP обменяет руку с оффхендом —
				// ванильное поведение клавиши F.
				int exchangeSlot = findItem(player, firstItem.get());
				if (exchangeSlot >= 0) {
					lastSwapSlot = exchangeSlot;
					submitSwap(client, player, exchangeSlot);
					return true;
				}
				// Второго такого же в инвентаре нет — работаем
				// переключателем «достать/убрать»: кладём предмет в ту
				// же ячейку, откуда он был взят. Если она уже занята
				// чем-то другим или свапа не было — ищем любую свободную.
				slot = restoreTargetSlot(player);
				if (slot < 0) {
					return false; // класть некуда — инвентарь забит
				}
				lastSwapSlot = -1;
				submitSwap(client, player, slot);
				return true;
			}
			// В оффхенде этого предмета нет — достаём его из инвентаря.
			slot = findItem(player, firstItem.get());
			if (slot < 0) {
				return false;
			}
			lastSwapSlot = slot;
		} else {
			// Два разных предмета — обычный циклический режим.
			// Что сейчас в руке, то и меняем на противоположное.
			String wanted = matches(offhand, firstItem.get())
					? secondItem.get()
					: firstItem.get();

			slot = findItem(player, wanted);
			if (slot < 0) {
				// Нужного предмета нет — пробуем второй вариант, чтобы
				// нажатие не пропадало впустую.
				wanted = wanted.equals(firstItem.get()) ? secondItem.get() : firstItem.get();
				slot = findItem(player, wanted);
			}
			// Запасной вариант совпал с тем, что уже в руке — менять нечего.
			if (slot < 0 || matches(offhand, wanted)) {
				return false;
			}
			lastSwapSlot = slot;
		}

		submitSwap(client, player, slot);
		return true;
	}

	/**
	 * Отправляет клик SWAP (слот ↔ оффхенд) НЕ СЕЙЧАС, а через тик — после
	 * того, как серверу достанется пакет стоящего игрока со снятым
	 * спринтом. Раньше пакет улетал здесь же, то есть вместе с движением
	 * бегущего игрока, и остановка не значила ничего: модуль тикает в конце
	 * тика, уже после отправки движения.
	 */
	private void submitSwap(MinecraftClient client, ClientPlayerEntity player, int slot) {
		final int swapSlot = slot;
		SwapPause.submit(() -> {
			if (blockingScreen(client) || !SwapUtil.canInteract(client, player)) {
				return;
			}
			client.interactionManager.clickSlot(
					player.playerScreenHandler.syncId,
					SwapUtil.toScreenSlot(swapSlot),
					OFFHAND_SWAP_BUTTON,
					SlotActionType.SWAP,
					player);
		});
	}

	/** Соответствует ли стак выбранному в настройке типу предмета. */
	private boolean matches(ItemStack stack, String itemName) {
		if (stack.isEmpty()) {
			return false;
		}
		return switch (itemName) {
			case SHIELD -> stack.isOf(Items.SHIELD);
			case TOTEM -> matchesTotem(stack);
			case GAPPLE -> stack.isOf(Items.GOLDEN_APPLE);
			case SPHERE -> isSphere(stack);
			default -> false;
		};
	}

	/** Тотем подходит всегда, если фильтр «Только чар. тотемы» выключен. */
	private boolean matchesTotem(ItemStack stack) {
		if (!stack.isOf(Items.TOTEM_OF_UNDYING)) {
			return false;
		}
		return !onlyEnchanted.get() || stack.hasEnchantments();
	}

	/**
	 * Ищет предмет во всём инвентаре (0–35) по имени настройки.
	 *
	 * Идём с конца: сначала глубокий инвентарь, потом хотбар — так свап
	 * не разбирает разложенный хотбар, пока в рюкзаке есть запас.
	 */
	private int findItem(ClientPlayerEntity player, String itemName) {
		for (int i = 35; i >= 0; i--) {
			if (matches(player.getInventory().getStack(i), itemName)) {
				return i;
			}
		}
		return -1;
	}

	/**
	 * Куда положить предмет из оффхенда при «убирании» в режиме
	 * «предмет сам с собой».
	 *
	 * Приоритет: исходная ячейка, если она ещё свободна → любая
	 * свободная в глубоком инвентаре → любая свободная в хотбаре.
	 * Занятые ячейки не трогаем: SWAP выкинул бы оттуда чужой предмет
	 * в оффхенд, и переключатель залип бы навсегда.
	 *
	 * @return индекс инвентаря 0–35 либо -1, если места нет
	 */
	private int restoreTargetSlot(ClientPlayerEntity player) {
		if (lastSwapSlot >= 0 && lastSwapSlot <= 35
				&& player.getInventory().getStack(lastSwapSlot).isEmpty()) {
			return lastSwapSlot;
		}
		// Сначала рюкзак (9–35), чтобы не занимать боевой хотбар
		for (int i = 9; i <= 35; i++) {
			if (player.getInventory().getStack(i).isEmpty()) {
				return i;
			}
		}
		for (int i = 0; i <= 8; i++) {
			if (player.getInventory().getStack(i).isEmpty()) {
				return i;
			}
		}
		return -1;
	}

	/**
	 * Проверяет, является ли предмет «Сферой».
	 *
	 * Сфера — это голова игрока (Player Head), у которой в displayName
	 * есть «Сфера» или «Шар» (в любом регистре). На серверах это
	 * кастомный предмет, который даёт эффект защиты.
	 *
	 * Проверка поdisplayName идёт первой (быстрая), затем проверяем
	 * тип предмета — чтобы не сканировать профиль каждой головы
	 * в инвентаре (медленно).
	 */
	private static boolean isSphere(ItemStack stack) {
		// Кастомное имя проверяем у ЛЮБОГО предмета, а не только у головы.
		// Раньше стоял жёсткий фильтр Items.PLAYER_HEAD, и если сервер
		// раздаёт сферу другим предметом (компас, снежок, звезда Нижнего
		// мира), она не находилась вообще — свап молча не срабатывал.
		if (stack.contains(net.minecraft.component.DataComponentTypes.CUSTOM_NAME)) {
			String name = stack.getName().getString().toLowerCase(Locale.ROOT);
			if (name.contains("сфера") || name.contains("шар") || name.contains("sphere")) {
				return true;
			}
		}
		// Дальше — только для голов игрока (проверка профиля дорогая)
		if (!stack.isOf(Items.PLAYER_HEAD)) {
			return false;
		}
		// Запасной вариант: проверяем профиль головы (если имя не задано,
		// но сущность профиля содержит «Сфера» или «Шар»)
		if (stack.contains(net.minecraft.component.DataComponentTypes.PROFILE)) {
			var profile = stack.get(net.minecraft.component.DataComponentTypes.PROFILE);
			if (profile != null) {
				var profileName = profile.getName();
				if (profileName.isPresent()) {
					String nameStr = profileName.get().toLowerCase(Locale.ROOT);
					if (nameStr.contains("сфера") || nameStr.contains("шар")) {
						return true;
					}
				}
			}
		}
		return false;
	}

	@Override
	protected void onDisable() {
		prevKeyDown = false;
		lastSwap = 0L;
		lastSwapSlot = -1;
	}
}
