package ru.neuclient.client.module.impl.movement;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.NumberSetting;

/**
 * Fly — свободный полёт на клиентской скорости (motion-fly).
 *
 * Каждый тик модуль сам задаёт вектор скорости игрока:
 *  - горизонталь берётся из реального ввода WASD с учётом угла обзора
 *    (те же формулы, что в SpeedModule#motionTowardsInput, включая диагонали);
 *  - вертикаль — пробел вверх, шифт вниз, иначе строго 0 (не падаем).
 *
 * Единственная настройка — «Скорость» 1..10, где 1 — примерно шаг пешком
 * (0.09 блока за тик ≈ 1.8 бл/с), а 10 — быстрый креативный полёт
 * (0.9 блока за тик ≈ 18 бл/с). Без ввода игрок просто висит на месте.
 *
 * fallDistance постоянно обнуляется, поэтому при выключении полёта в воздухе
 * урона от падения не будет — упадёте мягко.
 *
 * Ванильные abilities (creative-flight) намеренно НЕ трогаются: сервер
 * такой полёт не выдавал, и подмена abilities — первое, что ловит античит.
 * Здесь это чистая клиентская скорость, как у Speed.
 */
public final class FlyModule extends Module {

	/** Сколько блоков за тик даёт одна «единица» скорости из настройки. */
	private static final double UNIT = 0.09;

	private final NumberSetting speed = new NumberSetting("Скорость", 3.0, 1.0, 10.0, 1.0);


	public FlyModule() {
		super("Fly", "Полёт", Category.MOVEMENT);
		addSettings(speed);
	}

	@Override
	public void onTick(MinecraftClient client) {
		ClientPlayerEntity player = client.player;
		if (player == null || client.world == null || player.hasVehicle()) {
			return;
		}

		double perTick = speed.get() * UNIT;

		// --- Горизонталь по вводу игрока ---
		double[] horizontal = motionTowardsInput(player, perTick);

		// --- Вертикаль: пробел / шифт ---
		double vertical = 0.0;
		if (client.options.jumpKey.isPressed()) {
			vertical += perTick;
		}
		if (client.options.sneakKey.isPressed()) {
			vertical -= perTick;
		}

		// Без ввода просто висим на месте (гравитации нет)
		player.setVelocity(horizontal[0], vertical, horizontal[1]);

		// Ни падения, ни урона, ни «приземления» в глазах клиента
		player.fallDistance = 0.0;
		player.setOnGround(false);
	}

	@Override
	protected void onDisable() {
		ClientPlayerEntity player = mc.player;
		if (player != null) {
			// Отпускаем аккуратно: без резкого рывка вниз
			player.setVelocity(player.getVelocity().x, 0.0, player.getVelocity().z);
			player.fallDistance = 0.0;
		}
	}

	// ===== Утилиты =====

	private boolean isMoving(ClientPlayerEntity player) {
		return ru.neuclient.client.util.MoveUtil.isMoving(player);
	}

	/** Горизонтальная скорость в сторону реального ввода (см. MoveUtil). */
	private static double[] motionTowardsInput(ClientPlayerEntity player, double speed) {
		return ru.neuclient.client.util.MoveUtil.motionTowardsInput(player, speed);
	}
}
