package ru.neuclient.client.module.impl.misc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.util.Window;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.EntityHitResult;
import org.lwjgl.glfw.GLFW;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.config.FriendManager;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.util.ChatUtil;
import ru.neuclient.client.util.NeuSounds;

/**
 * MiddleClickFriend — средний клик по игроку добавляет его в друзья
 * (повторный клик — убирает).
 *
 * Работает по тому, на кого наведён прицел: берётся crosshairTarget, и если
 * это EntityHitResult по игроку — ник уходит в FriendManager. Список сразу
 * сохраняется в friends.json, поэтому друзья действуют и после перезахода.
 *
 * Кнопка опрашивается напрямую через InputUtil.isKeyPressed (как это делают
 * остальные модули клиента), а не через KeyBinding — так нажатие не конфликтует
 * с ванильным «выбрать блок» и работает при любом открытом экране.
 *
 * Срабатывает по переднему фронту: удержание кнопки не превращается
 * в многократное переключение.
 *
 * Настроек нет: уведомление и звук всегда включены.
 */
public class MiddleClickFriendModule extends Module {

	/** Состояние кнопки в прошлом тике — для детекта нажатия. */
	private boolean wasDown;

	public MiddleClickFriendModule() {
		super("MiddleClickFriend", "Средний клик по игроку — в друзья", Category.MISC);
	}

	@Override
	protected void onEnable() {
		// Не «доедать» нажатие, которое уже было до включения модуля
		wasDown = isMiddleDown(MinecraftClient.getInstance());
	}

	@Override
	protected void onDisable() {
		wasDown = false;
	}

	@Override
	public void onTick(MinecraftClient client) {
		boolean down = isMiddleDown(client);
		boolean pressed = down && !wasDown;
		wasDown = down;

		if (!pressed) {
			return;
		}
		try {
			toggle(client);
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка MiddleClickFriend", t);
		}
	}

	private static boolean isMiddleDown(MinecraftClient client) {
		Window window = client.getWindow();
		return window != null
				&& InputUtil.isKeyPressed(window, GLFW.GLFW_MOUSE_BUTTON_MIDDLE);
	}

	private void toggle(MinecraftClient client) {
		if (client.player == null
				|| !(client.crosshairTarget instanceof EntityHitResult hit)) {
			return;
		}
		Entity target = hit.getEntity();
		// Только игроки: мобы и прочие сущности в друзья не попадают
		if (!(target instanceof PlayerEntity player) || player == client.player) {
			return;
		}

		String name = player.getName().getString();
		if (name == null || name.isBlank()) {
			return;
		}

		FriendManager friends = NeuClient.getInstance().getFriendManager();
		if (friends == null) {
			return;
		}

		boolean added = !friends.isFriend(name);
		if (added) {
			friends.add(name);
		} else {
			friends.remove(name);
		}

		NeuSounds.toggle(added);
		ChatUtil.send((added ? "Друг добавлен: " : "Друг удалён: ") + name);
	}
}
