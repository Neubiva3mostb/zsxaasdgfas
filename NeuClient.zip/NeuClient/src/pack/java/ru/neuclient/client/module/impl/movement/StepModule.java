package ru.neuclient.client.module.impl.movement;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.NumberSetting;

/**
 * Step — перешагивает блоки без прыжка.
 *
 * Механика: у записи игрока крутится атрибут step_height (ваниль 0.6).
 * Пока модуль включён — ставим значение из \"Высота\" (1–5 блоков),
 * выключили/респавн — возвращаем 0.6. Высота применяется каждый тик,
 * т.к. после смерти атрибуты игрока пересоздаются.
 *
 * Честно: это клиентский атрибут, античит на сервере может откатывать —
 * режим «на свой страх и риск», как Speed.
 */
public final class StepModule extends Module {

	/** Ванильное значение step_height. */
	private static final double VANILLA = 0.6;

	private final NumberSetting height = new NumberSetting("Высота", 1.0, 1.0, 5.0, 1.0);

	public StepModule() {
		super("Step", "Поднимается на блоки без прыжка", Category.MOVEMENT);
		addSettings(height);
	}

	@Override
	public void onTick(MinecraftClient client) {
		ClientPlayerEntity player = client.player;
		if (player == null) {
			return;
		}
		EntityAttributeInstance attr = player.getAttributeInstance(EntityAttributes.STEP_HEIGHT);
		if (attr != null && attr.getBaseValue() != height.get()) {
			attr.setBaseValue(height.get());
		}
	}

	@Override
	protected void onDisable() {
		ClientPlayerEntity player = mc.player;
		if (player != null) {
			EntityAttributeInstance attr = player.getAttributeInstance(EntityAttributes.STEP_HEIGHT);
			if (attr != null) {
				attr.setBaseValue(VANILLA);
			}
		}
	}
}
