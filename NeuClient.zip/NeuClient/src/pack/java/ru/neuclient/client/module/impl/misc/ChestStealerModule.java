package ru.neuclient.client.module.impl.misc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.NumberSetting;

/**
 * ChestStealer — пока модуль включён, ВСЕГДА перетаскивает предметы из
 * открытого контейнера (сундук/шалкер/бочка и т.п.) в наш инвентарь.
 *
 * Работа легитная: тот же clickSlot с SlotActionType.QUICK_MOVE, что шлёт
 * ванилла при Shift+клике по слоту. По одному предмету за раз, с паузой
 * "Скорость" мс между переносами (анти-спам для пинговых серверов).
 * Когда контейнер пуст — просто ждёт.
 */
public final class ChestStealerModule extends Module {

	/** Пауза между переносами предметов, мс. */
	private final NumberSetting speed = new NumberSetting("Скорость", 150.0, 0.0, 500.0, 10.0);

	/** Время последнего переноса (System.currentTimeMillis). */
	private long lastSteal = 0L;

	public ChestStealerModule() {
		super("ChestStealer", "Крадет лут из сундуков", Category.MISC);
		addSettings(speed);
	}

	@Override
	public void onTick(MinecraftClient client) {
		if (client.player == null || client.interactionManager == null) {
			return;
		}
		if (!(client.currentScreen instanceof HandledScreen<?> screen)) {
			lastSteal = 0L; // экран закрыли — не тянуть паузу на следующий сундук
			return;
		}
		// Экран инвентаря игрока — не контейнер. Без этой проверки
		// ChestStealer начинал «обворовывать» собственный инвентарь игрока.
		if (client.currentScreen instanceof net.minecraft.client.gui.screen.ingame.InventoryScreen) {
			return;
		}

		long now = System.currentTimeMillis();
		if (now - lastSteal < speed.get().longValue()) {
			return;
		}

		ScreenHandler handler = screen.getScreenHandler();
		// Слоты контейнера идут ПЕРЕД слотами инвентаря игрока: определяем
		// их по инвентарю — наш инвентарь скипаем, чужой (контейнер) грабим
		for (Slot slot : handler.slots) {
			if (slot.inventory == client.player.getInventory()) {
				continue; // свой инвентарь
			}
			if (!slot.hasStack()) {
				continue; // пустой слот
			}
			client.interactionManager.clickSlot(handler.syncId, slot.id, 0,
					SlotActionType.QUICK_MOVE, client.player);
			lastSteal = now; // один предмет за окно паузы
			return;
		}
		// Сюда попадаем, когда контейнер пуст — паузу не трогаем
	}
}
