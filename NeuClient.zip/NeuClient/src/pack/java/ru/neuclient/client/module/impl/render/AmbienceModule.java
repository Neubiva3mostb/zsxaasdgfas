package ru.neuclient.client.module.impl.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.ModeSetting;

/**
 * Ambience — локально меняет время суток в мире.
 *
 * Ванильное время суток — это long «tickOfDay» в свойствах мира, где
 * 0 = рассвет, 6000 = полдень, 12000 = закат, 18000 = полночь. Клиент
 * каждый тик сам крутит это значение (shouldTickTimeOfDay) и синхронизирует
 * его с сервером по WorldTimeUpdateS2CPacket.
 *
 * Модуль каждый тик выставляет своё время через ClientWorld#setTime и
 * отключает клиентский ход времени, чтобы выбранная фаза не «уползала» и
 * не откатывалась серверной синхронизацией. Меняется только КАРТИНКА:
 * освещение, цвет неба и тени. Спавн мобов, сон и любая игровая логика
 * считаются на сервере по настоящему времени.
 *
 * Режимы: Рассвет (23000) / Утро (1000) / День (6000) / Вечер (12000)
 * / Ночь (18000).
 *
 * При выключении модуля клиентский ход времени возвращается — мир
 * синхронизируется с сервером на ближайшем пакете времени.
 */
public final class AmbienceModule extends Module {

	private static final String DAWN = "Рассвет";
	private static final String MORNING = "Утро";
	private static final String DAY = "День";
	private static final String EVENING = "Вечер";
	private static final String NIGHT = "Ночь";

	private final ModeSetting time = new ModeSetting("Время", DAY,
			DAWN, MORNING, DAY, EVENING, NIGHT);

	public AmbienceModule() {
		super("Ambience", "Локально меняет время суток в мире", Category.RENDER);
		addSettings(time);
	}

	@Override
	public void onTick(MinecraftClient client) {
		ClientWorld world = client.world;
		if (world == null) {
			return;
		}
		long target = tickOfDay(time.get());
		// Полный день = 24000 тиков; сохраняем номер дня, меняем только фазу
		long dayStart = world.getTimeOfDay() / 24000L * 24000L;
		// shouldTickTimeOfDay = false — клиент не крутит время сам,
		// фаза стоит ровно там, где мы её поставили
		world.setTime(world.getLevelProperties().getTime(), dayStart + target, false);
	}

	/** Режим → позиция внутри суток (0..23999). */
	private static long tickOfDay(String mode) {
		return switch (mode) {
			case DAWN -> 23000L;    // солнце только выходит
			case MORNING -> 1000L;  // раннее утро, длинные тени
			case EVENING -> 12000L; // закат
			case NIGHT -> 18000L;   // полночь
			default -> 6000L;       // полдень
		};
	}

	@Override
	protected void onDisable() {
		// Возвращаем клиентский ход времени: ближайший пакет с сервера
		// вернёт настоящее время мира
		if (mc.world != null) {
			mc.world.setTime(mc.world.getLevelProperties().getTime(),
					mc.world.getTimeOfDay(), true);
		}
	}
}
