package ru.neuclient.client.module.impl.misc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ExperienceBottleItem;
import net.minecraft.item.ItemStack;
import ru.neuclient.client.mixin.MinecraftClientAccessor;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.BooleanSetting;
import ru.neuclient.client.setting.NumberSetting;

/**
 * NoDelay — своя задержка правой кнопки вместо ванильной.
 *
 * Ваниль после любого успешного использования ПКМ (установка блока,
 * бросок пузырька опыта) ставит MinecraftClient#itemUseCooldown = 4
 * (≈200 мс до следующего срабатывания при зажатой кнопке). Модуль
 * стоит «сторожем»: когда кулдаун появился в нужном контексте и прошло
 * «Задержка» мс — обнуляет его, и кнопка срабатывает снова.
 *
 * Контексты (независимые галки):
 *  - «Строительство» — в руке блок (плейс-плейс-плейс в заданном темпе);
 *  - «Пузырьки опыта» — в руке пузырёк (быстрый мэнтинг).
 *
 * Играем честно: никаких дополнительных пакетов — мы только снимаем
 * клиентский таймер, а сами клики идут штатным ванильным путём
 * (тот же doItemUse, те же пакеты, что и у ваниллы).
 *
 * Ограничение честности: клиент тикает 20 раз/с, поэтому реальная
 * точность — один тик (50 мс): значения мягче 50 мс всё равно дают
 * «раз в тик». Учитывай и сервер: если античит/плагин режет темп
 * бросков, лишние пузырьки просто не засчитаются.
 */
public class NoDelayModule extends Module {

	private final BooleanSetting building = new BooleanSetting("Строительство", false);
	private final BooleanSetting expBottles = new BooleanSetting("Пузырьки опыта", true);
	private final NumberSetting delay = new NumberSetting("Задержка", 10, 0, 100, 5);

	/** Время последнего снятого кулдауна (0 — кнопка не зажата). */
	private long lastUseMs;

	public NoDelayModule() {
		super("NoDelay", "Убирает задержку на действия", Category.MISC);
		addSettings(building, expBottles, delay);
	}

	@Override
	public void onTick(MinecraftClient client) {
		ClientPlayerEntity player = client.player;
		if (player == null) {
			return;
		}
		if (!client.options.useKey.isPressed()) {
			lastUseMs = 0; // кнопку отпустили — следующее зажатие сработает сразу
			return;
		}

		ItemStack main = player.getMainHandStack();
		ItemStack off = player.getOffHandStack();

		boolean context = expBottles.get()
				&& (main.getItem() instanceof ExperienceBottleItem || off.getItem() instanceof ExperienceBottleItem);
		if (!context && building.get()) {
			context = main.getItem() instanceof BlockItem || off.getItem() instanceof BlockItem;
		}
		if (!context) {
			return;
		}

		MinecraftClientAccessor accessor = (MinecraftClientAccessor) client;
		if (accessor.pc$getItemUseCooldown() <= 0) {
			return; // кулдауна нет — нечего снимать
		}

		long now = System.currentTimeMillis();
		long delayMs = delay.get().longValue();
		if (lastUseMs == 0 || now - lastUseMs >= delayMs) {
			accessor.pc$setItemUseCooldown(0);
			lastUseMs = now;
		}
	}
}
