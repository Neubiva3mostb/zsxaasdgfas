package ru.neuclient.client.module.impl.player;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.NumberSetting;
import ru.neuclient.client.util.InventoryUtil;
import ru.neuclient.client.util.SwapPause;
import ru.neuclient.client.util.SwapUtil;

/** Автоматически ест еду при голоде. */
public class AutoEatModule extends Module {

	private final NumberSetting hungerThreshold = new NumberSetting("Порог голода", 14.0, 1.0, 19.0, 1.0);

	private boolean eating;
	private boolean equipping;
	private boolean useStarted;
	private int useTicks;

	private int restoreInvSlot = -1;
	private int restoreHotbarSlot = -1;
	private int restoreSelected = -1;

	public AutoEatModule() {
		super("AutoEat", "Автоматически есть при голоде", Category.PLAYER);
		addSettings(hungerThreshold);
	}

	@Override
	public void onTick(MinecraftClient client) {
		ClientPlayerEntity player = client.player;
		if (player == null) return;

		// Сначала обслуживаем уже начатую еду. Нельзя выходить по SwapPause
		// раньше этого блока: иначе RELEASE_USE_ITEM может не уйти на сервер.
		if (eating) {
			handleEating(client, player);
			return;
		}

		if (client.currentScreen != null || player.isDead()) {
			cancelAction(client);
			return;
		}
		if (SwapPause.isBusy()) {
			return;
		}

		int hunger = player.getHungerManager().getFoodLevel();
		if (hunger >= hungerThreshold.get().intValue()) {
			equipping = false;
			return;
		}

		// Свап завершился — начинаем использование уже после того, как
		// сервер получил смену слота.
		if (equipping) {
			equipping = false;
			if (isFood(player.getMainHandStack()) && client.interactionManager != null) {
				client.interactionManager.interactItem(player, Hand.MAIN_HAND);
				eating = true;
				useStarted = false;
				useTicks = 0;
			} else {
				restore(client);
			}
			return;
		}

		int foodSlot = findFoodSlot(player);
		if (foodSlot < 0) return;
		equipFood(client, player, foodSlot);
		equipping = true;
	}

	/** Удержание useKey с обязательным отслеживанием перехода «использует → отпустил». */
	private void handleEating(MinecraftClient client, ClientPlayerEntity player) {
		if (client.currentScreen != null || player.isDead() || !isFood(player.getMainHandStack())) {
			finishEating(client);
			return;
		}

		boolean using = player.isUsingItem();
		if (using) {
			useStarted = true;
		}
		useTicks++;

		// После завершения ванильной анимации отпускаем кнопку. Даже если
		// в стаке ещё осталась еда, повторно зажимать ПКМ нельзя.
		if ((useStarted && !using) || useTicks > 50) {
			finishEating(client);
			return;
		}

		// Это реальное состояние клавиши клиента: на следующем тике
		// Minecraft сам отправит серверу продолжение использования.
		client.options.useKey.setPressed(true);
	}

	private void finishEating(MinecraftClient client) {
		client.options.useKey.setPressed(false);
		eating = false;
		equipping = false;
		useStarted = false;
		useTicks = 0;
		restore(client);
	}

	private void cancelAction(MinecraftClient client) {
		client.options.useKey.setPressed(false);
		eating = false;
		equipping = false;
		useStarted = false;
		useTicks = 0;
		restore(client);
	}

	private int findFoodSlot(ClientPlayerEntity player) {
		for (int i = 0; i < 9; i++) {
			if (isFood(player.getInventory().getStack(i))) return i;
		}
		for (int i = 9; i <= 35; i++) {
			if (isFood(player.getInventory().getStack(i))) return i;
		}
		return -1;
	}

	private boolean isFood(ItemStack stack) {
		return !stack.isEmpty() && stack.contains(net.minecraft.component.DataComponentTypes.FOOD);
	}

	private void equipFood(MinecraftClient client, ClientPlayerEntity player, int slot) {
		if (isFood(player.getMainHandStack())) return;
		if (slot < 9) {
			InventoryUtil.selectSlot(player, slot, client.interactionManager);
			return;
		}

		int currentHotbar = player.getInventory().getSelectedSlot();
		int emptyHotbar = findEmptyHotbar(player);
		int targetHotbar = emptyHotbar >= 0 ? emptyHotbar : currentHotbar;
		if (SwapUtil.swapToHotbar(client, player, slot, targetHotbar)) {
			restoreInvSlot = slot;
			restoreHotbarSlot = targetHotbar;
			restoreSelected = currentHotbar;
			InventoryUtil.selectSlot(player, targetHotbar, client.interactionManager);
		}
	}

	private int findEmptyHotbar(ClientPlayerEntity player) {
		for (int i = 0; i < 9; i++) {
			if (player.getInventory().getStack(i).isEmpty()) return i;
		}
		return -1;
	}

	private void restore(MinecraftClient client) {
		ClientPlayerEntity player = client == null ? null : client.player;
		if (player == null || client.interactionManager == null) {
			restoreInvSlot = -1;
			restoreHotbarSlot = -1;
			restoreSelected = -1;
			return;
		}
		if (restoreInvSlot >= 0 && restoreHotbarSlot >= 0) {
			SwapUtil.restoreSwap(client, player, restoreInvSlot, restoreHotbarSlot);
		}
		restoreInvSlot = -1;
		restoreHotbarSlot = -1;
		if (restoreSelected >= 0) {
			InventoryUtil.selectSlot(player, restoreSelected, client.interactionManager);
			restoreSelected = -1;
		}
	}

	@Override
	protected void onDisable() {
		cancelAction(mc);
	}
}
