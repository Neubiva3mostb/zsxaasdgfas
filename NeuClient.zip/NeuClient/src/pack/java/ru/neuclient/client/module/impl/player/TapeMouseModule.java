package ru.neuclient.client.module.impl.player;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.ModeSetting;
import ru.neuclient.client.setting.NumberSetting;

/** Периодически выполняет один настоящий клик ЛКМ или ПКМ. */
public final class TapeMouseModule extends Module {

	private static final String LEFT = "ЛКМ";
	private static final String RIGHT = "ПКМ";

	private final ModeSetting button = new ModeSetting("Кнопка", LEFT, LEFT, RIGHT);
	private final NumberSetting interval = new NumberSetting("Интервал (сек)", 1.0, 1.0, 60.0, 1.0);
	private long nextClickAt;

	public TapeMouseModule() {
		super("TapeMouse", "Периодически нажимает выбранную кнопку мыши", Category.PLAYER);
		addSettings(button, interval);
	}

	@Override
	protected void onEnable() {
		nextClickAt = 0L;
	}

	@Override
	protected void onDisable() {
		nextClickAt = 0L;
	}

	@Override
	public void onTick(MinecraftClient client) {
		ClientPlayerEntity player = client.player;
		if (player == null || client.world == null || client.interactionManager == null
				|| client.currentScreen != null) {
			return;
		}

		long now = System.currentTimeMillis();
		if (now < nextClickAt) {
			return;
		}

		if (LEFT.equals(button.get())) {
			clickLeft(client, player);
		} else {
			clickRight(client, player);
		}
		// Даже если в воздух не попали, соблюдаем выбранный интервал,
		// чтобы модуль не превращался в спам при пустом прицеле.
		nextClickAt = now + interval.get().longValue() * 1_000L;
	}

	/** Один обычный ванильный клик ЛКМ по сущности или блоку. */
	private boolean clickLeft(MinecraftClient client, ClientPlayerEntity player) {
		if (client.crosshairTarget instanceof EntityHitResult hit) {
			Entity entity = hit.getEntity();
			if (entity == player) {
				return false;
			}
			client.interactionManager.attackEntity(player, entity);
			return true;
		}
		if (client.crosshairTarget instanceof BlockHitResult hit) {
			boolean accepted = client.interactionManager.attackBlock(hit.getBlockPos(), hit.getSide());
			if (accepted) {
				player.swingHand(Hand.MAIN_HAND);
			}
			return accepted;
		}
		return false;
	}

	/** Один обычный ванильный клик ПКМ по блоку или использование предмета. */
	private boolean clickRight(MinecraftClient client, ClientPlayerEntity player) {
		ActionResult result;
		if (client.crosshairTarget instanceof BlockHitResult hit) {
			result = client.interactionManager.interactBlock(player, Hand.MAIN_HAND, hit);
		} else {
			result = client.interactionManager.interactItem(player, Hand.MAIN_HAND);
		}
		return result.isAccepted();
	}
}
