package ru.neuclient.client.module.impl.player;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.NumberSetting;
import ru.neuclient.client.setting.TextSetting;

/**
 * AutoClanInvest — вкладывает заданную сумму в казну клана.
 *
 * Ограничение интервала намеренно начинается с 15 минут: именно такой
 * минимальный период указан в правилах автоматизации FunTime. Команда
 * отправляется обычным ванильным sendChatCommand, без подмены пакетов.
 */
public final class AutoClanInvestModule extends Module {

	private static final long MIN_INTERVAL_MS = 15L * 60L * 1000L;

	/** Текст нужен, чтобы можно было ввести точную сумму вручную. */
	private final TextSetting amount = new TextSetting("Сумма", "100000", 16);
	private final NumberSetting intervalMinutes = new NumberSetting(
			"Интервал", 15.0, 15.0, 60.0, 1.0);

	private long nextInvestAt;

	public AutoClanInvestModule() {
		super("AutoClanInvest", "Автоматически пополняет казну клана", Category.PLAYER);
		addSettings(amount, intervalMinutes);
	}

	@Override
	protected void onEnable() {
		// Первое вложение можно сделать сразу после включения.
		nextInvestAt = 0L;
	}

	@Override
	protected void onDisable() {
		nextInvestAt = 0L;
	}

	@Override
	public void onTick(MinecraftClient client) {
		if (client.player == null || client.world == null || client.currentScreen != null) {
			return;
		}
		ClientPlayNetworkHandler handler = client.getNetworkHandler();
		if (handler == null) {
			return;
		}

		long now = System.currentTimeMillis();
		if (now < nextInvestAt) {
			return;
		}

		String rawAmount = amount.get() == null ? "" : amount.get().trim().replace("_", "");
		if (!rawAmount.matches("[0-9]{1,16}")) {
			// Неверная строка не должна превращаться в командный спам.
			nextInvestAt = now + 5_000L;
			return;
		}
		long investAmount;
		try {
			investAmount = Long.parseLong(rawAmount);
		} catch (NumberFormatException ignored) {
			nextInvestAt = now + 5_000L;
			return;
		}
		if (investAmount < 1L) {
			nextInvestAt = now + 5_000L;
			return;
		}

		long interval = Math.max(MIN_INTERVAL_MS,
				intervalMinutes.get().longValue() * 60_000L);
		try {
			// sendChatCommand принимает команду без начального слэша.
			handler.sendChatCommand("clan invest " + investAmount);
			nextInvestAt = now + interval;
		} catch (Throwable t) {
			ru.neuclient.client.NeuClient.LOGGER.error(
					"[NeuClient] AutoClanInvest: не удалось отправить команду", t);
			// При ошибке не блокируем модуль на 15 минут.
			nextInvestAt = now + 5_000L;
		}
	}
}
