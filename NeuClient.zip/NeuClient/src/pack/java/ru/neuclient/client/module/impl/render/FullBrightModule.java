package ru.neuclient.client.module.impl.render;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.SimpleOption;
import ru.neuclient.client.mixin.SimpleOptionAccessor;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;

/**
 * FullBright — полная яркость: ночь и пещеры видно как днём.
 *
 * Ванильная яркость (гамма) клэмпится ползунком настроек в диапазон
 * 0..1. Мы пишем сразу +100 СЫРЫМ значением в SimpleOption (через
 * акцессор-миксин, минуя клэмп) — LightmapTextureManager каждый кадр
 * читает getGamma().getValue() и строит лайтмапу с ней, поэтому
 * становится светло везде без всяких источников света.
 *
 * ПОЧЕМУ ГАММА ПОДДЕРЖИВАЕТСЯ КАЖДЫЙ ТИК, А НЕ ПИШЕТСЯ ОДИН РАЗ.
 * Раньше значение выставлялось только в onEnable(), и модуль ломался
 * после перезахода по двум независимым причинам:
 *
 *  1. ПЕРЕЗАХОД НА СЕРВЕР. Ваниль периодически перечитывает и
 *     переписывает настройки (GameOptions#load, применение опций из
 *     экрана настроек, ресурс-паки серверa). Наше «сырое» значение
 *     при этом затирается штатным из options.txt, а onEnable() второй
 *     раз уже не вызовется — модуль-то всё ещё включён.
 *
 *  2. ПЕРЕЗАПУСК КЛИЕНТА. Модуль включается из конфига при старте
 *     (ConfigManager вызывает setEnabled(true) → onEnable()), но в
 *     этот момент mc.options ещё может быть не готов — старая версия
 *     просто молча выходила по `if (mc.options == null) return`, и
 *     яркость не применялась вообще.
 *
 * Теперь onTick() каждый тик проверяет фактическое значение и
 * восстанавливает его, если ваниль перебила. Это дёшево: сравнение
 * double плюс запись поля только при расхождении.
 */
public class FullBrightModule extends Module {

	/** Гамма «максимальной яркости» — далеко за пределами ползунка. */
	private static final double FULL_GAMMA = 100.0;

	/**
	 * Гамма до включения модуля; null = ещё не запоминали.
	 *
	 * Запоминается лениво (при первом успешном применении), потому что
	 * на момент onEnable() настройки могут быть недоступны.
	 */
	private Double previousGamma;

	public FullBrightModule() {
		super("FullBright", "Полная яркость", Category.RENDER);
	}

	@Override
	protected void onEnable() {
		// Ничего не делаем принудительно: применением занимается onTick.
		// Так модуль корректно поднимается и при включении из конфига,
		// когда mc.options ещё не создан.
		apply();
	}

	@Override
	protected void onDisable() {
		if (previousGamma != null && mc.options != null) {
			setGamma(mc.options.getGamma(), previousGamma);
		}
		// Сбрасываем, чтобы при следующем включении запомнить актуальную
		// пользовательскую яркость, а не устаревшую.
		previousGamma = null;
	}

	@Override
	public void onTick(MinecraftClient client) {
		apply();
	}

	/**
	 * Выставить гамму, если она сбилась.
	 *
	 * Вызывается и при включении, и каждый тик — идемпотентно.
	 */
	private void apply() {
		MinecraftClient client = MinecraftClient.getInstance();
		if (client == null || client.options == null) {
			return; // настройки ещё не готовы — попробуем на следующем тике
		}
		SimpleOption<Double> gamma = client.options.getGamma();
		Double current = gamma.getValue();
		if (current == null) {
			return;
		}
		if (previousGamma == null) {
			// Первое успешное применение: запоминаем яркость игрока.
			// Если ваниль уже успела подсунуть наше же значение (модуль
			// был включён до перезахода), не сохраняем его как
			// «пользовательское» — иначе после выключения останется 100.
			previousGamma = current == FULL_GAMMA ? 1.0 : current;
		}
		if (current != FULL_GAMMA) {
			setGamma(gamma, FULL_GAMMA);
		}
	}

	/** Запись гаммы напрямую в поле value — клэмп SimpleOption.setValue обходится. */
	@SuppressWarnings("unchecked")
	private static void setGamma(SimpleOption<Double> option, double value) {
		((SimpleOptionAccessor) (Object) option).pc$setValue(value);
	}
}
