package ru.neuclient.client.module.impl.misc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.NumberSetting;

/**
 * AntiAFK — предотвращает кик за AFK на сервере.
 * 
 * Механика: отправляет серверные пакеты движения и действий,
 * чтобы сервер видел что игрок активен (не только клиентские действия).
 */
public final class AntiAFKModule extends Module {

    private final NumberSetting interval = new NumberSetting("Интервал", 20.0, 5.0, 100.0, 1.0);

    private int tickCounter = 0;
    private boolean lastAction = false;

    public AntiAFKModule() {
        super("AntiAFK", "Предотвращает кик за AFK", Category.MISC);
        addSettings(interval);
    }

    @Override
    public void onTick(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (player == null || client.getNetworkHandler() == null) return;

        tickCounter++;
        if (tickCounter < interval.get().intValue()) return;
        tickCounter = 0;

        // Отправляем серверу пакеты, чтобы он видел активность
        float yaw = player.getYaw();
        float pitch = player.getPitch();

        // Чередование: поворот головы + прыжок или взмах рукой
        if (!lastAction) {
            // Поворот головы для сервера
            float newYaw = yaw + 1.0f;
            player.networkHandler.sendPacket(
                new PlayerMoveC2SPacket.LookAndOnGround(newYaw, pitch, player.isOnGround(), player.horizontalCollision));
            player.networkHandler.sendPacket(
                new PlayerMoveC2SPacket.LookAndOnGround(yaw, pitch, player.isOnGround(), player.horizontalCollision));
            
            // Прыжок для сервера
            if (player.isOnGround()) {
                player.jump();
            }
        } else {
            // Взмах рукой — серверный пакет
            player.networkHandler.sendPacket(
                new PlayerActionC2SPacket(PlayerActionC2SPacket.Action.SWAP_ITEM_WITH_OFFHAND,
                    BlockPos.ORIGIN, Direction.DOWN));
            // Отменяем свап обратно
            player.networkHandler.sendPacket(
                new PlayerActionC2SPacket(PlayerActionC2SPacket.Action.SWAP_ITEM_WITH_OFFHAND,
                    BlockPos.ORIGIN, Direction.DOWN));
        }
        lastAction = !lastAction;
    }

    @Override
    protected void onEnable() {
        tickCounter = 0;
        lastAction = false;
    }

    @Override
    protected void onDisable() {
        tickCounter = 0;
    }
}
