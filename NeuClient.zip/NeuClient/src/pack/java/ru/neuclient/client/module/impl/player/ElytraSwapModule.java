package ru.neuclient.client.module.impl.player;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.KeyBindSetting;
import ru.neuclient.client.util.InventoryUtil;
import ru.neuclient.client.util.SwapUtil;

/**
 * ElytraSwap — своя клавиша на свап нагрудника и на феерверк.
 *
 * Кнопки назначаются как обычные бинды: в настройках модуля ЛКМ по строке
 * клавиши → жмёшь любую кнопку (Esc снимает).
 *
 * «Кнопка свапа элитр»: если на тебе элитры — надевает лучший нагрудник,
 * если нагрудник — элитры. Вещь летит СРАЗУ В НАГРУДНИК честными кликами
 * инвентаря (взял на курсор → клик по слоту груди → старое обратно на место).
 *
 * «Кнопка феерверка»: берёт фейерверк В РУКУ перед использованием и тут же
 * пускает его (только если надеты элитры). После — возвращает слот/предмет.
 *
 * Правило паузы как у всех свапперов: предмет из ХОТБАРА — мгновенно,
 * из глубокого ИНВЕНТАРЯ — остановка на время \"Задержка\", затем свап.
 * Свапы настоящие — сервер видит то же, что и клиент (clickSlot-пакеты).
 */
public final class ElytraSwapModule extends Module {

	/** Пауза перед свапом из глубокого инвентаря, мс (уменьшено). */
	private static final long SWAP_PAUSE_MS = 100L;
	private final KeyBindSetting swapKey = new KeyBindSetting("Кнопка свапа элитр", GLFW.GLFW_KEY_B);
	private final KeyBindSetting rocketKey = new KeyBindSetting("Кнопка феерверка", GLFW.GLFW_KEY_N);

	// ---- Детект фронта клавиш ----
	private boolean prevSwapDown = false;
	private boolean prevRocketDown = false;

	// ---- Общая машина действий ----
	/** Чем заняты: 0 = ничем, 1 = свап груди, 2 = феерверк. */
	private int action = 0;
	/** Шаг внутри действия. */
	private int step = 0;
	/** Ячейка источника (0–8 хотбар, 9–35 инвентарь). */
	private int sourceIndex = -1;
	/** Момент старта паузы, -1 = паузы нет. */
	private long pendingSince = -1L;
	/** Пауза в тиках между движениями (хотбарные пути). */
	private int tickDelay = 0;
	/** Выбранный слот до макроса (для возврата при феерверке). */
	private int prevSlot = -1;
	/** Слот инвентаря для обратного свапа феерверка (-1 = не было). */
	private int restoreInvSlot = -1;
	/** Ячейка хотбара, куда клали фейерверк (возврат идёт именно в неё). */
	private int restoreHotbarSlot = -1;
	/** Открыли GUI посреди фейерверка: возврат предмета отложен до закрытия. */
	private boolean restoreAfterScreen;

	public ElytraSwapModule() {
		super("ElytraSwap", "Свапает элики по бинду", Category.PLAYER);
		addSettings(swapKey, rocketKey);
	}

	@Override
	public void onTick(MinecraftClient client) {
		ClientPlayerEntity player = client.player;
		if (player == null || client.world == null || client.interactionManager == null) {
			abort();
			return;
		}
		long handle = client.getWindow().getHandle();
		boolean swapDown = swapKey.get() != KeyBindSetting.NONE
				&& GLFW.glfwGetKey(handle, swapKey.get()) == GLFW.GLFW_PRESS;
		boolean rocketDown = rocketKey.get() != KeyBindSetting.NONE
				&& GLFW.glfwGetKey(handle, rocketKey.get()) == GLFW.GLFW_PRESS;
		// В любом GUI запрещены и старт, и очередные шаги сценария.
		// Если уже переложили ракету, вернём её только после закрытия GUI.
		if (blockingScreen(client)) {
			if (action == 2) restoreAfterScreen = true;
			action = step = 0;
			pendingSince = -1L;
			tickDelay = 0;
			prevSwapDown = swapDown;
			prevRocketDown = rocketDown;
			return;
		}
		if (restoreAfterScreen) {
			if (!ru.neuclient.client.util.SwapPause.isBusy()) {
				restore(client, player);
				restoreAfterScreen = false;
				abort();
			}
			prevSwapDown = swapDown;
			prevRocketDown = rocketDown;
			return;
		}

		// --- Текущее действие крутим всегда вперёд ---
		if (action != 0) {
			tickAction(client, player);
			prevSwapDown = swapDown;
			prevRocketDown = rocketDown;
			return;
		}

		// --- Старт по фронту клавиш ---
		if (swapDown && !prevSwapDown) {
			beginChestSwap(player);
		} else if (rocketDown && !prevRocketDown) {
			beginRocket(player);
		}
		prevSwapDown = swapDown;
		prevRocketDown = rocketDown;
	}

	// ===== Общая машина: пауза для инвентаря, мгновенно для хотбара =====

	private void tickAction(MinecraftClient client, ClientPlayerEntity player) {
		// Свап и смена слота уходят на сервер отложенно — на тик позже
		// вызова, вместе с пакетом стоящего игрока (см. SwapPause).
		// Пока это не отработало, фейерверка в руке ещё нет: пуск ушёл
		// бы предыдущим предметом.
		if (ru.neuclient.client.util.SwapPause.isBusy()) {
			return;
		}
		// Пауза «из инвентаря» (мс) — только в шаге 0
		if (pendingSince >= 0L) {
			// Неподвижность в момент клика обеспечивает SwapPause
			// (один пакет), здесь выдерживается пауза между шагами
			// сценария: надеть элитры → взлететь.
			long now = System.currentTimeMillis();
			if (now - pendingSince < SWAP_PAUSE_MS) {
				return;
			}
			pendingSince = -1L;
		}
		if (tickDelay > 0) {
			tickDelay--;
			return;
		}
		tickRocket(client, player);
	}

	// ===== Свап нагрудника/элитр =====

	private void beginChestSwap(ClientPlayerEntity player) {
		boolean wearingElytra = player.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA);
		sourceIndex = wearingElytra ? findChestplate(player) : findElytra(player);
		if (sourceIndex < 0) {
			return; // менять не на что
		}
		// Единый механизм клиента (SwapUtil): три клика PICKUP по слоту
		// нагрудника прямо из мира — без открытия экрана; остановка на
		// один тик (50 мс) берётся внутри SwapUtil
		if (mc.player != null && SwapUtil.swapToArmor(mc, mc.player, sourceIndex, EquipmentSlot.CHEST, true)) {
			sourceIndex = -1;
		}
		action = 0;
		step = 0;
		pendingSince = -1L;
		tickDelay = 0;
	}

	// ===== Феерверк =====

	private void beginRocket(ClientPlayerEntity player) {
		// Без надетых элитр феерверк бессмысленен — не тратим
		if (!player.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA)) {
			return;
		}
		PlayerInventory inv = player.getInventory();
		prevSlot = inv.getSelectedSlot();
		restoreInvSlot = -1;

		// Уже в руке — сразу пуск
		if (inv.getStack(prevSlot).isOf(Items.FIREWORK_ROCKET)) {
			// Уже в руке: ничего не перекладываем, задержка не нужна.
			action = 2;
			step = 1;
			pendingSince = -1L;
			tickDelay = 0;
			return;
		}
		sourceIndex = InventoryUtil.findInHotbar(player, s -> s.isOf(Items.FIREWORK_ROCKET));
		if (sourceIndex >= 0) {
			// Хотбар: выбор слота → пуск. Остановка на один тик берётся
			// и здесь — смена слота стоит столько же, сколько свап из
			// инвентаря, иначе пути отличались бы для сервера.
			selectSlotInWorld(player, sourceIndex);
			action = 2;
			step = 1;
			pendingSince = -1L;
			tickDelay = 0; // задержку выдерживает барьер SwapPause в tickAction
			return;
		}
		sourceIndex = InventoryUtil.findInInventory(player, s -> s.isOf(Items.FIREWORK_ROCKET));
		if (sourceIndex < 0) {
			return;
		}
		// Инвентарь: мгновенный свап в текущий слот хотбара → пуск
		action = 2;
		step = 0;
		pendingSince = -1L;
		tickDelay = 0;
	}

	private void tickRocket(MinecraftClient client, ClientPlayerEntity player) {
		PlayerInventory inv = player.getInventory();
		switch (step) {
			case 0 -> {
				// (только путь из инвентаря) свап феерверка в текущий слот хотбара
				int slot = InventoryUtil.findInInventory(player, s -> s.isOf(Items.FIREWORK_ROCKET));
				if (slot < 0) {
					abort();
					return;
				}
				int target = inv.getSelectedSlot();
				if (SwapUtil.swapToHotbar(client, player, slot, target, true)) {
					restoreInvSlot = slot;
					restoreHotbarSlot = target;
				}
				step = 1;
				tickDelay = 0; // задержку выдерживает барьер SwapPause
			}
			case 1 -> {
				// Пуск: фейерверк в руке, честное ИСПОЛЬЗОВАНИЕ
				if (!inv.getStack(inv.getSelectedSlot()).isOf(Items.FIREWORK_ROCKET)) {
					restore(client, player);
					abort();
					return;
				}
				client.interactionManager.interactItem(player, Hand.MAIN_HAND);
				player.swingHand(Hand.MAIN_HAND);
				step = 2;
				tickDelay = 1;
			}
			default -> {
				restore(client, player);
				abort(); // цикл завершён
			}
		}
	}

	/**
	 * Возврат слота/предметов сразу после пуска фейерверка.
	 *
	 * Возвращаем в ЗАПОМНЕННУЮ ячейку хотбара, а не в «текущую
	 * выбранную»: в полёте игрок часто крутит колесо, и обратный SWAP
	 * относительно текущего слота растаскивал хотбар.
	 */
	private void restore(MinecraftClient client, ClientPlayerEntity player) {
		if (restoreInvSlot >= 0 && restoreHotbarSlot >= 0 && client.interactionManager != null) {
			SwapUtil.swapToHotbar(mc, player, restoreInvSlot, restoreHotbarSlot, true);
		}
		restoreInvSlot = -1;
		restoreHotbarSlot = -1;

		if (prevSlot >= 0 && prevSlot != player.getInventory().getSelectedSlot()
				&& client.interactionManager != null) {
			selectSlotInWorld(player, prevSlot);
		}
	}

	/** Не исполнять отложенную смену слота, если за время паузы открылся экран. */
	private void selectSlotInWorld(ClientPlayerEntity player, int slot) {
		if (blockingScreen(mc) || mc.interactionManager == null) return;
		ru.neuclient.client.util.SwapPause.submit(() -> {
			if (!blockingScreen(mc) && mc.player == player && mc.interactionManager != null) {
				InventoryUtil.selectSlot(player, slot, mc.interactionManager, false);
			}
		});
	}

	// ===== Поиск предметов =====

	/** Лучший нагрудник (любой тир выше кожи тоже считаем), -1 если нет. */
	private int findChestplate(ClientPlayerEntity player) {
		PlayerInventory inv = player.getInventory();
		int bestScore = 0;
		int bestIndex = -1;
		for (int i = 0; i <= 35; i++) {
			ItemStack stack = inv.getStack(i);
			if (stack.isEmpty()) {
				continue;
			}
			String id = Registries.ITEM.getId(stack.getItem()).getPath();
			if (!id.endsWith("_chestplate")) {
				continue;
			}
			int s = chestScore(id);
			if (s > bestScore) {
				bestScore = s;
				bestIndex = i;
			}
		}
		return bestIndex;
	}

	private int chestScore(String id) {
		if (id.startsWith("netherite_")) return 6;
		if (id.startsWith("diamond_")) return 5;
		if (id.startsWith("iron_")) return 4;
		if (id.startsWith("chainmail_")) return 3;
		if (id.startsWith("golden_")) return 2;
		if (id.startsWith("leather_")) return 1;
		return 0;
	}

	/** Элитры где угодно в инвентаре/хотбаре (сначала хотбар — мгновенный путь). */
	private int findElytra(ClientPlayerEntity player) {
		int hotbar = InventoryUtil.findInHotbar(player, s -> s.isOf(Items.ELYTRA));
		return hotbar >= 0 ? hotbar
				: InventoryUtil.findInInventory(player, s -> s.isOf(Items.ELYTRA));
	}

	private void abort() {
		restoreAfterScreen = false;
		action = 0;
		step = 0;
		sourceIndex = -1;
		pendingSince = -1L;
		tickDelay = 0;
		restoreInvSlot = -1;
		prevSlot = -1;
	}

	@Override
	protected void onDisable() {
		ClientPlayerEntity player = mc.player;
		if (action == 2 && player != null) {
			restore(mc, player); // выключили посреди пуска — вернуть предметы
		}
		abort();
	}
}
