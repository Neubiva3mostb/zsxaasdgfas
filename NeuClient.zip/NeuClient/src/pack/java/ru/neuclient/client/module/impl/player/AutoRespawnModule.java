package ru.neuclient.client.module.impl.player;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.DeathScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.NumberSetting;

/**
 * AutoRespawn — автоматический респавн после смерти.
 * 
 * Механика: как только появился экран смерти (DeathScreen),
 * ждём "Задержка" тиков и нажимаем кнопку респавна.
 */
public final class AutoRespawnModule extends Module {

    private final NumberSetting delay = new NumberSetting("Задержка", 5.0, 1.0, 40.0, 1.0);
    
    private long respawnAt = -1L;

    public AutoRespawnModule() {
        super("AutoRespawn", "Автоматический респавн после смерти", Category.PLAYER);
        addSettings(delay);
    }

    @Override
    public void onTick(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (player == null) return;

        // Если на экране смерти
        if (client.currentScreen instanceof DeathScreen) {
            if (respawnAt < 0L) {
                // Запускаем таймер
                respawnAt = System.currentTimeMillis() + delay.get().longValue() * 50L; // 1 тик = 50мс
                return;
            }

            if (System.currentTimeMillis() >= respawnAt) {
                // Респавнимся
                respawnAt = -1L;
                try {
                    player.requestRespawn();
                    client.setScreen(null);
                } catch (Throwable t) {
                    ru.neuclient.client.NeuClient.LOGGER.error("[NeuClient] AutoRespawn ошибка", t);
                }
            }
        } else {
            // Не на экране смерти — сбрасываем таймер
            respawnAt = -1L;
        }
    }

    @Override
    protected void onDisable() {
        respawnAt = -1L;
    }
}
