package ru.neuclient.client.module.impl.combat;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SplashPotionItem;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Hand;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.BooleanSetting;
import ru.neuclient.client.setting.NumberSetting;

/**
 * AutoPot — автоматическое кидание splash-зелий под себя с серверным спуфом.
 *
 * ЛОГИКА:
 *  - Сила/Скорость/Огнестойкость: если эффекта нет на игроке, находим
 *    splash-зелье в инвентаре и кидаем под себя через спуф.
 *  - Исцеление: если HP ниже порога, кидаем splash хилку под ноги.
 *
 * СЕРВЕРНЫЙ СПУФ:
 *  1. UpdateSelectedSlotC2SPacket — "предмет в нужном слоте"
 *  2. PlayerMoveC2SPacket.LookAndOnGround — "голова смотрит вниз" (pitch=90)
 *  3. UseItemC2SPacket — бросок зелья
 *  4. Обратные пакеты — возврат слота и головы
 *  Клиент не видит ничего: камера стоит, предмет в руке не меняется.
 */
public final class AutoPotModule extends Module {

	private final BooleanSetting useStrength = new BooleanSetting("Сила", true);
	private final BooleanSetting useSpeed = new BooleanSetting("Скорость", true);
	private final BooleanSetting useFireRes = new BooleanSetting("Огнестойкость", true);
	private final BooleanSetting useHealing = new BooleanSetting("Исцеление", true);

	/** Порог HP (в единицах, макс 20) для использования зелья исцеления. */
	private final NumberSetting healThreshold = new NumberSetting("Порог HP", 10.0, 2.0, 18.0, 1.0);

	/** Минимальное время между бросками (тики). */
	private final NumberSetting cooldown = new NumberSetting("Кулдаун", 10.0, 3.0, 30.0, 1.0);

	/** Фазы броска зелья. */
	private enum Phase {
		IDLE,           // Ждём условий
		SWAPPING,       // Свапаем зелье из инвентаря в хотбар
		PREPARING,      // Отправляем спуф-пакеты (слот + голова вниз)
		THROWING,       // Бросаем зелье
		RETURNING       // Возвращаем слот и голову
	}

	private Phase phase = Phase.IDLE;
	private int phaseTicks = 0;

	/** Тиков с последнего броска. */
	private int cooldownTicks = 0;

	/** Сохранённые значения для возврата. */
	private int savedSlot = 0;
	private float savedPitch = 0.0f;
	private int potInventorySlot = -1; // слот зелья в инвентаре (для свапа)
	private int potHotbarSlot = -1;    // слот хотбара куда свапнули

	public AutoPotModule() {
		super("AutoPot", "Кидает splash-зелья под себя", Category.COMBAT);
		addSettings(useStrength, useSpeed, useFireRes, useHealing, healThreshold, cooldown);
	}

	@Override
	protected void onEnable() {
		phase = Phase.IDLE;
		phaseTicks = 0;
		cooldownTicks = 0;
		savedSlot = 0;
		savedPitch = 0.0f;
		potInventorySlot = -1;
		potHotbarSlot = -1;
	}

	@Override
	protected void onDisable() {
		phase = Phase.IDLE;
		phaseTicks = 0;
	}

	@Override
	public void onTick(MinecraftClient client) {
		ClientPlayerEntity player = client.player;
		if (player == null || client.world == null || client.getNetworkHandler() == null) {
			return;
		}

		if (cooldownTicks > 0) {
			cooldownTicks--;
		}

		phaseTicks++;

		switch (phase) {
			case IDLE -> tickIdle(client, player);
			case SWAPPING -> tickSwapping(client, player);
			case PREPARING -> tickPreparing(client, player);
			case THROWING -> tickThrowing(client, player);
			case RETURNING -> tickReturning(client, player);
		}
	}

	/**
	 * IDLE: проверяем условия и начинаем бросок если нужно.
	 */
	private void tickIdle(MinecraftClient client, ClientPlayerEntity player) {
		if (cooldownTicks > 0) return;
		if (client.currentScreen != null) return;

		// Исцеление — приоритет (если HP низкий)
		if (useHealing.get()) {
			float currentHp = player.getHealth();
			float threshold = healThreshold.get().floatValue();
			if (currentHp < threshold) {
				int slot = findSplashPotion(player, StatusEffects.INSTANT_HEALTH);
				if (slot >= 0) {
					startThrow(player, slot);
					return;
				}
			}
		}

		// Баффы — только если эффекта нет
		if (useStrength.get() && !hasEffect(player, StatusEffects.STRENGTH)) {
			int slot = findSplashPotion(player, StatusEffects.STRENGTH);
			if (slot >= 0) {
				startThrow(player, slot);
				return;
			}
		}

		if (useSpeed.get() && !hasEffect(player, StatusEffects.SPEED)) {
			int slot = findSplashPotion(player, StatusEffects.SPEED);
			if (slot >= 0) {
				startThrow(player, slot);
				return;
			}
		}

		if (useFireRes.get() && !hasEffect(player, StatusEffects.FIRE_RESISTANCE)) {
			int slot = findSplashPotion(player, StatusEffects.FIRE_RESISTANCE);
			if (slot >= 0) {
				startThrow(player, slot);
				return;
			}
		}
	}

	/**
	 * Начало броска: сохраняем слот и pitch, свапаем если нужно.
	 */
	private void startThrow(ClientPlayerEntity player, int slot) {
		savedSlot = player.getInventory().getSelectedSlot();
		savedPitch = player.getPitch();

		if (slot < 9) {
			// Зелье уже в хотбаре — сразу к спуфу
			potHotbarSlot = slot;
			potInventorySlot = -1;
			phase = Phase.PREPARING;
		} else {
			// Зелье в инвентаре — нужно свапнуть в хотбар
			potInventorySlot = slot;
			potHotbarSlot = savedSlot; // свапнем в текущий слот хотбара
			phase = Phase.SWAPPING;
		}
		phaseTicks = 0;
	}

	/**
	 * SWAPPING: свапаем зелье из инвентаря в хотбар через SwapUtil.
	 */
	private void tickSwapping(MinecraftClient client, ClientPlayerEntity player) {
		// Не ставим второй свап в очередь, пока не отработал первый.
		if (ru.neuclient.client.util.SwapPause.isBusy()) {
			return;
		}
		if (phaseTicks >= 1) {
			// Свапаем зелье из инвентаря в хотбар
			boolean swapped = ru.neuclient.client.util.SwapUtil.swapToHotbar(
					client, player, potInventorySlot, potHotbarSlot);
			if (swapped) {
				phase = Phase.PREPARING;
				phaseTicks = 0;
			}
			// Если свап не удался (очередь занята), повторим на следующем тике
		}
	}

	/**
	 * PREPARING: отправляем спуф-пакеты (слот + голова вниз).
	 */
	private void tickPreparing(MinecraftClient client, ClientPlayerEntity player) {
		// Ждём, пока отработает предыдущее отложенное действие (свап
		// зелья в хотбар): его клик уходит на тик позже вызова.
		if (ru.neuclient.client.util.SwapPause.isBusy()) {
			return;
		}
		if (phaseTicks >= 1) {
			// Остановка на один тик (50 мс). Для сервера смена слота —
			// такое же действие с инвентарём, как клик, и она обязана
			// стоить столько же. Иначе путь «зелье уже в хотбаре» шёл бы
			// на полном бегу, а путь «зелье в рюкзаке» — стоя.
			//
			// Спуф-пакеты уходят внутри задачи: они должны прийти после
			// пакета стоящего игрока, иначе смена слота снова окажется
			// «на бегу» — ровно то, от чего эта пауза и существует.
			ru.neuclient.client.util.SwapPause.submit(() -> {
				if (player.networkHandler == null) {
					return;
				}
				// Спуф слота — сервер думает что зелье в руке
				player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(potHotbarSlot));
				// Спуф головы вниз — зелье полетит под ноги
				player.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(
						player.getYaw(), 90.0f, player.isOnGround(), player.horizontalCollision));
			});

			phase = Phase.THROWING;
			phaseTicks = 0;
		}
	}

	/**
	 * THROWING: бросаем зелье.
	 * Траектория считается КЛИЕНТОМ по реальному pitch игрока,
	 * поэтому нужно реально опустить голову на 1 кадр.
	 */
	private void tickThrowing(MinecraftClient client, ClientPlayerEntity player) {
		// Спуф слота отправляется отложенно — бросать можно только после
		// того, как он реально ушёл на сервер.
		if (ru.neuclient.client.util.SwapPause.isBusy()) {
			return;
		}
		// Реально опускаем голову — зелье полетит под ноги
		player.setPitch(90.0f);
		// Бросок
		client.interactionManager.interactItem(player, Hand.MAIN_HAND);
		// Сразу возвращаем pitch (камера дёрнется только на 1 кадр)
		player.setPitch(savedPitch);

		phase = Phase.RETURNING;
		phaseTicks = 0;
	}

	/**
	 * RETURNING: возвращаем слот и голову, свапаем обратно если нужно.
	 */
	private void tickReturning(MinecraftClient client, ClientPlayerEntity player) {
		// Возвращаем голову
		player.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(
				player.getYaw(), savedPitch, player.isOnGround(), player.horizontalCollision));
		// Возвращаем слот
		player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(savedSlot));

		// Зелье брошено — предмет отработал, сразу раскладываем слоты
		// обратно. Тот же обмен повторно возвращает вытесненный из
		// хотбара предмет на его место, а остаток зелий — в инвентарь.
		if (potInventorySlot >= 0 && potHotbarSlot >= 0) {
			ru.neuclient.client.util.SwapUtil.restoreSwap(
					client, player, potInventorySlot, potHotbarSlot);
		}

		// Кулдаун
		cooldownTicks = cooldown.get().intValue();

		phase = Phase.IDLE;
		phaseTicks = 0;
		potInventorySlot = -1;
		potHotbarSlot = -1;
	}

	/**
	 * Есть ли у игрока данный эффект (с оставшимся временем > 10 секунд).
	 */
	private boolean hasEffect(ClientPlayerEntity player, RegistryEntry<StatusEffect> effect) {
		StatusEffectInstance instance = player.getStatusEffect(effect);
		return instance != null && instance.getDuration() > 200; // > 10 секунд
	}

	/**
	 * Поиск SPLASH-зелья с нужным эффектом в хотбаре и инвентаре.
	 * @return индекс слота (0-35) или -1
	 */
	private int findSplashPotion(ClientPlayerEntity player, RegistryEntry<StatusEffect> effect) {
		// Сначала ищем в хотбаре (0-8) — быстрее достать
		for (int i = 0; i < 9; i++) {
			ItemStack stack = player.getInventory().getStack(i);
			if (isSplashPotionWithEffect(stack, effect)) {
				return i;
			}
		}
		// Потом в инвентаре (9-35)
		for (int i = 9; i < 36; i++) {
			ItemStack stack = player.getInventory().getStack(i);
			if (isSplashPotionWithEffect(stack, effect)) {
				return i;
			}
		}
		return -1;
	}

	/**
	 * Проверка: является ли предмет SPLASH-зельем с нужным эффектом.
	 */
	private boolean isSplashPotionWithEffect(ItemStack stack, RegistryEntry<StatusEffect> effect) {
		if (stack.isEmpty()) return false;
		// Только splash, не обычные зелья
		if (!(stack.getItem() instanceof SplashPotionItem)) return false;

		PotionContentsComponent contents = stack.get(DataComponentTypes.POTION_CONTENTS);
		if (contents == null) return false;

		for (StatusEffectInstance instance : contents.getEffects()) {
			if (instance.getEffectType().equals(effect)) {
				return true;
			}
		}
		return false;
	}
}
