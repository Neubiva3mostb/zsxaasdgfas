package ru.neuclient.client.module.impl.misc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.util.InputUtil;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.KeyBindSetting;
import ru.neuclient.client.util.InventoryUtil;
import ru.neuclient.client.util.KeyNames;

import java.util.Arrays;
import java.util.Locale;

/**
 * FTHelper — быстрое использование биндовых предметов «на ПКМ».
 *
 * ИДЕЯ. На FunTime и подобных серверах есть предметы-«свистки» с особым
 * лором (трапка, дезориентация, снежок-заморозка и т.д.). Их надо держать
 * в руке и нажимать ПКМ в нужный момент — вручную это медленно и неудобно
 * под нагрузкой боя. Модуль позволяет забиндить до шести таких предметов
 * на отдельные клавиши: нажал клавишу — клиент сам взял предмет из ХОТБАРА
 * в руку и один раз нажал ПКМ.
 *
 * ПОЧЕМУ ПРОВЕРКА ПО ЛОРУ, А НЕ ПО ИМЕНИ/ТИПУ ПРЕДМЕТА. У всех этих
 * предметов ванильная основа одна и та же (например снежок, яйцо,
 * светокамень), различает их только кастомный лор, который выдаёт сервер.
 * Поэтому единственный надёжный признак — заранее заданный текст в лоре.
 * Сравнение идёт по подстроке без учёта регистра и без цветовых кодов §x.
 *
 * ТЕКСТЫ ЛОРА ЗАШИТЫ В КОД. В GUI у каждого слота только клавиша — сам
 * текст, по которому ищется предмет, задан константой в {@link #LOR}. Так
 * клик по настройке сразу привязывает конкретный предмет к клавише, без
 * ручного ввода текста. Если сервер поменяет лор — правится одна строка
 * в этом массиве.
 *
 * ТОЛЬКО ХОТБАР. Предмет должен уже лежать в хотбаре (слоты 0–8). Модуль
 * НЕ вытаскивает предметы из глубокого инвентаря: свап с рюкзаком — это
 * лишний пакет и остановка на тик, которые в бою только мешают. Если
 * нужного предмета в хотбаре нет — нажатие просто игнорируется.
 *
 * РУЧНОЕ УПРАВЛЕНИЕ. Отправляется ровно один interactItem (ПКМ) на нажатие
 * клавиши — как будто игрок сам выбрал слот и кликнул. Ничего лишнего
 * клиент не делает.
 */
public class FTHelperModule extends Module {

	/** Сколько предметов можно забиндить одновременно. */
	private static final int SLOTS = 6;
	/** Минимальная длина текста лора, чтобы не ловить случайные совпадения. */
	private static final int MIN_LORE_LEN = 3;

	/**
	 * Названия слотов в GUI (индекс 0 = первый слот). Показываются вместо
	 * безликих «Клавиша N», чтобы сразу было понятно, что забиндено.
	 */
	private static final String[] NAMES = {
			"Трапка",            // 1 — Неразрушимая клетка
			"Дезориентация",     // 2 — Звуковая волна
			"Явная пыль",        // 3 — Световая вспышка
			"Божья Аура",        // 4 — Божественная аура
			"Снежок заморозки",  // 5 — Ледяная сфера
			"Пласт"              // 6 — Неразрушимая стена
	};

	/**
	 * Тексты лора по слотам (индекс 0 = первый слот). Зашиты в код:
	 * настройки текста в GUI нет, предмет для слота фиксирован.
	 */
	private static final String[] LOR = {
			"Неразрушимая клетка",   // 1 — Трапка
			"Звуковая волна",        // 2 — Дезориентация
			"Световая вспышка",      // 3 — Явная пыль
			"Божественная аура",     // 4 — Божья Аура
			"Ледяная сфера",         // 5 — Снежок заморозка
			"Неразрушимая стена"     // 6 — Пласт
	};

	/** Для каждого слота: клавиша использования. */
	private final KeyBindSetting[] binds = new KeyBindSetting[SLOTS];

	/** Предыдущее состояние клавиши (детект фронта нажатия). */
	private final boolean[] prevPressed = new boolean[SLOTS];

	/** Пауза между использованиями, мс (защита от дребезга нажатий). */
	private long lastUseAt;

	public FTHelperModule() {
		super("FTHelper", "Помогает с предметами на сервере", Category.MISC);

		// В GUI — только клавиши; текст лора берётся из LOR.
		KeyBindSetting[] all = new KeyBindSetting[SLOTS];
		for (int i = 0; i < SLOTS; i++) {
			KeyBindSetting bind = new KeyBindSetting(NAMES[i], KeyNames.NONE);
			binds[i] = bind;
			all[i] = bind;
		}
		addSettings(all);
	}

	@Override
	protected void onDisable() {
		// Сбрасываем фронт нажатий, чтобы при следующем включении не
		// сработало «залипшее» нажатие, оставшееся с прошлого раза.
		Arrays.fill(prevPressed, false);
	}

	@Override
	public void onTick(MinecraftClient client) {
		ClientPlayerEntity player = client.player;
		if (player == null || client.interactionManager == null) {
			return;
		}
		// В меню/инвентаре клавиши предметов не трогаем — там свой ввод.
		if (client.currentScreen != null || player.isDead()) {
			Arrays.fill(prevPressed, false);
			return;
		}

		for (int i = 0; i < SLOTS; i++) {
			int key = binds[i].get();
			if (key == KeyBindSetting.NONE) {
				prevPressed[i] = false;
				continue;
			}

			boolean now = InputUtil.isKeyPressed(client.getWindow(), key);
			boolean was = prevPressed[i];
			prevPressed[i] = now;

			// Реагируем только на фронт нажатия — одно ПКМ на нажатие.
			if (now && !was) {
				useItem(client, player, LOR[i]);
			}
		}
	}

	/**
	 * Найти в хотбаре предмет с нужным лором, взять в руку и нажать ПКМ.
	 * Пустой/слишком короткий текст игнорируется.
	 */
	private void useItem(MinecraftClient client, ClientPlayerEntity player, String loreNeedle) {
		if (loreNeedle == null || loreNeedle.isBlank()) {
			return;
		}
		String needle = normalize(loreNeedle);
		if (needle.length() < MIN_LORE_LEN) {
			return;
		}
		long now = System.currentTimeMillis();
		if (now - lastUseAt < 100L) {
			return; // защита от дребезга
		}

		int slot = findItemInHotbar(player, needle);
		if (slot < 0) {
			return; // предмета нет в хотбаре — молча выходим
		}

		// Слот уже выбран — просто жмём ПКМ, иначе СНАЧАЛА берём в руку.
		// ВАЖНО: pause=false — обычный selectSlot откладывает смену слота на
		// тик (SwapPause), и interactItem уходил бы СО СТАРОГО слота, а свап
		// уже после. Порядок пакетов обязан быть: UpdateSelectedSlot → UseItem.
		if (player.getInventory().getSelectedSlot() != slot) {
			InventoryUtil.selectSlot(player, slot, client.interactionManager, false);
		}
		// Нажимаем ПКМ тем, что сейчас в руке — как обычный игрок.
		client.interactionManager.interactItem(player, Hand.MAIN_HAND);
		lastUseAt = now;
	}

	/**
	 * Первый предмет в хотбаре, чей лор содержит нужный текст (или чьё имя
	 * само содержит текст — на случай, если сервер положил подпись в имя).
	 */
	private int findItemInHotbar(ClientPlayerEntity player, String needle) {
		for (int i = 0; i < 9; i++) {
			ItemStack stack = player.getInventory().getStack(i);
			if (stack.isEmpty()) {
				continue;
			}
			if (matchesLore(stack, needle)) {
				return i;
			}
		}
		return -1;
	}

	/** Есть ли у стака в лоре (или в имени) подстрока needle. */
	private boolean matchesLore(ItemStack stack, String needle) {
		// Имя предмета.
		String name = normalize(stack.getName().getString());
		if (name.contains(needle)) {
			return true;
		}
		// Лор (в 1.21 хранится в компоненте LORE).
		LoreComponent lore = stack.get(DataComponentTypes.LORE);
		if (lore != null) {
			for (Text lineText : lore.lines()) {
				if (normalize(lineText.getString()).contains(needle)) {
					return true;
				}
			}
		}
		return false;
	}

	/** Убрать цветовые коды §x, обрезать края и привести к нижнему регистру. */
	private static String normalize(String s) {
		if (s == null) {
			return "";
		}
		return s.replaceAll("§.", "").trim().toLowerCase(Locale.ROOT);
	}
}
