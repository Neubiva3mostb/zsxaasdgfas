package ru.neuclient.client.module.impl.misc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.BooleanSetting;
import ru.neuclient.client.setting.NumberSetting;
import ru.neuclient.client.setting.TextSetting;

/**
 * Spammer — повторяет заданное сообщение в чат сервера через равные паузы.
 *
 * Настройки:
 *   • «Текст»     — что писать (вводится с клавиатуры прямо в ClickGUI);
 *   • «Задержка»  — пауза между отправками, секунды, шаг 0.5, максимум 30;
 *   • «Суффикс»   — дописывать в конец короткий случайный хвост
 *                   (·, ~, ⋅ и т.п.), чтобы сервер не резал повторы
 *                   как одинаковые сообщения.
 *
 * Отправка идёт ванильным путём (sendChatMessage / sendChatCommand), то есть
 * ровно так же, как если бы ты набрал строку руками: сервер получает обычное
 * чат-сообщение. Строка, начинающаяся со слэша, уходит как команда.
 *
 * Первое сообщение отправляется сразу при включении, дальше — по таймеру.
 */
public final class SpammerModule extends Module {

	/** Символы для генерации случайного суффикса (цифры + английские буквы). */
	private static final String SUFFIX_CHARS = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";

	/** Текст сообщения. */
	private final TextSetting text = new TextSetting("Текст", "NeuClient", 64);

	/** Пауза между отправками, секунды. */
	private final NumberSetting delay = new NumberSetting("Задержка", 5.0, 0.5, 30.0, 0.5);

	/** Дописывать случайный хвост, чтобы обойти анти-флуд по повторам. */
	private final BooleanSetting suffix = new BooleanSetting("Суффикс", true);

	/** Момент следующей отправки (currentTimeMillis); -1 — отправить сразу. */
	private long nextSendAt = -1L;

	public SpammerModule() {
		super("Spammer", "Спамит текстом в чат", Category.MISC);
		addSettings(text, delay, suffix);
	}

	@Override
	protected void onEnable() {
		nextSendAt = -1L;
	}

	@Override
	protected void onDisable() {
		nextSendAt = -1L;
	}

	@Override
	public void onTick(MinecraftClient client) {
		ClientPlayerEntity player = client.player;
		ClientPlayNetworkHandler handler = client.getNetworkHandler();
		if (player == null || handler == null) {
			// Вне игры таймер не тикает — при заходе отправим сразу
			nextSendAt = -1L;
			return;
		}

		String message = text.get() == null ? "" : text.get().trim();
		if (message.isEmpty()) {
			return; // нечего слать
		}

		long now = System.currentTimeMillis();
		if (nextSendAt > 0L && now < nextSendAt) {
			return;
		}

		send(handler, message);
		nextSendAt = now + (long) (delay.get() * 1000.0);
	}

	/** Отправка строки на сервер: со слэша — команда, иначе обычный чат. */
	private void send(ClientPlayNetworkHandler handler, String message) {
		try {
			if (message.startsWith("/")) {
				// Команда идёт отдельным пакетом и БЕЗ ведущего слэша
				handler.sendChatCommand(message.substring(1));
				return;
			}
			handler.sendChatMessage(decorate(message));
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Spammer: не удалось отправить сообщение", t);
		}
	}

	/** Дописать хвост (только к обычному чату — команду он бы сломал). */
	private String decorate(String message) {
		if (!suffix.get()) {
			return message;
		}
		// Генерируем случайный суффикс из 3-8 разных символов
		java.util.concurrent.ThreadLocalRandom rng = java.util.concurrent.ThreadLocalRandom.current();
		int len = 3 + rng.nextInt(6); // 3..8
		StringBuilder tail = new StringBuilder(" ");
		java.util.Set<Character> used = new java.util.HashSet<>();
		while (tail.length() - 1 < len) {
			char c = SUFFIX_CHARS.charAt(rng.nextInt(SUFFIX_CHARS.length()));
			if (used.add(c)) {
				tail.append(c);
			}
		}
		String tailStr = tail.toString();
		// 256 — лимит ванильного чат-пакета
		if (message.length() + tailStr.length() > 256) {
			return message;
		}
		return message + tailStr;
	}
}
