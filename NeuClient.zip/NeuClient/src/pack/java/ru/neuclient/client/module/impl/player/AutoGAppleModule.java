package ru.neuclient.client.module.impl.player;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.NumberSetting;
import ru.neuclient.client.util.InventoryUtil;
import ru.neuclient.client.util.SwapPause;
import ru.neuclient.client.util.SwapUtil;

/** Автоматически съедает золотое яблоко при низком здоровье. */
public final class AutoGAppleModule extends Module {

	private final NumberSetting healthThreshold = new NumberSetting(
			"Порог здоровья", 10.0, 1.0, 19.0, 1.0);

	private boolean pendingUse;
	private boolean eating;
	private boolean useStarted;
	private int useTicks;
	private int restoreInventorySlot = -1;
	private int restoreHotbarSlot = -1;
	private int restoreSelectedSlot = -1;
	private long nextUseAt;

	public AutoGAppleModule() {
		super("AutoGApple", "Ест золотое яблоко при низком здоровье", Category.PLAYER);
		addSettings(healthThreshold);
	}

	@Override
	public void onTick(MinecraftClient client) {
		ClientPlayerEntity player = client.player;
		if (player == null || client.interactionManager == null) return;

		// Обрабатываем завершение еды до проверки SwapPause, чтобы обязательно
		// отправить серверу release use item.
		if (eating) {
			handleEating(client, player);
			return;
		}

		if (client.currentScreen != null || player.isDead()) {
			cancelAction(client);
			return;
		}
		if (SwapPause.isBusy()) return;

		if (pendingUse) {
			pendingUse = false;
			if (isGoldenApple(player.getMainHandStack()) && !player.isUsingItem()) {
				client.interactionManager.interactItem(player, Hand.MAIN_HAND);
				eating = true;
				useStarted = false;
				useTicks = 0;
			} else {
				restore(client);
			}
			return;
		}

		if (player.isUsingItem() || player.getHealth() > healthThreshold.get()
				|| System.currentTimeMillis() < nextUseAt) {
			return;
		}

		int slot = findGoldenApple(player);
		if (slot >= 0 && equipApple(client, player, slot)) {
			pendingUse = true;
		}
	}

	private void handleEating(MinecraftClient client, ClientPlayerEntity player) {
		if (client.currentScreen != null || player.isDead() || !isGoldenApple(player.getMainHandStack())) {
			finishEating(client);
			return;
		}

		boolean using = player.isUsingItem();
		if (using) useStarted = true;
		useTicks++;
		if ((useStarted && !using) || useTicks > 50) {
			finishEating(client);
			return;
		}

		client.options.useKey.setPressed(true);
	}

	private void finishEating(MinecraftClient client) {
		client.options.useKey.setPressed(false);
		eating = false;
		pendingUse = false;
		useStarted = false;
		useTicks = 0;
		restore(client);
		nextUseAt = System.currentTimeMillis() + 350L;
	}

	private void cancelAction(MinecraftClient client) {
		client.options.useKey.setPressed(false);
		eating = false;
		pendingUse = false;
		useStarted = false;
		useTicks = 0;
		restore(client);
	}

	private int findGoldenApple(ClientPlayerEntity player) {
		// Сначала зачарованное, затем обычное.
		for (int i = 0; i <= 35; i++) {
			if (player.getInventory().getStack(i).isOf(Items.ENCHANTED_GOLDEN_APPLE)) return i;
		}
		for (int i = 0; i <= 35; i++) {
			if (player.getInventory().getStack(i).isOf(Items.GOLDEN_APPLE)) return i;
		}
		return -1;
	}

	private boolean isGoldenApple(ItemStack stack) {
		return stack.isOf(Items.GOLDEN_APPLE) || stack.isOf(Items.ENCHANTED_GOLDEN_APPLE);
	}

	private boolean equipApple(MinecraftClient client, ClientPlayerEntity player, int slot) {
		if (slot < 9) {
			restoreSelectedSlot = player.getInventory().getSelectedSlot();
			InventoryUtil.selectSlot(player, slot, client.interactionManager);
			return true;
		}

		int selected = player.getInventory().getSelectedSlot();
		int targetHotbar = findEmptyHotbar(player);
		if (targetHotbar < 0) targetHotbar = selected;
		if (!SwapUtil.swapToHotbar(client, player, slot, targetHotbar)) return false;
		restoreInventorySlot = slot;
		restoreHotbarSlot = targetHotbar;
		restoreSelectedSlot = selected;
		InventoryUtil.selectSlot(player, targetHotbar, client.interactionManager);
		return true;
	}

	private int findEmptyHotbar(ClientPlayerEntity player) {
		for (int i = 0; i < 9; i++) {
			if (player.getInventory().getStack(i).isEmpty()) return i;
		}
		return -1;
	}

	private void restore(MinecraftClient client) {
		ClientPlayerEntity player = client == null ? null : client.player;
		if (player == null || client.interactionManager == null) {
			restoreInventorySlot = -1;
			restoreHotbarSlot = -1;
			restoreSelectedSlot = -1;
			return;
		}
		if (restoreInventorySlot >= 0 && restoreHotbarSlot >= 0) {
			SwapUtil.restoreSwap(client, player, restoreInventorySlot, restoreHotbarSlot);
		}
		restoreInventorySlot = -1;
		restoreHotbarSlot = -1;
		if (restoreSelectedSlot >= 0) {
			InventoryUtil.selectSlot(player, restoreSelectedSlot, client.interactionManager);
			restoreSelectedSlot = -1;
		}
	}

	@Override
	protected void onDisable() {
		cancelAction(mc);
	}
}
