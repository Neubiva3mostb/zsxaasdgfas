package ru.neuclient.client.module.impl.player;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.NumberSetting;
import ru.neuclient.client.setting.TextSetting;

/**
 * AutoCommand — периодически выполняет выбранную команду.
 * Команда вводится текстом, со слэшем или без него.
 */
public final class AutoCommandModule extends Module {

	private final TextSetting command = new TextSetting("Команда", "near", 96);
	private final NumberSetting interval = new NumberSetting(
			"Интервал", 15.0, 5.0, 3600.0, 1.0);
	private long nextRunAt;

	public AutoCommandModule() {
		super("AutoCommand", "Сам выполняет команды на сервер", Category.PLAYER);
		addSettings(command, interval);
	}

	@Override
	protected void onEnable() {
		nextRunAt = 0L;
	}

	@Override
	protected void onDisable() {
		nextRunAt = 0L;
	}

	@Override
	public void onTick(MinecraftClient client) {
		if (client.player == null || client.world == null || client.currentScreen != null) {
			return;
		}
		ClientPlayNetworkHandler handler = client.getNetworkHandler();
		if (handler == null) {
			return;
		}

		long now = System.currentTimeMillis();
		if (now < nextRunAt) {
			return;
		}

		String raw = command.get() == null ? "" : command.get().trim();
		if (raw.startsWith("/")) {
			raw = raw.substring(1).trim();
		}
		if (raw.isEmpty()) {
			nextRunAt = now + 5_000L;
			return;
		}

		try {
			// Команда идёт тем же ванильным путём, что и введённая вручную.
			handler.sendChatCommand(raw);
			nextRunAt = now + Math.max(5_000L, interval.get().longValue() * 1_000L);
		} catch (Throwable t) {
			ru.neuclient.client.NeuClient.LOGGER.error(
					"[NeuClient] AutoCommand: не удалось отправить команду", t);
			nextRunAt = now + 5_000L;
		}
	}
}
