package ru.neuclient.client.module.impl.movement;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec2f;
import ru.neuclient.client.mixin.KeyBindingAccessor;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;

/**
 * SafeWalk — реально зажимает шифт на краю блока.
 *
 * Никакой магии с движением: когда игрок стоит на земле и под ним впереди
 * кончается опора, модуль буквально вызывает sneakKey.setPressed(true) —
 * ровно то, что делает клавиша, только раньше реакции человека. Как только
 * край пропал, состояние шифта возвращается к тому, что физически держит
 * рука (читаем клавиатуру через InputUtil) — свой шифт игрока не ломается.
 */
public final class SafeWalkModule extends Module {

	/** Отступ внутрь от края хитбокса — насколько рано зажимаем шифт. */
	private static final double EDGE_MARGIN = 0.3;

	/** true, пока шифт держим МЫ (а не игрок). */
	private boolean holdingSneak = false;

	public SafeWalkModule() {
		super("SafeWalk", "Зажимает шифт на краю блока, чтобы не упасть", Category.MOVEMENT);
	}

	@Override
	public void onTick(MinecraftClient client) {
		ClientPlayerEntity player = client.player;
		KeyBinding sneak = client.options.sneakKey;

		boolean need = client.world != null
				&& player != null
				&& player.isOnGround()
				&& !player.isTouchingWater()
				&& !player.isClimbing()
				&& !player.hasVehicle()
				&& isMovingInput(player)
				&& nearEdge(client);

		if (need) {
			if (!sneak.isPressed()) {
				sneak.setPressed(true); // та самая «реальная» клавиша
			}
			holdingSneak = true;
		} else if (holdingSneak) {
			// Возвращаем состояние ровно в то, что держит рука игрока
			sneak.setPressed(physicallyHeld(client, sneak));
			holdingSneak = false;
		}
	}

	/** Нажата ли сейчас движущая клавиша (WASD) — иначе зажимать шифт незачем. */
	private boolean isMovingInput(ClientPlayerEntity player) {
		if (player.input == null) {
			return false;
		}
		Vec2f move = player.input.getMovementInput();
		return move.x != 0.0f || move.y != 0.0f;
	}

	/**
	 * true, если под хитбоксом (чуть суженным и опущенным на полблока)
	 * нет ни одного твёрдого блока — вот-вот сойдём с края.
	 */
	private boolean nearEdge(MinecraftClient client) {
		ClientPlayerEntity player = client.player;
		Box box = player.getBoundingBox()
				.offset(0.0, -0.5, 0.0)
				.expand(-EDGE_MARGIN, 0.0, -EDGE_MARGIN);
		return !client.world.getBlockCollisions(player, box).iterator().hasNext();
	}

	/** Физическое состояние клавиши шифта у игрока (для корректного отпускания). */
	private boolean physicallyHeld(MinecraftClient client, KeyBinding sneak) {
		try {
			int code = ((KeyBindingAccessor) sneak).pc$getBoundKey().getCode();
			return InputUtil.isKeyPressed(client.getWindow(), code);
		} catch (Throwable t) {
			return false;
		}
	}

	@Override
	protected void onDisable() {
		if (holdingSneak) {
			MinecraftClient client = MinecraftClient.getInstance();
			if (client != null && client.options != null) {
				client.options.sneakKey.setPressed(physicallyHeld(client, client.options.sneakKey));
			}
			holdingSneak = false;
		}
	}
}
