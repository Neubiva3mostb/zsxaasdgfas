package ru.neuclient.client.module.impl.misc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.BooleanSetting;
import ru.neuclient.client.setting.ModeSetting;
import ru.neuclient.client.setting.NumberSetting;
import ru.neuclient.client.util.ChatUtil;

/**
 * AutoLeave — аварийный выход из боя.
 *
 * Триггер (настройка «Триггер»):
 *   • «По ХП»       — срабатывает, когда здоровье (с учётом абсорбции)
 *                     падает до порога «ХП» или ниже;
 *   • «По игроку»   — срабатывает, когда в радиусе «Радиус» появляется
 *                     любой другой игрок (друзья и NPC-стойки не в счёт,
 *                     если включены соответствующие галки).
 *
 * Куда уходим (настройка «Куда»):
 *   • «Хаб»    — отправляет команду /hub на сервер
 *                (networkHandler.sendChatCommand — обычный путь ванильного
 *                клиента, тот же, что при вводе команды руками);
 *   • «Выход»  — рвёт соединение с сервером (connection.disconnect).
 *
 * Модуль однократный: сработав, он сам выключается — иначе после /hub
 * он продолжит спамить командой в лобби. Включай заново, когда снова нужен.
 *
 * Важно: при «Выход» AutoReconnect автоматически выключается, иначе он
 * тут же вернёт тебя обратно на тот сервер, с которого ты уходил.
 */
public final class AutoLeaveModule extends Module {

	private static final String TRIGGER_HP = "По ХП";
	private static final String TRIGGER_PLAYER = "По игроку";

	private static final String DEST_HUB = "Хаб";
	private static final String DEST_QUIT = "Выход";

	/** Что считать поводом уйти. */
	private final ModeSetting trigger = new ModeSetting("Триггер", TRIGGER_HP, TRIGGER_HP, TRIGGER_PLAYER);

	/** Порог здоровья (ХП + абсорбция), при котором уходим. */
	private final NumberSetting health = new NumberSetting("ХП", 6.0, 1.0, 20.0, 0.5);

	/** Радиус поиска чужого игрока (блоки). */
	private final NumberSetting radius = new NumberSetting("Радиус", 20.0, 3.0, 100.0, 1.0);

	/** Куда уходить. */
	private final ModeSetting destination = new ModeSetting("Куда", DEST_HUB, DEST_HUB, DEST_QUIT);

	/** Команда для режима «Хаб» (без слэша). */
	private final ru.neuclient.client.setting.TextSetting command =
			new ru.neuclient.client.setting.TextSetting("Команда", "hub", 24);

	/** Не считать друзей поводом уходить. */
	private final BooleanSetting ignoreFriends = new BooleanSetting("Игнорировать друзей", true);

	/** Сработали уже? Защита от повторной отправки в том же включении. */
	private boolean fired;

	public AutoLeaveModule() {
		super("AutoLeave", "Автоматически ливает", Category.MISC);

		// Порог ХП виден только в режиме «По ХП», радиус — только в «По игроку»
		health.visibleWhen(() -> TRIGGER_HP.equals(trigger.get()));
		radius.visibleWhen(() -> TRIGGER_PLAYER.equals(trigger.get()));
		ignoreFriends.visibleWhen(() -> TRIGGER_PLAYER.equals(trigger.get()));
		command.visibleWhen(() -> DEST_HUB.equals(destination.get()));

		addSettings(trigger, health, radius, ignoreFriends, destination, command);
	}

	@Override
	protected void onEnable() {
		fired = false;
	}

	@Override
	protected void onDisable() {
		fired = false;
	}

	@Override
	public void onTick(MinecraftClient client) {
		if (fired) {
			return;
		}
		ClientPlayerEntity player = client.player;
		if (player == null || client.world == null || player.isDead()) {
			return;
		}
		// В меню/экранах смерти ничего не делаем — там мы уже никуда не бежим
		if (client.getNetworkHandler() == null) {
			return;
		}

		boolean shouldLeave = TRIGGER_HP.equals(trigger.get())
				? hpTriggered(player)
				: playerNearby(client, player);

		if (!shouldLeave) {
			return;
		}

		fired = true;
		if (DEST_QUIT.equals(destination.get())) {
			quit(client);
		} else {
			hub(client);
		}
		// Одноразовое срабатывание: гасим себя, чтобы не спамить в лобби
		setEnabled(false);
	}

	// ===== Триггеры =====

	/** ХП с абсорбцией упало до порога. */
	private boolean hpTriggered(ClientPlayerEntity player) {
		float hp = player.getHealth() + player.getAbsorptionAmount();
		return hp > 0.0f && hp <= health.get().floatValue();
	}

	/** Есть ли в радиусе чужой игрок. */
	private boolean playerNearby(MinecraftClient client, ClientPlayerEntity self) {
		double r = radius.get();
		double rSq = r * r;
		boolean skipFriends = ignoreFriends.get();

		for (PlayerEntity other : client.world.getPlayers()) {
			if (other == self || other == null || other.isSpectator() || !other.isAlive()) {
				continue;
			}
			if (other.squaredDistanceTo(self) > rSq) {
				continue;
			}
			if (skipFriends && isFriend(other)) {
				continue;
			}
			return true;
		}
		return false;
	}

	private static boolean isFriend(PlayerEntity other) {
		try {
			return NeuClient.getInstance() != null
					&& NeuClient.getInstance().getFriendManager() != null
					&& NeuClient.getInstance().getFriendManager().isFriend(other.getName().getString());
		} catch (Throwable t) {
			return false;
		}
	}

	// ===== Уходы =====

	/** Отправка команды на сервер (ванильный путь, как ввод руками). */
	private void hub(MinecraftClient client) {
		ClientPlayNetworkHandler handler = client.getNetworkHandler();
		if (handler == null) {
			return;
		}
		String cmd = command.get() == null ? "" : command.get().trim();
		if (cmd.startsWith("/")) {
			cmd = cmd.substring(1);
		}
		if (cmd.isEmpty()) {
			cmd = command.getDefault();
		}
		try {
			// sendChatCommand принимает команду БЕЗ ведущего слэша
			handler.sendChatCommand(cmd);
			ChatUtil.send("AutoLeave: ухожу командой /" + cmd);
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] AutoLeave: не удалось отправить команду", t);
		}
	}

	/** Полный разрыв соединения с сервером. */
	private void quit(MinecraftClient client) {
		// AutoReconnect тут же вернул бы нас назад — гасим его
		try {
			AutoReconnectModule reconnect = NeuClient.getInstance() != null
					&& NeuClient.getInstance().getModuleManager() != null
					? NeuClient.getInstance().getModuleManager().get(AutoReconnectModule.class)
					: null;
			if (reconnect != null && reconnect.isEnabled()) {
				reconnect.setEnabled(false);
				ChatUtil.send("AutoLeave: AutoReconnect выключен, иначе он вернёт обратно");
			}
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] AutoLeave: не удалось выключить AutoReconnect", t);
		}

		ClientPlayNetworkHandler handler = client.getNetworkHandler();
		if (handler == null) {
			return;
		}
		try {
			handler.getConnection().disconnect(Text.literal("NeuClient · AutoLeave"));
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] AutoLeave: не удалось отключиться", t);
		}
	}
}
