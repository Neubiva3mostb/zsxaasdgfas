package ru.neuclient.client.module.impl.combat;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.AttributeModifiersComponent;
import net.minecraft.component.type.BundleContentsComponent;
import net.minecraft.component.type.EquippableComponent;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.BundleItemSelectedC2SPacket;
import net.minecraft.screen.slot.SlotActionType;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.BooleanSetting;
import ru.neuclient.client.util.SwapUtil;

/**
 * AutoArmor — надевает лучшую броню из инвентаря и из мешков (бандлов).
 *
 * КАК НАДЕВАЕТСЯ.
 * Одним пакетом SlotActionType.SWAP: слот-источник меняется местами со
 * слотом брони. Прежняя схема из трёх кликов PICKUP через SwapUtil была
 * ненадёжной (предмет висит на курсоре между кликами) и вдобавок шла
 * через прежний SwapFreeze, который ждал полной остановки игрока —
 * до 20 тиков (он удалён, теперь остановка длится один пакет).
 * Броню надо надевать на бегу, поэтому ожидание убрано.
 *
 * ЧТО СЧИТАЕТСЯ «ЛУЧШЕЙ» БРОНЁЙ.
 * Не тир предмета по имени (прежний код сравнивал строки вида
 * "netherite_"), а РЕАЛЬНЫЕ характеристики: сумма модификаторов брони и
 * прочности брони из компонента ATTRIBUTE_MODIFIERS плюс уровень
 * Protection. Так кожанка с Prot IV корректно проигрывает алмазу, а
 * кастомные серверные предметы вообще перестают быть невидимыми для
 * модуля.
 *
 * ПОЧТИ СЛОМАННАЯ БРОНЯ.
 * Если надетая вещь вот-вот развалится (осталось меньше 41 ед.
 * прочности), приоритет меняется: ищем замену по ОСТАТКУ ПРОЧНОСТИ, а не
 * по защите — иначе игрок остаётся голым в бою.
 */
public final class AutoArmorModule extends Module {

	/** Не переодеваться в движении (кроме срочных случаев). */
	private final BooleanSetting notMoving = new BooleanSetting("Не в движении", true);

	/** Доставать броню из мешков (bundle). */
	private final BooleanSetting fromBundles = new BooleanSetting("Из мешков", true);

	/** Порог «почти сломано», ед. прочности. */
	private static final int LOW_DURABILITY = 41;

	/** Бонус к оценке, когда текущая вещь вот-вот сломается. */
	private static final int URGENT_BONUS = 20;

	/** Скорость, выше которой игрок считается движущимся. */
	private static final double MOVING_SPEED_SQ = 1.0E-4;

	private static final EquipmentSlot[] ARMOR_SLOTS = {
			EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

	/** Счётчик тиков: обычные переодевания идём через тик. */
	private int tickCounter;

	public AutoArmorModule() {
		super("AutoArmor", "Автоматически надевает лучшую броню", Category.COMBAT);
		addSettings(notMoving, fromBundles);
	}

	@Override
	protected void onEnable() {
		tickCounter = 0;
	}

	@Override
	protected void onDisable() {
		tickCounter = 0;
	}

	@Override
	public void onTick(MinecraftClient client) {
		ClientPlayerEntity player = client.player;
		if (player == null || client.world == null || client.interactionManager == null) {
			return;
		}
		// Клик уходит по playerScreenHandler (syncId 0). Открытый чужой
		// контейнер этот syncId не примет — ждём закрытия. Свой инвентарь
		// не мешает: это тот же самый хендлер.
		if (player.currentScreenHandler != player.playerScreenHandler) {
			return;
		}
		// Предмет на курсоре — идёт ручная перекладка, не вмешиваемся.
		if (!player.playerScreenHandler.getCursorStack().isEmpty()) {
			return;
		}

		tickCounter++;

		// Срочно = хоть одна надетая вещь почти сломана. Тогда работаем
		// каждый тик и не ждём остановки.
		boolean urgent = false;
		for (EquipmentSlot slot : ARMOR_SLOTS) {
			if (isNearlyBroken(player.getEquippedStack(slot))) {
				urgent = true;
				break;
			}
		}

		if (!urgent) {
			if (tickCounter % 2 != 0) {
				return;
			}
			if (notMoving.get() && player.getVelocity().horizontalLengthSquared() > MOVING_SPEED_SQ) {
				return;
			}
		}

		// За тик надеваем максимум одну вещь: сервер не любит пачку
		// кликов по инвентарю в одном пакете-тике.
		for (EquipmentSlot slot : ARMOR_SLOTS) {
			if (equipBest(client, player, slot)) {
				return;
			}
		}
	}

	/**
	 * Найти и надеть лучшую вещь для слота.
	 *
	 * @return true — свап отправлен
	 */
	private boolean equipBest(MinecraftClient client, ClientPlayerEntity player, EquipmentSlot slot) {
		ItemStack current = player.getEquippedStack(slot);
		boolean urgent = isNearlyBroken(current);

		// Когда вещь почти сломана, сравниваем ОСТАТОК ПРОЧНОСТИ и даём
		// запас, чтобы не менять хлам на такой же хлам.
		double best = urgent ? durabilityLeft(current) + URGENT_BONUS : protectionScore(current);

		int bestSlot = -1;
		int bestBundleIndex = -1;

		PlayerInventory inv = player.getInventory();
		for (int i = 0; i <= 35; i++) {
			ItemStack stack = inv.getStack(i);

			if (fitsSlot(stack, slot)) {
				double value = urgent ? durabilityLeft(stack) : protectionScore(stack);
				if (value > best) {
					best = value;
					bestSlot = i;
					bestBundleIndex = -1;
				}
			}

			// Заглядываем внутрь мешков.
			if (!fromBundles.get()) {
				continue;
			}
			BundleContentsComponent bundle = stack.get(DataComponentTypes.BUNDLE_CONTENTS);
			if (bundle == null) {
				continue;
			}
			for (int b = 0; b < bundle.size(); b++) {
				ItemStack inner = bundle.get(b);
				if (!fitsSlot(inner, slot)) {
					continue;
				}
				double value = urgent ? durabilityLeft(inner) : protectionScore(inner);
				if (value > best) {
					best = value;
					bestSlot = i;
					bestBundleIndex = b;
				}
			}
		}

		if (bestSlot < 0) {
			return false;
		}

		// Пакет выбора предмета в мешке НЕ отправляем здесь: клик по
		// слоту теперь отложен на тик остановки, а этот пакет обязан
		// идти вплотную перед ним. Отправим оба вместе внутри swapWithArmor.
		if (bestBundleIndex >= 0 && player.networkHandler == null) {
			return false;
		}

		swapWithArmor(client, player, bestSlot, slot, bestBundleIndex);
		return true;
	}

	/**
	 * Обмен слота инвентаря со слотом брони одним пакетом.
	 *
	 * Кнопка в SlotActionType.SWAP — это индекс ХОТБАРА, поэтому для
	 * брони он не годится. Зато работает обратный вариант: кликаем по
	 * слоту брони (5–8) и указываем кнопкой слот-источник, если тот
	 * лежит в хотбаре. Для глубокого инвентаря такого пакета нет, и
	 * там остаётся честный PICKUP-обмен.
	 */
	private void swapWithArmor(MinecraftClient client, ClientPlayerEntity player,
			int inventoryIndex, EquipmentSlot slot, int bundleIndex) {
		int armorSlot = SwapUtil.armorScreenSlot(slot);
		if (armorSlot < 0) {
			return;
		}
		// Остановка на один тик (50 мс) вокруг клика — та же цена, что и
		// у остальных свап-модулей. Берётся и когда броня лежит в хотбаре
		// (атомарный SWAP ниже), и когда она в глубоком инвентаре: для
		// сервера обе картины должны выглядеть одинаково.
		//
		// Клики уходят СЛЕДУЮЩИМ тиком, когда серверу уже отправлен пакет
		// стоящего игрока. Всё тело свапа лежит в одной задаче: цепочку
		// PICKUP разрывать по тикам нельзя — предмет остался бы висеть на
		// курсоре.
		ru.neuclient.client.util.SwapPause.submit(() -> {
			if (!SwapUtil.canInteract(client, player)) {
				return;
			}
			// Достаём вещь из мешка: сервер сначала должен узнать, какой
			// именно предмет внутри выбран. Пакет обязан идти вплотную
			// перед кликом, поэтому лежит здесь же, в одной задаче.
			if (bundleIndex >= 0) {
				if (player.networkHandler == null) {
					return;
				}
				player.networkHandler.sendPacket(new BundleItemSelectedC2SPacket(
						SwapUtil.toScreenSlot(inventoryIndex), bundleIndex));
			}
			int syncId = player.playerScreenHandler.syncId;
			if (inventoryIndex < 9) {
				// Источник в хотбаре — атомарный SWAP одним пакетом.
				client.interactionManager.clickSlot(syncId, armorSlot, inventoryIndex,
						SlotActionType.SWAP, player);
				return;
			}
			// Источник в глубоком инвентаре: взять → надеть → убрать снятое.
			int screenSlot = SwapUtil.toScreenSlot(inventoryIndex);
			client.interactionManager.clickSlot(syncId, screenSlot, 0, SlotActionType.PICKUP, player);
			client.interactionManager.clickSlot(syncId, armorSlot, 0, SlotActionType.PICKUP, player);
			client.interactionManager.clickSlot(syncId, screenSlot, 0, SlotActionType.PICKUP, player);
		});
	}

	/** Подходит ли предмет в слот брони (по компоненту, а не по имени). */
	private boolean fitsSlot(ItemStack stack, EquipmentSlot slot) {
		if (stack.isEmpty()) {
			return false;
		}
		EquippableComponent equippable = stack.get(DataComponentTypes.EQUIPPABLE);
		if (equippable == null || equippable.slot() != slot) {
			return false;
		}
		// Элитра формально «нагрудник», но защиты не даёт — надевать её
		// вместо брони в бою нельзя.
		return !stack.isOf(Items.ELYTRA);
	}

	/** Осталось прочности (для неломающихся вещей — условно много). */
	private int durabilityLeft(ItemStack stack) {
		if (stack.isEmpty()) {
			return 0;
		}
		if (!stack.isDamageable()) {
			return Integer.MAX_VALUE / 2;
		}
		return stack.getMaxDamage() - stack.getDamage();
	}

	/** Надета ли почти сломанная вещь. */
	private boolean isNearlyBroken(ItemStack stack) {
		return !stack.isEmpty() && stack.isDamageable() && durabilityLeft(stack) < LOW_DURABILITY;
	}

	/**
	 * Оценка защиты: броня + прочность брони из атрибутов, плюс
	 * Protection. Считается по компонентам, поэтому работает и с
	 * кастомными серверными предметами.
	 */
	private double protectionScore(ItemStack stack) {
		if (stack.isEmpty()) {
			return 0.0;
		}
		double score = 0.0;

		AttributeModifiersComponent modifiers = stack.get(DataComponentTypes.ATTRIBUTE_MODIFIERS);
		if (modifiers != null) {
			for (AttributeModifiersComponent.Entry entry : modifiers.modifiers()) {
				if (entry.attribute() == EntityAttributes.ARMOR
						|| entry.attribute() == EntityAttributes.ARMOR_TOUGHNESS) {
					score += entry.modifier().value();
				}
			}
		}

		// Уровень Protection берём из компонента зачарований: реестр
		// зачарований для этого поднимать не нужно.
		var enchantments = stack.getEnchantments();
		for (var entry : enchantments.getEnchantmentEntries()) {
			if (entry.getKey().matchesKey(net.minecraft.enchantment.Enchantments.PROTECTION)) {
				score += entry.getIntValue();
			}
		}
		return score;
	}
}
