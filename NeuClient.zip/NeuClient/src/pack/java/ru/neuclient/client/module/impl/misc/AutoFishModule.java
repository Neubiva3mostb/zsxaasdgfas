package ru.neuclient.client.module.impl.misc;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.projectile.FishingBobberEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.NumberSetting;

/**
 * AutoFish — автоматическая рыбалка.
 * 
 * Механика: ждёт стабилизации поплавка в воде, затем отслеживает
 * погружение (velocityY < -0.07) и своевременно подсекает рыбу.
 * Исправлен спам забросами: добавлен кулдаун после каждого заброса.
 */
public final class AutoFishModule extends Module {

    private final NumberSetting recastDelay = new NumberSetting("Задержка заброса", 15.0, 5.0, 40.0, 1.0);

    private int ticksSinceCast = 0;
    private int ticksSinceRecast = 0;
    private boolean needsRecast = false;
    private boolean bobberStabilized = false;
    /** Кулдаун после заброса/подсечки, чтобы не было спама. */
    private int actionCooldown = 0;

    public AutoFishModule() {
        super("AutoFish", "Автоматически рыбачит", Category.MISC);
        addSettings(recastDelay);
    }

    @Override
    public void onTick(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (player == null || client.interactionManager == null) return;

        // Глобальный кулдаун после действий
        if (actionCooldown > 0) {
            actionCooldown--;
        }

        if (!isHoldingFishingRod(player)) {
            reset();
            return;
        }

        FishingBobberEntity bobber = player.fishHook;

        if (bobber != null) {
            ticksSinceCast++;

            if (ticksSinceCast >= 15 && bobber.isTouchingWater()) {
                bobberStabilized = true;
            }

            if (bobberStabilized && actionCooldown <= 0) {
                double velY = bobber.getVelocity().y;
                if (velY < -0.07) {
                    // Подсечка
                    client.interactionManager.interactItem(player, Hand.MAIN_HAND);
                    needsRecast = true;
                    ticksSinceRecast = 0;
                    bobberStabilized = false;
                    ticksSinceCast = 0;
                    actionCooldown = 10; // Кулдаун после подсечки
                }
            }
        } else if (needsRecast) {
            ticksSinceRecast++;
            if (ticksSinceRecast >= recastDelay.get().intValue() && actionCooldown <= 0) {
                client.interactionManager.interactItem(player, Hand.MAIN_HAND);
                actionCooldown = 10; // Кулдаун после заброса
                reset();
            }
        } else if (actionCooldown <= 0) {
            // Начальный заброс — только если нет кулдауна
            client.interactionManager.interactItem(player, Hand.MAIN_HAND);
            ticksSinceCast = 0;
            bobberStabilized = false;
            actionCooldown = 10; // Кулдаун после заброса
        }
    }

    private boolean isHoldingFishingRod(ClientPlayerEntity player) {
        return player.getMainHandStack().getItem() == Items.FISHING_ROD;
    }

    private void reset() {
        ticksSinceCast = 0;
        ticksSinceRecast = 0;
        needsRecast = false;
        bobberStabilized = false;
    }

    @Override
    protected void onEnable() {
        reset();
        actionCooldown = 0;
    }

    @Override
    protected void onDisable() {
        reset();
        actionCooldown = 0;
    }
}
