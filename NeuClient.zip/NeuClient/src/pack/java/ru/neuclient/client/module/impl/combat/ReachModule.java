package ru.neuclient.client.module.impl.combat;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.util.Identifier;
import ru.neuclient.client.NeuClient;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.NumberSetting;

/**
 * Reach — увеличенная дистанция атаки по игрокам.
 *
 * Дистанция в Minecraft 1.21 берётся не из константы, а из атрибута
 * {@code EntityAttributes.ENTITY_INTERACTION_RANGE} (база 3.0 у игрока).
 * Клиент наводит курсор и проверяет возможность взаимодействия именно по нему:
 * PlayerEntity.getEntityInteractionRange() -> getAttributeValue(...).
 * Модуль вешает на этот атрибут временный модификатор ADD_VALUE.
 *
 * Работает только на сущностей: дистанция добычи блоков
 * (BLOCK_INTERACTION_RANGE) не трогается.
 *
 * ВАЖНО. Атрибут меняется ТОЛЬКО на клиенте — сервер о нём не знает и
 * проверяет удары по своей дистанции. Поэтому на сервере с античитом удар
 * дальше ванильных 3 блоков будет отменён (игрок «оттянется» назад). Модуль
 * честнее всего ведёт себя на серверах без проверки дистанции.
 *
 * Модификатор временный (addTemporaryModifier), поэтому в атрибуты игрока
 * он не сохраняется и снимается при выключении.
 */
public class ReachModule extends Module {

	private static final Identifier MODIFIER_ID = Identifier.of("perfstream", "reach");

	private final NumberSetting distance = new NumberSetting("Дистанция", 3.5, 3.0, 6.0, 0.1);

	/** Последнее применённое значение — чтобы не пересоздавать модификатор зря. */
	private double applied = Double.NaN;

	public ReachModule() {
		super("Reach", "Бьёт игроков дальше", Category.COMBAT);
		addSettings(distance);
	}

	@Override
	public void onEnable() {
		applied = Double.NaN;
	}

	@Override
	public void onDisable() {
		removeModifier();
		applied = Double.NaN;
	}

	@Override
	public void onTick(MinecraftClient client) {
		apply(client.player);
	}

	private void apply(ClientPlayerEntity player) {
		try {
			if (player == null || !isEnabled()) {
				return;
			}
			EntityAttributeInstance instance = player.getAttributeInstance(EntityAttributes.ENTITY_INTERACTION_RANGE);
			if (instance == null) {
				return;
			}
			double wanted = distance.get();
			if (applied == wanted && instance.getModifier(MODIFIER_ID) != null) {
				return; // уже стоит то, что нужно
			}
			instance.removeModifier(MODIFIER_ID);
			if (wanted > 0.0) {
				instance.addTemporaryModifier(new EntityAttributeModifier(
						MODIFIER_ID, wanted - 3.0, EntityAttributeModifier.Operation.ADD_VALUE));
			}
			applied = wanted;
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка Reach", t);
		}
	}

	/** Снять модификатор, если он стоит. */
	private void removeModifier() {
		try {
			ClientPlayerEntity player = MinecraftClient.getInstance().player;
			if (player == null) {
				return;
			}
			EntityAttributeInstance instance = player.getAttributeInstance(EntityAttributes.ENTITY_INTERACTION_RANGE);
			if (instance != null) {
				instance.removeModifier(MODIFIER_ID);
			}
		} catch (Throwable t) {
			NeuClient.LOGGER.error("[NeuClient] Ошибка Reach (снятие)", t);
		}
	}
}
