package ru.neuclient.client.module.impl.combat;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;
import ru.neuclient.client.setting.BooleanSetting;
import ru.neuclient.client.setting.NumberSetting;
import ru.neuclient.client.util.SwapUtil;

/**
 * AutoTotem — тотем в левую руку при падении здоровья ниже порога.
 *
 * КАК БЕРЁТСЯ ТОТЕМ.
 * Одним пакетом SlotActionType.SWAP с кнопкой 40. Это ровно то, что
 * делает ваниль по клавише F: слот-источник меняется местами с оффхендом
 * атомарно, на сервере. Прежняя схема из трёх кликов PICKUP (взять →
 * положить → вернуть) была ненадёжной: она держит предмет «на курсоре»
 * между кликами, и если сервер отклонял или переупорядочивал хотя бы
 * один клик, тотем оставался висеть на курсоре и терялся, а из глубокого
 * инвентаря (слоты 9–35) свап не проходил вовсе.
 *
 * ПОЧЕМУ КЛИК УХОДИТ СРАЗУ, БЕЗ ОЖИДАНИЯ ОСТАНОВКИ.
 * Прежний SwapFreeze откладывал операцию до полной остановки игрока —
 * до 20 тиков ожидания. Для брони это терпимо, для тотема смертельно:
 * секунда задержки на низком ХП = смерть. Теперь вместо ожидания
 * запрашивается SwapPause — движение гаснет ровно на один пакет
 * вокруг клика, и тотем встаёт в руку в том же тике.
 */
public final class AutoTotemModule extends Module {

	// ===== Настройки =====
	private final NumberSetting hp = new NumberSetting("ХП", 6.0, 0.5, 20.0, 0.5);

	/** Вернуть в оффхенд то, что там лежало, когда здоровье восстановится. */
	private final BooleanSetting returnItem = new BooleanSetting("Возвращать предмет", true);

	/** Сначала искать тотемы без зачарования (зачарованные приберечь). */
	private final BooleanSetting plainFirst = new BooleanSetting("Сначала обычные тотемы", true);

	/** Не дёргать оффхенд, пока игрок ест. */
	private final BooleanSetting notWhileEating = new BooleanSetting("Не во время еды", false);

	/**
	 * Умное перемещение: не прерывать доедание голдапла, если урона
	 * за оставшиеся тики точно не хватит, чтобы убить.
	 */
	private final BooleanSetting smartMove = new BooleanSetting("Умное перемещение", true);

	/** Пауза между свапами, чтобы не спамить пакетами при дрожании ХП. */
	private static final long SWAP_COOLDOWN_MS = 400L;

	/** Кнопка оффхенда в SlotActionType.SWAP (ванильная клавиша F). */
	private static final int OFFHAND_SWAP_BUTTON = 40;

	/** История здоровья за последние 20 тиков: [0] — текущий тик. */
	private final float[] healthHistory = new float[20];

	/** Слот, из которого взят тотем, — куда возвращать вытесненный предмет. */
	private int returnSlot = -1;

	private long lastSwap;

	public AutoTotemModule() {
		super("AutoTotem", "Берет тотем в левую руку при низком ХП", Category.COMBAT);
		addSettings(hp, returnItem, plainFirst, notWhileEating, smartMove);
	}

	@Override
	protected void onEnable() {
		returnSlot = -1;
		lastSwap = 0L;
	}

	@Override
	protected void onDisable() {
		returnSlot = -1;
		lastSwap = 0L;
	}

	@Override
	public void onTick(MinecraftClient client) {
		ClientPlayerEntity player = client.player;
		if (player == null || client.world == null || client.interactionManager == null) {
			return;
		}
		// Кликаем по playerScreenHandler (syncId 0). Если открыт чужой
		// контейнер (сундук, печка), сервер этот syncId не примет —
		// ждём закрытия. Свой инвентарь открытым быть может: у него тот
		// же самый хендлер.
		if (player.currentScreenHandler != player.playerScreenHandler) {
			return;
		}

		// Скользящее окно здоровья для предсказания урона.
		System.arraycopy(healthHistory, 0, healthHistory, 1, healthHistory.length - 1);
		healthHistory[0] = player.getHealth() + player.getAbsorptionAmount();

		if (notWhileEating.get() && isConsuming(player)) {
			return;
		}

		Boolean shouldEquip = shouldEquip(player);
		if (shouldEquip == null) {
			// Мёртвая зона гистерезиса: состояние не меняем.
			return;
		}

		if (shouldEquip) {
			if (System.currentTimeMillis() - lastSwap < SWAP_COOLDOWN_MS) {
				return;
			}
			if (equipTotem(client, player)) {
				lastSwap = System.currentTimeMillis();
			}
		} else {
			restoreOffhand(client, player);
		}
	}

	/**
	 * Нужен ли тотем в руке прямо сейчас.
	 *
	 * @return TRUE — надеть, FALSE — можно вернуть предмет обратно,
	 *         null — ничего не менять (гистерезис или доедание).
	 */
	private Boolean shouldEquip(ClientPlayerEntity player) {
		// Тотем на кулдауне (только что сработал) — свапать бессмысленно.
		if (player.getItemCooldownManager().isCoolingDown(Items.TOTEM_OF_UNDYING.getDefaultStack())) {
			return Boolean.FALSE;
		}

		// Умное перемещение: не сбивать длинное поедание почём зря.
		if (smartMove.get() && isConsuming(player)) {
			ItemStack active = player.getActiveItem();
			if (active.getItem().getMaxUseTime(active, player) > 5) {
				int ticksLeft = player.getItemUseTimeLeft();
				// Доедание почти закончено — дотерпим.
				if (ticksLeft < 10) {
					return null;
				}
				// Прогноз: урон за оставшиеся тики по текущему темпу.
				// Если он не съедает всё ХП — тоже дотерпим.
				float dpsPerTick = (healthHistory[healthHistory.length - 1] - healthHistory[0])
						/ healthHistory.length;
				if (ticksLeft < 30 && dpsPerTick * ticksLeft < healthHistory[0]) {
					return null;
				}
			}
		}

		float threshold = hp.get().floatValue();
		if (healthHistory[0] <= threshold) {
			return Boolean.TRUE;
		}
		// Гистерезис 0.5 ХП: между порогом и порогом+0.5 состояние
		// сохраняется, иначе на границе тотем дёргался бы каждый тик.
		return healthHistory[0] >= threshold + 0.5f ? Boolean.FALSE : null;
	}

	/** Найти тотем и закинуть его в оффхенд. */
	private boolean equipTotem(MinecraftClient client, ClientPlayerEntity player) {
		ItemStack offhand = player.getOffHandStack();
		boolean preferPlain = plainFirst.get();

		// Тотем уже в руке: менять нечего. Исключение — стоит опция
		// «сначала обычные», а в руке зачарованный: его меняем на простой.
		if (isTotem(offhand) && (!preferPlain || !offhand.hasGlint())) {
			return false;
		}

		int slot = preferPlain ? findTotem(player, true) : -1;
		if (slot == -1 && !isTotem(offhand)) {
			slot = findTotem(player, false);
		}
		if (slot == -1) {
			return false;
		}

		// Запоминаем, куда вернуть вытесненный предмет (щит и т.п.).
		// Если оффхенд был пуст, возвращать нечего.
		if (returnItem.get() && returnSlot == -1 && !offhand.isEmpty()) {
			returnSlot = slot;
		}

		swapWithOffhand(client, player, slot);
		return true;
	}

	/** Здоровье восстановилось — вернуть в оффхенд то, что там было. */
	private void restoreOffhand(MinecraftClient client, ClientPlayerEntity player) {
		if (!returnItem.get() || returnSlot == -1) {
			returnSlot = -1;
			return;
		}
		ItemStack offhand = player.getOffHandStack();
		// Возвращаем, только если в руке всё ещё наш тотем (или пусто).
		// Если игрок сам положил туда что-то другое — не трогаем.
		if (offhand.isEmpty() || isTotem(offhand)) {
			swapWithOffhand(client, player, returnSlot);
		}
		returnSlot = -1;
	}

	/**
	 * Обмен слота инвентаря с оффхендом одним пакетом.
	 *
	 * @param inventoryIndex индекс в PlayerInventory (0–35)
	 */
	private void swapWithOffhand(MinecraftClient client, ClientPlayerEntity player, int inventoryIndex) {
		if (inventoryIndex < 0 || inventoryIndex > 35) {
			return;
		}
		// Клик ставится в очередь остановки и уйдёт СЛЕДУЮЩИМ тиком —
		// сразу после пакета стоящего игрока со снятым спринтом. Тотем
		// приходит на 50 мс позже, зато сервер видит человеческую
		// последовательность, а не клик по слоту на полном бегу.
		ru.neuclient.client.util.SwapPause.submit(() -> {
			if (!SwapUtil.canInteract(client, player)) {
				return;
			}
			client.interactionManager.clickSlot(
					player.playerScreenHandler.syncId,
					SwapUtil.toScreenSlot(inventoryIndex),
					OFFHAND_SWAP_BUTTON,
					SlotActionType.SWAP,
					player);
		});
	}

	/**
	 * Поиск тотема ВО ВСЁМ инвентаре: хотбар 0–8 и основная сетка 9–35.
	 *
	 * @param plainOnly брать только незачарованные
	 * @return индекс инвентаря или -1
	 */
	private int findTotem(ClientPlayerEntity player, boolean plainOnly) {
		PlayerInventory inv = player.getInventory();
		for (int i = 0; i <= 35; i++) {
			ItemStack stack = inv.getStack(i);
			if (isTotem(stack) && (!plainOnly || !stack.hasGlint())) {
				return i;
			}
		}
		return -1;
	}

	private boolean isTotem(ItemStack stack) {
		return !stack.isEmpty() && stack.isOf(Items.TOTEM_OF_UNDYING);
	}

	/** Игрок ест/пьёт (а не тянет лук и не держит щит). */
	private boolean isConsuming(ClientPlayerEntity player) {
		if (!player.isUsingItem()) {
			return false;
		}
		ItemStack active = player.getActiveItem();
		return !active.isEmpty() && active.get(DataComponentTypes.CONSUMABLE) != null;
	}
}
