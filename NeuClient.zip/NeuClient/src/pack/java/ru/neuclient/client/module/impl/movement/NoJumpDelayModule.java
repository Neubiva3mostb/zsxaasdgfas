package ru.neuclient.client.module.impl.movement;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import ru.neuclient.client.mixin.LivingEntityAccessor;
import ru.neuclient.client.module.Category;
import ru.neuclient.client.module.Module;

/**
 * NoJumpDelay — убирает ванильную задержку между прыжками.
 *
 * Ваниль после каждого прыжка выставляет LivingEntity#jumpingCooldown = 10
 * (полсекунды ждать следующего прыжка при зажатом пробеле). Мы каждый
 * клиентский тик обнуляем этот кулдаун у локального игрока — прыжок
 * срабатывает сразу при касании земли. Единственный не-«легитный» модуль
 * из связки (механику не эмулирует, а подправляет таймер).
 */
public class NoJumpDelayModule extends Module {

	public NoJumpDelayModule() {
		super("NoJumpDelay", "Прыжки без задержки", Category.MOVEMENT);
	}

	@Override
	public void onTick(MinecraftClient client) {
		ClientPlayerEntity player = client.player;
		if (player != null) {
			((LivingEntityAccessor) player).pc$setJumpingCooldown(0);
		}
	}
}
